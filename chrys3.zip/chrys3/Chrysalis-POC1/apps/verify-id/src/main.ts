import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { VerifyIdModule } from './app/verify-id.module';
import { environment } from './environments/environment';

if (environment.production) {
    try {
        enableProdMode();
    } catch (err) {
        console.log('Production mode already enabled in container app');
    }
}

platformBrowserDynamic()
    .bootstrapModule(VerifyIdModule, { ngZoneEventCoalescing: true })
    .catch((err) => console.error(err));
