import { ChangeDetectionStrategy, ChangeDetectorRef, Component, NgZone, ViewEncapsulation } from '@angular/core';

import { HRBBaseComponent, HRBStateManagerService, mobileQuery, desktopQuery } from '@chrysalis/core';
import { IHRBInterstitial } from '@chrysalis/ui-controls';

import { appName } from './constants/hrb-app.constants';

/** Verify ID root component */
@Component({
    selector: 'hrb-chrysalis-root',
    templateUrl: './verify-id.component.html',
    styleUrls: ['./verify-id.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    encapsulation: ViewEncapsulation.ShadowDom
})
export class VerifyIdComponent extends HRBBaseComponent {
    /** Mobile query */
    public mobileQuery = mobileQuery;
    /** Desktop query */
    public desktopQuery = desktopQuery;
    /** Is mobile/tablet/desktop */
    public content: IHRBInterstitial;

    private screenName = 'welcome';
    private user = 'Ann';
    /**
     * Constructor function
     */
    constructor(private stateManager: HRBStateManagerService,
        cdr: ChangeDetectorRef,
        ngZone: NgZone) {
        super(cdr, ngZone);
    }

    /** Subscribe to global state  */
    protected init(): void {
        this.addSafeSubscriber(this.stateManager.onContentUpdated, (data) => {
            const callback = () => {
                const content: Partial<IHRBInterstitial> = {
                    headerText: data[appName][this.screenName].content.text.replace('{{user}}', this.user),
                    theme: data[appName][this.screenName].content.theme,
                    contentImageUrl: data[appName][this.screenName].content.imgUrl,
                };
                this.content = { ...{}, ...content };
            };
            this.render(callback);
        });
    }
    /** Dummy destroy */
    protected destroy(): void {
    }
}
