import { TestBed } from '@angular/core/testing';
import { VerifyIdComponent } from './verify-id.component';

describe('VerifyIdComponent', () => {
    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [VerifyIdComponent]
        }).compileComponents();
    });

    it('should create the app', () => {
        const fixture = TestBed.createComponent(VerifyIdComponent);
        const app = fixture.componentInstance;
        expect(app).toBeTruthy();
    });

});
