/** App name */
export const appName = 'onboarding';
