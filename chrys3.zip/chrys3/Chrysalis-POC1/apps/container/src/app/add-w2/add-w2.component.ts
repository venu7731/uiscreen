import { ChangeDetectionStrategy, ChangeDetectorRef, Component, NgZone } from '@angular/core';

import { HRBBaseComponent, HRBMicroUIAppManager } from '@chrysalis/core';

import { microApps } from '../micro/config';

/**
 * Home root route
 */
@Component({
  selector: 'hrb-add-w2-root',
  templateUrl: './add-w2.component.html',
  styleUrls: ['./add-w2.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBAddW2Component extends HRBBaseComponent {
  /** App loading done */
  public isLoaded = false;
  /**
   * Constructor method
   * @param cdr Change detector reference
   */
  constructor(cdr: ChangeDetectorRef,
    ngZone: NgZone) {
    super(cdr, ngZone);
  }

  /** Load micro UIs */
  protected init(): void {
    const appManager = new HRBMicroUIAppManager(microApps['hrb-add-w2']);
    const callback = () => {
      this.isLoaded = true;
    };
    appManager.staticLoad().then(() => {
      this.render(callback);
    }).catch();
  }
  /** Dummy destroy */
  protected destroy(): void { }

}
