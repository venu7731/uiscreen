import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBAddW2Component } from './add-w2.component';

describe('HRBAddW2Component', () => {
  let component: HRBAddW2Component;
  let fixture: ComponentFixture<HRBAddW2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBAddW2Component]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBAddW2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
