import { BrowserModule } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { defineCustomElements } from '@bds/bds-core/loader';
import { BdsNgModule } from '@bds/bds-ng';
import { UiControlsModule } from '@chrysalis/ui-controls';

import { ContainerComponent } from './container.component';
import { routes } from './routing/routes';
import { HRBHomeComponent } from './home/home.component';
import { HRBVerifyIdComponent } from './verify-id/verify-id.component';
import { HRBAddW2Component } from './add-w2/add-w2.component';
import { HRBOnboardingComponent } from './onboarding/onboarding.component';
import { HRBPopupComponent } from './popup/hrb-popup.component';

@NgModule({
    declarations: [ContainerComponent, HRBHomeComponent, HRBVerifyIdComponent, HRBAddW2Component,
        HRBOnboardingComponent, HRBPopupComponent],
    imports: [BrowserModule, BdsNgModule, RouterModule.forRoot(routes, { useHash: true }), UiControlsModule],
    providers: [],
    bootstrap: [ContainerComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ContainerModule {
    constructor() {
        defineCustomElements(window);
    }
}
