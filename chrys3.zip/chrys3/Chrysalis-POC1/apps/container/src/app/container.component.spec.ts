import { RouterModule } from '@angular/router';
import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { APP_BASE_HREF } from '@angular/common';

import { HRBContentManagerService, HRBHttpProxyService } from '@chrysalis/core';

import { ContainerComponent } from './container.component';
import { routes } from './routing/routes';

class MockHttpClass {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    public get(url: string, options?: object, body?: object): Observable<{}> {
        return of(null);
    }
}
describe('ContainerComponent', () => {
    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [ContainerComponent],
            providers: [
                HRBContentManagerService,
                { provide: HRBHttpProxyService, useClass: MockHttpClass }, HttpClient,
                { provide: APP_BASE_HREF, useValue: '/' }
            ],
            imports: [HttpClientTestingModule, RouterModule.forRoot(routes)]
        }).compileComponents();
    });

    it('should create the app', () => {
        const fixture = TestBed.createComponent(ContainerComponent);
        const app = fixture.componentInstance;
        expect(app).toBeTruthy();
    });

});
