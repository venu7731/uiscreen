import { ChangeDetectionStrategy, ChangeDetectorRef, Component, NgZone } from '@angular/core';

import { HRBBaseComponent, HRBMicroUIAppManager } from '@chrysalis/core';

import { microApps } from '../micro/config';

/**
 * Home root route
 */
@Component({
  selector: 'hrb-home-root',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBHomeComponent extends HRBBaseComponent {
  /** App loading done */
  public isLoaded = false;
  /**
   * Constructor method
   * @param cdr Change detector reference
   */
  constructor(cdr: ChangeDetectorRef,
    ngZone: NgZone) {
    super(cdr, ngZone);
  }

  /** Load micro UIs */
  protected init(): void {
    const appManager = new HRBMicroUIAppManager(microApps['hrb-home']);
    const callback = () => {
      this.isLoaded = true;
    };
    appManager.staticLoad().then(() => {
      this.render(callback);
    }).catch();
  }
  /** Dummy destroy */
  protected destroy(): void { }

}
