import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBOnboardingComponent } from './onboarding.component';

describe('HRBOnboardingComponent', () => {
  let component: HRBOnboardingComponent;
  let fixture: ComponentFixture<HRBOnboardingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBOnboardingComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBOnboardingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
