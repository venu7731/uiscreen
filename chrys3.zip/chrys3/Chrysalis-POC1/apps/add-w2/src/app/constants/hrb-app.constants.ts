/** App name */
export const appName = 'add-w2';
/** Form name */
export const formName = 'AO_TXW2';
/** Device types */
export const Devices = {
    Desktop: 'desktop',
    Mobile: 'mobile'
};
