import { BrowserModule } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, Injector, NgModule } from '@angular/core';
import { createCustomElement } from '@angular/elements';
import { BdsNgModule } from '@bds/bds-ng';

import { UiControlsModule } from '@chrysalis/ui-controls';

import { ManualEntryComponent } from './manual-entry-w2.component';

@NgModule({
    declarations: [ManualEntryComponent],
    imports: [BrowserModule, BdsNgModule, UiControlsModule],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AddW2Module {
    constructor(private injector: Injector) { }

    /** Hook for manual bootstrapping of the application */
    public ngDoBootstrap() {

        /** Convert Angular component into a custom element */
        const appElement = createCustomElement(ManualEntryComponent, { injector: this.injector });

        /** Define custom element tag */
        const customElementTag = 'hrb-add-w2';

        /** Verify if custom element is already present in the customElementRegistry */
        if (!customElements.get(customElementTag)) {
            /** Define a new custom element */
            customElements.define(customElementTag, appElement);
        }
    }
}