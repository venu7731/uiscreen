const { compilerOptions } = require('../../tsconfig.base.json');
const { each } = require('lodash');

const moduleNameMapper = each(compilerOptions.paths, (path, idx, item) => {
    item[idx] = `<rootDir>/../../${item[idx]}`;
});
moduleNameMapper['^lodash-es$'] = 'lodash';

module.exports = {
    displayName: 'home',
    preset: '../../jest.preset.js',
    setupFilesAfterEnv: ['<rootDir>/src/test-setup.ts'],
    globals: {
        'ts-jest': {
            tsConfig: '<rootDir>/tsconfig.spec.json',
            stringifyContentPathRegex: '\\.(html|svg)$',
            astTransformers: {
                before: [
                    'jest-preset-angular/build/InlineFilesTransformer',
                    'jest-preset-angular/build/StripStylesTransformer'
                ]
            }
        }
    },
    coverageDirectory: '../../coverage/apps/home',
    snapshotSerializers: [
        'jest-preset-angular/build/AngularNoNgAttributesSnapshotSerializer.js',
        'jest-preset-angular/build/AngularSnapshotSerializer.js',
        'jest-preset-angular/build/HTMLCommentSerializer.js'
    ],
    collectCoverage: true,
    reporters: [
        'default',
        [
            'jest-junit',
            {
                outputDirectory: 'coverage/apps/',
                outputName: 'TESTS-home.xml'
            }
        ]
    ],
    coverageReporters: ['lcov', 'cobertura'],
    moduleNameMapper,
    transformIgnorePatterns: ['^.+\\.js$']
};
