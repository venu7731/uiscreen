import { IHRBNavBarContent, IHRBProgressContent, IHRBButtonContent } from '@chrysalis/ui-controls';

import { IHRBPrimaryCardContent } from './primary-card/primary-card.interface';
import { IHRBSecondaryCardContent } from './secondary-card/secondary-card.interface';
import { IHRBTotalRefund } from './total-fund/total-fund.interface';

/** Home content */
export interface IHRBHomeContent {
    /** Header menu content */
    headerMenuContent: IHRBHeaderMenuContent;
    /** Refund content */
    refundContent: IHRBTotalRefund;
    /** Primary card content */
    primaryCardContent: IHRBPrimaryCardContent;
    /** Secondary card content */
    secondaryCardContent: IHRBSecondaryCardContent[];
    /** Popup menu button list */
    buttonList: IHRBButtonContent[];
}

/** Header menu content */
export interface IHRBHeaderMenuContent {
    /** Progress content */
    progressContent: IHRBProgressContent,
    /** Header content */
    headerContent: IHRBNavBarContent[];
    /** Accounct nav content */
    accountContent: IHRBNavBarContent[];
    /** Refund content */
    refundContent: IHRBTotalRefund;
}
