import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';

import { HRBBaseComponent } from '@chrysalis/core';

import { IHRBSecondaryCardContent } from './secondary-card.interface';

/**
 * Secondary card component
 */
@Component({
  selector: 'hrb-secondary-card',
  templateUrl: './secondary-card.component.html',
  styleUrls: ['./secondary-card.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBSecondaryCardComponent extends HRBBaseComponent {

  /** Secondary card content */
  @Input() public cardContent: IHRBSecondaryCardContent;
  /** Card clicked event */
  @Output() public cardClicked = new EventEmitter<string>();

  /** Emit card state */
  public emitClickEvent(state: string) {
    this.cardClicked.emit(state);
  }
  /** Dummy init */
  protected init(): void {
  }
  /** Dummy destroy */
  protected destroy(): void {
  }

}
