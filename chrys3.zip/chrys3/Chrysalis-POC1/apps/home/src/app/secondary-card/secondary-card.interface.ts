import { IHRBPrimaryCardContent } from '../primary-card/primary-card.interface';

/** Secondary card content */
export type IHRBSecondaryCardContent = IHRBPrimaryCardContent;