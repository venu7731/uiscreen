/** Total refund content */
export interface IHRBTotalRefund {
    /** Total refund Text */
    text: string;
    /** Total refund description */
    description: string;
    /** Total refund total Amount */
    totalAmount: number;
    /** Total refund theme */
    theme: string;
}
