import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

import { desktopQuery, HRBBaseComponent, mobileQuery } from '@chrysalis/core';

import { IHRBHeaderMenuContent } from '../home.interface';

/**
 * Home Header component
 */
@Component({
  selector: 'hrb-header-menu',
  templateUrl: './header-menu.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./header-menu.component.scss']
})
export class HeaderMenuComponent extends HRBBaseComponent {

  /** Content */
  @Input() public content: IHRBHeaderMenuContent;
  /** Desktop media query */
  public desktopQuery = desktopQuery;
  /** Mobile media query */
  public mobileQuery = mobileQuery;

  /** Dummy init */
  protected init(): void {
    this.content.headerContent[0].isSelected = true;
  }
  /** Dummy destroy */
  protected destroy(): void {
  }
}
