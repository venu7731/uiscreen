import { ChangeDetectionStrategy, ChangeDetectorRef, Component, NgZone } from '@angular/core';
import { cloneDeep } from 'lodash-es';

import { mobileQuery, desktopQuery, HRBBaseComponent, HRBStateManagerService, HRBOverlayService, CustomEvents } from '@chrysalis/core';

import { IHRBHomeContent } from './home.interface';
import { appName } from './constants/hrb-app.constants';

/** Home root component */
@Component({
    selector: 'hrb-chrysalis-root',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class HomeComponent extends HRBBaseComponent {

    /** Mobile query */
    public mobileQuery = mobileQuery;
    /** Desktop query */
    public desktopQuery = desktopQuery;
    /** Content */
    public content: IHRBHomeContent;
    /** Is mobile? */
    public isMobile: boolean;

    private screenName = 'home';
    private state = 'confirm-status';
    private secondary_state = 'draft';
    private refundAmount = 0;
    private overlayButtonActionMap = new Map([
        [3, this.openManualW2Entry.bind(this)]
    ]);
    private route: string;
    /**
     * Constructor
     * @param cdr Change detector reference
     * @param ngZone NgZone
     * @param stateManager State manager service
     */
    constructor(
        cdr: ChangeDetectorRef, ngZone: NgZone,
        private stateManager: HRBStateManagerService,
        private overlayManager: HRBOverlayService) {
        super(cdr, ngZone);
    }
    /** Handle route change */
    public handleNavigation(route: string) {
        this.route = route;
        if (this.route === 'add-w2') {
            this.overlayManager.updateOverlayStatus(true);
        }
    }
    /** Handle overlay Click */
    public handleOverlayButton(idx: number) {
        this.overlayButtonActionMap.get(idx)();
    }
    /** Get content data and pass it to child components */
    protected init(): void {
        this.addSafeSubscriber(this.stateManager.onContentUpdated, (data) => {
            const callback = () => {
                // TO DO add disabled state for Filing status
                data[appName][this.screenName].total_refund.totalAmount = this.refundAmount;
                const content: IHRBHomeContent = {
                    headerMenuContent: {
                        accountContent: data[appName][this.screenName].navbar_account.options,
                        headerContent: data[appName][this.screenName].navbar_header.options,
                        progressContent: data[appName][this.screenName].progress_circle,
                        refundContent: data[appName][this.screenName].total_refund
                    },
                    primaryCardContent: data[appName][this.screenName][`primary_card-${this.state}`],
                    refundContent: data[appName][this.screenName].total_refund,
                    secondaryCardContent: data[appName][this.screenName][`secondary_card-${this.secondary_state}`].options,
                    buttonList: data[appName][this.screenName].add_w2_overlay.options
                };
                this.content = cloneDeep(content);
            };
            this.render(callback);
        });
        this.addSafeSubscriber(this.stateManager.onDeviceUpdated, (data) => {
            const callback = () => {
                this.isMobile = data;
            };
            this.render(callback);
        });
    }
    /** Dummy destroy */
    protected destroy(): void {
    }

    private openManualW2Entry() {
        const event = new CustomEvent(CustomEvents.RouteChange, { detail: { route: [this.route] } });
        document.dispatchEvent(event);
    }
}
