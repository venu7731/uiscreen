const { readdirSync } = require('fs');
const cli = require('@nrwl/cli/lib/init-local.js').initLocal;

const getDirectories = (source) => {
    return readdirSync(source, { withFileTypes: true })
        .filter((dirent) => dirent.isDirectory())
        .map((dirent) => dirent.name);
};

const excludeList = ['container', 'container-e2e', 'local-server'];
const microapps = getDirectories('./apps').filter(
    (app) => !excludeList.includes(app)
);
process.argv[2] = 'build';
for (const app of microapps) {
    process.argv[3] = app;
    cli({ type: 'angular', dir: __dirname.replace(/\/*\\*tools/g, '') });
}
