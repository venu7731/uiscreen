const documentationCli = require('@compodoc/compodoc/dist/index-cli');
const _ = require('lodash');

const approvedApps = ['container', 'verify-id', 'home', 'add-w2', 'onboarding'];
const approvedLibs = ['ui-controls', 'core'];
const passedName = process.argv[2];
if (
    !approvedApps.includes(_.toLower(passedName)) &&
    !approvedLibs.includes(_.toLower(passedName))
) {
    console.log(
        '\x1b[31m%s\x1b[0m',
        `Invalid target ${process.argv[2]} provided for documentation`
    );
    console.log(
        '\x1b[33m%s\x1b[0m',
        `Valid options are 
        
        ${approvedApps}
        ${approvedLibs}
        `
    );
    process.exit(1);
}

if (approvedApps.includes(_.toLower(passedName))) {
    process.argv[3] = `./apps/${passedName}/.compodocrc.json`;
} else {
    process.argv[3] = `./libs/${passedName}/.compodocrc.json`;
}
process.argv[2] = '-c';

const cli = new documentationCli.CliApplication();
cli.start();
