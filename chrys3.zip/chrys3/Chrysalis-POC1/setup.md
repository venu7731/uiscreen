-- Global Installs
1.npm i -g nx 

-- Local
1.Npm install
2.run nx build core
3.run nx build home
4.run application - npm run dev
 
