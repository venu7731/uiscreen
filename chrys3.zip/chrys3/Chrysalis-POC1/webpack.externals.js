module.exports = {
    externals: {
        '@angular/core': 'ng.core',
        '@angular/common': 'ng.common',
        '@angular/common/http': 'ng.common.http',
        '@angular/elements': 'ng.elements',
        '@angular/forms': 'ng.forms',
        '@angular/platform-browser': 'ng.platformBrowser',
        '@hrblock-ocap/logger': 'hrb.logger',
        '@hrblock-ocap/ui-utility': 'hrb.uiUtility',
        '@microsoft/applicationinsights-web': 'Microsoft.ApplicationInsights',
        'lodash-es': '_',
        rxjs: 'rxjs',
        'rxjs/operators': 'rxjs.operators',
        '@chrysalis/core': 'hrb.core'
    }
};
