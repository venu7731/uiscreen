/**
 * HTTP Request Methods
 */
export enum RequestMethod {
    Get,
    Post,
    Put,
    Delete,
    Options,
    Head,
    Patch
}
