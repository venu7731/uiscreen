/**
 * Tax Group state for individual group types like 'FEDERAL', '${STATENAME}'
 */
export interface IHRBTaxGroupTypeState {
    /**
     * Form name of the tax return
     */
    returnFormName: string;
    /**
     * Form Enum ID of the tax return
     */
    returnFormEnumId: number;
    /**
     * Tax group of the tax return (FEDERAL or any other state name)
     */
    taxGroup: string;
}
