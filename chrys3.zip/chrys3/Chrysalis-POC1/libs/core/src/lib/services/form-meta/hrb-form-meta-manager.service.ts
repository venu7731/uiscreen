import { Injectable } from '@angular/core';
import { each } from 'lodash-es';

import { IHRBFormMeta } from './hrb-form.interfaces';
import { HRBBaseService } from '../../base-classes';
import { HRBHttpProxyService } from '../http/hrb-http-proxy.service';
import { formatData } from './hrb-form.helpers';

/**
 * Platform level Service to share the Content across Micro frontends
 */
@Injectable({
    providedIn: 'platform'
})
export class HRBMetaDataManagerService extends HRBBaseService {

    /** Screen field location */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public screenFieldLocations: any = {};
    /** Meta data */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public currentMetaData: any;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    private screenFields: Record<string, any>;
    /**
     * Constructor function
     */
    constructor(
        private httpService: HRBHttpProxyService
    ) {
        super();
    }
    /** Get Form meta */
    public getFormMeta(device: string, formName: string) {
        return this.httpService.get(`/api/form-meta/get/${device}/${formName}`).toPromise()
            .then((data: IHRBFormMeta) => {
                this.screenFields = data.screenFields;
                this.createScreenFieldLocationMap();
                return formatData(data, { screenFields: this.screenFields, screenFieldLocations: this.screenFieldLocations });
            });
    }

    /** Get page meta */
    public getMetaData(appName: string, screenName: string, device?: string) {
        let url = `/api/form-meta/get/${appName}/${screenName}`;
        if (device) {
            url = `${url}/${device}`;
        }
        return this.httpService.get(url).toPromise().then((data) => {
            this.currentMetaData = data;
            return data;
        });
    }

    /** Dummy destroy */
    protected destroy(): void { }

    private createScreenFieldLocationMap() {
        each(this.screenFields, (val, key) => {
            this.screenFieldLocations[key] = { hide: [], show: [] };
        });
    }
}
