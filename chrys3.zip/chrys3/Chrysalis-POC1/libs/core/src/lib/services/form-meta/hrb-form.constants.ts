/** Main entity name */
export const Main_Entity = 'Main';

/** Dynamic content */
export const DYNAMIC_CONTENT = 'Dynamic';