import { Injectable } from '@angular/core';

import { HRBBaseService } from '../../base-classes';
import { HRBStateManagerService } from '../state/hrb-state-manager.service';
import { isMobileOrTablet } from '../../utilities';

/**
 * Platform level Service to share the Content across Micro frontends.
 */
@Injectable({
    providedIn: 'platform'
})
export class HRBDeviceManagerService extends HRBBaseService {

    /**
     * Constructor function
     */
    constructor(private stateManager: HRBStateManagerService) {
        super();
    }
    /** Initialize the service */
    public init() {
        this.stateManager.emitDeviceState(isMobileOrTablet);
    }
    /** Dummy destroy */
    protected destroy(): void { }

}
