import { Injectable } from '@angular/core';

import { HRBBaseService } from '../../base-classes';
import { IHRBUserDetails } from './hrb-user-details.interface';

/**
 * This service contains the user session details
 */
@Injectable({
    providedIn: 'platform'
})
export class HRBUserDetailsService extends HRBBaseService {
    private userDetails: Partial<IHRBUserDetails> = {};

    /** Creates an instance of HRBUserDetailsService */
    constructor() {
        super();
    }

    /** Sets the user details property
     * @param  userDetails User details
     */
    public setUserDetails(userDetails: IHRBUserDetails) {
        this.userDetails = { ...userDetails };
    }

    /** Gets the user details property
     * @returns IHRBUserDetails
     */
    public getUserDetails(): Partial<IHRBUserDetails> {
        return this.userDetails;
    }

    /**
     * OnDestroy life cycle method, called when service is destroyed
     */
    protected destroy(): void { }
}
