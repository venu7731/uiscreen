import { TestBed } from '@angular/core/testing';

import { HRBStateManagerService } from './hrb-state-manager.service';

describe('HRBStateManagerService', () => {
    let service: HRBStateManagerService;
    beforeEach(async () => {
        await TestBed.configureTestingModule({
            providers: [HRBStateManagerService]
        });
        service = TestBed.inject(HRBStateManagerService);
    });

    afterAll(async () => {
        service.ngOnDestroy();
    });
    it('should create the service', () => {
        expect(service).toBeDefined();
    });
    it('should emit device state', () => {
        // eslint-disable-next-line @typescript-eslint/dot-notation
        const spy = spyOn(service['deviceSource$'], 'next');
        service.emitDeviceState(true);
        expect(spy).toHaveBeenCalledWith(true);
    });
    it('should emit content state', () => {
        // eslint-disable-next-line @typescript-eslint/dot-notation
        const spy = spyOn(service['contentSource$'], 'next');
        service.emitContentState({});
        expect(spy).toHaveBeenCalledWith({});
    });
});
