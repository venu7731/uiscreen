import { HRBNavigationCommandService } from './implementations/hrb-navigation-command.service';
import { HRBOnboardingExitCommandService } from './implementations/hrb-onboarding-exit-command.service';

/** Type of commands */
export enum HRBCommands {
    Navigate = 'navigate',
    OnboardingExit = 'onboarding_exit'
}

/** Command implementations */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const HRBCommandMap = new Map<HRBCommands, any>([
    [HRBCommands.Navigate, HRBNavigationCommandService],
    [HRBCommands.OnboardingExit, HRBOnboardingExitCommandService]
]);