import { IHRBTaxGroupTypeState } from './hrb-tax-group-type-state.interface';

/**
 * Base interface for the tax return state
 */
export interface IHRBTaxReturnStateBase {
    /** Unique Id of the tax return */
    returnId: string;
    /** Tax year */
    taxYear: number;
    /** Tax system (1040, 1041, etc.) */
    taxSystem: string;
    /** Tax group of the tax return currently selected(FEDERAL or any other state name) */
    taxGroup: string;
    /** Return Lock Id */
    lockGuid: string;
    /** Return Lock Timestamp */
    lockTimestamp: string;
    /** Current active application */
    applicationName: string;
}

/**
 * Current State of the Tax Return along with current states of the different Tax groups
 */
export interface IHRBTaxReturnState extends IHRBTaxReturnStateBase {
    /** Saved states of FEDERAL and other state tax groups(if any) */
    states: IHRBTaxGroupTypeState[];
}
