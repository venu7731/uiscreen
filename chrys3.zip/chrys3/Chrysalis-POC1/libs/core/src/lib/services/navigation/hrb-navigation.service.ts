import { Injectable } from '@angular/core';

import { HRBBaseService } from '../../base-classes';
import { CustomEvents } from '../../utilities';
import { HRBMetaDataManagerService } from '../form-meta';
import { NavigationConstants } from './hrb-navigation.constants';

/**
 * Platform level Service for navigation.
 */
@Injectable({
    providedIn: 'platform'
})
export class HRBNavigationService extends HRBBaseService {

    /** Constructor method */
    constructor(private metaDataService: HRBMetaDataManagerService) {
        super();
    }

    /** Navigate to routes */
    public navigate({ direction, route }: { direction: NavigationConstants, route?: string }) {
        let target: string[];
        if (direction === NavigationConstants.GoTo) {
            target = route.split('/');
        } else {
            const routes = this.metaDataService.currentMetaData.navigation[direction];
            if (routes.includes('/')) {
                target = routes.split('/');
            }
        }
        const event = new CustomEvent(CustomEvents.RouteChange, { detail: { route: target } });
        document.dispatchEvent(event);
    }
    /** Dummy destroy */
    protected destroy(): void { }

}
