import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError as observableThrowError, Observable, timer } from 'rxjs';
import { catchError, retryWhen, mergeMap } from 'rxjs/operators';

import { RequestMethod } from './hrb-http-request-methods.enum';
import { HTTP_CONSTANTS } from './hrb-http-proxy.constants';
import { IHRBHttpRequest } from './hrb-http-proxy.interface';
import { HRBBaseService } from '../../base-classes';

/**
 * Custom wrapper on the Angular HttpClient Service
 */
@Injectable({
    providedIn: 'platform'
})
export class HRBHttpProxyService extends HRBBaseService {

    /** Constructor function
     * @param private http HTTP Client
     * @param private urlService URL Service
     */
    constructor(private http: HttpClient) {
        super();
    }

    /**
     * Performs a request with `get` http method.
     */
    public get(url: string, options?: object, body?: object): Observable<{}> {
        return this._request(RequestMethod.Get, url, body, options);
    }

    /**
     * Performs a request with `post` http method.
     */
    public post(url: string, body: object, options?: object): Observable<{}> {
        return this._request(RequestMethod.Post, url, body, options);
    }

    /**
     * Performs a request with `put` http method.
     */
    public put(url: string, body: object, options?: object): Observable<{}> {
        return this._request(RequestMethod.Put, url, body, options);
    }

    /**
     * Performs a request with `delete` http method.
     */
    public delete(url: string, body?: object, options?: object): Observable<{}> {
        return this._request(RequestMethod.Delete, url, body, options);
    }

    /**
     * Performs a request with `patch` http method.
     */
    public patch(url: string, body: object, options?: object): Observable<{}> {
        return this._request(RequestMethod.Patch, url, body, options);
    }

    /**
     * Performs a request with `head` http method.
     */
    public head(url: string, options?: object): Observable<{}> {
        return this._request(RequestMethod.Head, url, null, options);
    }

    /**
     * Performs a request with `options` http method.
     */
    public options(url: string, options?: object): Observable<{}> {
        return this._request(RequestMethod.Options, url, null, options);
    }

    /**
     * OnDestroy life cycle method, called when service is destroyed
     */
    protected destroy(): void { }

    /** Add Http headers
     * @param headers HTTP header
     */
    private appendHeaders(headers: HttpHeaders) {
        if (!headers) {
            headers = new HttpHeaders();
        }
        return headers;
    }
    /** Generic request method shared by all Http methods
     * @param  method Http Method
     * @param  url URL
     * @param  body? Http Body
     * @param  options? Http Request Options
     * @returns Observable
     */
    private _request(method: RequestMethod, url: string, body?: object, options?: IHRBHttpRequest): Observable<{}> {
        // Append Headers
        const requestOptions: IHRBHttpRequest = Object.assign({}, options, { body });
        requestOptions.headers = this.appendHeaders(requestOptions.headers);
        return this.sendRequest(method, url, requestOptions);
    }

    /** This method does the actual HttpClient call with the prepared parameters
     * @param  method Http Method
     * @param  url URL
     * @param  requestOptions Http Request Options
     * @returns Observable
     */
    private sendRequest(method: RequestMethod, url: string, requestOptions: object): Observable<{}> {
        return this.http.request(RequestMethod[method], url, requestOptions)
            .pipe(
                catchError((err: object): Observable<object> => {
                    console.error(`Error while HttpClient ${RequestMethod[method]} call`, err);
                    return observableThrowError(err);
                }),
                // Retry after a delay of 3 second. If delay is not required just use .retry(2)
                retryWhen(this.retry)
            );
    }

    /** In case of Http method failure, we retry after 3 seconds for HttpRequest_Retry_count times
     * @param attempts Retry Attempts Observable
     */
    private retry(attempts: Observable<HttpErrorResponse>) {
        let count = 0;
        return attempts.pipe(mergeMap(error => {
            return ++count >= HTTP_CONSTANTS.HttpRequest_Retry_count || error.status === 404 ?
                observableThrowError(error) : timer(3000);
        }));
    }

}
