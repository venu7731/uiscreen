import { Injectable } from '@angular/core';

import { HRBBaseService } from '../../../base-classes';
import { HRBNavigationService } from '../../navigation';
import { IHRBCommand } from '../hrb-command.interface';

/**
 * Command for navigation
 */
@Injectable({
    providedIn: 'platform'
})
export class HRBNavigationCommandService extends HRBBaseService implements IHRBCommand {

    /** Constructor method */
    constructor(private navService: HRBNavigationService) {
        super();
    }
    /** Handle navigation to other routes */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public process(params: any): Promise<void> {
        return new Promise((resolve) => {
            this.navService.navigate(params);
            resolve();
        });
    }
    /** dummy destroy */
    protected destroy(): void {
    }

}
