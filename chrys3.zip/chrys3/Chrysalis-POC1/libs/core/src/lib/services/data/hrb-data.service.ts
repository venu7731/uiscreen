import { Injectable } from '@angular/core';
import { cloneDeep, first } from 'lodash-es';

import { HRBBaseService } from '../../base-classes';
import { Main_Entity } from '../form-meta';
import { HRBHttpProxyService } from '../http/hrb-http-proxy.service';
import { HRBReturnStateService } from '../return-state';
import { HRBEntityState } from './hrb-save-form.interface';

/** Data service */
@Injectable({
    providedIn: 'platform'
})
export class HRBDataService extends HRBBaseService {
    /** Form data */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public formData: any = {};
    /** Changed properties list */
    private changedProps: Record<string, string[]> = {};
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    private serverData: any = {};
    private mainEntityId = Main_Entity;

    /**
     * Constructor method
     * @param returnState return state
     * @param http Http
     */
    constructor(
        private returnState: HRBReturnStateService,
        private http: HRBHttpProxyService
    ) {
        super();
    }
    /** Add changed props */
    public addChangedProps(entityType: string, prop: string) {
        if (!this.changedProps[entityType]) {
            this.changedProps[entityType] = [];
        }
        if (!this.changedProps[entityType].includes(prop)) {
            this.changedProps[entityType].push(prop);
        }
    }
    /** Get form data */
    public getFormData(formName: string, formId: string, mappingFormIds: string) {
        const { returnId, taxGroup, taxSystem, taxYear } = this.returnState.getTaxReturnState();
        return this.http.get('/tax/page',
            {
                params: {
                    formName, formId, returnId, taxGroup,
                    taxSystem, taxYear, mappingFormIds
                }
            }).toPromise()
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            .then((data: any[]) => {
                let form = formName;
                if (formId) {
                    form = `${form}:${formId}`;
                }
                this.serverData = { ...this.serverData, [form]: first(data) };
                this.formData = cloneDeep(this.serverData);
                return this.formData;
            });
    }

    /** Save Form data */
    public saveData(formName: string, formId: string, mappingFormIds: string) {
        let form = formName;
        if (formId) {
            form = `${form}:${formId}`;
        }
        const { returnId, taxGroup, taxSystem, taxYear } = this.returnState.getTaxReturnState();
        const mainEntity = this.createMainEntity(form);
        const gridEntities = this.createGridEntities(form);
        if (!mainEntity.ChangedProperties.length && !gridEntities.length) {
            return Promise.resolve({});
        }
        const entities = !mainEntity.ChangedProperties.length ? gridEntities :
            !gridEntities.length ? [mainEntity] :
                [mainEntity, ...gridEntities];
        return this.http.post('/tax/page/save',
            {
                BindingContext: {
                    isCalculationRequired: true, isCommandExecutionRequired: true, isNotifyRequired: true,
                    mappingFormIds, returnId, taxGroup, taxSystem, taxYear, formName, formId, version: this.serverData[form].Version,
                    isRetry: false, isPageSave: true, isSignalRRefreshGet: false, TrackValues: { IsPageLevelSave: true }
                }, Entities: entities
            }
        ).toPromise()
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            .then((data: any) => {
                this.changedProps = {};
                this.formData[form].Version = data.Version;
                this.serverData = cloneDeep(this.formData);
            });
    }
    /** Dummy destroy */
    protected destroy(): void {
    }

    private createMainEntity(form: string) {
        const changedEntities = {};
        const changedProps = this.changedProps[this.mainEntityId].filter((prop) => {
            if (this.serverData[form][prop].val !== this.formData[form][prop].val) {
                changedEntities[prop] = this.formData[form][prop];
                return prop;
            }
        });
        return {
            Entity: {
                $type: this.serverData[form].$type,
                EntityState: HRBEntityState.Modified,
                ...changedEntities,
            },
            ChangedProperties: changedProps
        };
    }

    private createGridEntities(form: string) {
        const gridEntities = Object.keys(this.changedProps).filter(key => key.startsWith('Grid_'));
        const returnEntities = [];
        const { taxGroup, taxSystem, taxYear } = this.returnState.getTaxReturnState();
        gridEntities.forEach((entity) => {
            const [entityName, rowId] = entity.split('-');
            const entityState = this.serverData[form][entityName].Children?.[+rowId] ? HRBEntityState.Modified :
                HRBEntityState.Added;
            const changedEntities = {};
            const changedProps = this.changedProps[entity].filter((prop) => {
                if (entityState === HRBEntityState.Added) {
                    changedEntities[prop] = this.formData[form][entityName].Children?.[+rowId][prop];
                    return prop;
                }
                if (this.serverData[form][entityName].Children?.[+rowId][prop].val !==
                    this.formData[form][entityName].Children?.[+rowId][prop].val) {
                    changedEntities[prop] = this.formData[form][entityName].Children?.[+rowId][prop];
                    return prop;
                }
            });
            if (changedProps.length) {
                returnEntities.push({
                    Entity: {
                        $type: `HRBlock.OCAP.Orm.${entityName}_RowItem, HRBlock.ION.ORM.${taxYear}.${taxSystem}.${taxGroup}`,
                        ...changedEntities,
                        Id: this.formData[form][entityName].Children?.[+rowId].Id,
                        [`${entityName}Id`]: this.formData[form][entityName].Children?.[+rowId][`${entityName}Id`],
                        Version: this.serverData[form].Version,
                        EntityState: entityState,
                        ChildId: this.formData[form][entityName].Children?.[+rowId].ChildId
                    },
                    ChangedProperties: changedProps
                });
            }
        });
        return returnEntities;
    }
}