/** Navigation Directions */
export enum NavigationConstants {
    Next = 'next',
    Previous = 'prev',
    GoTo = 'goto'
}