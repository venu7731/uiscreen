import { HttpHandler, HttpXhrBackend, HttpRequest, HttpEvent, HTTP_INTERCEPTORS } from '@angular/common/http';
import { Injector } from '@angular/core';
import { Observable } from 'rxjs';

import { HRBHttpInterceptorHandler } from './hrb-http-interceptor';

/**
 * Http interceptor custom implementation
 */
export class HRBHttpCustomInterceptHandler implements HttpHandler {
    private chain: HttpHandler | null = null;
    private httpBackend: HttpHandler;

    /**
     * Creates an instance of HRBHttpCustomInterceptHandler.
     * @param injector Static Injector
     */
    constructor(private injector: Injector) {
        this.httpBackend = new HttpXhrBackend({ build: () => new XMLHttpRequest() });
    }

    /**
     * Handle http requests
     * @param req Http Request
     * @returns Observable of HttpEvent
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public handle(req: HttpRequest<any>): Observable<HttpEvent<any>> {
        if (this.chain === null) {
            const interceptors = this.injector.get(HTTP_INTERCEPTORS, []);
            this.chain = interceptors.reduceRight((next, interceptor) =>
                new HRBHttpInterceptorHandler(next, interceptor), this.httpBackend);
        }
        return this.chain.handle(req);
    }
}
