import { TestBed } from '@angular/core/testing';

import { HRBPreloaderService } from './hrb-preloader.service';
describe('HRBPreloaderService', () => {
    let service: HRBPreloaderService;
    beforeEach(async () => {
        await TestBed.configureTestingModule({
            providers: [HRBPreloaderService]
        });
        service = TestBed.inject(HRBPreloaderService);
    });

    afterAll(async () => {
        service.ngOnDestroy();
    });
    it('should create the service', () => {
        expect(service).toBeDefined();
    });
    it('should preload image', () => {
        const spy = spyOn(document.head, 'appendChild');
        service.preload('image', '/a.jpg');
        const linkElement = document.createElement('link');
        linkElement.rel = 'preload';
        linkElement.as = 'image';
        linkElement.href = '/a.jpg';
        expect(spy).toHaveBeenCalledWith(linkElement);
    });
    it('should not load duplicates', () => {
        const spy = spyOn(document.head, 'appendChild');
        service.preload('image', '/a.jpg');
        service.preload('image', '/a.jpg');
        expect(spy).toHaveBeenCalledTimes(1);
    });
});
