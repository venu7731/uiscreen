import { TestBed } from '@angular/core/testing';

import { HRBReturnStateService } from './hrb-return-state.service';
describe('HRBReturnStateService', () => {
    let service: HRBReturnStateService;
    beforeEach(async () => {
        await TestBed.configureTestingModule({
            providers: [HRBReturnStateService]
        });
        service = TestBed.inject(HRBReturnStateService);
    });

    afterAll(async () => {
        service.ngOnDestroy();
    });
    it('should create the service', () => {
        expect(service).toBeDefined();
    });
    it('should set tax group', () => {
        service.setTaxGroup('FD');
        expect(service.getTaxReturnState().taxGroup).toEqual('FD');
    });
    it('should set tax return state', () => {
        service.setTaxReturnState({ taxYear: 2020 });
        expect(service.getTaxReturnState()).toEqual({ taxYear: 2020 });
    });
});
