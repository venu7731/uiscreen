import { Injectable, Injector } from '@angular/core';

import { HRBBaseService } from '../../base-classes';
import { HRBCommandMap } from './hrb-command.constants';
import { IHRBCommand, IHRBCommandAction } from './hrb-command.interface';

/**
 * Platform level Service to execute commands
 */
@Injectable({
    providedIn: 'platform'
})
export class HRBCommandManagerService extends HRBBaseService {

    /** Constructor */
    constructor(private injector: Injector) {
        super();
    }
    /** Execute commands in loop */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public async execute(actions: IHRBCommandAction[], data: any): Promise<any> {
        let result = {};
        for (const action of actions) {
            const implementation = this.injector.get<IHRBCommand>(HRBCommandMap.get(action.type));
            action.params.data = data;
            const response = await implementation.process(action.params);
            if (response) {
                result = { ...result, ...response };
            }
        }
        return Promise.resolve(result);
    }
    /** dummy destroy */
    protected destroy(): void {
    }

}
