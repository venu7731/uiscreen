/**
 * User Details interface
 */
export interface IHRBUserDetails {
    /**
     * Office Id of the user
     */
    officeId: string;
    /**
     * Taxpro Id of the user
     */
    taxProId: string;
    /**
     * Device Id of machine
     */
    deviceId?: string;
}
