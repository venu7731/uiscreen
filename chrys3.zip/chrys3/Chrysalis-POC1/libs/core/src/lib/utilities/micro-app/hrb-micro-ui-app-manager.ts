import { ElementRef } from '@angular/core';

import { get } from '../hrb-lodash';
import { IHRBMicroAppConfig } from './hrb-micro-ui-config.interface';

/**
 * Manager for loading and unloading of Micro Elements
 * This is not an Angular Component and the module which is using it should construct and destruct
 * by constructor and by destroying the reference by assigning null
 */
export class HRBMicroUIAppManager {
    /** Creates and appends scripts */
    public static createScript(src: string, preload = false) {
        if (preload) {
            const link = document.createElement('link');
            link.href = src;
            link.rel = 'preload';
            link.as = 'script';
            document.head.appendChild(link);
        } else {
            const script = document.createElement('script');
            script.src = src;
            document.body.appendChild(script);
        }
    }

    /** Creates and appends stylesheets */
    public static createStyle(src: string, preload = false) {
        const link = document.createElement('link');
        link.href = src;
        if (preload) {
            link.rel = 'preload';
            link.as = 'style';
            document.head.appendChild(link);
        } else {
            link.rel = 'stylesheet';
            document.body.appendChild(link);
        }
    }

    /**
     * Setting value for pConfig
     * @param  any pConfig
     */
    public set config(pConfig: IHRBMicroAppConfig) {
        this.pConfig = pConfig;
    }

    /**
     * Getting value of pConfig
     */
    public get config() { return this.pConfig; }

    /**
     * Micro application names and source paths.
     */
    private pConfig: IHRBMicroAppConfig;

    /** Creates an instance of HRBMicroUIAppManager*/
    constructor(pConfig?: IHRBMicroAppConfig) {
        if (pConfig) {
            this.pConfig = pConfig;
        }
    }

    /**
     * Load micro application.
     * @param  any containerRef
     */
    public load(containerRef: ElementRef) {

        // Find the config for app to be loaded in the container.

        if (this.pConfig && containerRef.nativeElement) {
            this.remove(containerRef);
            const appName = get(this.pConfig, 'name', '');
            this.setScriptAndStyle();
            // Create custom element by the app name.
            const elRef: HTMLElement = document.createElement(appName);
            containerRef.nativeElement.appendChild(elRef);
        }
    }

    /** To load only css and script path */
    public staticLoad() {
        // Find the config for app to be loaded in the container.
        if (this.pConfig) {
            return this.setScriptAndStyle();
        }
        return Promise.resolve();
    }
    /**
     * Remove element from the DOM.
     * @param  any containerRef
     * @returns void
     */
    public remove(containerRef: ElementRef): void {
        containerRef.nativeElement.innerHTML = '';
    }

    /** set the css and script to the head
     * @param  HTMLElement nativeElement
     */
    private setScriptAndStyle() {
        return new Promise((resolve, reject) => {
            if (this.pConfig.loaded) {
                resolve(null);
            } else {
                const src = get(this.pConfig, 'path', '');
                const cssPath = get(this.pConfig, 'cssPath', '');
                if (src) {
                    const script = document.createElement('script');
                    script.src = src;
                    script.onerror = () => {
                        this.pConfig.loaded = false;
                        reject();
                    };
                    script.onload = () => {
                        this.pConfig.loaded = true;
                        resolve(null);
                    };
                    document.body.appendChild(script);
                }
                if (cssPath) {
                    const link = document.createElement('link');
                    link.href = cssPath;
                    link.rel = 'stylesheet';
                    document.body.appendChild(link);
                }
            }
        });
    }

}
