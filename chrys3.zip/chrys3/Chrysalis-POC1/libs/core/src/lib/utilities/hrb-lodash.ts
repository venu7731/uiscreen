/* eslint-disable max-len, no-restricted-imports, @typescript-eslint/no-explicit-any */
import * as _ from 'lodash-es';

/** Interface for numeric dictionary */
interface INumericDictionary<T> {
    /** Numeric index */
    [index: number]: T;
}

/** Type safe Wrapper for lodash get function */
export function get<TObject extends object, TKey extends keyof TObject>(object: TObject, path: TKey | [TKey]): TObject[TKey];
/** Type safe Wrapper for lodash get function */
export function get<TObject extends object, TKey extends keyof TObject>(object: TObject | null | undefined, path: TKey | [TKey]): TObject[TKey] | undefined;
/** Type safe Wrapper for lodash get function */
export function get<TObject extends object, TKey extends keyof TObject, TDefault>(object: TObject | null | undefined, path: TKey | [TKey], defaultValue: TDefault): Exclude<TObject[TKey], undefined> | TDefault;
/** Type safe Wrapper for lodash get function */
export function get<TObject extends object, TKey1 extends keyof TObject, TKey2 extends keyof TObject[TKey1]>(object: TObject, path: [TKey1, TKey2]): TObject[TKey1][TKey2];
/** Type safe Wrapper for lodash get function */
export function get<TObject extends object, TKey1 extends keyof TObject, TKey2 extends keyof TObject[TKey1]>(object: TObject | null | undefined, path: [TKey1, TKey2]): TObject[TKey1][TKey2] | undefined;
/** Type safe Wrapper for lodash get function */
export function get<TObject extends object, TKey1 extends keyof TObject, TKey2 extends keyof TObject[TKey1], TDefault>(object: TObject | null | undefined, path: [TKey1, TKey2], defaultValue: TDefault): Exclude<TObject[TKey1][TKey2], undefined> | TDefault;
/** Type safe Wrapper for lodash get function */
export function get<TObject extends object, TKey1 extends keyof TObject, TKey2 extends keyof TObject[TKey1], TKey3 extends keyof TObject[TKey1][TKey2]>(object: TObject, path: [TKey1, TKey2, TKey3]): TObject[TKey1][TKey2][TKey3];
/** Type safe Wrapper for lodash get function */
export function get<TObject extends object, TKey1 extends keyof TObject, TKey2 extends keyof TObject[TKey1], TKey3 extends keyof TObject[TKey1][TKey2]>(object: TObject | null | undefined, path: [TKey1, TKey2, TKey3]): TObject[TKey1][TKey2][TKey3] | undefined;
/** Type safe Wrapper for lodash get function */
export function get<TObject extends object, TKey1 extends keyof TObject, TKey2 extends keyof TObject[TKey1], TKey3 extends keyof TObject[TKey1][TKey2], TDefault>(object: TObject | null | undefined, path: [TKey1, TKey2, TKey3], defaultValue: TDefault): Exclude<TObject[TKey1][TKey2][TKey3], undefined> | TDefault;
/** Type safe Wrapper for lodash get function */
export function get<TObject extends object, TKey1 extends keyof TObject, TKey2 extends keyof TObject[TKey1], TKey3 extends keyof TObject[TKey1][TKey2], TKey4 extends keyof TObject[TKey1][TKey2][TKey3]>(object: TObject, path: [TKey1, TKey2, TKey3, TKey4]): TObject[TKey1][TKey2][TKey3][TKey4];
/** Type safe Wrapper for lodash get function */
export function get<TObject extends object, TKey1 extends keyof TObject, TKey2 extends keyof TObject[TKey1], TKey3 extends keyof TObject[TKey1][TKey2], TKey4 extends keyof TObject[TKey1][TKey2][TKey3]>(object: TObject | null | undefined, path: [TKey1, TKey2, TKey3, TKey4]): TObject[TKey1][TKey2][TKey3][TKey4] | undefined;
/** Type safe Wrapper for lodash get function */
export function get<TObject extends object, TKey1 extends keyof TObject, TKey2 extends keyof TObject[TKey1], TKey3 extends keyof TObject[TKey1][TKey2], TKey4 extends keyof TObject[TKey1][TKey2][TKey3], TDefault>(object: TObject | null | undefined, path: [TKey1, TKey2, TKey3, TKey4], defaultValue: TDefault): Exclude<TObject[TKey1][TKey2][TKey3][TKey4], undefined> | TDefault;
/** Type safe Wrapper for lodash get function */
export function get<T>(object: INumericDictionary<T>, path: number): T;
/** Type safe Wrapper for lodash get function */
export function get<T>(object: INumericDictionary<T> | null | undefined, path: number): T | undefined;
/** Type safe Wrapper for lodash get function */
export function get<T, TDefault>(object: INumericDictionary<T> | null | undefined, path: number, defaultValue: TDefault): T | TDefault;
/** Type safe Wrapper for lodash get function */
export function get<TObject extends object, TKey extends keyof TObject, TDefault>(object: TObject | null | undefined, path: TKey | [TKey], defaultValue?: TDefault): Exclude<TObject[TKey], undefined> | TDefault {
    return _.get(object, path, defaultValue);
}

/** Type safe Wrapper for lodash set function */
export function set<TObject extends object, TKey extends keyof TObject>(object: TObject | null | undefined, path: TKey | [TKey], value: any): TObject;
/** Type safe Wrapper for lodash set function */
export function set<TObject extends object, TKey1 extends keyof TObject, TKey2 extends keyof TObject[TKey1]>(object: TObject | null | undefined, path: [TKey1, TKey2], value: any): TObject;
/** Type safe Wrapper for lodash set function */
export function set<TObject extends object, TKey1 extends keyof TObject, TKey2 extends keyof TObject[TKey1], TKey3 extends keyof TObject[TKey1][TKey2]>(object: TObject | null | undefined, path: [TKey1, TKey2, TKey3], value: any): TObject;
/** Type safe Wrapper for lodash set function */
export function set<TObject extends object, TKey1 extends keyof TObject, TKey2 extends keyof TObject[TKey1], TKey3 extends keyof TObject[TKey1][TKey2], TKey4 extends keyof TObject[TKey1][TKey2][TKey3]>(object: TObject | null | undefined, path: [TKey1, TKey2, TKey3, TKey4], value: any): TObject;
/** Type safe Wrapper for lodash set function */
export function set<TObject extends object, TKey extends keyof TObject>(object: TObject | null | undefined, path: TKey | [TKey], value: any): TObject {
    return _.set(object, path, value);
}
