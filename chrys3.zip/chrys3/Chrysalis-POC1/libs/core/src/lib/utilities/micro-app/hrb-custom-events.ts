/** Custom Events */
export enum CustomEvents {
    RouteChange = 'routeChange',
    PopupOpen = 'popupOpen'
}
