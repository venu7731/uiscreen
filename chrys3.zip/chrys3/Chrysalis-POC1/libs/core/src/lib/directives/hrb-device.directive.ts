import { ChangeDetectorRef, Directive, Input, NgZone, TemplateRef, ViewContainerRef } from '@angular/core';
import { HRBBaseComponent } from '../base-classes';

/**
 * Directive to handle multiviews for single component based on screen size.
 * Based on MediaQueryList
 */
@Directive({ selector: '[hrbDevice]' })
export class HRBDeviceDirective extends HRBBaseComponent {
    /** Input query to be executed by matchMedia API */
    @Input() public set hrbDevice(query: string) {
        // cleanup old listener
        if (this.removeListener) {
            this.removeListener();
        }
        this.setListener(query);
    }
    private hasView = false;
    private removeListener: () => void;

    /** constructor function */
    constructor(
        private readonly viewContainer: ViewContainerRef,
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        private readonly template: TemplateRef<any>,
        cdr: ChangeDetectorRef,
        ngZone: NgZone
    ) {
        super(cdr, ngZone);
    }

    /** Dummy init */
    protected init(): void { }
    /** Dummy destroy */
    protected destroy(): void { }

    private setListener(query: string) {
        const mediaQueryList = window.matchMedia(query);
        const listener = event => {
            const callback = () => {
                // create view if true and not created already
                if (event.matches && !this.hasView) {
                    this.hasView = true;
                    this.viewContainer.createEmbeddedView(this.template);
                }
                // destroy view if false and created
                if (!event.matches && this.hasView) {
                    this.hasView = false;
                    this.viewContainer.clear();
                }
            };
            this.render(callback);
        };
        // run once and then add listener
        listener(mediaQueryList);
        mediaQueryList.addEventListener('change', listener);
        // add cleanup listener
        this.removeListener = () => mediaQueryList.removeEventListener('change', listener);
    }
}
