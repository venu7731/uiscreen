/** Theme constants */
export const Themes = {
    Primary: 'primary',
    Secondary: 'secondary'
};