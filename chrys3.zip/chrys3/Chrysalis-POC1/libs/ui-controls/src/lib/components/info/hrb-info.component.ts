import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { cloneDeep, each, map } from 'lodash-es';

import { get, HRBBaseComponent, DYNAMIC_CONTENT } from '@chrysalis/core';

import { HRBInfoGroups, HRBInfoTypes, IHRBInfo, IHRBInfoAction } from './hrb-info.interfaces';
import { getMeta } from '../utilities/hrb-composer-utils';

/**
 * Info component
 */
@Component({
  selector: 'hrb-info-wrapper',
  templateUrl: './hrb-info.component.html',
  styleUrls: ['./hrb-info.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBInfoComponent extends HRBBaseComponent {
  /** Content */
  @Input()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public set content(val: any) {
    if (val) {
      this.originalContent = cloneDeep(val);
    }
  }
  /** Meta data */
  @Input()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public set metaData(val: any) {
    if (val) {
      this.pMetaData = val;
      this.processMetaData();
    }
  }
  public get metaData() {
    return this.pMetaData;
  }
  /** Data */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  @Input() public data: any;
  /** Passing action data  */
  @Output() public actionEvent = new EventEmitter<IHRBInfoAction[]>();
  /** Info content */
  public infoContent: IHRBInfo;
  /** Info Groups */
  public HRBInfoGroups = HRBInfoGroups;
  /** Info Types */
  public HRBInfoTypes = HRBInfoTypes;
  /** Original Content */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public originalContent: any;
  /** Interstitial Set Initially */
  private state;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private pMetaData: any;

  /** Handle primary button */
  public handlePrimaryButton() {
    this.actionEvent.emit(this.getMeta(this.metaData.groups, HRBInfoGroups.Footer, HRBInfoTypes.PrimaryButton)?.actions);
  }
  /** Handle secondary button */
  public handleSecondaryButton() {
    this.actionEvent.emit(this.getMeta(this.metaData.groups, HRBInfoGroups.Footer, HRBInfoTypes.SecondaryButton)?.actions);
  }
  /** Handle Footer link */
  public handleFooterLink() {
    this.actionEvent.emit(this.getMeta(this.metaData.groups, HRBInfoGroups.Footer, HRBInfoTypes.FooterLink)?.actions);
  }
  /** Dummy init */
  protected init(): void { }
  /** Clear state */
  protected destroy(): void {
    delete this.data.state;
    this.state = undefined;
  }

  private processMetaData() {
    this.state = this.data.state;
    this.infoContent = {
      theme: `container--${this.contentMetaData(HRBInfoTypes.Default, HRBInfoGroups.Default, 'theme')}`,
      headerText: this.contentMetaData(HRBInfoTypes.HeaderText, HRBInfoGroups.Header, 'headerText'),
      headerSubText: this.contentMetaData(HRBInfoTypes.HeaderSubText, HRBInfoGroups.Header, 'headerSubText'),
      contentText: this.contentMetaData(HRBInfoTypes.ContentText, HRBInfoGroups.Content, 'contentText'),
      contentSubText: this.contentMetaData(HRBInfoTypes.ContentSubText, HRBInfoGroups.Content, 'contentSubText'),
      contentImageUrl: this.contentMetaData(HRBInfoTypes.ContentImageUrl, HRBInfoGroups.Content, 'contentImageUrl'),
      contentImageText: this.contentMetaData(HRBInfoTypes.ContentImageText, HRBInfoGroups.Content, 'contentImageText'),
      footerText: this.contentMetaData(HRBInfoTypes.FooterText, HRBInfoGroups.Footer, 'footerText')
    };
    this.infoContent.footerLink = {
      description: this.contentMetaData(HRBInfoTypes.FooterLink, HRBInfoGroups.Footer, 'description'),
      theme: this.contentMetaData(HRBInfoTypes.FooterLink, HRBInfoGroups.Footer, 'theme')
    };
    this.infoContent.primaryButton = {
      description: this.contentMetaData(HRBInfoTypes.PrimaryButton, HRBInfoGroups.Footer, 'description'),
      theme: this.contentMetaData(HRBInfoTypes.PrimaryButton, HRBInfoGroups.Footer, 'theme')
    };
    this.infoContent.secondaryButton = {
      description: this.contentMetaData(HRBInfoTypes.SecondaryButton, HRBInfoGroups.Footer, 'description'),
      theme: this.contentMetaData(HRBInfoTypes.SecondaryButton, HRBInfoGroups.Footer, 'theme')
    };
    // For lists, special processing is needed
    this.infoContent.contentCards = this.processLists(
      this.contentMetaData(HRBInfoTypes.ContentCards, HRBInfoGroups.Content, 'contentCards.name'),
      this.getMeta(this.metaData.groups, HRBInfoGroups.Content, HRBInfoTypes.ContentCards)?.contentCards
    );
  }
  private contentMetaData(itemName: HRBInfoTypes, groupName: HRBInfoGroups, prop: string) {
    const { appName, screenName, groups } = this.metaData;
    const meta = this.getMeta(groups, groupName, itemName);
    if (!meta) {
      return null;
    }
    const name = meta.type === DYNAMIC_CONTENT ? `${meta.name}-${this.state}` : meta.name;
    return get(this.originalContent[appName][screenName][name], get(meta, prop));
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private getMeta(groups: any[], groupName: HRBInfoGroups, itemName: HRBInfoTypes): any {
    const group = groups.find(grp => grp.name === groupName);
    if (!group) {
      return null;
    }
    return getMeta<HRBInfoTypes>(group?.items, itemName);
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private processLists(list: any[], listMeta: any) {
    if (!list || !listMeta) {
      return null;
    }
    const keys = Object.keys(listMeta);
    const values: string[] = Object.values(listMeta);
    const nameIndex = keys.findIndex(key => key === 'name');
    keys.splice(nameIndex, 1);
    values.splice(nameIndex, 1);

    return map(list, (item) => {
      const returnObj = {};
      each(keys, (key, index) => {
        returnObj[key] = item[values[index]];
      });
      return returnObj;
    });
  }
}
