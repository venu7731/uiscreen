import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HrbUiComposerComponent } from './hrb-ui-composer.component';

describe('HrbUiComposerComponent', () => {
  let component: HrbUiComposerComponent;
  let fixture: ComponentFixture<HrbUiComposerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HrbUiComposerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HrbUiComposerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
