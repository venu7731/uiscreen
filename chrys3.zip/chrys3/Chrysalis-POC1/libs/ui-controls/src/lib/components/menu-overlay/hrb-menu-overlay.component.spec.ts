import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBMenuOverlayComponent } from './hrb-menu-overlay.component';

describe('HRBMenuOverlayComponent', () => {
  let component: HRBMenuOverlayComponent;
  let fixture: ComponentFixture<HRBMenuOverlayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBMenuOverlayComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBMenuOverlayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
