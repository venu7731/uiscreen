import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBEditDataComponent } from './hrb-edit-data.component';

describe('HRBEditDataComponent', () => {
  let component: HRBEditDataComponent;
  let fixture: ComponentFixture<HRBEditDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBEditDataComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBEditDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
