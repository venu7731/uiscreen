import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, NgZone, Output } from '@angular/core';

import { HRBBaseComponent, HRBDataService, IHRBFormSection, Main_Entity } from '@chrysalis/core';
import { IHRBButtonAction } from '../button';

@Component({
  selector: 'hrb-dynamic-form',
  templateUrl: './hrb-dynamic-form.component.html',
  styleUrls: ['./hrb-dynamic-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBDynamicFormComponent extends HRBBaseComponent {
  /** Dynamic form content */
  @Input() public section: IHRBFormSection;
  /** Dynamic form data */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  @Input() public data: any;
  /** Dynamic form content */
  @Output() public buttonClicked = new EventEmitter<IHRBButtonAction[]>();

  /** Constructor method */
  constructor(cdr: ChangeDetectorRef, ngZone: NgZone, private dataService: HRBDataService) {
    super(cdr, ngZone);
  }

  /** Button cliked event */
  public handleButtonClick(actions: IHRBButtonAction[]) {
    this.buttonClicked.emit(actions);
  }
  /** Button cliked event */
  public updateChangedProps(alias: string) {
    this.dataService.addChangedProps(Main_Entity, alias);
  }
  /** Dummy init */
  protected init(): void { }
  /** Dummy destroy */
  protected destroy(): void {
  }
}
