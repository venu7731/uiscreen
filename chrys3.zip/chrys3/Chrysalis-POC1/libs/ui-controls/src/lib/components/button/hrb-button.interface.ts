import { IHRBCommandAction } from '@chrysalis/core';

/** Button meta */
export interface IHRBButtonContent {
    /** description */
    description: string;
    /** icon */
    icon?: string;
    /** Actions on click */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    actions?: any[];
    /** theme? */
    theme?: string;
}

/**
 * Button Action
 */
export type IHRBButtonAction = IHRBCommandAction;