/** Duration of Interstitial Screen */
export const InterstitialDuration = 2800;

/** States for Interstitial */
export const States = {
    Play: 'play',
    Pause: 'pause'
};
