import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, NgZone } from '@angular/core';
import { size } from 'lodash-es';

import { HRBBaseComponent, HRBCommandManagerService, IHRBCommandAction } from '@chrysalis/core';

/** UI Composer class */
@Component({
  selector: 'hrb-ui-composer',
  templateUrl: './hrb-ui-composer.component.html',
  styleUrls: ['./hrb-ui-composer.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBUiComposerComponent extends HRBBaseComponent {

  /** Content for the composite component */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  @Input() public content: any;
  /** Meta data for the composite component */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  @Input() public metaData: any;
  /** Data for the composite component */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  @Input() public data: any;

  constructor(private commandManger: HRBCommandManagerService,
    cdr: ChangeDetectorRef, ngZone: NgZone) {
    super(cdr, ngZone);
  }
  /** send action back to concrete class */
  public async callback(actions: IHRBCommandAction[]) {
    if (size(actions)) {
      const result = await this.commandManger.execute(actions, this.data);
      this.data = { ...this.data, ...result };
    }
  }
  /** Dummy init */
  protected init(): void { }
  /** Dummy destroy */
  protected destroy(): void {
  }
}