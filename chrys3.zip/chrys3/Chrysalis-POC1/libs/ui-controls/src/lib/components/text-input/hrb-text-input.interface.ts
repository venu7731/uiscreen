/** Text input meta */
export interface IHRBTextInput {
    /** description */
    description: string;
    /** alias name */
    alias?: string;
}
