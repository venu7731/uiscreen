import { IHRBCommandAction } from '@chrysalis/core';

/** Interface for Interstitial component */
export interface IHRBInterstitial {
    /** Header text */
    headerText?: string;
    /** Content Image url */
    contentImageUrl?: string;
    /** Sub Text */
    subText?: string;
    /** Footer Icon url */
    footerIconUrl?: string;
    /** Theme */
    theme?: string;
    /** Duration */
    duration?: number;
}

/** Interstitial action */
export type IHRBInterstitialAction = IHRBCommandAction;

/** Interstitial component types */
export enum HRBInterstitialTypes {
    Default = 'default',
    HeaderText = 'headerText',
    SubText = 'subText',
    ContentImage = 'contentImage',
    FooterImage = 'footerImage',
}