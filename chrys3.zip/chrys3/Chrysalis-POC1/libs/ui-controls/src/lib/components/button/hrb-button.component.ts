import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';

import { HRBBaseComponent } from '@chrysalis/core';

import { IHRBButtonAction, IHRBButtonContent } from './hrb-button.interface';

@Component({
  selector: 'hrb-button-wrapper',
  templateUrl: './hrb-button.component.html',
  styleUrls: ['./hrb-button.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBButtonComponent extends HRBBaseComponent {
  /** Button content */
  @Input() public item: IHRBButtonContent;
  /** Button click event */
  @Output() public buttonClicked = new EventEmitter();

  /**
   * Emit button actions
   */
  public emitButtonClick(actions: IHRBButtonAction[]) {
    this.buttonClicked.emit(actions);
  }
  /** Dummy init */
  protected init(): void { }
  /** Dummy destroy */
  protected destroy(): void {
  }
}
