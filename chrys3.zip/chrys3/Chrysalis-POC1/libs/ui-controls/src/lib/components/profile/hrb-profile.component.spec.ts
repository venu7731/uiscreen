import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBProfileComponent } from './hrb-profile.component';

describe('HRBProfileComponent', () => {
  let component: HRBProfileComponent;
  let fixture: ComponentFixture<HRBProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBProfileComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
