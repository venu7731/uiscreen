/* eslint-disable @typescript-eslint/no-explicit-any */
import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { cloneDeep, each, first } from 'lodash-es';

import { HRBBaseComponent, formatGroup } from '@chrysalis/core';

import { HRBEditDataTypes, IHRBEditData, IHRBEditDataAction } from './hrb-edit-data.interfaces';
import { contentMetaData, getMeta, getProps, remapKeys } from '../utilities/hrb-composer-utils';

/** Edit Popup component */
@Component({
  selector: 'hrb-edit-data',
  templateUrl: './hrb-edit-data.component.html',
  styleUrls: ['./hrb-edit-data.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBEditDataComponent extends HRBBaseComponent {
  /** Content */
  @Input()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public set content(val: any) {
    if (val) {
      this.originalContent = cloneDeep(val);
    }
  }
  /** Meta data */
  @Input()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public set metaData(val: any) {
    if (val) {
      this.pMetaData = val;
      this.processMetaData();
    }
  }
  public get metaData() {
    return this.pMetaData;
  }
  /** Data */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  @Input() public data: any;
  /** Passing action data  */
  @Output() public actionEvent = new EventEmitter<IHRBEditDataAction[]>();
  /** Edit data content */
  public editDataContent: IHRBEditData;
  /** Original Content */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public originalContent: any;
  /** HRBInterstitial Types */
  public HRBEditDataTypes = HRBEditDataTypes;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private pMetaData: any;
  private state: string;

  /** Handle primary button */
  public handlePrimaryButton() {
    this.actionEvent.emit(getMeta<HRBEditDataTypes>(this.metaData.items, HRBEditDataTypes.PrimaryButton)?.actions);
  }

  /** Dummy init */
  protected init(): void {
  }
  /** Dummy destroy */
  protected destroy(): void {
  }

  private processMetaData() {
    this.editDataContent = {
      theme: contentMetaData<HRBEditDataTypes>(this, HRBEditDataTypes.Default, 'theme'),
      headerText: contentMetaData<HRBEditDataTypes>(this, HRBEditDataTypes.HeaderText, 'headerText')
    };
    this.editDataContent.infoCard = {
      headerText: contentMetaData<HRBEditDataTypes>(this, HRBEditDataTypes.InfoCard, 'headerText'),
      alias: getProps<HRBEditDataTypes>(this.metaData.items, HRBEditDataTypes.InfoCard, 'alias')
    };
    this.processDynamicForm();
    this.editDataContent.primaryButton = {
      description: contentMetaData<HRBEditDataTypes>(this, HRBEditDataTypes.PrimaryButton, 'description'),
      theme: contentMetaData<HRBEditDataTypes>(this, HRBEditDataTypes.PrimaryButton, 'theme'),
    };
  }

  private processDynamicForm() {
    this.editDataContent.dynamicForm = {
      name: getProps<HRBEditDataTypes>(this.metaData.items, HRBEditDataTypes.DynamicForm, 'alias'),
      groups: this.getGroups()
    };
    this.editDataContent.dynamicForm = formatGroup(this.editDataContent.dynamicForm, { section: null }, {}) as any;
  }

  private getGroups() {
    const result = [];
    const groupMetas = getProps<HRBEditDataTypes>(this.metaData.items, HRBEditDataTypes.DynamicForm, 'groups');
    const layoutMetas = getProps<HRBEditDataTypes>(this.metaData.items, HRBEditDataTypes.DynamicForm, 'layouts');
    const itemMetas = getProps<HRBEditDataTypes>(this.metaData.items, HRBEditDataTypes.DynamicForm, 'items');
    const groups = contentMetaData<HRBEditDataTypes>(this, HRBEditDataTypes.DynamicForm, 'groups');
    each(groupMetas, (groupMeta, index) => {
      const meta: any = first(groupMeta.contentMeta);
      const tranformedGroup: any = remapKeys(groups[index], meta);
      each(layoutMetas, (layoutMeta, layoutIndex) => {
        const lMeta: any = first(layoutMeta.contentMeta);
        tranformedGroup.layouts[layoutIndex] = remapKeys(tranformedGroup.layouts[layoutIndex], lMeta);
        each(itemMetas, (itemMeta, itemIndex) => {
          const iMeta: any = first(itemMeta.contentMeta);
          tranformedGroup.layouts[layoutIndex].items[itemIndex] =
            remapKeys(tranformedGroup.layouts[layoutIndex].items[itemIndex], iMeta);
          tranformedGroup.layouts[layoutIndex].items[itemIndex].alias = itemMeta.alias;
          tranformedGroup.layouts[layoutIndex].items[itemIndex].type = itemMeta.type;
        });
      });
      result.push(tranformedGroup);
    });
    return result;
  }

}
