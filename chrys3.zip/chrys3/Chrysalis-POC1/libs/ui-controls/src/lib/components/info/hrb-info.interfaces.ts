import { IHRBCommandAction } from '@chrysalis/core';

import { IHRBButtonContent } from '../button';
import { IHRBLinkContent } from '../link';

/** Interface for Info component */
export interface IHRBInfo {
    /** Header text */
    headerText?: string;
    /** Header subtext */
    headerSubText?: string;
    /** Content text */
    contentText?: string;
    /** Content subtext */
    contentSubText?: string;
    /** Content Image url */
    contentImageUrl?: string;
    /** Content Image text */
    contentImageText?: string;
    /** Content Image text */
    contentCards?: IHRBInfoCard[];
    /** Primary Button */
    primaryButton?: IHRBButtonContent;
    /** Secondary Button */
    secondaryButton?: IHRBButtonContent;
    /** Footer Link */
    footerLink?: IHRBLinkContent;
    /** Footer Text */
    footerText?: string;
    /** Theme */
    theme?: string;
}

/** Interface for info card component */
export interface IHRBInfoCard {
    /** Text */
    text?: string;
    /** Image url */
    imageUrl?: string;
}

/** Info action */
export type IHRBInfoAction = IHRBCommandAction;

/** Info component groups */
export enum HRBInfoGroups {
    Default = 'default',
    Header = 'header',
    Content = 'content',
    Footer = 'footer'
}

/** Info component types */
export enum HRBInfoTypes {
    /** Default page */
    Default = 'default',
    /** Header text */
    HeaderText = 'headerText',
    /** Header subtext */
    HeaderSubText = 'headerSubText',
    /** Content text */
    ContentText = 'contentText',
    /** Content subtext */
    ContentSubText = 'contentSubText',
    /** Content Image url */
    ContentImageUrl = 'contentImageUrl',
    /** Content Image text */
    ContentImageText = 'contentImageText',
    /** Content Image text */
    ContentCards = 'contentCards',
    /** Primary Button */
    PrimaryButton = 'primaryButton',
    /** Secondary Button */
    SecondaryButton = 'secondaryButton',
    /** Footer Link */
    FooterLink = 'footerLink',
    /** Footer Text */
    FooterText = 'footerText'
}
