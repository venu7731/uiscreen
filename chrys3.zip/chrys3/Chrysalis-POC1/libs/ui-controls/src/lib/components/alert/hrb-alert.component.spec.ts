import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBAlertComponent } from './hrb-alert.component';

describe('HRBAlertComponent', () => {
  let component: HRBAlertComponent;
  let fixture: ComponentFixture<HRBAlertComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBAlertComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBAlertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
