/** Drop down meta */
export interface IHRBSelect {
    /** description */
    description: string;
    /** options */
    options: IHRBSelectOption[];
    /** Form alias */
    alias?: string;
}

/** Drop down meta */
export interface IHRBSelectOption {
    /** Display */
    display: string;
    /** Value */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    value: any;
    /** selected */
    selected?: boolean;
}
