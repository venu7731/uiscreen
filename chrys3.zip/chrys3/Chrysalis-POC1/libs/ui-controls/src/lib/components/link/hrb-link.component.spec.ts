import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBLinkComponent } from './hrb-link.component';

describe('HrbLinkComponent', () => {
  let component: HRBLinkComponent;
  let fixture: ComponentFixture<HRBLinkComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBLinkComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBLinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
