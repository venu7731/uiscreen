import { getNewGuid, HRBEntityState, IHRBFormItem, IHRBFormSection } from '@chrysalis/core';

import { IHRBGridContent } from './hrb-grid.interface';

/** Function to add a new row to a Grid */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function addRowUtil(section: IHRBFormSection, data: any, params: any, formName: string) {
    let target: IHRBFormItem[] = [];
    const gridName = params.description;
    loop1:
    // eslint-disable-next-line @typescript-eslint/prefer-for-of
    for (let i = 0; i < section.groups.length; ++i) {
        // eslint-disable-next-line @typescript-eslint/prefer-for-of
        for (let j = 0; j < section.groups[i].layouts.length; ++j) {
            // eslint-disable-next-line @typescript-eslint/prefer-for-of
            for (let k = 0; k < section.groups[i].layouts[j].items.length; ++k) {
                if (section.groups[i].layouts[j].items[k].description === gridName) {
                    // eslint-disable-next-line @typescript-eslint/prefer-for-of
                    for (let l = 0; l < (section.groups[i].layouts[j].items[k] as IHRBGridContent).layouts.length; ++l) {
                        target = [...target, ...(section.groups[i].layouts[j].items[k] as IHRBGridContent).layouts[l].items];
                    }
                    break loop1;
                }
            }
        }
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const result: any = {};
    target.forEach((item) => {
        if (item.alias) {
            result[item.alias] = { dtl: false, prf: false, pval: null, val: null };
        }
    });
    result.EntityState = HRBEntityState.Added;
    result.ChildId = getNewGuid();
    const currentData = data[`Grid_${formName}_${gridName}`].Children;
    if (currentData === null) {
        result.Id = 0;
        result[`Grid_${formName}_${gridName}Id`] = 0;
        data[`Grid_${formName}_${gridName}`].Children = [result];
    } else {
        result.Id = currentData.length;
        result[`Grid_${formName}_${gridName}Id`] = result.Id;
        result.ChildId = getNewGuid();
        data[`Grid_${formName}_${gridName}`].Children.push(result);
    }
}