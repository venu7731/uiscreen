export * from './hrb-label.component';
export * from './hrb-label.interface';