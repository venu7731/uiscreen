import { each, first } from 'lodash-es';

import { DYNAMIC_CONTENT } from '@chrysalis/core';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function getProps<T>(items: any[], itemName: T, prop: string): any {
    let item = items.find(itm => itm.type === itemName);
    if (!item) {
        item = first(items);
    }
    return item[prop];
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function remapKeys(list: any, listMeta: any) {
    if (!list || !listMeta) {
        return null;
    }
    const keys = Object.keys(listMeta);
    const values: string[] = Object.values(listMeta);

    const returnObj = {};
    each(keys, (key, index) => {
        returnObj[key] = list[values[index]];
    });
    return returnObj;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function getMeta<T>(items: any[], itemName: T, fieldName?: string): any {
    let item;
    if (fieldName) {
        item = items.find(itm => itm.type === itemName && itm.fieldName === fieldName);
    } else {
        item = items.find(itm => itm.type === itemName);
    }
    if (!item) {
        return null;
    }
    return first(item.contentMeta);
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function contentMetaData<T>(self: any, itemName: T, prop: string, fieldName?: string) {
    const { appName, screenName, items } = self.metaData;
    const meta = getMeta<T>(items, itemName, fieldName);
    if (!meta) {
        return null;
    }
    const name = meta.type === DYNAMIC_CONTENT ? `${meta.name}-${self.state}` : meta.name;
    return self.originalContent[appName][screenName][name][meta[prop]];
}