import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

import { HRBBaseComponent } from '@chrysalis/core';

import { IHRBLabel } from './hrb-label.interface';

/**
 * Label component
 */
@Component({
  selector: 'hrb-label-wrapper',
  templateUrl: './hrb-label.component.html',
  styleUrls: ['./hrb-label.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBLabelComponent extends HRBBaseComponent {
  /** Text info */
  @Input() public item: IHRBLabel;
  /** Dummy init */
  protected init(): void {
  }
  /** Dummy destroy */
  protected destroy(): void {
  }
}
