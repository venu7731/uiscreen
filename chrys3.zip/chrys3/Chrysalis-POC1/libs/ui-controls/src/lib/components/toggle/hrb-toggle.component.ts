import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';

import { HRBBaseComponent } from '@chrysalis/core';

import { HRBToggleState, IHRBToggle, IHRBToggleAction } from './hrb-toggle.interface';

/** Toggle component */
@Component({
  selector: 'hrb-toggle-wrapper',
  templateUrl: './hrb-toggle.component.html',
  styleUrls: ['./hrb-toggle.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBToggleComponent extends HRBBaseComponent {
  /** Toggle info */
  @Input() public item: IHRBToggle;
  /** Button click event */
  @Output() public buttonClicked = new EventEmitter();

  public toggleState = HRBToggleState;

  /**
   * Emit button actions
   */
  public emitButtonClick(actions: IHRBToggleAction[]) {
    this.buttonClicked.emit(actions);
  }
  /** Dummy init */
  protected init(): void {
  }
  /** Dummy destroy */
  protected destroy(): void {
  }
}
