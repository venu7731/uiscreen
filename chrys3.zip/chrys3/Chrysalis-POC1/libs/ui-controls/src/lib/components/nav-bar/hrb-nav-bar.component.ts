import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { each } from 'lodash-es';

import { HRBBaseComponent } from '@chrysalis/core';

import { IHRBNavBarContent } from './hrb-nav-bar.interface';

/**
 * Nav bar component
 */
@Component({
  selector: 'hrb-nav-bar-wrapper',
  templateUrl: './hrb-nav-bar.component.html',
  styleUrls: ['./hrb-nav-bar.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBNavBarComponent extends HRBBaseComponent {

  /**
   * Nav bar content
   */
  @Input() public navContent: IHRBNavBarContent[];
  /**
   * Nav bar item clicked
   */
  @Output() public navContentClicked = new EventEmitter<number>();

  /**
   * Nav bar item clicked event
   */
  public linkClicked(evt: Event) {
    const target = (evt as CustomEvent)?.composedPath();
    if (target.length) {
      const text = (target[0] as HTMLLabelElement).innerText;
      each(this.navContent, (item, index, list) => {
        list[index].isSelected = false;
      });
      const currentIndex = this.navContent.findIndex((item) => item.text === text);
      this.navContent[currentIndex].isSelected = true;
      this.navContentClicked.emit(currentIndex);
    }
  }
  /** Dummy init */
  protected init(): void {
  }
  /** Dummy destroy */
  protected destroy(): void {
  }

}
