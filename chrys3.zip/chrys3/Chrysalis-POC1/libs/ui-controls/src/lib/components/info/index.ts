export * from './hrb-info.component';
export * from './hrb-info.interfaces';
