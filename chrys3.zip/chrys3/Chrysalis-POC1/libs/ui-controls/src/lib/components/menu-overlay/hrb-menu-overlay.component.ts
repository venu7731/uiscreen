import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, NgZone, Output } from '@angular/core';

import { HRBBaseComponent, HRBOverlayService } from '@chrysalis/core';

import { IHRBButtonContent } from '../button';

@Component({
  selector: 'hrb-menu-btn-popup',
  templateUrl: './hrb-menu-overlay.component.html',
  styleUrls: ['./hrb-menu-overlay.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBMenuOverlayComponent extends HRBBaseComponent {
  /** Button list */
  @Input() public buttonList: IHRBButtonContent[];
  /** Button clicked event */
  @Output() public buttonClicked = new EventEmitter<number>();
  /** is overlay open */
  public overlayOpen = false;

  /**
   * Constructor method
   * @param cdr ChangeDetectorRef
   * @param ngZone NgZone
   * @param overlayService HRBOverlayService
   */
  constructor(
    cdr: ChangeDetectorRef, ngZone: NgZone,
    private overlayService: HRBOverlayService) {
    super(cdr, ngZone);
  }

  /** Close overlay */
  public closeOverlay() {
    this.overlayService.updateOverlayStatus(false);
  }

  /** Emit clicked button index */
  public emitButtonClick(idx: number) {
    this.buttonClicked.emit(idx);
  }
  /** Listen for overlay changes */
  protected init(): void {
    this.addSafeSubscriber(this.overlayService.onOverlayStatus, (status: boolean) => {
      const callback = () => {
        this.overlayOpen = status;
      };
      this.render(callback);
    });
  }
  /** Dummy destroy */
  protected destroy(): void {
  }

}
