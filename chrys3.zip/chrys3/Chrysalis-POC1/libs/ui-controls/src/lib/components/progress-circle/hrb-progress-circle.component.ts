import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

import { HRBBaseComponent } from '@chrysalis/core';
/**
 * Progress circle component
 */
@Component({
  selector: 'hrb-progress-circle',
  templateUrl: './hrb-progress-circle.component.html',
  styleUrls: ['./hrb-progress-circle.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBProgressCircleComponent extends HRBBaseComponent {
  /**
   * Image url
   */
  @Input() public imgUrl: string;

  /** Dummy init */
  protected init(): void {
  }
  /** Dummy destroy */
  protected destroy(): void {
  }
}
