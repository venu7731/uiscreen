import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBSelectComponent } from './hrb-select.component';

describe('HRBSelectComponent', () => {
  let component: HRBSelectComponent;
  let fixture: ComponentFixture<HRBSelectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBSelectComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
