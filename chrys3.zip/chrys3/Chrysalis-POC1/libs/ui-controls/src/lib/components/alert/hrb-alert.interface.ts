import { IHRBButtonAction } from '../button';

/** Label meta */
export interface IHRBAlertContent {
    /** description */
    description: string;
    /** button text */
    buttonText?: string;
    /** button actions */
    actions?: IHRBButtonAction[];
    /** button actions */
    closeActions?: IHRBButtonAction[];
    /** button theme */
    buttonTheme?: string;
    /** theme */
    theme?: string;
}
