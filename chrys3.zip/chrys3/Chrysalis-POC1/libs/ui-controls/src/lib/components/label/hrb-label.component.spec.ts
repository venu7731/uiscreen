import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBLabelComponent } from './hrb-label.component';

describe('HRBLabelComponent', () => {
  let component: HRBLabelComponent;
  let fixture: ComponentFixture<HRBLabelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBLabelComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBLabelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
