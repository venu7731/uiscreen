/** Nav bar content */
export interface IHRBNavBarContent {
    /** Text */
    text: string;
    /** Is selected */
    isSelected?: boolean;
    /** Icon */
    icon?: string;
    /** disabled */
    disabled?: boolean;
}