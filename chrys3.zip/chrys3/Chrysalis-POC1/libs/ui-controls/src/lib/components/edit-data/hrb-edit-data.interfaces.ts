import { IHRBCommandAction, IHRBFormSection } from '@chrysalis/core';

import { IHRBButtonContent } from '../button';

/** Interface for Edit Data component */
export interface IHRBEditData {
    /** Header text */
    headerText?: string;
    /** Header subtext */
    infoCard?: IHRBInfoCard;
    /** Dynamic form */
    dynamicForm?: IHRBFormSection;
    /** Primary Button */
    primaryButton?: IHRBButtonContent;
    /** Theme */
    theme?: string;
}

/** Info card */
export interface IHRBInfoCard {
    /** Header text */
    headerText?: string;
    /** Alias name */
    alias?: string;
}

/** Edit Data action */
export type IHRBEditDataAction = IHRBCommandAction;

/** Edit Data component types */
export enum HRBEditDataTypes {
    /** Default page */
    Default = 'default',
    /** Header text */
    HeaderText = 'headerText',
    /** Info card */
    InfoCard = 'infoCard',
    /** Dynamic form */
    DynamicForm = 'dynamicForm',
    /** Primary Button */
    PrimaryButton = 'primaryButton'
}
