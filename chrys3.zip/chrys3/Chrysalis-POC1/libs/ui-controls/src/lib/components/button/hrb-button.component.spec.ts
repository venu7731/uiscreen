import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBButtonComponent } from './hrb-button.component';

describe('HRBButtonComponent', () => {
  let component: HRBButtonComponent;
  let fixture: ComponentFixture<HRBButtonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBButtonComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
