import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBTaskComponent } from './hrb-task.component';

describe('HRBTaskComponent', () => {
  let component: HRBTaskComponent;
  let fixture: ComponentFixture<HRBTaskComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBTaskComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
