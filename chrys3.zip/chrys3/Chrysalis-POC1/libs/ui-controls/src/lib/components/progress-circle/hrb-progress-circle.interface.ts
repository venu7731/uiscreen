/** Progress content */
export interface IHRBProgressContent {
    /** Image url */
    imgUrl: string;
}