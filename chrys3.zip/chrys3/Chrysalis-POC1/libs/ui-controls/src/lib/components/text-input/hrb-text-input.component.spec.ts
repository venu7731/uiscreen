import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBTextInputComponent } from './hrb-text-input.component';

describe('HRBTextInputComponent', () => {
  let component: HRBTextInputComponent;
  let fixture: ComponentFixture<HRBTextInputComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBTextInputComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBTextInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
