import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBToggleComponent } from './hrb-toggle.component';

describe('HRBToggleComponent', () => {
  let component: HRBToggleComponent;
  let fixture: ComponentFixture<HRBToggleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBToggleComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBToggleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
