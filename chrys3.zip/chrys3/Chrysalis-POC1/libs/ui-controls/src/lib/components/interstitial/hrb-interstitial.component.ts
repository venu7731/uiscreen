import { ChangeDetectionStrategy, EventEmitter, Component, Input, Output } from '@angular/core';
import { cloneDeep } from 'lodash-es';

import { HRBBaseComponent, getFormattedMessages } from '@chrysalis/core';

import { InterstitialDuration, States } from './hrb-interstitial.constants';
import { HRBInterstitialTypes, IHRBInterstitial, IHRBInterstitialAction } from './hrb-interstitial.interfaces';
import { contentMetaData, getMeta } from '../utilities/hrb-composer-utils';

/**
 * Interstitial component
 */
@Component({
    selector: 'hrb-interstitial',
    templateUrl: './hrb-interstitial.component.html',
    styleUrls: ['./hrb-interstitial.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBInterstitialComponent extends HRBBaseComponent {
    /** Content */
    @Input()
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public set content(val: any) {
        if (val) {
            this.originalContent = cloneDeep(val);
        }
    }
    /** Meta data */
    @Input()
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public set metaData(val: any) {
        if (val) {
            this.pMetaData = val;
            this.processMetaData();
        }
    }
    public get metaData() {
        return this.pMetaData;
    }
    /** Data */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    @Input() public data: any;
    /** Passing action data  */
    @Output() public actionEvent = new EventEmitter<IHRBInterstitialAction[]>();
    /** Interstitial content */
    public interstitialContent: IHRBInterstitial;
    /** Original Content */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public originalContent: any;
    /** HRBInterstitial Types */
    public HRBInterstitialTypes = HRBInterstitialTypes;
    /** Interstitial Set Initially */
    private state = States.Pause;
    /** Timer interval */
    private interval;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    private pMetaData: any;

    /** Event for pause Button */
    public onCompleted() {
        if (this.state === States.Pause) {
            this.showPlayButton();
        } else {
            this.state = States.Pause;
            this.actionEvent.emit(getMeta<HRBInterstitialTypes>(this.metaData.items, HRBInterstitialTypes.FooterImage)?.actions);
        }
    }

    /** Dummy init */
    protected init(): void { }
    /** Clear the timeout */
    protected destroy(): void {
        if (this.interval) {
            clearTimeout(this.interval);
        }
    }

    private processMetaData() {
        this.interstitialContent = {
            headerText: getFormattedMessages(contentMetaData<HRBInterstitialTypes>(this, HRBInterstitialTypes.HeaderText, 'headerText'),
                this.data),
            theme: `container--${contentMetaData<HRBInterstitialTypes>(this, HRBInterstitialTypes.Default, 'theme')}`,
            footerIconUrl: contentMetaData<HRBInterstitialTypes>(this, HRBInterstitialTypes.FooterImage, 'footerIconUrl'),
            subText: contentMetaData<HRBInterstitialTypes>(this, HRBInterstitialTypes.SubText, 'subText'),
            contentImageUrl: contentMetaData<HRBInterstitialTypes>(this, HRBInterstitialTypes.ContentImage, 'contentImageUrl'),
            duration: contentMetaData<HRBInterstitialTypes>(this, HRBInterstitialTypes.Default, 'duration') || InterstitialDuration
        };
        if (this.interval) {
            clearTimeout(this.interval);
        }
        this.interval = setTimeout(() => {
            this.actionEvent.emit(getMeta<HRBInterstitialTypes>(this.metaData.items, HRBInterstitialTypes.FooterImage)?.actions);
        }, this.interstitialContent.duration);
    }
    /** Event Starts after play button*/
    private showPlayButton() {
        this.state = States.Play;
        this.interstitialContent.footerIconUrl = contentMetaData<HRBInterstitialTypes>(this, HRBInterstitialTypes.FooterImage,
            'footerIconUrl');
        if (this.interval) {
            clearTimeout(this.interval);
        }
    }

}