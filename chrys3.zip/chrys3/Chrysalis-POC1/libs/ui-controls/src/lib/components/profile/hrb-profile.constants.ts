/** Profile Button states */
export const ProfileButtonStates = {
    Unchanged: 'unchanged',
    Changed: 'changed'
};