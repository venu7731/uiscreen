import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';

import { HRBBaseComponent } from '@chrysalis/core';

import { IHRBCheckboxContent } from './hrb-checkbox.interface';

@Component({
  selector: 'hrb-checkbox-wrapper',
  templateUrl: './hrb-checkbox.component.html',
  styleUrls: ['./hrb-checkbox.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBCheckboxComponent extends HRBBaseComponent {
  /** Checkbox content */
  @Input() public item: IHRBCheckboxContent;
  /** Text data */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  @Input() public data: any;
  /** Emit data changed */
  @Output() public emitDataChanged = new EventEmitter<string>();
  /** Update changes */
  public updateChanges(name: string) {
    this.emitDataChanged.emit(name);
  }
  /** Dummy init */
  protected init(): void { }
  /** Dummy destroy */
  protected destroy(): void {
  }
}