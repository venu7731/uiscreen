import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BdsNgModule } from '@bds/bds-ng';

import { HRBInterstitialComponent } from './components/interstitial/hrb-interstitial.component';
import { HRBProgressCircleComponent } from './components/progress-circle/hrb-progress-circle.component';
import { HRBNavBarComponent } from './components/nav-bar/hrb-nav-bar.component';
import { HRBTaskComponent } from './components/task/hrb-task.component';
import { HRBTextInputComponent } from './components/text-input/hrb-text-input.component';
import { HRBLabelComponent } from './components/label/hrb-label.component';
import { HRBAlertComponent } from './components/alert/hrb-alert.component';
import { HRBSelectComponent } from './components/select/hrb-select.component';
import { HRBCheckboxComponent } from './components/checkbox/hrb-checkbox.component';
import { HRBButtonComponent } from './components/button/hrb-button.component';
import { HRBDynamicFormComponent } from './components/dynamic-form/hrb-dynamic-form.component';
import { HRBMenuOverlayComponent } from './components/menu-overlay/hrb-menu-overlay.component';
import { HRBGridComponent } from './components/grid/hrb-grid.component';
import { HRBLinkComponent } from './components/link/hrb-link.component';
import { HRBToggleComponent } from './components/toggle/hrb-toggle.component';
import { HRBUiComposerComponent } from './components/ui-composer/hrb-ui-composer.component';
import { HRBInfoComponent } from './components/info/hrb-info.component';
import { HRBProfileComponent } from './components/profile/hrb-profile.component';
import { HRBEditDataComponent } from './components/edit-data/hrb-edit-data.component';

const COMPONENTS = [
    HRBInterstitialComponent, HRBProgressCircleComponent,
    HRBNavBarComponent, HRBTaskComponent, HRBTextInputComponent, HRBLabelComponent,
    HRBAlertComponent, HRBSelectComponent, HRBCheckboxComponent, HRBButtonComponent, HRBDynamicFormComponent,
    HRBMenuOverlayComponent, HRBGridComponent, HRBLinkComponent, HRBToggleComponent, HRBUiComposerComponent,
    HRBInfoComponent, HRBProfileComponent, HRBEditDataComponent
];
@NgModule({
    imports: [CommonModule, BdsNgModule, FormsModule],
    declarations: COMPONENTS,
    exports: COMPONENTS,
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class UiControlsModule { }
