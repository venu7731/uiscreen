import * as process from 'process'

import { stringToDashCase } from '../src/utils/strings'

import environment from '../src/constants/environment'
import * as styleConstants from '../src/constants/styles'
import assetUrls from '../src/constants/asset-urls'

import {
  createDirectory,
  createFile,
  generateSassVariables,
  lineBreak,
} from './utils'

// Lists the keys of the files in which a map of the variables will also
// be generated and included
const constantsWithMaps = ['colors', 'spacing']
const constantsAsListOnly = ['icons']

// any object here will be converted to Sass on every release
const constantsForBuildOnReleaseProcess = { assetUrls }

// any object in this array will be converted to a string before being written to Sass
const constantObjectsToConvertToStrings = [assetUrls]
const keyListFromConstantsToConvertToStrings = constantObjectsToConvertToStrings.map(
  object => Object.keys(object),
)
// flatten the array created above
const valuesToConvertToStrings = [].concat(
  ...keyListFromConstantsToConvertToStrings,
)

const destinationDirectory = process.argv[2]
const isRelease =
  !!process.argv[3] &&
  (process.argv[3] === `--${environment.qa}` ||
    process.argv[3] === `--${environment.prod}`)

const constantsToConvert = isRelease
  ? constantsForBuildOnReleaseProcess
  : styleConstants

const constantsKeys = Object.keys(constantsToConvert)

if (!destinationDirectory) {
  // eslint-disable-next-line no-console
  console.error('Missing argument: <destinationDirectory>')
  process.exit(1)
}

if (!constantsKeys) {
  // eslint-disable-next-line no-console
  console.error('Missing argument: <constantsKeys>')
  process.exit(1)
}

const doNotEditWarning = 'DO NOT MANUALLY EDIT THIS FILE'
const fileDescription = (key: string): string =>
  `// ${doNotEditWarning}, this file is auto-generated.${lineBreak}// To add varibles refer to '/src/constants/${key}.ts'${lineBreak}// and '/src/constants/styles.ts'${lineBreak}// Then use 'npm run generate-sass-variables'`

createDirectory(destinationDirectory)

constantsKeys.forEach((key: string): void => {
  const dashCaseKey = stringToDashCase(key)
  const values = constantsToConvert[key]
  const keys = Object.keys(values)
  const variables = generateSassVariables(
    keys,
    values,
    valuesToConvertToStrings,
  ).join(lineBreak)
  let variableMap = ''
  let listMap = ''

  if (constantsWithMaps.includes(key)) {
    const map = generateSassVariables(
      keys,
      values,
      valuesToConvertToStrings,
      true,
    ).join(lineBreak)
    variableMap = `${lineBreak}$${key}-map: (${lineBreak}${map}${lineBreak});${lineBreak}`
  }

  if (constantsAsListOnly.includes(key)) {
    const icons = JSON.stringify(values)
      .replace('[', '(')
      .replace(']', ')')
    listMap = `${lineBreak}$${key}: ${icons};${lineBreak}`
  }

  const topComments = fileDescription(dashCaseKey)
  const bottomComments = `// ${doNotEditWarning}${lineBreak}`

  const sassVariables = `${lineBreak}${lineBreak}${variables}${lineBreak}${variableMap}${lineBreak}`
  const iconsAsList = key === 'icons' && `${lineBreak}${listMap}${lineBreak}`
  const variableOrList = iconsAsList || sassVariables

  const contents = `${topComments}${variableOrList}${bottomComments}`
  const fileName = `_${dashCaseKey}.scss`

  createFile(`${destinationDirectory}/`, fileName, contents)
})
