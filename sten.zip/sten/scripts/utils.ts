import * as fs from 'fs'

import { stringToDashCase } from '../src/utils/strings'

export const lineBreak = '\n'

export const createDirectory = (directory: string): void => {
  if (!fs.existsSync(directory)) {
    fs.mkdirSync(directory)
  }
}

export const createFile = (
  path: string,
  fileName: string,
  contents: string,
): void => {
  const fileEncodingOptions: any = { encoding: 'utf8' }

  fs.writeFileSync(`${path}${fileName}`, contents, fileEncodingOptions)
}

export const generateSassVariables = (
  keys: string[],
  values: {},
  valuesToConvertToStrings: string[],
  isMap = false,
): string[] =>
  keys.map(valuesKey => {
    const dashCaseValueKey = stringToDashCase(valuesKey)
    // Using quotes in Sass map keys to avoid possible errors
    const valueKey = isMap ? `"${dashCaseValueKey}"` : dashCaseValueKey

    const value = values[valuesKey]
    const willSaveAsString = valuesToConvertToStrings.includes(valuesKey)

    const sassValue = willSaveAsString ? "'" + value.trim() + "'" : value
    const prefix = isMap ? `  ` : '$'
    const separator = isMap ? ',' : ';'

    return `${prefix}${valueKey}: ${sassValue}${separator}`
  })
