import * as fs from 'fs'
import * as process from 'process'
import * as util from 'util'

import * as styleConstants from '../src/constants/styles'
import assetUrls from '../src/constants/asset-urls'

import config from './build-config'
import {
  createDirectory,
  createFile,
  generateSassVariables,
  lineBreak,
} from './utils'

// any object in this array will be converted to a string before being written to Sass
const constantObjectsToConvertToStrings = [assetUrls]
const keyListFromConstantsToConvertToStrings = constantObjectsToConvertToStrings.map(
  object => Object.keys(object),
)
// flatten the array created above
const valuesToConvertToStrings = [].concat(
  ...keyListFromConstantsToConvertToStrings,
)

const constantsKeys = Object.keys(styleConstants)

if (!constantsKeys) {
  // eslint-disable-next-line no-console
  console.error('Missing argument: <constantsKeys>')
  process.exit(1)
}

const jsConstantsContent = (): string => {
  const { jsConstants } = config

  const jsConstantsFile = Object.keys(jsConstants)
    .map((key: string): string => {
      const values = jsConstants[key]

      const constantsObject = `${lineBreak} export const ${key} = ${util.inspect(
        values,
        {
          compact: false,
        },
      )}${lineBreak}`

      return constantsObject
    })
    .join(' ')

  return jsConstantsFile
}

const sassMixinsContent = (): string => {
  const { sassMixinFiles } = config

  const sassMixinFileContent = sassMixinFiles
    .map(sassPath => {
      const path = `${process.cwd()}/${sassPath}`
      const file = fs.readFileSync(path, { encoding: 'utf8' })

      return file
    })
    .join(' ')

  const contentString = `@import './constants';${lineBreak}${lineBreak}${sassMixinFileContent}`

  return contentString
}

const sassVariablesContent = (): string => {
  const { jsToSassVariables } = config

  const sassVariablesFile = Object.keys(jsToSassVariables)
    .map((key: string): string => {
      const values = jsToSassVariables[key]
      let sassVariables = null

      // icons or any array variables
      if (Array.isArray(values)) {
        const sassValue = JSON.stringify(values)
          .replace('[', '(')
          .replace(']', ')')

        sassVariables = `$${key}:${sassValue}`
      } else {
        // classic variables
        const keys = Object.keys(values)

        sassVariables = generateSassVariables(
          keys,
          values,
          valuesToConvertToStrings,
        ).join(lineBreak)
      }

      const sassVariableOutput = `${lineBreak}// ${key}${lineBreak}${sassVariables}${lineBreak}`

      return sassVariableOutput
    })
    .join(' ')

  return sassVariablesFile
}

createDirectory(config.destinationDirectory)

createFile(
  `${config.destinationDirectory}/`,
  '_constants.scss',
  sassVariablesContent(),
)
createFile(
  `${config.destinationDirectory}/`,
  '_mixins.scss',
  sassMixinsContent(),
)
createFile(`${config.destinationDirectory}/`, 'index.js', jsConstantsContent())
