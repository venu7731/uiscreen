/* eslint-disable no-console, consistent-return, func-style */
import * as fs from 'fs-extra'

function modifyPackage(err, data): void {
  if (err) return console.log(err)
  const parsedData = JSON.parse(data)
  delete parsedData.devDependencies
  delete parsedData.dependencies
  delete parsedData.scripts
  fs.writeFileSync(
    './publish/package.json',
    JSON.stringify(parsedData, null, 2),
  )
  fs.copyFileSync('./README.md', './publish/README.md')
  fs.copyFileSync('./LICENSE', './publish/LICENSE')
  fs.copyFileSync('./tools/.npmrc', './publish/.npmrc')
}

function readPackage(err): void {
  if (err) return console.log(err)
  fs.readFile('./package.json', modifyPackage)
}

function moveFolders(err): void {
  if (err) return console.log(err)
  fs.move(this.src, this.dest, this.callback)
}

fs.mkdir(
  './publish',
  moveFolders.bind({
    src: './dist/',
    dest: './publish/dist/',
    callback: moveFolders.bind({
      src: './constants/',
      dest: './publish/constants/',
      callback: moveFolders.bind({
        src: './loader/',
        dest: './publish/loader/',
        callback: readPackage,
      }),
    }),
  }),
)
