import * as styleConstants from '../src/constants/styles'
import * as textStyles from '../src/constants/text-styles'
import icons from '../src/constants/icons'

const sassBasePath = `/src/sass`

// These files will be exposed to the top-level of the npm package
// via the generate-build-variables process
const config = {
  destinationDirectory: 'constants',
  jsConstants: { ...styleConstants, ...textStyles, icons },
  jsToSassVariables: { ...styleConstants },
  sassMixinFiles: [
    `${sassBasePath}/tools/_grid.scss`,
    `${sassBasePath}/tools/_media-queries.scss`,
    `${sassBasePath}/tools/_typography.scss`,
    `${sassBasePath}/tools/_animations.scss`,
    `${sassBasePath}/settings/_spacing.scss`,
  ],
}

export default config
