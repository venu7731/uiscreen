/* eslint-disable */

import * as SVGSpriter from 'svg-sprite'
import * as fs from 'fs-extra'
import * as path from 'path'
import * as util from 'util'

import { createFile, lineBreak } from './utils'

const config = {
  dest: path.resolve(__dirname, '../src/assets/svg-sprite'), // Main output directory
  log: null, // Logging verbosity (default: no logging)
  shape: {
    // SVG shape related options
    id: {
      // SVG shape ID related options
      separator: '--', // Separator for directory name traversal
      generator: function(name) {
        return (
          'hrb-icon--' +
          path.basename(name.split(path.sep).join(this.separator), '.svg')
        )
      }, // SVG shape ID generator callback
      pseudo: '~', // File name separator for shape states (e.g. ':hover')
    },
    dimension: {
      // Dimension related options
      maxWidth: 2000, // Max. shape width
      maxHeight: 2000, // Max. shape height
      precision: 2, // Floating point precision
      attributes: false, // Width and height attributes on embedded shapes
    },
    spacing: {
      // Spacing related options
      padding: 0, // Padding around all shapes
      box: 'content', // Padding strategy (similar to CSS `box-sizing`)
    },
    transform: ['svgo'], // List of transformations / optimizations
    meta: null, // Path to YAML file with meta / accessibility data
    align: null, // Path to YAML file with extended alignment data
    dest: null, // Output directory for optimized intermediate SVG shapes
  },
  svg: {
    // General options for created SVG files
    xmlDeclaration: true, // Add XML declaration to SVG sprite
    doctypeDeclaration: true, // Add DOCTYPE declaration to SVG sprite
    namespaceIDs: true, // Add namespace token to all IDs in SVG shapes
    namespaceClassnames: false, // Add namespace token to all CSS class names in SVG shapes
    dimensionAttributes: true, // Width and height attributes on the sprite
  },
  mode: {
    defs: true, // Prepare for inline embedding
    symbol: true, // Create a «symbol» sprite
  },
  // variables: {} // Custom Mustache templating variables and functions
}

// Create spriter instance (see below for `config` examples)

const spriter = new SVGSpriter(config)

const iconsSrc = path.resolve(__dirname, '../src/assets/icons')
const iconNameArray = []

fs.readdirSync(iconsSrc).forEach((file: string): void => {
  const iconSrc = path.resolve(iconsSrc, file)

  spriter.add(iconSrc, file, fs.readFileSync(iconSrc, { encoding: 'utf-8' }))
  iconNameArray.push(file.replace('.svg', ''))
})

const getIconConstantsContent = (): string => {
  const doNotEditWarning = 'DO NOT MANUALLY EDIT THIS FILE'
  const fileDescription = `// ${doNotEditWarning}, this file is auto-generated.${lineBreak}// To add new icons place svg file in /src/assets/icons${lineBreak}// and run 'npm run generate-svg-sprites'`

  const iconsConstant = `${lineBreak}const icons = ${util.inspect(
    iconNameArray,
    {
      compact: false,
    },
  )}${lineBreak}${lineBreak}export default icons${lineBreak}`

  return `${fileDescription}${lineBreak}${iconsConstant}${lineBreak}${fileDescription}${lineBreak}`
}

createFile('src/constants/', 'icons.ts', getIconConstantsContent())

spriter.compile((error: string, result: object) => {
  /* Write `result` files to disk (or do whatever with them ...) */
  // console.log('result', result);
  if (error) {
    console.error(`error while compiling svg: ${error}`)
  }
  for (var mode in result) {
    for (var resource in result[mode]) {
      // console.log('resource', resource);
      fs.mkdirp(path.dirname(result[mode][resource].path))
      fs.writeFileSync(
        result[mode][resource].path,
        result[mode][resource].contents,
      )
    }
  }
})
