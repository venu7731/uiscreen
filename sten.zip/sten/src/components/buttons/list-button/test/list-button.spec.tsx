import { newSpecPage } from '@stencil/core/testing'

import { ListButton } from '../list-button'

describe('List Button', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [ListButton],
      html: `
        <hrb-list-button disabled outlined theme="white-light-grey-1" metadata="Feb 25">Sed et egestas</hrb-list-button>
      `,
    })
    expect(page.root).toEqualHtml(`
      <hrb-list-button disabled="" metadata="Feb 25" outlined="" theme="white-light-grey-1">
        <button aria-disabled="true" class="hrb-list-button hrb-list-button--disabled hrb-list-button--metadata hrb-list-button--outlined hrb-list-button--white-light-grey-1" disabled="">
          <span class="hrb-list-button__container">
            <span class="hrb-list-button__text">
              <hrb-text style-type="cta-small">
                Sed et egestas
              </hrb-text>
              <hrb-text style-type="metadata">
                Feb 25
              </hrb-text>
            </span>
            <span class="hrb-list-button__icon">
              <hrb-circled size="x-small">
                <hrb-icon name="check"></hrb-icon>
              </hrb-circled>
            </span>
          </span>
        </button>
      </hrb-list-button>
    `)
  })
})
