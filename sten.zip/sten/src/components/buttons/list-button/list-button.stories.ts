import { boolean, select, text, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import {
  buttonTypes,
  groupIds,
  listButtonThemes,
  reset,
  targets,
} from '@src/constants/storybook'
import icons from '@src/constants/icons'

import * as readme from './readme.md'

/* eslint-disable-next-line */
const listButton = (
  buttonText,
  ariaLabel,
  ariaLabelledBy,
  ariaRole,
  as,
  circled,
  disabled,
  href,
  icon,
  metadata,
  outlined,
  rel,
  target,
  theme,
  type,
) =>
  `<hrb-list-button 
    p-aria-label="${ariaLabel}" 
    p-aria-labelled-by="${ariaLabelledBy}" 
    p-aria-role="${ariaRole}" 
    as="${as}" 
    circled="${circled}" 
    ${disabled ? 'disabled' : ''} 
    href="${href}" 
    icon="${icon}" 
    metadata="${metadata}" 
    outlined="${outlined}" 
    ${rel ? `rel="${rel}"` : ''} 
    target="${target}" 
    theme="${theme}"
    ${type ? `type="${type}"` : ''}>
      ${buttonText}
  </hrb-list-button>`

const wrapperOpen = `${reset}<div style="padding: 30px">`
const wrapperClose = `</div>`

storiesOf('Buttons/List Buttons', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-list-button'],
    notes: { markdown: readme },
  })
  .add('List Button', () => {
    return `${wrapperOpen}${listButton(
      text('Text', 'Sed et egestas', groupIds.testable),
      text('Aria Label', 'Button label', groupIds.aria),
      text('Aria Labelled By', 'Button labelled by', groupIds.aria),
      text('Aria Role', 'button', groupIds.aria),
      select('As', buttonTypes, buttonTypes[1], groupIds.testable),
      boolean('Circled', true, groupIds.testable),
      boolean('Disabled', false, groupIds.testable),
      text('Href', 'https://www.hrblock.com/', groupIds.testable),
      select('Icon', icons, icons[15], groupIds.testable),
      text('Metadata', 'Feb 25', groupIds.testable),
      boolean('Outlined', false, groupIds.testable),
      text('Rel', '', groupIds.additional),
      select('Target', targets, targets[0], groupIds.testable),
      select('Theme', listButtonThemes, listButtonThemes[0], groupIds.testable),
      text('Type', '', groupIds.additional),
    )}${wrapperClose}`
  })
