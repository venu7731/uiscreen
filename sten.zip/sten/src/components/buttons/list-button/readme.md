# hrb-list-button

The `hrb-list-button` is very similar to `hrb-button` in terms of behavior, but specific enough to be its own component.

`hrb-list-button` can be used to render a list `button` (default). Use the `as` props to change the main rendered element: `button`, `a` or `span`.

📝 Note:

- If you want to render an `a` element, don't forget to pass the `href`, `target` and `rel` props.
- We recommend to render a `span` if you only want a styled component with no interactive elements.

## Examples

`hrb-list-button` accept a variety of icons with the `icon` prop. If one is not passed, the check icon is used by default.

```html
<hrb-list-button icon="plus">Add an account</hrb-list-button>
```

The icon is circled by default, but can be removed using the `circled` prop.

```html
<hrb-list-button icon="plus" circled="false">
  Add an account
</hrb-list-button>
```

---

`hrb-list-button` can display an outline if needed with the `outlined` prop. The outline color is determined by the background hover color.

```html
<hrb-list-button icon="plus" outlined>
  Add an account
</hrb-list-button>
```

---

`hrb-list-button` accepts a `metadata` prop to render an additional text below the main one.

```html
<hrb-list-button icon="check" outlined metadata="Feb 25">
  Added an account
</hrb-list-button>
```

---

`hrb-list-button` can use a variety of themes, listed below, with the `theme` prop.

```html
<hrb-list-button theme="green">Button Text</hrb-list-button>
```

List of available themes:

- `green`
- `yellow`
- `blue`
- `white`
- `white-light-grey-1`
- `white-yellow`
- `white-green`
- `white-blue`
- `white-light-grey-2`
- `light-grey-1`
- `light-grey-1-yellow`
- `light-grey-1-green`
- `light-grey-1-blue`

📝 Note: The `white` and `light-grey-1` theme make the icon background transparent.
The themes follow the convention of the first color being the button background color and the second color being the background of the icon.

---

`hrb-list-button` can be disabled with the `disabled` prop.

```html
<hrb-list-button disabled>A disabled Button</hrb-list-button>
```

📝 Note: the `disabled` prop also automatically adds `aria-disabled="true"` on to the element.

<!-- Auto Generated Below -->


## Properties

| Property          | Attribute           | Description                                          | Type                                                                                                                                                                                                                                    | Default     |
| ----------------- | ------------------- | ---------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------- |
| `as`              | `as`                | Sets tag for button (defaults to <button />)         | `"a" \| "button" \| "span"`                                                                                                                                                                                                             | `'button'`  |
| `circled`         | `circled`           | Applies circled style to button (defaults to true)   | `boolean`                                                                                                                                                                                                                               | `true`      |
| `disabled`        | `disabled`          | Sets button to disabled                              | `boolean`                                                                                                                                                                                                                               | `false`     |
| `href`            | `href`              | Applies optional href attribute                      | `string`                                                                                                                                                                                                                                | `undefined` |
| `icon`            | `icon`              | Adds an icon to the button (defaults to 'check')     | `string`                                                                                                                                                                                                                                | `'check'`   |
| `metadata`        | `metadata`          | Sets metadata content to button                      | `string`                                                                                                                                                                                                                                | `undefined` |
| `outlined`        | `outlined`          | Applies outlined style to button (defaults to false) | `boolean`                                                                                                                                                                                                                               | `false`     |
| `pAriaLabel`      | `p-aria-label`      | Applies `aria-label` to button                       | `string`                                                                                                                                                                                                                                | `undefined` |
| `pAriaLabelledby` | `p-aria-labelledby` | Applies `aria-labelledby` to button                  | `string`                                                                                                                                                                                                                                | `undefined` |
| `pAriaRole`       | `p-aria-role`       | Applies `aria-role` to button                        | `string`                                                                                                                                                                                                                                | `undefined` |
| `rel`             | `rel`               | Applies optional rel attribute                       | `string`                                                                                                                                                                                                                                | `undefined` |
| `target`          | `target`            | Applies optional target attribute                    | `string`                                                                                                                                                                                                                                | `undefined` |
| `theme`           | `theme`             | Applies color theme (defaults to white)              | `"blue" \| "green" \| "light-grey-1" \| "light-grey-1-blue" \| "light-grey-1-green" \| "light-grey-1-yellow" \| "white" \| "white-blue" \| "white-green" \| "white-light-grey-1" \| "white-light-grey-2" \| "white-yellow" \| "yellow"` | `'white'`   |
| `type`            | `type`              | Applies type attribute                               | `string`                                                                                                                                                                                                                                | `undefined` |


## Dependencies

### Depends on

- [hrb-icon](../../icon)
- [hrb-circled](../../circled)
- [hrb-text](../../text)

### Graph
```mermaid
graph TD;
  hrb-list-button --> hrb-icon
  hrb-list-button --> hrb-circled
  hrb-list-button --> hrb-text
  style hrb-list-button fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
