import { Component, h, Host, Prop } from '@stencil/core'

import { getClassnames } from '@src/utils/misc'
import { getIsValidButtonType, getIsValidIcon } from '@src/utils/validations'

import buttonTypes from '@src/constants/button-types'

import { TListButtonThemes, TListButtonTypes } from './types'

const Constants = {
  baseClassname: 'hrb-list-button',
}

@Component({
  tag: 'hrb-list-button',
  styleUrl: 'list-button.scss',
})
export class ListButton {
  /**
   * Applies `aria-label` to button
   */
  @Prop({ attribute: 'p-aria-label' }) pAriaLabel: string

  /**
   * Applies `aria-labelledby` to button
   */
  @Prop({ attribute: 'p-aria-labelledby' }) pAriaLabelledby: string

  /**
   * Applies `aria-role` to button
   */
  @Prop({ attribute: 'p-aria-role' }) pAriaRole: string

  /**
   * Sets tag for button (defaults to <button />)
   */
  @Prop() as: TListButtonTypes = 'button'

  /**
   * Applies optional target attribute
   */
  @Prop() target: string

  /**
   * Applies optional rel attribute
   */
  @Prop() rel: string

  /**
   * Applies optional href attribute
   */
  @Prop() href: string

  /**
   * Sets button to disabled
   */
  @Prop() disabled = false

  /**
   * Applies type attribute
   */
  @Prop() type: string

  /**
   * Applies circled style to button (defaults to true)
   */
  @Prop() circled = true

  /**
   * Applies outlined style to button (defaults to false)
   */
  @Prop() outlined = false

  /**
   * Adds an icon to the button (defaults to 'check')
   */
  @Prop() icon = 'check'

  /**
   * Sets metadata content to button
   */
  @Prop() metadata: string

  /**
   * Applies color theme (defaults to white)
   */
  @Prop() theme: TListButtonThemes = 'white'

  componentWillLoad(): void {
    this.validateIcon()
    this.validateLinkType()
  }

  validateIcon(): void {
    const { icon } = this
    const isValidIcon = getIsValidIcon(icon)

    if (!isValidIcon) {
      this.throwConsoleError(icon, 'icon')
    }
  }

  validateLinkType(): void {
    const { as } = this
    const isValidLinkType = getIsValidButtonType(as)

    if (!isValidLinkType) {
      this.throwConsoleError(as, 'type')
    }
  }

  throwConsoleError(val: string, prop: string): void {
    // eslint-disable-next-line no-console
    console.error(
      `<hrb-list-button /> : "${val}" is not a valid button ${prop}`,
    )
  }

  getProps = (): object => {
    const {
      pAriaLabel,
      pAriaLabelledby,
      pAriaRole,
      as,
      disabled,
      href,
      rel,
      target,
      type,
    } = this

    const isAnchor = as === buttonTypes.anchor
    const isButton = as === buttonTypes.button

    const sharedProps = {
      'aria-label': pAriaLabel,
      'aria-labelledby': pAriaLabelledby,
      'aria-role': pAriaRole,
      'aria-disabled': disabled.toString(),
    }

    if (isAnchor) {
      return {
        ...sharedProps,
        href,
        rel,
        target,
      }
    }

    if (isButton) {
      return {
        ...sharedProps,
        type,
        disabled,
      }
    }

    return {
      ...sharedProps,
    }
  }

  renderIcon(): JSX.Element {
    const { icon } = this

    return <hrb-icon name={icon}></hrb-icon>
  }

  renderCircledIcon(): JSX.Element {
    return <hrb-circled size="x-small">{this.renderIcon()}</hrb-circled>
  }

  renderMetadata(): JSX.Element {
    const { metadata } = this

    return <hrb-text style-type="metadata">{metadata}</hrb-text>
  }

  render(): JSX.Element {
    const { circled, disabled, metadata, outlined, theme } = this
    const hasMetadata = !!metadata
    const props = this.getProps()

    const classes = getClassnames([
      `${Constants.baseClassname}`,
      !circled && `${Constants.baseClassname}--transparent-circle`,
      disabled && `${Constants.baseClassname}--disabled`,
      hasMetadata && `${Constants.baseClassname}--metadata`,
      outlined && `${Constants.baseClassname}--outlined`,
      theme && `${Constants.baseClassname}--${theme}`,
    ])

    return (
      <Host>
        <this.as class={classes} {...props}>
          <span class={`${Constants.baseClassname}__container`}>
            <span class={`${Constants.baseClassname}__text`}>
              <hrb-text style-type="cta-small">
                <slot></slot>
              </hrb-text>
              {hasMetadata && this.renderMetadata()}
            </span>
            <span class={`${Constants.baseClassname}__icon`}>
              {this.renderCircledIcon()}
            </span>
          </span>
        </this.as>
      </Host>
    )
  }
}
