export type TButtonThemes =
  | 'primary'
  | 'primary-light'
  | 'secondary'
  | 'secondary-light'

export type TButtonSizes = 'small' | 'medium' | 'large'

export type TButtonTypes = 'a' | 'button' | 'span'
