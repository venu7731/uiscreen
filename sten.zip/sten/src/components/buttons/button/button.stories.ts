import * as readme from './readme.md'

export default {
  component: 'hrb-button',
  title: 'Buttons/Buttons CTA',
  parameters: {
    notes: { markdown: readme },
  },
}

export const Button = (): string =>
  `
  <hrb-global reset></hrb-global>
  <hrb-button>Button</hrb-button>
  `
export const ButtonPrimary = (): string =>
  `
  <hrb-button>Primary Button</hrb-button>
  `
export const ButtonPrimaryLight = (): string =>
  `
  <hrb-layout class="hrb-background-color--ui-green p-sp-8" layout="2col">
      <hrb-button theme="primary-light">Primary Light</hrb-button>
  </hrb-layout>
  `
export const ButtonSecondary = (): string =>
  `
  <hrb-button theme="secondary">Secondary Button</hrb-button>
  `
export const ButtonSecondaryLight = (): string =>
  `
  <hrb-layout class="hrb-background-color--ui-green p-sp-8" layout="2col">
      <hrb-button theme="secondary-light">Secondary Light</hrb-button>
  </hrb-layout>
  `
export const ButtonSmall = (): string =>
  `
  <hrb-button size="small">Small Button</hrb-button>
  `
export const ButtonMedium = (): string =>
  `
  <hrb-button size="medium">Medium Button (Default)</hrb-button>
  `
export const ButtonSizesLarge = (): string =>
  `
  <hrb-button size="large">Large Button</hrb-button>
  `
export const ButtonFullWidth = (): string =>
  `
  <hrb-button full-width>Button</hrb-button>
  `
