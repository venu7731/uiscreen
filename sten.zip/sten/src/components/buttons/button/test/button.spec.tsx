import { newSpecPage } from '@stencil/core/testing'

import { HrbButton } from '../button'

describe('Button', () => {
  // Themes
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbButton],
      html: `
      <hrb-button>Button</hrb-button>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-button class="hrb-button" theme="primary">
      <button>
        <span class="hrb-button__container">
          <span class="hrb-button__text-container">
            <hrb-text class="hrb-button__text">
              Button
            </hrb-text>
          </span>
        </span>
        <svg class="pill-expand" xmlns="http://www.w3.org/2000/svg">
        <rect height="100%" rx="30" viewBox="0 0 100 100" width="100%"></rect>
        </svg>
        </button>
    </hrb-button>`)
  })
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbButton],
      html: `
      <hrb-button theme="primary-light">Button</hrb-button>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-button class="hrb-button" theme="primary-light">
      <button>
        <span class="hrb-button__container">
          <span class="hrb-button__text-container">
            <hrb-text class="hrb-button__text">
              Button
            </hrb-text>
          </span>
        </span>
        <svg class="pill-expand" xmlns="http://www.w3.org/2000/svg">
        <rect height="100%" rx="30" viewBox="0 0 100 100" width="100%"></rect>
        </svg>
        </button>
    </hrb-button>
    `)
  })
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbButton],
      html: `
      <hrb-button theme='secondary'>Button</hrb-button>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-button class="hrb-button" theme="secondary">
      <button>
        <span class="hrb-button__container">
          <span class="hrb-button__text-container">
            <hrb-text class="hrb-button__text">
              Button
            </hrb-text>
          </span>
        </span>
        <svg class="pill-expand" xmlns="http://www.w3.org/2000/svg">
        <rect height="100%" rx="30" viewBox="0 0 100 100" width="100%"></rect>
        </svg>
        </button>
    </hrb-button>
    `)
  })
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbButton],
      html: `
      <hrb-button theme='secondary-light'>Button</hrb-button>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-button class="hrb-button" theme="secondary-light">
      <button>
        <span class="hrb-button__container">
          <span class="hrb-button__text-container">
            <hrb-text class="hrb-button__text">
              Button
            </hrb-text>
          </span>
        </span>
        <svg class="pill-expand" xmlns="http://www.w3.org/2000/svg">
        <rect height="100%" rx="30" viewBox="0 0 100 100" width="100%"></rect>
        </svg>
        </button>
    </hrb-button>
    `)
  })
  // Heights
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbButton],
      html: `
      <hrb-button button-height='large'>Button</hrb-button>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-button class="hrb-button" button-height="large" theme="primary">
      <button>
        <span class="hrb-button__container">
          <span class="hrb-button__text-container">
            <hrb-text class="hrb-button__text">
              Button
            </hrb-text>
          </span>
        </span>
        <svg class="pill-expand" xmlns="http://www.w3.org/2000/svg">
        <rect height="100%" rx="30" viewBox="0 0 100 100" width="100%"></rect>
        </svg>
        </button>
    </hrb-button>
    `)
  })
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbButton],
      html: `
      <hrb-button button-height='medium'>Button</hrb-button>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-button class="hrb-button" button-height="medium" theme="primary">
      <button>
        <span class="hrb-button__container">
          <span class="hrb-button__text-container">
            <hrb-text class="hrb-button__text">
              Button
            </hrb-text>
          </span>
        </span>
        <svg class="pill-expand" xmlns="http://www.w3.org/2000/svg">
        <rect height="100%" rx="30" viewBox="0 0 100 100" width="100%"></rect>
        </svg>
        </button>
    </hrb-button>
    `)
  })
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbButton],
      html: `
      <hrb-button button-height='small'>Button</hrb-button>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-button class="hrb-button" button-height="small" theme="primary">
      <button>
        <span class="hrb-button__container">
          <span class="hrb-button__text-container">
            <hrb-text class="hrb-button__text">
              Button
            </hrb-text>
          </span>
        </span>
        <svg class="pill-expand" xmlns="http://www.w3.org/2000/svg">
        <rect height="100%" rx="30" viewBox="0 0 100 100" width="100%"></rect>
        </svg>
        </button>
    </hrb-button>
    `)
  })
  // Qualifier
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbButton],
      html: `
      <hrb-button qualifier='qualifier text'>Button</hrb-button>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-button class="hrb-button" qualifier="qualifier text" theme="primary">
      <button>
        <span class="hrb-button__container">
          <span class="hrb-button__text-container">
            <hrb-text class="hrb-button__text">
              Button
            </hrb-text>
            <span class="hrb-button__qualifier">
              <hrb-text class="hrb-button__qualifier-text" style-type="cta-qualifier">
                qualifier text
              </hrb-text>
            </span>
          </span>
        </span>
        <svg class="pill-expand" xmlns="http://www.w3.org/2000/svg">
        <rect height="100%" rx="30" viewBox="0 0 100 100" width="100%"></rect>
        </svg>
        </button>
    </hrb-button>
    `)
  })
  // Icons
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbButton],
      html: `
      <hrb-button icon="chevron-left"
      icon-position="left">Button</hrb-button>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-button class="hrb-button" icon="chevron-left" icon-position="left" theme="primary">
      <button>
        <span class="hrb-button__container">
          <span class="hrb-button__text-container">
            <hrb-text class="hrb-button__text">
              Button
            </hrb-text>
          </span>
          <hrb-icon class="hrb-button__icon" name="chevron-left"></hrb-icon>
        </span>
        <svg class="pill-expand" xmlns="http://www.w3.org/2000/svg">
        <rect height="100%" rx="30" viewBox="0 0 100 100" width="100%"></rect>
        </svg>
        </button>
    </hrb-button>
    `)
  })
  // Aria
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbButton],
      html: `
      <hrb-button p-aria-labelledby="Element Name"
      p-aria-label="Button Label"
      p-aria-pressed="true"
      >Button</hrb-button>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-button class="hrb-button" p-aria-label="Button Label" p-aria-labelledby="Element Name" p-aria-pressed="true" theme="primary">
      <button aria-label="Button Label" aria-labelledby="Element Name" aria-pressed="true">
        <span class="hrb-button__container">
          <span class="hrb-button__text-container">
            <hrb-text class="hrb-button__text">
              Button
            </hrb-text>
          </span>
        </span>
        <svg class="pill-expand" xmlns="http://www.w3.org/2000/svg">
        <rect height="100%" rx="30" viewBox="0 0 100 100" width="100%"></rect>
        </svg>
        </button>
    </hrb-button>
    `)
  })
  // Disabled
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbButton],
      html: `
      <hrb-button disabled>Button</hrb-button>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-button class="hrb-button" disabled="" theme="primary">
      <button aria-disabled="" disabled="">
        <span class="hrb-button__container">
          <span class="hrb-button__text-container">
            <hrb-text class="hrb-button__text">
              Button
            </hrb-text>
          </span>
        </span>
        <svg class="pill-expand" xmlns="http://www.w3.org/2000/svg">
        <rect height="100%" rx="30" viewBox="0 0 100 100" width="100%"></rect>
        </svg>
        </button>
    </hrb-button>`)
  })
})
