import { Component, h, Host, Prop } from '@stencil/core'

import { getIsValidIcon } from '@src/utils/validations'

import { TButtonThemes, TButtonSizes } from './types'

const Constants = {
  baseClassname: 'hrb-button',
}

@Component({
  tag: 'hrb-button',
  styleUrl: 'button.scss',
})
export class HrbButton {
  private hrbButton?: HTMLElement

  constructor() {
    this.focusButton = this.focusButton.bind(this)
    this.blurButton = this.blurButton.bind(this)
  }

  focusButton(): void {
    this.hrbButton.classList.add('tooltip-focus')
  }

  blurButton(): void {
    this.hrbButton.classList.remove('tooltip-focus')
  }

  /**
   * Applies `aria-label` to button
   */
  @Prop({ attribute: 'p-aria-label' })
  pAriaLabel: string

  /**
   * Applies `aria-labelledby` to button
   */
  @Prop({ attribute: 'p-aria-labelledby' }) pAriaLabelledby: string

  /**
   * Applies `aria-role` to button
   */
  @Prop({ attribute: 'p-aria-role' }) pAriaRole: string

  /**
   * Applies `aria-pressed` as a way to show an "active" state
   */
  @Prop({ attribute: 'p-aria-pressed' }) pAriaPressed: string

  /**
   * Sets button to disabled
   */
  @Prop() disabled = false

  /**
   * Applies type attribute
   */
  @Prop() type: string

  /**
   * Set button to 100% width
   */
  @Prop({ attribute: 'full-width' }) fullWidth = false

  /**
   * Adds icon to button (defaults to none)
   */
  @Prop() icon = 'none'

  /**
   * Adjusts icon position on the button (defaults to right)
   */
  @Prop() iconPosition: 'right' | 'left' = 'right'

  /**
   * Add secondary text label
   */
  @Prop() qualifier: string

  /**
   * Sets button to small or large variety (defaults to medium)
   */
  @Prop() size: TButtonSizes = 'medium'

  /**
   * Applies color theme (defaults to primary)
   */
  @Prop() theme: TButtonThemes = 'primary'

  /**
   * Sets button to loading state
   */
  @Prop() loading = false

  /**
   * Sets button to secondary
   */
  @Prop() secondary = false

  componentWillLoad(): void {
    this.validateIcon()
  }

  validateIcon(): void {
    const { icon } = this
    const isValidIcon = getIsValidIcon(icon)

    if (!isValidIcon && icon !== 'none') {
      this.throwConsoleError(icon, 'icon')
    }
  }

  throwConsoleError(val: string, prop: string): void {
    // eslint-disable-next-line no-console
    console.error(`<hrb-button /> : "${val}" is not a valid button ${prop}`)
  }

  getProps = (): object => {
    const {
      pAriaLabel,
      pAriaLabelledby,
      pAriaRole,
      pAriaPressed,
      disabled,
    } = this

    const sharedProps = {
      'aria-label': pAriaLabel,
      'aria-labelledby': pAriaLabelledby,
      'aria-role': pAriaRole,
      'aria-disabled': disabled,
      'aria-pressed': pAriaPressed,
    }

    if (disabled !== false) {
      return {
        ...sharedProps,
        disabled,
      }
    }

    return {
      ...sharedProps,
    }
  }

  renderLoader = (): JSX.Element => {
    const { theme } = this
    const color = theme === 'primary' ? 'white' : 'primary-black'

    return (
      <span class={`${Constants.baseClassname}__loader`} aria-hidden="true">
        <hrb-loader color={color}></hrb-loader>
      </span>
    )
  }

  render(): JSX.Element {
    const { icon, qualifier, loading, renderLoader } = this

    const hasQualifier = !!qualifier
    const props = this.getProps()

    return (
      <Host
        class="hrb-button"
        // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
        ref={el => (this.hrbButton = el as HTMLButtonElement)}
        theme={this.theme}
      >
        <button {...props} onFocus={this.focusButton} onBlur={this.blurButton}>
          {loading && renderLoader()}
          <span class={`${Constants.baseClassname}__container`}>
            <span class={`${Constants.baseClassname}__text-container`}>
              <hrb-text class={`${Constants.baseClassname}__text`}>
                <slot></slot>
              </hrb-text>
              {hasQualifier && (
                <span class={`${Constants.baseClassname}__qualifier`}>
                  <hrb-text
                    class={`${Constants.baseClassname}__qualifier-text`}
                    style-type="cta-qualifier"
                  >
                    {qualifier}
                  </hrb-text>
                </span>
              )}
            </span>
            {icon !== 'none' && (
              <hrb-icon
                class={`${Constants.baseClassname}__icon`}
                name={icon}
              ></hrb-icon>
            )}
          </span>
          <svg class="pill-expand" xmlns="http://www.w3.org/2000/svg">
            <rect height="100%" width="100%" rx="30" viewBox="0 0 100 100" />
          </svg>
        </button>
      </Host>
    )
  }
}
