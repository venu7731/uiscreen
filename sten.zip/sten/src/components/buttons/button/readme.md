# hrb-button

`hrb-button` can be used to render a `button` (default). Use the `as` props to change the main rendered element: `button`, `a` or `span`.

📝 Note:

- If you want to render an `a` element, don't forget to pass the `href`, `target` and `rel` props.
- We recommend to render a `span` if you only want a styled component with no interactive elements, such as inside of a larger button like a card that has a click event.

## Examples

In some context, you need aria attributes to make an `hbr-button` more accessible.

We exposed `p-aria-*` props translating to aria attributes on the main `button`, `a` or `span` element (see `as` props): `p-aria-label`, `p-aria-labelledby` and `p-aria-role`.

```html
<hrb-button p-aria-label="Go to a specific product page">Learn More</hrb-button>
```

---

`hrb-button` can use a variety of themes, listed below, with the `theme` prop.

```html
<hrb-button theme="primary">Button Text</hrb-button>
<hrb-button theme="primary-light">Button Text</hrb-button>
<hrb-button theme="secondary">Button Text</hrb-button>
<hrb-button theme="secondary-light">Button Text</hrb-button>
```

---

`hrb-button` can be disabled with the `disabled` prop.

```html
<hrb-button disabled>A disabled Button</hrb-button>
```

📝 Note: the `disabled` prop also automatically adds `aria-disabled="true"` on to the element.

---

`hrb-button` accept a variety of icons with the `icon` prop. If one is not passed, by default there will ne no icon.

```html
<hrb-button icon="heart">Button Text</hrb-button>
```

`hrb-button` accepts an icon position property as well. If one is not passed, by default the icon will be on the right.

```html
<hrb-button icon="heart" icon-position="right">Button Text</hrb-button>
```

---

`hrb-button` can expand to the width of their container if the `full-width` prop is provided.

```html
<hrb-button full-width>Button Text</hrb-button>
```

---

`hrb-button` can have a loading state using the `loading` prop which displays a loader (spinner) instead of the label

```html
<hrb-button loading>Button Text</hrb-button>
```

---

To render an `a` tag, use the `as` prop.

```html
<hrb-button as="a">
  Button Text
</hrb-button>
```

`hrb-button` rendering an `a` element can be passed `href`, `target` and `rel` props.

```html
<hrb-button
  as="a"
  href="https://www.hrblock.com"
  target="_blank"
  rel="noreferrer noopener"
>
  Button Text
</hrb-button>
```

<!-- Auto Generated Below -->


## Properties

| Property          | Attribute           | Description                                                | Type                                                               | Default     |
| ----------------- | ------------------- | ---------------------------------------------------------- | ------------------------------------------------------------------ | ----------- |
| `disabled`        | `disabled`          | Sets button to disabled                                    | `boolean`                                                          | `false`     |
| `fullWidth`       | `full-width`        | Set button to 100% width                                   | `boolean`                                                          | `false`     |
| `icon`            | `icon`              | Adds icon to button (defaults to none)                     | `string`                                                           | `'none'`    |
| `iconPosition`    | `icon-position`     | Adjusts icon position on the button (defaults to right)    | `"left" \| "right"`                                                | `'right'`   |
| `loading`         | `loading`           | Sets button to loading state                               | `boolean`                                                          | `false`     |
| `pAriaLabel`      | `p-aria-label`      | Applies `aria-label` to button                             | `string`                                                           | `undefined` |
| `pAriaLabelledby` | `p-aria-labelledby` | Applies `aria-labelledby` to button                        | `string`                                                           | `undefined` |
| `pAriaPressed`    | `p-aria-pressed`    | Applies `aria-pressed` as a way to show an "active" state  | `string`                                                           | `undefined` |
| `pAriaRole`       | `p-aria-role`       | Applies `aria-role` to button                              | `string`                                                           | `undefined` |
| `qualifier`       | `qualifier`         | Add secondary text label                                   | `string`                                                           | `undefined` |
| `secondary`       | `secondary`         | Sets button to secondary                                   | `boolean`                                                          | `false`     |
| `size`            | `size`              | Sets button to small or large variety (defaults to medium) | `"large" \| "medium" \| "small"`                                   | `'medium'`  |
| `theme`           | `theme`             | Applies color theme (defaults to primary)                  | `"primary" \| "primary-light" \| "secondary" \| "secondary-light"` | `'primary'` |
| `type`            | `type`              | Applies type attribute                                     | `string`                                                           | `undefined` |


## Dependencies

### Used by

 - [hrb-attachment-item](../../attachment-item)
 - [hrb-dropdown-menu](../../dropdown-menu)
 - [hrb-message-card](../../card composites/card-message)

### Depends on

- [hrb-loader](../../loader)
- [hrb-text](../../text)
- [hrb-icon](../../icon)

### Graph
```mermaid
graph TD;
  hrb-button --> hrb-loader
  hrb-button --> hrb-text
  hrb-button --> hrb-icon
  hrb-attachment-item --> hrb-button
  hrb-dropdown-menu --> hrb-button
  hrb-message-card --> hrb-button
  style hrb-button fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
