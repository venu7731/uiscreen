# hrb-circle-button

The `hrb-circle-button` is very similar to `hrb-button` in terms of behavior, but specific enough to be its own component.

`hrb-circle-button` can be used to render a circled `button` (default). Use the `as` props to change the main rendered element: `button`, `a` or `span`.

📝 Note:

- If you want to render an `a` element, don't forget to pass the `href`, `target` and `rel` props.
- We recommend to render a `span` if you only want a styled component with no interactive elements.

`hrb-circle-button` elements are made to work with a `hrb-icon` child. It is also **strongly** recommended to use the `p-aria-label` for screenreaders to understand the meaning of the button.

```html
<hrb-circle-button p-aria-label="Like">
  <hrb-icon name="heart"></hrb-icon>
</hrb-circle-button>
```

## Examples

As mentionned before, you need aria attributes to make an `hbr-button` more accessible.

We exposed `p-aria-*` props translating to aria attributes on the main `button`, `a` or `span` element (see `as` props): `p-aria-label`, `p-aria-labelledby` and `p-aria-role`.

```html
<hrb-circle-button p-aria-label="Edit your profile">
  <hrb-icon name="edit"></hrb-icon>
</hrb-circle-button>
```

---

`hrb-circle-button` can use a variety of themes, listed below, with the `theme` prop.

```html
<hrb-circle-button p-aria-label="Edit your profile" theme="default">
  <hrb-icon name="edit"></hrb-icon>
</hrb-circle-button>

<hrb-circle-button p-aria-label="Edit your profile" theme="outline">
  <hrb-icon name="edit"></hrb-icon>
</hrb-circle-button>

<hrb-circle-button p-aria-label="Edit your profile" theme="white">
  <hrb-icon name="edit"></hrb-icon>
</hrb-circle-button>

<hrb-circle-button p-aria-label="Edit your profile" theme="light-grey-1">
  <hrb-icon name="edit"></hrb-icon>
</hrb-circle-button>

<hrb-circle-button p-aria-label="Edit your profile" theme="ui-green">
  <hrb-icon name="edit"></hrb-icon>
</hrb-circle-button>
```

---

`hrb-circle-button` can be disabled with the `disabled` prop.

```html
<hrb-circle-button
  p-aria-label="You cannot edit your profile at this time"
  theme="yellow"
  disabled
>
  <hrb-icon name="edit"></hrb-icon>
</hrb-circle-button>
```

📝 Note: the `disabled` prop also automatically adds `aria-disabled="true"` on to the element.

---

`hrb-circle-button` can be x-small, small, medium or large with the `size` prop. If no size is passed, small is used by default.

```html
<hrb-circle-button p-aria-label="Edit your profile" size="large">
  <hrb-icon name="edit"></hrb-icon>
</hrb-circle-button>
```

---

To render an `a` tag, use the `as` prop. Don't forget the appropriate `href`, `target` and `rel` props if needed!

```html
<hrb-circle-button p-aria-label="Go to a specific product page" as="a" href="/">
  <hrb-icon name="chevron-right"></hrb-icon>
</hrb-circle-button>
```

<!-- Auto Generated Below -->


## Properties

| Property          | Attribute           | Description                                                       | Type                                                                | Default     |
| ----------------- | ------------------- | ----------------------------------------------------------------- | ------------------------------------------------------------------- | ----------- |
| `as`              | `as`                | Sets tag for button (defaults to <button />)                      | `"a" \| "button" \| "span"`                                         | `'button'`  |
| `disabled`        | `disabled`          | Sets button to disabled                                           | `boolean`                                                           | `false`     |
| `href`            | `href`              | Applies optional href attribute                                   | `string`                                                            | `undefined` |
| `pAriaControls`   | `p-aria-controls`   | Applies `aria-controls` to button                                 | `string`                                                            | `undefined` |
| `pAriaExpaned`    | `p-aria-expanded`   | Applies `aria-expanded` to button                                 | `string`                                                            | `undefined` |
| `pAriaLabel`      | `p-aria-label`      | Applies `aria-label` to button                                    | `string`                                                            | `undefined` |
| `pAriaLabelledby` | `p-aria-labelledby` | Applies `aria-labelledby` to button                               | `string`                                                            | `undefined` |
| `pAriaRole`       | `p-aria-role`       | Applies `aria-role` to button                                     | `string`                                                            | `undefined` |
| `pTabIndex`       | `p-tab-index`       | Applies `tab-index` to button                                     | `number`                                                            | `undefined` |
| `rel`             | `rel`               | Applies optional rel attribute                                    | `string`                                                            | `undefined` |
| `size`            | `size`              | Sets button to small, medium or large variety (defaults to small) | `"large" \| "medium" \| "small" \| "x-small"`                       | `'small'`   |
| `target`          | `target`            | Applies optional target attribute                                 | `string`                                                            | `undefined` |
| `theme`           | `theme`             | Applies color theme                                               | `"default" \| "light-grey-1" \| "outline" \| "ui-green" \| "white"` | `'default'` |
| `transparent`     | `transparent`       | Applies transparent style                                         | `boolean`                                                           | `false`     |
| `type`            | `type`              | Applies type attribute                                            | `string`                                                            | `undefined` |


## Dependencies

### Used by

 - [hrb-card-expandable](../../card composites/card-expandable)
 - [hrb-message-card](../../card composites/card-message)
 - [hrb-modal](../../modal)
 - [hrb-overflow-menu](../../overflow-menu)

### Depends on

- [hrb-circled](../../circled)

### Graph
```mermaid
graph TD;
  hrb-circle-button --> hrb-circled
  hrb-card-expandable --> hrb-circle-button
  hrb-message-card --> hrb-circle-button
  hrb-modal --> hrb-circle-button
  hrb-overflow-menu --> hrb-circle-button
  style hrb-circle-button fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
