import { Component, Host, h, Prop } from '@stencil/core'

import { getClassnames } from '@src/utils/misc'
import { getIsValidButtonType } from '@src/utils/validations'

import buttonTypes from '@src/constants/button-types'

import {
  TCircleButtonThemes,
  TCircleButtonSize,
  TCircleButtonTypes,
} from './types'

const Constants = {
  baseClassname: 'hrb-circle-button',
}

@Component({
  tag: 'hrb-circle-button',
  styleUrl: 'circle-button.scss',
})
export class CircleButton {
  /**
   * Applies `aria-label` to button
   */
  @Prop({ attribute: 'p-aria-label' }) pAriaLabel: string

  /**
   * Applies `aria-labelledby` to button
   */
  @Prop({ attribute: 'p-aria-labelledby' }) pAriaLabelledby: string

  /**
   * Applies `aria-role` to button
   */
  @Prop({ attribute: 'p-aria-role' }) pAriaRole: string

  /**
   * Applies `aria-expanded` to button
   */
  @Prop({ attribute: 'p-aria-expanded' }) pAriaExpaned: string

  /**
   * Applies `aria-controls` to button
   */
  @Prop({ attribute: 'p-aria-controls' }) pAriaControls: string

  /**
   * Applies `tab-index` to button
   */
  @Prop({ attribute: 'p-tab-index' }) pTabIndex: number

  /**
   * Sets tag for button (defaults to <button />)
   */
  @Prop() as: TCircleButtonTypes = 'button'

  /**
   * Applies optional target attribute
   */
  @Prop() target: string

  /**
   * Applies optional rel attribute
   */
  @Prop() rel: string

  /**
   * Applies optional href attribute
   */
  @Prop() href: string

  /**
   * Sets button to disabled
   */
  @Prop() disabled = false

  /**
   * Applies type attribute
   */
  @Prop() type: string

  /**
   * Sets button to small, medium or large variety (defaults to small)
   */
  @Prop() size: TCircleButtonSize = 'small'

  /**
   * Applies color theme
   */
  @Prop() theme: TCircleButtonThemes = 'default'

  /**
   * Applies transparent style
   */
  @Prop() transparent = false

  componentWillLoad(): void {
    this.validateLinkType()
  }

  validateLinkType(): void {
    const isValidLinkType = getIsValidButtonType(this.as)

    if (!isValidLinkType) {
      this.throwConsoleError(this.as, 'type')
    }
  }

  throwConsoleError(val: string, prop: string): void {
    // eslint-disable-next-line no-console
    console.error(
      `<hrb-circle-button /> : "${val}" is not a valid circle-button ${prop}`,
    )
  }

  getProps = (): object => {
    const {
      pAriaControls,
      pAriaExpaned,
      pAriaLabel,
      pAriaLabelledby,
      pAriaRole,
      pTabIndex,
      as,
      disabled,
      href,
      rel,
      target,
      type,
    } = this

    const isAnchor = as === buttonTypes.anchor
    const isButton = as === buttonTypes.button

    const sharedProps = {
      'aria-label': pAriaLabel,
      'aria-labelledby': pAriaLabelledby,
      'aria-role': pAriaRole,
      'aria-disabled': disabled,
      'aria-controls': pAriaControls,
      'aria-expanded': pAriaExpaned,
      tabindex: pTabIndex,
    }

    if (isAnchor) {
      return {
        ...sharedProps,
        href,
        rel,
        target,
      }
    }

    if (isButton) {
      return {
        ...sharedProps,
        type,
        disabled,
      }
    }

    return {
      ...sharedProps,
    }
  }

  render(): JSX.Element {
    const props = this.getProps()
    const { disabled, size, theme } = this
    const { baseClassname } = Constants

    const classes = getClassnames([
      `${baseClassname}`,
      disabled && `${baseClassname}--disabled`,
    ])

    return (
      <Host>
        <this.as class={classes} {...props}>
          <hrb-circled size={size} theme={theme}>
            <slot />
            <svg
              class="circle-bg"
              viewBox="0 0 80 80"
              xmlns="http://www.w3.org/2000/svg"
            >
              <circle cx="40" cy="40" r="40" />
            </svg>
          </hrb-circled>
        </this.as>
      </Host>
    )
  }
}
