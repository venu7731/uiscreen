import { newSpecPage } from '@stencil/core/testing'

import { CircleButton } from '../circle-button'

describe('Circle Button', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [CircleButton],
      html: `
      <hrb-circle-button disabled theme="light-grey-1" p-aria-label="Like">
        <hrb-icon name="heart"></hrb-icon>
      </hrb-circle-button>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-circle-button disabled="" p-aria-label="Like" theme="light-grey-1">
      <button aria-disabled="" aria-label="Like" class="hrb-circle-button hrb-circle-button--disabled" disabled="">
        <hrb-circled size="small" theme="light-grey-1">
          <hrb-icon name="heart"></hrb-icon>
          <svg class="circle-bg" viewBox="0 0 80 80" xmlns="http://www.w3.org/2000/svg">
             <circle cx="40" cy="40" r="40"></circle>
           </svg>
        </hrb-circled>
      </button>
    </hrb-circle-button>
    `)
  })
})
