export type TCircleButtonThemes =
  | 'default'
  | 'outline'
  | 'white'
  | 'light-grey-1'
  | 'ui-green'

export type TCircleButtonSize = 'x-small' | 'small' | 'medium' | 'large'

export type TCircleButtonTypes = 'a' | 'button' | 'span'
