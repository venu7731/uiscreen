import * as readme from './readme.md'

export default {
  component: 'hrb-circle-button',
  title: 'Buttons/Circle Buttons',
  parameters: {
    notes: { markdown: readme },
  },
}

export const CircleButton = (): string =>
  `
  <hrb-global reset></hrb-global>
  <hrb-circle-button theme="light-grey-1" size="x-small" p-aria-label="Like">
    <hrb-icon name="heart"></hrb-icon>
  </hrb-circle-button>
  `
export const CircleButtonXSmall = (): string =>
  `
  <hrb-circle-button theme="light-grey-1" size="x-small" p-aria-label="Like">
    <hrb-icon name="heart"></hrb-icon>
  </hrb-circle-button>
  `
export const CircleButtonSmall = (): string =>
  `
  <hrb-circle-button theme="light-grey-1" size="small" p-aria-label="Like">
    <hrb-icon name="heart"></hrb-icon>
  </hrb-circle-button>
  `
export const CircleButtonMedium = (): string =>
  `
  <hrb-circle-button theme="light-grey-1" size="medium" p-aria-label="Like">
    <hrb-icon name="heart"></hrb-icon>
  </hrb-circle-button>
  `
export const CircleButtonLarge = (): string =>
  `
  <hrb-circle-button theme="light-grey-1" size="large" p-aria-label="Like">
    <hrb-icon name="heart"></hrb-icon>
  </hrb-circle-button>
  `
export const CircleButtonThemesDefault = (): string =>
  `
  <hrb-circle-button theme="default" size="medium" p-aria-label="Like">
    <hrb-icon name="heart"></hrb-icon>
  </hrb-circle-button>
  `
export const CircleButtonThemesOutline = (): string =>
  `
  <hrb-circle-button theme="outline" size="medium" p-aria-label="Like">
    <hrb-icon name="heart"></hrb-icon>
  </hrb-circle-button>
  `
export const CircleButtonThemeslightGrey1 = (): string =>
  `
  <hrb-circle-button theme="light-grey-1" size="medium" p-aria-label="Like">
    <hrb-icon name="heart"></hrb-icon>
  </hrb-circle-button>
  `
