import { Component, h, Host, Prop } from '@stencil/core'

import { getIsValidButtonType } from '@src/utils/validations'
import { getClassnames } from '@src/utils/misc'

import buttonTypes from '@src/constants/button-types'

import { TCircleButtonWithLabelButtonTypes, TColorThemes } from './types'

const Constants = {
  baseClassname: 'hrb-circle-button-with-label',
}

@Component({
  tag: 'hrb-circle-button-with-label',
  styleUrl: 'circle-button-with-label.scss',
})
export class CircleButtonWithLabel {
  /**
   * Applies `aria-label` to button
   */
  @Prop({ attribute: 'p-aria-label' }) pAriaLabel: string

  /**
   * Applies `aria-labelledby` to button
   */
  @Prop({ attribute: 'p-aria-labelledby' }) pAriaLabelledby: string

  /**
   * Applies `aria-role` to button
   */
  @Prop({ attribute: 'p-aria-role' }) pAriaRole: string

  /**
   * Sets tag for button (defaults to <button />)
   */
  @Prop() as: TCircleButtonWithLabelButtonTypes = 'a'

  /**
   * Applies optional target attribute
   */
  @Prop() target: string

  /**
   * Applies optional rel attribute
   */
  @Prop() rel: string

  /**
   * Applies optional href attribute
   */
  @Prop() href: string

  /**
   * Sets button to disabled
   */
  @Prop() disabled = false

  /**
   * Applies type attribute
   */
  @Prop() type: string

  /**
   * Adds an icon to the button (defaults to 'phone')
   */
  @Prop() icon = 'phone'

  /**
   * Applies color theme (defaults to 'yellow')
   */
  @Prop() theme: TColorThemes = 'default'

  componentWillLoad(): void {
    this.validateLinkType()
  }

  validateLinkType(): void {
    if (!this.as) return // button type is not required so this is valid

    const { as } = this
    const isValidLinkType = getIsValidButtonType(as)

    if (!isValidLinkType) {
      this.throwConsoleError(as, 'link type')
    }
  }

  throwConsoleError(val: string, prop: string): void {
    // eslint-disable-next-line no-console
    console.error(
      `<hrb-circle-button-with-label /> : "${val}" is not a valid ${prop}`,
    )
  }

  getProps = (): object => {
    const {
      pAriaLabel,
      pAriaLabelledby,
      pAriaRole,
      as,
      disabled,
      href,
      rel,
      target,
      type,
    } = this

    const isAnchor = as === buttonTypes.anchor
    const isButton = as === buttonTypes.button

    const sharedProps = {
      'aria-label': pAriaLabel,
      'aria-labelledby': pAriaLabelledby,
      'aria-role': pAriaRole,
      'aria-disabled': disabled,
    }

    if (isAnchor) {
      return {
        ...sharedProps,
        href,
        rel,
        target,
      }
    }

    if (isButton) {
      return {
        ...sharedProps,
        type,
        disabled,
      }
    }

    return {
      ...sharedProps,
    }
  }

  render(): JSX.Element {
    const props = this.getProps()
    const { baseClassname } = Constants
    const { icon, theme } = this

    const classnames = getClassnames([
      `${baseClassname}`,
      `${baseClassname}--${theme}`,
    ])

    return (
      <Host>
        <this.as class={classnames} {...props}>
          <hrb-circled class={`${baseClassname}__icon`} theme={theme}>
            <hrb-icon name={icon}></hrb-icon>
          </hrb-circled>
          <span class={`${baseClassname}__label`}>
            <slot></slot>
          </span>
        </this.as>
      </Host>
    )
  }
}
