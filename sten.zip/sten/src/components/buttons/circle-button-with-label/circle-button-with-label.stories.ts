import { boolean, select, text, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import {
  buttonTypes,
  circledWithLabelThemes,
  groupIds,
  reset,
  targets,
} from '@src/constants/storybook'
import icons from '@src/constants/icons'

import * as readme from './readme.md'

/* eslint-disable-next-line */
const circleButton = (
  buttonText,
  icon,
  ariaLabel,
  ariaLabelledBy,
  ariaRole,
  as,
  disabled,
  href,
  rel,
  target,
  theme,
  type,
) => `<hrb-circle-button-with-label 
        p-aria-label="${ariaLabel}" 
        p-aria-labelled-by="${ariaLabelledBy}" 
        p-aria-role="${ariaRole}" 
        as="${as}"
        ${disabled ? 'disabled' : ''}
        href="${href}"
        icon="${icon}"
        ${rel ? `rel="${rel}"` : ''}
        target="${target}" 
        theme="${theme}"
        ${type ? `type="${type}"` : ''}>
          ${buttonText}
      </hrb-circle-button-with-label>`

const wrapperOpen = `${reset}<div style="padding: 30px">`
const wrapperClose = `</div>`

storiesOf('Buttons/Action Buttons', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-circle-button-with-label'],
    notes: { markdown: readme },
  })
  .add('Action Button w/ Label', () => {
    return `${wrapperOpen}
    
    ${circleButton(
      text('Button Text', '1-800-472-5625', groupIds.testable),
      select('Icon', icons, icons[53], groupIds.testable),
      text('Aria Label', 'Like', groupIds.aria),
      text('Aria Labelled By', 'Button labelled by', groupIds.aria),
      text('Aria Role', 'button', groupIds.aria),
      select('As', buttonTypes, buttonTypes[1], groupIds.testable),
      boolean('Disabled', false, groupIds.testable),
      text('Href', 'https://www.hrblock.com/', groupIds.testable),
      text('Rel', '', groupIds.additional),
      select('Target', targets, targets[0], groupIds.testable),
      select(
        'Theme',
        circledWithLabelThemes,
        circledWithLabelThemes[0],
        groupIds.testable,
      ),
      text('Type', '', groupIds.additional),
    )}
    
    ${wrapperClose}`
  })
