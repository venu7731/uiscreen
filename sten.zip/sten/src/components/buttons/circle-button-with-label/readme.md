# hrb-circle-button-with-label

Similar to `hrb-circle-button`, the `hrb-circle-button-with-label` component provides a container that hosts a label next to a `hrb-circle-button` element.
Its main prupose is to be used as a child of a footer module (see Design Guidelines).

```html
<hrb-circle-button-with-label href="/" p-aria-label="Like" icon="location">
  Find an office
</hrb-circle-button-with-label>
```

📝 Note: see the [hrb-circle-button readme](../circle-button) to find more documentation about the main properties.

<!-- Auto Generated Below -->


## Properties

| Property          | Attribute           | Description                                      | Type                                                                                                                                                                                                                            | Default     |
| ----------------- | ------------------- | ------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------- |
| `as`              | `as`                | Sets tag for button (defaults to <button />)     | `"a" \| "button" \| "span"`                                                                                                                                                                                                     | `'a'`       |
| `disabled`        | `disabled`          | Sets button to disabled                          | `boolean`                                                                                                                                                                                                                       | `false`     |
| `href`            | `href`              | Applies optional href attribute                  | `string`                                                                                                                                                                                                                        | `undefined` |
| `icon`            | `icon`              | Adds an icon to the button (defaults to 'phone') | `string`                                                                                                                                                                                                                        | `'phone'`   |
| `pAriaLabel`      | `p-aria-label`      | Applies `aria-label` to button                   | `string`                                                                                                                                                                                                                        | `undefined` |
| `pAriaLabelledby` | `p-aria-labelledby` | Applies `aria-labelledby` to button              | `string`                                                                                                                                                                                                                        | `undefined` |
| `pAriaRole`       | `p-aria-role`       | Applies `aria-role` to button                    | `string`                                                                                                                                                                                                                        | `undefined` |
| `rel`             | `rel`               | Applies optional rel attribute                   | `string`                                                                                                                                                                                                                        | `undefined` |
| `target`          | `target`            | Applies optional target attribute                | `string`                                                                                                                                                                                                                        | `undefined` |
| `theme`           | `theme`             | Applies color theme (defaults to 'yellow')       | `"blue" \| "default" \| "light-grey-1" \| "light-grey-2" \| "medium-dark-blue" \| "medium-dark-green" \| "medium-dark-yellow" \| "medium-light-blue" \| "medium-light-green" \| "medium-light-yellow" \| "outline" \| "yellow"` | `'default'` |
| `type`            | `type`              | Applies type attribute                           | `string`                                                                                                                                                                                                                        | `undefined` |


## Dependencies

### Depends on

- [hrb-circled](../../circled)
- [hrb-icon](../../icon)

### Graph
```mermaid
graph TD;
  hrb-circle-button-with-label --> hrb-circled
  hrb-circle-button-with-label --> hrb-icon
  style hrb-circle-button-with-label fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
