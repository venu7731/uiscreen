import { newSpecPage } from '@stencil/core/testing'

import { CircleButtonWithLabel } from '../circle-button-with-label'

describe('Circle Button With Label', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [CircleButtonWithLabel],
      html: `
      <hrb-circle-button-with-label href="/" p-aria-label="Like" icon="like">
        Find an office
      </hrb-circle-button-with-label>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-circle-button-with-label href="/" icon="like" p-aria-label="Like">
      <a aria-label="Like" class="hrb-circle-button-with-label hrb-circle-button-with-label--default" href="/">
        <hrb-circled class="hrb-circle-button-with-label__icon" theme="default">
          <hrb-icon name="like"></hrb-icon>
        </hrb-circled>
        <span class="hrb-circle-button-with-label__label">
          Find an office
        </span>
      </a>
    </hrb-circle-button-with-label>
    `)
  })
})
