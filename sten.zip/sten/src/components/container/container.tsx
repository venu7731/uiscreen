import { Component, Host, h, Prop } from '@stencil/core'

@Component({
  tag: 'hrb-container',
  styleUrl: 'container.scss',
})
export class Container {
  @Prop() padding: string

  render(): JSX.Element {
    return (
      <Host>
        <slot></slot>
      </Host>
    )
  }
}
