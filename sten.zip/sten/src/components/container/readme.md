# hrb-container

The `hrb-container` component is a simple container which takes in account the left/right padding specific to the grid, across the different breakpoints.

```html
<hrb-grid-row>
  <hrb-grid-row>
    <hrb-grid-col col-span="1/3" col-span-l="1/3">
      Content
    </hrb-grid-col>
    <!-- more cols -->
  </hrb-grid-row>
</hrb-grid-row>
```

<!-- Auto Generated Below -->


## Properties

| Property  | Attribute | Description | Type     | Default     |
| --------- | --------- | ----------- | -------- | ----------- |
| `padding` | `padding` |             | `string` | `undefined` |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
