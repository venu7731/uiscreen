import { newSpecPage } from '@stencil/core/testing'

import { Container } from '../container'

describe('Container', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [Container],
      html: `
      <hrb-container>
        <div></div>
      </hrb-container>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-container>
       <div></div>
     </hrb-container>
    `)
  })
})
