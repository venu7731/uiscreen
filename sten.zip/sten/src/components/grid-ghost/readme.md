# hrb-grid-ghost

<!-- Auto Generated Below -->


## Properties

| Property      | Attribute       | Description | Type     | Default    |
| ------------- | --------------- | ----------- | -------- | ---------- |
| `pAriaHidden` | `p-aria-hidden` |             | `string` | `'hidden'` |


## Dependencies

### Depends on

- [hrb-grid-col](../grid-col)
- [hrb-grid-row](../grid-row)

### Graph
```mermaid
graph TD;
  hrb-grid-ghost --> hrb-grid-col
  hrb-grid-ghost --> hrb-grid-row
  style hrb-grid-ghost fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
