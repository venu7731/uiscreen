import { Component, h, Host, Prop } from '@stencil/core'

import columns from '@src/constants/columns'

const Constants = {
  baseClassname: 'hrb-grid-ghost',
}

@Component({
  tag: 'hrb-grid-ghost',
  styleUrl: 'grid-ghost.scss',
})
export class HrbGridGhost {
  @Prop() pAriaHidden = 'hidden'

  generateCols = (): Element[] => {
    const cols = [...Array(columns.colL)]

    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    return cols.map((col: number, index: number) => (
      <hrb-grid-col
        class={`${Constants.baseClassname}-item`}
        col-span={`${index + 1}/${index + 2}`}
      ></hrb-grid-col>
    ))
  }

  render(): JSX.Element {
    return (
      <Host aria-hidden={this.pAriaHidden} class={Constants.baseClassname}>
        <hrb-grid-row class={`${Constants.baseClassname}--full-height`}>
          {this.generateCols()}
        </hrb-grid-row>
      </Host>
    )
  }
}
