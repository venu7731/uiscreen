import * as readme from './readme.md'

export default {
  component: 'hrb-nav-secondary',
  title: 'Secondary Nav',
  parameters: {
    notes: { markdown: readme },
  },
  argTypes: {
    isCurrent: { control: 'boolean' },
  },
}

export const SecondaryNavItem = (args): string =>
  `
  <hrb-nav-secondary-item ${
    args.isCurrent ? `is-current` : ''
  } link-text="Prior Year"></hrb-nav-secondary-item>
  `

export const SecondaryNav = (): string =>
  `
  <hrb-nav-secondary>
    <hrb-nav-secondary-item as='button'
      link-text="Current Year"
      is-current></hrb-nav-secondary-item>
    <hrb-nav-secondary-item link-text="Prior Year"></hrb-nav-secondary-item>
    <hrb-nav-secondary-item link-text="Documents"></hrb-nav-secondary-item>
    <hrb-nav-secondary-item link-text="Tax Returns"></hrb-nav-secondary-item>
  </hrb-nav-secondary>
  `
