# hrb-nav-secondary

<!-- Auto Generated Below -->


## Properties

| Property      | Attribute      | Description                                                              | Type     | Default |
| ------------- | -------------- | ------------------------------------------------------------------------ | -------- | ------- |
| `hiddenTitle` | `hidden-title` | Applies accessible/hidden title when a contextual title is not available | `string` | `''`    |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
