import { Component, Prop, h, Host, Event, EventEmitter } from '@stencil/core'

import { getClassnames } from '@src/utils/misc'

@Component({
  tag: 'hrb-nav-secondary-item',
  styleUrl: 'nav-secondary-item.scss',
})
export class NavSecondaryItem {
  /**
   * If the link navigates, it should be an 'a' tag. If the link triggers a functional action, it should be a 'button'. You will need to set the item according to your use case. Defaults to 'a'
   */
  @Prop() as: 'a' | 'button' = 'a'

  /**
   * Applying to the currently selected element will style it correctly
   */
  @Prop() isCurrent = false

  /**
   * This is the text the user sees
   */
  @Prop() linkText = ''

  /**
   * Applies href if the element is a link
   */
  @Prop() href = ''

  /**
   * Applies optional target attribute
   */
  @Prop() target: string

  /**
   * Applies optional rel attribute
   */
  @Prop() rel: string

  /**
   * Applies optional disabled if the element is a button
   */
  @Prop() disabled = false

  /**
   * linkClicked will emit when the link is clicked
   */
  @Event() linkClicked: EventEmitter

  linkClickedHandler(e): void {
    this.linkClicked.emit(e)
  }

  getProps = (): object => {
    const { href, linkText, rel, target, disabled, isCurrent } = this

    const sharedProps = {
      linkText,
      isCurrent,
    }

    if (this.as === 'a') {
      return {
        ...sharedProps,
        href,
        rel,
        target,
      }
    }

    if (this.as === 'button') {
      return {
        ...sharedProps,
        disabled: disabled,
      }
    }

    return {
      ...sharedProps,
    }
  }

  render(): JSX.Element {
    const linkClasses = getClassnames([
      `hrb-nav-link`,
      this.isCurrent && ` hrb-nav-link--current`,
    ])

    const props = this.getProps()

    return (
      <Host class="hrb-nav-item">
        <this.as
          class={linkClasses}
          role="menuitem"
          onClick={(e): void => this.linkClickedHandler(e)}
          {...props}
        >
          <hrb-text>{this.linkText}</hrb-text>
        </this.as>
      </Host>
    )
  }
}
