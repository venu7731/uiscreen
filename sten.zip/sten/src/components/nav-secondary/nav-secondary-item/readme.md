# hrb-nav-secondary-item

<!-- Auto Generated Below -->


## Properties

| Property    | Attribute    | Description                                                                                                                                                                                  | Type              | Default     |
| ----------- | ------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------- | ----------- |
| `as`        | `as`         | If the link navigates, it should be an 'a' tag. If the link triggers a functional action, it should be a 'button'. You will need to set the item according to your use case. Defaults to 'a' | `"a" \| "button"` | `'a'`       |
| `disabled`  | `disabled`   | Applies optional disabled if the element is a button                                                                                                                                         | `boolean`         | `false`     |
| `href`      | `href`       | Applies href if the element is a link                                                                                                                                                        | `string`          | `''`        |
| `isCurrent` | `is-current` | Applying to the currently selected element will style it correctly                                                                                                                           | `boolean`         | `false`     |
| `linkText`  | `link-text`  | This is the text the user sees                                                                                                                                                               | `string`          | `''`        |
| `rel`       | `rel`        | Applies optional rel attribute                                                                                                                                                               | `string`          | `undefined` |
| `target`    | `target`     | Applies optional target attribute                                                                                                                                                            | `string`          | `undefined` |


## Events

| Event         | Description                                    | Type               |
| ------------- | ---------------------------------------------- | ------------------ |
| `linkClicked` | linkClicked will emit when the link is clicked | `CustomEvent<any>` |


## Dependencies

### Depends on

- [hrb-text](../../text)

### Graph
```mermaid
graph TD;
  hrb-nav-secondary-item --> hrb-text
  style hrb-nav-secondary-item fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
