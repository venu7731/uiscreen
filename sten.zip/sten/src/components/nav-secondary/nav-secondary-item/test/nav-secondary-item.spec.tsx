import { newSpecPage } from '@stencil/core/testing'

import { NavSecondaryItem } from '../nav-secondary-item'

describe('nav-secondary-item', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [NavSecondaryItem],
      html: `<hrb-nav-secondary-item disabled
      as='button'
      link-text="Current Year"
      is-current></hrb-nav-secondary-item>`,
    })
    expect(page.root).toEqualHtml(`
    <hrb-nav-secondary-item as="button" class="hrb-nav-item" disabled="" is-current="" link-text="Current Year">
      <button class="hrb-nav-link hrb-nav-link--current" disabled="" iscurrent="" linktext="Current Year" role="menuitem">
        <hrb-text>
          Current Year
        </hrb-text>
      </button>
    </hrb-nav-secondary-item>`)
  })
})
