import { Component, h, Prop } from '@stencil/core'

@Component({
  tag: 'hrb-nav-secondary',
  styleUrl: 'nav-secondary.scss',
})
export class NavSecondary {
  /**
   * Applies accessible/hidden title when a contextual title is not available
   */
  @Prop() hiddenTitle = ''

  render(): JSX.Element {
    return (
      <section class="hrb-navbar-section">
        <nav class="hrb-navbar" aria-label="my-label">
          {this.hiddenTitle !== '' && (
            <h2 class="visuallyhidden">{this.hiddenTitle}</h2>
          )}
          <div class="hrb-navbar-nav" role="menu">
            <slot />
          </div>
        </nav>
      </section>
    )
  }
}
