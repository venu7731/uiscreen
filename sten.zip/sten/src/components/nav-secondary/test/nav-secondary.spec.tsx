import { newSpecPage } from '@stencil/core/testing'

import { NavSecondary } from '../nav-secondary'

describe('nav-secondary', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [NavSecondary],
      html: `<nav-secondary></nav-secondary>`,
    })
    expect(page.root).toEqualHtml(`
    <nav-secondary></nav-secondary>
    `)
  })
})
