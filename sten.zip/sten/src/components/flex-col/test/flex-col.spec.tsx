import { newSpecPage } from '@stencil/core/testing'

import { HrbFlexCol } from '../flex-col'

describe('HrbFlexCol', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbFlexCol],
      html: `
      <hrb-flex-container>
        <hrb-flex-row>
          <hrb-flex-col col="5"
            col-s="17"
            col-m="5"
            col-l="15"
            style="background: #f5cc02; padding: 16px; color: white;">Left Nav
          </hrb-flex-col>
          <hrb-flex-col col="12"
            col-s="17"
            col-m="12"
            col-l="20"
            style="background: #14aa40; padding: 16px; color: white;">Main
            Content
          </hrb-flex-col>
        </hrb-flex-row>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-flex-col class="hrb-col--l_15 hrb-col--m_5 hrb-col--s_17 hrb-flex-col" col="5" col-l="15" col-m="5" col-s="17" style="background: #f5cc02; padding: 16px; color: white;">
      Left Nav
    </hrb-flex-col>
    `)
  })
})
