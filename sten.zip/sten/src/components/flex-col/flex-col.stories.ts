import { boolean, number, select, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import {
  colSpanSmallMediumOptions,
  colSpanLargeOptions,
  groupIds,
  reset,
} from '@src/constants/storybook'

import * as readme from './readme.md'

const slot = `
  <hrb-text style-type="body-copy-small" style="max-width: 300px">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</hrb-text>
  
  <img src="https://via.placeholder.com/1200x1200/fcee0a" alt="Missing Placeholder Image">
`

/* eslint-disable-next-line */
const flexCol = (
  defaultSpanValue,
  smallSpanValue,
  smallOffsetValue,
  mediumSpanValue,
  mediumOffsetValue,
  largeSpanValue,
  largeOffsetValue,
  isCentered,
) =>
  `<hrb-flex-col 
    col="${defaultSpanValue}"
    col-s="${smallSpanValue}"
    col-m="${mediumSpanValue}"
    col-l="${largeSpanValue}"
    offset-s="${smallOffsetValue}"
    offset-m="${mediumOffsetValue}"
    offset-l="${largeOffsetValue}"
    ${isCentered ? 'center' : ''}>
    ${slot}
  </hrb-flex-col>`

const wrapperOpen = `${reset}<hrb-flex-container><hrb-flex-row>`
const wrapperClose = `</hrb-flex-row></hrb-flex-container>`

storiesOf('Layouts/Flex-Layouts', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-flex-col'],
    notes: { markdown: readme },
  })
  .add('Flex Columns', () => {
    return `${wrapperOpen}

    ${flexCol(
      number('Default Number of Columns', 17, {}, groupIds.default),
      select(
        'Number of Columns',
        colSpanSmallMediumOptions,
        colSpanSmallMediumOptions[16],
        groupIds.small,
      ),
      number('Offset', 0, {}, groupIds.small),
      select(
        'Number of Columns',
        colSpanSmallMediumOptions,
        colSpanSmallMediumOptions[8],
        groupIds.medium,
      ),
      number('Offset', 0, {}, groupIds.medium),
      select(
        'Number of Columns',
        colSpanLargeOptions,
        colSpanLargeOptions[16],
        groupIds.large,
      ),
      number('Offset', 0, {}, groupIds.large),
      boolean('Is Centered', false, groupIds.default),
    )}

    ${wrapperClose}`
  })
