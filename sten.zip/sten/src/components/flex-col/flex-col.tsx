import { Component, Prop, h, Host } from '@stencil/core'

import columns from '@src/constants/columns'

@Component({
  tag: 'hrb-flex-col',
  styleUrl: 'flex-col.scss',
})
export class HrbFlexCol {
  /**
   * Number of columns - Default size.
   */
  @Prop() col = 0

  /**
   *Number of columns - S
   */
  @Prop({ attribute: 'col-s' }) colS = 0

  /**
   *Number of columns - M
   */
  @Prop({ attribute: 'col-m' }) colM = 0

  /**
   *Number of columns - L
   */
  @Prop({ attribute: 'col-l' }) colL = 0

  /**
   * Offset - S
   */
  @Prop({ attribute: 'offset-s' }) offsetS = 0

  /**
   * Offset - M
   */
  @Prop({ attribute: 'offset-m' }) offsetM = 0

  /**
   * Offset - L
   */
  @Prop({ attribute: 'offset-l' }) offsetL = 0

  /**
   * Is centered
   */
  @Prop({ attribute: 'center' }) isCentered = false

  getColClassnames = (): string => {
    const colD = this.col
    const colS = this.colS || colD
    const colM = this.colM || colS
    const colL = this.colL || colM

    const colSClassname =
      (colS && colS !== colD) || colS > 0 ? `hrb-col--s_${colS}` : ''
    const colMClassname =
      (colM && colM !== colS) || (columns.colM !== columns.colS && colM > 0)
        ? `hrb-col--m_${colM}`
        : ''
    const colLClassname =
      (colL && colL !== colM) || (columns.colL !== columns.colM && colL > 0)
        ? `hrb-col--l_${colL}`
        : ''
    return `${colSClassname} ${colMClassname} ${colLClassname}`
  }

  getOffsetClassnames = (): string => {
    // if no offset at all, no need for classes
    if (!this.offsetS && !this.offsetM && !this.offsetL) return ''

    const offsetSClassname =
      this.offsetS > 0 ? `hrb-col--offset_s_${this.offsetS}` : ''
    const offsetMClassname =
      this.offsetM > 0 ? `hrb-col--offset_m_${this.offsetM}` : ''
    const offsetLClassname =
      this.offsetL > 0 ? `hrb-col--offset_l_${this.offsetL}` : ''

    return `${offsetSClassname} ${offsetMClassname} ${offsetLClassname}`
  }

  render(): JSX.Element {
    const isCentered = this.isCentered ? `hrb-flex-col--center` : ''

    return (
      <Host
        class={`hrb-flex-col
              ${isCentered}
              ${this.getColClassnames()}
              ${this.getOffsetClassnames()}
            `}
      >
        <slot />
      </Host>
    )
  }
}
