# hrb-flex-col

## Examples

The hrb-flex-col component goes inside of a two additional components:

hrb-flex-container (sets block, margin centered, width 100%)

hrb-flex-row (sets flex, wrap, and direction)

```.html
<hrb-flex-container>
  <hrb-flex-row>
    <hrb-flex-col>
      You're Content Can Go Here
    </hrb-flex-col>
  <hrb-flex-row>
</hrb-flex-container>
```

<!-- Auto Generated Below -->


## Properties

| Property     | Attribute  | Description                       | Type      | Default |
| ------------ | ---------- | --------------------------------- | --------- | ------- |
| `col`        | `col`      | Number of columns - Default size. | `number`  | `0`     |
| `colL`       | `col-l`    | Number of columns - L             | `number`  | `0`     |
| `colM`       | `col-m`    | Number of columns - M             | `number`  | `0`     |
| `colS`       | `col-s`    | Number of columns - S             | `number`  | `0`     |
| `isCentered` | `center`   | Is centered                       | `boolean` | `false` |
| `offsetL`    | `offset-l` | Offset - L                        | `number`  | `0`     |
| `offsetM`    | `offset-m` | Offset - M                        | `number`  | `0`     |
| `offsetS`    | `offset-s` | Offset - S                        | `number`  | `0`     |


## Dependencies

### Used by

 - [hrb-flex-ghost](../flex-ghost)

### Graph
```mermaid
graph TD;
  hrb-flex-ghost --> hrb-flex-col
  style hrb-flex-col fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
