import {
  Component,
  Event,
  EventEmitter,
  h,
  Host,
  Listen,
  Method,
  Prop,
  State,
} from '@stencil/core'

import { generateSimpleID, getClassnames } from '@src/utils/misc'
import { isIe11 } from '@src/utils/browser-tests'

import {
  key as keyConstants,
  keyCode as keyCodeConstants,
  keysThatOpenDropdown,
} from '@src/constants/keyboard-events'

import { observeDOM } from '@src/utils/mutationObserver'

import { TOptionListObject } from '../select/types'
import Constants from '../select/constants'

import {
  clearKeyClearTimeout,
  findItemToFocus,
  setListboxScrollPosition,
  willElementSitBelowFoldAndFitAboveContainer,
} from './utils'

@Component({
  tag: 'hrb-select-custom',
  styleUrl: 'select-custom.scss',
})
export class SelectCustom {
  @Event() hrbSelectBlur: EventEmitter

  @Event() hrbSelectChange: EventEmitter

  @Event() hrbSelectFocus: EventEmitter

  @Event() hrbSelectInput: EventEmitter

  /**
   * Input is disabled
   */
  @Prop() disabled: boolean

  /**
   * Error label
   */
  @Prop() errorLabel: string

  /**
   * Input has error
   */
  @Prop() hasError = false

  /**
   * Input helper text
   */
  @Prop() helperText: string

  /**
   * Label
   */
  @Prop() label = ''

  /**
   * Input is loading
   */
  @Prop() loading = false

  /**
   * Value
   */
  @Prop({ mutable: true }) value = ''

  /**
   * Option Group Name
   */
  @Prop({ mutable: true }) optionGroupName = ''

  /**
   * currently focused option
   */
  @State() currentlyFocusedOptionIndex = 0

  /**
   * index of currently selected option
   */
  @State() currentlySelectedOptionIndex: number

  /**
   * current active state
   */
  @State() isActive = false

  /**
   * current focus state
   */
  @State() isFocused = false

  /**
   * current focus state
   */
  @State() optionList: TOptionListObject[]

  @State() showDropdownAboveInput = false

  private activeDescendant = null

  private baseId = `${generateSimpleID()}__${Constants.baseId}`

  private containerRef: HTMLSpanElement

  private hasInitialized = false

  private ieBlurTimeout = null

  private ieFocusTimeout = null

  private optionListRef: HTMLUListElement

  private optionCount: number

  private optionNodes: NodeListOf<HTMLElement>

  private slotContainerRef: HTMLSpanElement

  private prevMousePosition = { x: 0, y: 0 }

  @Listen('optionClick') handleOnOptionClick(event: CustomEvent): void {
    const { detail } = event
    const { focusItem, getSelectedOptionNode, selectOption } = this
    const selectedOption = getSelectedOptionNode(detail)

    focusItem(detail)
    selectOption(selectedOption)
  }

  @Listen('optionMouseEnter') handleOnOptionMouseEnter(
    event: CustomEvent,
  ): void {
    const { prevMousePosition } = this
    const {
      detail: { clientX, clientY, optionCount },
    } = event

    const hasMouseMoved =
      clientX !== prevMousePosition.x || clientY !== prevMousePosition.y

    if (!hasMouseMoved) return

    this.prevMousePosition = { x: clientX, y: clientY }

    const isMouseEvent = true
    this.focusItem(optionCount, isMouseEvent)
  }

  @Method() async updateOptionList(): Promise<void> {
    this.hasInitialized = false
    this.getOptionList()
  }

  componentDidLoad(): void {
    const { hasInitialized, optionList } = this

    this.getOptionList()

    observeDOM(this.slotContainerRef, () => {
      this.getOptionList()
      this.hasInitialized = false
      // TODO: work on changing the selected node if it is not there
    })

    if (!hasInitialized && !!optionList) {
      this.initializeSelect()
    }
  }

  componentDidRender(): void {
    const { hasInitialized, optionList } = this

    if (!hasInitialized && !!optionList) {
      this.initializeSelect()
    }
  }

  componentDidUnload(): void {
    clearKeyClearTimeout()
    this.resetActiveState()
    this.clearIeBlurTimeout()
    this.clearIeFocusTimeout()
  }

  initializeSelect = (): void => {
    this.hasInitialized = true

    this.setOptionNodes()
    this.setOptionCount()
    this.checkForSelectedOption()
  }

  clearIeBlurTimeout = (): void => {
    const { ieBlurTimeout } = this

    if (ieBlurTimeout) {
      clearTimeout(ieBlurTimeout)
      this.ieBlurTimeout = null
    }
  }

  clearIeFocusTimeout = (): void => {
    const { ieFocusTimeout } = this

    if (ieFocusTimeout) {
      clearTimeout(ieFocusTimeout)
      this.ieFocusTimeout = null
    }
  }

  getOptionListFromOptGroup = (
    children: HTMLCollection,
    label: string,
  ): TOptionListObject[] => {
    const optGroupOptions = Array.from(children).map(
      (child: HTMLOptionElement): TOptionListObject => {
        return {
          isSelected: child.selected,
          text: child.textContent,
          value: child.value || child.textContent,
        }
      },
    )

    return [
      {
        isOptGroup: true,
        text: label,
      },
      ...optGroupOptions,
    ]
  }

  getOptionList = (): void => {
    const options = this.slotContainerRef.children

    const optionList = Array.from(options).map((option: HTMLOptionElement) => {
      const { children, label, tagName, textContent, value } = option

      if (tagName === Constants.childTypes.optGroup) {
        return this.getOptionListFromOptGroup(children, label)
      }

      const isSelected = this.value === value
      return {
        isSelected: isSelected,
        text: textContent,
        value: value || textContent,
      }
    })

    this.optionList = [].concat(...optionList)
  }

  setOptionCount = (): number => (this.optionCount = this.optionNodes.length)

  setOptionNodes = (): void => {
    const { optionListRef } = this

    this.optionNodes =
      !!optionListRef && optionListRef.querySelectorAll('[role=option]')
  }

  checkForSelectedOption = (): void => {
    const selectedIndex = this.optionList.findIndex(
      (option): boolean => option.value === this.value,
    )

    const found = this.optionList.some(el => el.isOptGroup === true)

    if (!found) {
      if (selectedIndex !== -1) {
        this.selectOption(this.getSelectedOptionNode(selectedIndex + 1))
        this.focusItem(selectedIndex + 1)
      }
    } else if (found) {
      if (selectedIndex !== -1) {
        this.selectOption(this.getSelectedOptionNode(selectedIndex))
        this.focusItem(selectedIndex)
      }
    }
  }

  // the option count starts at 1, but the node list is 0 based
  // so we need to subtract 1 when searching for our optionNode
  getSelectedOptionNode = (optionNodeIndex: number): HTMLElement =>
    this.optionNodes[optionNodeIndex - 1]

  getIndexOfSelectedOptionNode = (option: Element): number => {
    const { optionNodes } = this

    const indexOfOption = Array.from(optionNodes)
      .map(optionNode => optionNode.id)
      .findIndex(optionNodeId => optionNodeId === option.id)

    return indexOfOption + 1
  }

  checkListBoxScrollPosition = (): void => {
    const {
      currentlySelectedOptionIndex,
      currentlyFocusedOptionIndex,
      getSelectedOptionNode,
      isActive,
      optionListRef,
    } = this

    const targetOptionIndex =
      currentlySelectedOptionIndex || currentlyFocusedOptionIndex
    const targetOptionNode = getSelectedOptionNode(targetOptionIndex)

    if (isActive) {
      window.requestAnimationFrame(() => {
        setListboxScrollPosition(targetOptionNode, optionListRef)
      })
    }
  }

  checkListBoxScreenPosition = (): void => {
    const { containerRef, optionListRef, showDropdownAboveInput } = this

    const willPositionDropdownAboveContainer = willElementSitBelowFoldAndFitAboveContainer(
      containerRef,
      optionListRef,
    )

    if (showDropdownAboveInput !== willPositionDropdownAboveContainer) {
      this.showDropdownAboveInput = willPositionDropdownAboveContainer
    }

    window.addEventListener('scroll', this.checkListBoxScreenPosition)
  }

  resetActiveState = (willKeepFocus?: boolean): void => {
    this.isActive = false
    this.currentlyFocusedOptionIndex = 0
    this.showDropdownAboveInput = false
    window.removeEventListener('scroll', this.checkListBoxScreenPosition)

    if (willKeepFocus) {
      this.containerRef.focus()
    } else {
      this.isFocused = false
      this.hrbSelectBlur.emit(this)
    }
  }

  setActiveState = (): void => {
    const { currentlySelectedOptionIndex } = this

    this.checkListBoxScreenPosition()

    this.isActive = true
    this.isFocused = true
    this.currentlyFocusedOptionIndex = currentlySelectedOptionIndex || null
    this.hrbSelectFocus.emit(this)
  }

  selectOption = (option: Element): void => {
    const { getIndexOfSelectedOptionNode, isActive, resetActiveState } = this
    const { textContent } = option.querySelector('button')

    window.requestAnimationFrame(() => {
      this.value = textContent
      this.hrbSelectChange.emit(this)
      this.hrbSelectInput.emit(this)

      this.currentlySelectedOptionIndex = getIndexOfSelectedOptionNode(option)

      if (isActive) {
        this.containerRef.focus()
      }

      const willKeepFocus = true
      resetActiveState(willKeepFocus)
    })
  }

  focusItem = (itemIndex: number, isMouseEvent?: boolean): void => {
    const { isActive, getSelectedOptionNode, optionListRef } = this

    this.currentlyFocusedOptionIndex = itemIndex

    if (isActive && !isMouseEvent) {
      const element = getSelectedOptionNode(itemIndex)
      setListboxScrollPosition(element, optionListRef)
    }
  }

  focusNextOption = (): void => {
    const { currentlyFocusedOptionIndex, focusItem, optionCount } = this
    const nextOption = currentlyFocusedOptionIndex + 1

    if (nextOption > optionCount) {
      return
    }

    focusItem(nextOption)
  }

  focusPrevOption = (): void => {
    const { currentlyFocusedOptionIndex, focusItem } = this
    const prevOption = currentlyFocusedOptionIndex - 1

    if (prevOption <= 0) {
      return
    }

    focusItem(prevOption)
  }

  focusFirstOption = (): void => this.focusItem(1)

  focusLastOption = (): void => this.focusItem(this.optionCount)

  closeOptions = (): void => {
    const willKeepFocus = true
    this.resetActiveState(willKeepFocus)
    this.containerRef.focus()
  }

  handleReturnPress = (): void => {
    const {
      currentlyFocusedOptionIndex,
      getSelectedOptionNode,
      selectOption,
    } = this
    const selectedOption = getSelectedOptionNode(currentlyFocusedOptionIndex)

    if (!selectedOption) {
      const willKeepFocus = true
      this.resetActiveState(willKeepFocus)
      return
    }

    selectOption(selectedOption)
  }

  keyEventMap: object = {
    arrowDown: this.focusNextOption,
    arrowUp: this.focusPrevOption,
    home: this.focusFirstOption,
    end: this.focusLastOption,
    escape: this.closeOptions,
    pageDown: this.focusNextOption,
    pageUp: this.focusPrevOption,
    returnK: this.handleReturnPress,
    space: this.handleReturnPress,
  }

  handleOnBlur = (event?: FocusEvent): void => {
    const {
      clearIeBlurTimeout,
      currentlySelectedOptionIndex,
      focusItem,
      resetActiveState,
    } = this
    const relatedTarget = !!event && (event.relatedTarget as HTMLElement)

    if (relatedTarget && this.containerRef.contains(relatedTarget)) {
      return
    }

    if (isIe11) {
      this.ieBlurTimeout = setTimeout(() => {
        resetActiveState()
        clearIeBlurTimeout()

        if (currentlySelectedOptionIndex) {
          focusItem(currentlySelectedOptionIndex)
        }
      }, Constants.ieBlurDelay)

      return
    }

    resetActiveState()

    if (currentlySelectedOptionIndex) {
      focusItem(currentlySelectedOptionIndex)
    }
  }

  handleOnClick = (): void => {
    const { checkListBoxScrollPosition, isActive, resetActiveState } = this

    if (isActive) {
      resetActiveState()
      return
    }

    this.setActiveState()
    window.requestAnimationFrame(() => this.optionListRef.focus())

    checkListBoxScrollPosition()
  }

  handleOnFocus = (): void => {
    this.isFocused = true
    this.hrbSelectFocus.emit(this)
  }

  handleIeOnOptionListFocus = (): void => {
    const { clearIeFocusTimeout, setActiveState } = this
    const { ieBlurDelay } = Constants

    this.ieFocusTimeout = setTimeout(() => {
      setActiveState()
      clearIeFocusTimeout()
    }, ieBlurDelay + 2)
  }

  handleOnKeyDown = (event: KeyboardEvent): void => {
    const {
      activeDescendant,
      checkListBoxScrollPosition,
      currentlySelectedOptionIndex,
      isActive,
      focusItem,
      optionCount,
      optionNodes,
      setActiveState,
    } = this
    const { keyCode, key } = event
    const keyValue = key ? keyConstants[key] : keyCodeConstants[keyCode]

    if (!keyValue) {
      const itemToFocusIndex = findItemToFocus(
        keyCode,
        key,
        activeDescendant,
        optionCount,
        optionNodes,
      )

      if (itemToFocusIndex) {
        setActiveState()
        focusItem(itemToFocusIndex)
      }

      return
    }

    if (!isActive && keysThatOpenDropdown.includes(keyValue)) {
      event.preventDefault()

      setActiveState()
      window.requestAnimationFrame(() => this.optionListRef.focus())
      checkListBoxScrollPosition()

      if (key === 'space' || keyCode === 32 || currentlySelectedOptionIndex) {
        return
      }
    }

    event.preventDefault()

    if (isActive) {
      this.keyEventMap[keyValue]()
    }
  }

  renderLoader = (): JSX.Element => {
    return (
      <span
        class={`${Constants.baseClassnameCustom}__loader`}
        aria-hidden="true"
      >
        <hrb-loader></hrb-loader>
      </span>
    )
  }

  renderError = (): JSX.Element => {
    const { errorLabel } = this
    const { baseClassnameCustom } = Constants

    return (
      <span class={`${baseClassnameCustom}__error`} role="alert">
        {errorLabel}
      </span>
    )
  }

  renderHelper = (): JSX.Element => {
    const { helperText, baseId } = this
    const { baseClassnameCustom } = Constants

    return (
      <div id={`${baseId}__helper`} class={`${baseClassnameCustom}__helper`}>
        {helperText}
      </div>
    )
  }

  renderOptGroupLabel = (label: string): HTMLElement => {
    const { baseClassnameCustom } = Constants

    return <li class={`${baseClassnameCustom}__opt-group-label`}>{label}</li>
  }

  render(): JSX.Element {
    const {
      baseId,
      currentlyFocusedOptionIndex,
      currentlySelectedOptionIndex,
      disabled,
      errorLabel,
      getSelectedOptionNode,
      handleIeOnOptionListFocus,
      handleOnBlur,
      handleOnClick,
      handleOnFocus,
      handleOnKeyDown,
      handleOnOptionClick,
      handleOnOptionMouseEnter,
      hasError,
      helperText,
      isActive,
      isFocused,
      label,
      loading,
      optionList,
      renderError,
      renderHelper,
      renderLoader,
      showDropdownAboveInput,
      value,
    } = this
    const {
      baseClassnameCustom,
      inputIcons: { chevronDown, chevronUp },
    } = Constants

    const currentlyFocusedOption =
      currentlyFocusedOptionIndex > 0
        ? getSelectedOptionNode(currentlyFocusedOptionIndex)
        : null

    const iconBaseClassname = `${baseClassnameCustom}__icon`
    const containerClassnames = getClassnames([
      baseClassnameCustom,
      !!value && `${baseClassnameCustom}--has-text`,
      isActive && `${baseClassnameCustom}--is-active`,
      isFocused && `${baseClassnameCustom}--is-focused`,
      hasError && `${baseClassnameCustom}--has-error`,
      disabled && `${baseClassnameCustom}--is-disabled`,
      loading && `${baseClassnameCustom}--is-loading`,
      showDropdownAboveInput && `${baseClassnameCustom}--has-top-dropdown`,
    ])

    let indexIterator = -1

    return (
      <Host>
        <span
          aria-haspopup="listbox"
          aria-labelledby={`${baseId}__label ${baseId}__input`}
          class={containerClassnames}
          onBlur={!disabled && handleOnBlur}
          onFocus={!disabled && handleOnFocus}
          onKeyDown={!disabled && handleOnKeyDown}
          ref={(el): HTMLSpanElement =>
            (this.containerRef = el as HTMLSpanElement)
          }
          role="button"
          tabIndex={disabled ? -1 : 0}
          aria-disabled={disabled ? 'true' : 'false'}
          data-hrb-select-focus-target
        >
          <span id={`${baseId}__label`} class={`${baseClassnameCustom}__label`}>
            {label}
          </span>
          {/* eslint-disable-next-line jsx-a11y/interactive-supports-focus, jsx-a11y/click-events-have-key-events */}
          <span
            class={`${baseClassnameCustom}__button`}
            onClick={!disabled && handleOnClick}
            role="button"
          >
            <input
              class={`${baseClassnameCustom}__value`}
              readOnly
              value={value}
              id={`${baseId}__input`}
              tabIndex={-1}
              disabled={disabled}
              data-hrb-select-input
            />
            <span class={`${iconBaseClassname}-container`}>
              <hrb-icon
                name={chevronUp}
                class={`${iconBaseClassname} ${iconBaseClassname}-up`}
              ></hrb-icon>
              <hrb-icon
                name={chevronDown}
                class={`${iconBaseClassname} ${iconBaseClassname}-down`}
              ></hrb-icon>
            </span>
            {loading && renderLoader()}
          </span>
          <span class={`${baseClassnameCustom}__option-container`}>
            {/* eslint-disable-next-line jsx-a11y/aria-activedescendant-has-tabindex */}
            <ul
              role="listbox"
              aria-activedescendant={
                currentlyFocusedOption ? currentlyFocusedOption.id : null
              }
              tabIndex={-1}
              aria-hidden={isActive ? 'false' : 'true'}
              aria-labelledby={`${baseId}__label`}
              class={`${baseClassnameCustom}__option-list`}
              onBlur={handleOnBlur}
              onFocus={isIe11 ? handleIeOnOptionListFocus : null}
              ref={(el): HTMLUListElement =>
                (this.optionListRef = el as HTMLUListElement)
              }
            >
              {!!optionList &&
                optionList.map(
                  (option: TOptionListObject): HTMLElement => {
                    if (option.isOptGroup) {
                      this.optionGroupName = option.text
                      return this.renderOptGroupLabel(option.text)
                    }

                    indexIterator += 1

                    return (
                      <li>
                        <hrb-select-option
                          base-id={baseId}
                          currentlyFocusedOptionIndex={
                            currentlyFocusedOptionIndex
                          }
                          currentlySelectedOptionIndex={
                            currentlySelectedOptionIndex
                          }
                          index={indexIterator}
                          option={option}
                          option-click={handleOnOptionClick}
                          option-mouse-enter={handleOnOptionMouseEnter}
                          option-group={this.optionGroupName}
                        ></hrb-select-option>
                      </li>
                    )
                  },
                )}
            </ul>
          </span>
          <span
            class={`${baseClassnameCustom}__slots`}
            ref={(el): HTMLSpanElement =>
              (this.slotContainerRef = el as HTMLSpanElement)
            }
          >
            <slot />
          </span>
        </span>
        {hasError && !!errorLabel && renderError()}
        {helperText && renderHelper()}
        <span
          aria-atomic="true"
          aria-live="assertive"
          class={`${baseClassnameCustom}__live-region`}
          role="dialog"
        >
          {value}
        </span>
      </Host>
    )
  }
}
