# hrb-select-custom

<!-- Auto Generated Below -->


## Properties

| Property          | Attribute           | Description       | Type      | Default     |
| ----------------- | ------------------- | ----------------- | --------- | ----------- |
| `disabled`        | `disabled`          | Input is disabled | `boolean` | `undefined` |
| `errorLabel`      | `error-label`       | Error label       | `string`  | `undefined` |
| `hasError`        | `has-error`         | Input has error   | `boolean` | `false`     |
| `helperText`      | `helper-text`       | Input helper text | `string`  | `undefined` |
| `label`           | `label`             | Label             | `string`  | `''`        |
| `loading`         | `loading`           | Input is loading  | `boolean` | `false`     |
| `optionGroupName` | `option-group-name` | Option Group Name | `string`  | `''`        |
| `value`           | `value`             | Value             | `string`  | `''`        |


## Events

| Event             | Description | Type               |
| ----------------- | ----------- | ------------------ |
| `hrbSelectBlur`   |             | `CustomEvent<any>` |
| `hrbSelectChange` |             | `CustomEvent<any>` |
| `hrbSelectFocus`  |             | `CustomEvent<any>` |
| `hrbSelectInput`  |             | `CustomEvent<any>` |


## Methods

### `updateOptionList() => Promise<void>`



#### Returns

Type: `Promise<void>`




## Dependencies

### Used by

 - [hrb-select](../select)

### Depends on

- [hrb-loader](../loader)
- [hrb-icon](../icon)
- [hrb-select-option](../select-option)

### Graph
```mermaid
graph TD;
  hrb-select-custom --> hrb-loader
  hrb-select-custom --> hrb-icon
  hrb-select-custom --> hrb-select-option
  hrb-select-option --> hrb-icon
  hrb-select --> hrb-select-custom
  style hrb-select-custom fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
