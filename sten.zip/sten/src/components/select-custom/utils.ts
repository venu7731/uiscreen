const Constants = {
  keysSoFar: '',
  keyClearTimeout: null,
}

const findMatchInRange = (
  optionNodes: NodeListOf<HTMLElement>,
  startIndex: number,
  endIndex: number,
): number => {
  for (let i = startIndex; i < endIndex; i += 1) {
    const selectedOption = optionNodes[i]
    const { innerText } = selectedOption.querySelector('button')

    if (
      innerText &&
      innerText.toLowerCase().indexOf(Constants.keysSoFar) === 0
    ) {
      return i + 1
    }
  }

  return null
}

export const clearKeyClearTimeout = (): void => {
  if (Constants.keyClearTimeout) {
    clearTimeout(Constants.keyClearTimeout)
    Constants.keyClearTimeout = null
  }
}

const clearKeysSoFarAfterDelay = (): void => {
  clearKeyClearTimeout()

  Constants.keyClearTimeout = setTimeout(() => {
    Constants.keysSoFar = ''
    Constants.keyClearTimeout = null
  }, 500)
}

export const findItemToFocus = (
  keyCode: number,
  key: string,
  activeDescendant: string,
  optionCount: number,
  optionNodes: NodeListOf<HTMLElement>,
): number => {
  const character = key || String.fromCharCode(keyCode)
  let searchIndex = 0

  if (!Constants.keysSoFar) {
    optionNodes.forEach((option: HTMLElement, index: number) => {
      if (option.id === activeDescendant) {
        searchIndex = index
      }
    })
  }

  Constants.keysSoFar += character
  clearKeysSoFarAfterDelay()

  const nextMatch =
    findMatchInRange(optionNodes, searchIndex, optionCount) ||
    findMatchInRange(optionNodes, 0, searchIndex)

  return nextMatch
}

export const setListboxScrollPosition = (
  option: HTMLElement,
  optionListRef: HTMLElement,
): void => {
  const optionListNode = optionListRef
  const { clientHeight, scrollHeight, scrollTop } = optionListRef

  if (!option) {
    optionListNode.scrollTop = 0
    return
  }

  const {
    offsetTop: optionOffsetTop,
    offsetHeight: optionOffsetHeight,
  } = option

  if (scrollHeight > clientHeight) {
    const scrollBottom = clientHeight + scrollTop
    const optionBottom = optionOffsetTop + optionOffsetHeight

    if (optionBottom > scrollBottom) {
      // if the option is below the container view scroll down
      optionListNode.scrollTop = optionBottom - clientHeight
    } else if (optionOffsetTop < scrollTop) {
      // if the option is above the container view scroll up
      optionListNode.scrollTop = optionOffsetTop - 15
    }
  }
}

export const willElementSitBelowFoldAndFitAboveContainer = (
  containerRef: HTMLElement,
  optionListRef: HTMLElement,
): boolean => {
  const viewportHeight = window.innerHeight
  const {
    bottom: containerBottom,
    top: containerTop,
  } = containerRef.getBoundingClientRect()
  const { height, maxHeight } = getComputedStyle(optionListRef)
  const optionListHeight = parseInt(
    !!maxHeight && maxHeight !== 'none' ? maxHeight : height,
    10,
  )

  if (optionListHeight > containerTop) {
    return false
  }

  if (containerBottom + optionListHeight > viewportHeight) {
    return true
  }

  return false
}
