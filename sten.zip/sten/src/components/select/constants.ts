const Constants = {
  baseClassname: 'hrb-select',
  baseClassnameCustom: 'hrb-select-custom',
  baseClassnameNative: 'hrb-select-native',
  baseClassnameOption: 'hrb-select-option',
  baseId: `hrb-select`,
  childTypes: {
    option: 'OPTION',
    optGroup: 'OPTGROUP',
  },
  ieBlurDelay: 200,
  inputIcons: {
    chevronDown: 'chevron-down',
    chevronUp: 'chevron-up',
  },
}

export default Constants
