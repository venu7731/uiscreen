# hrb-select

The `hrb-select` element reproduces a `select` element's behavior and functionality by creating a styled and accessible drop-down list.

If the user is in a mobile context, it fallbacks to a classic `select` element behind the scenes when the user interacts with the element, and displays a standard selection UI.

Start using the `hrb-select` element with a `label` prop by simply adding standard `option` children.
Using the `value` prop is recommended, but its value would be taken from the text content of the `option` element if not provided.

```html
<hrb-select label="What's your favorite dinosaur?">
  <option value="Tyrannosaurus">Tyrannosaurus</option>
  <option value="Velociraptor">Velociraptor</option>
  <option value="Deinonychus">Deinonychus</option>
  <option value="Dino">Dino</option>
</hrb-select>
```

You can also use `optgroup` with a `label` prop to group your options:

```html
<hrb-select label="What's your favorite dinosaur?">
  <optgroup label="Theropods">
    <option value="Tyrannosaurus">Tyrannosaurus</option>
    <option value="Velociraptor">Velociraptor</option>
    <option value="Deinonychus">Deinonychus</option>
    <option value="Dino">Dino</option>
  </optgroup>
  <optgroup label="Other">
    <option value="anotherOption">Another option</option>
    <option value="anOption">An option</option>
    <option value="last">The default selected option</option>
  </optgroup>
</hrb-select>
```

## Event Examples

We've added custom events to expose a consistent API across all the custom inputs and accomodate for specific events that are not available by default on custom elements, such as `change`, `focus` and `blur`.

Every custom events return a reference to element, available in `e.detail`.

```js
const selectMenus = form.querySelectorAll('hrb-select')

// Focus
selectMenus[0].addEventListener('hrbFocus', e => {
  console.log('hrbFocus =>', e)
})

// Blur
selectMenus[0].addEventListener('hrbBlur', e => {
  console.log('blur', e.detail)
})

// Change
selectMenus[0].addEventListener('hrbChange', e => {
  console.log('change', e.detail)
})

// Input
selectMenus[0].addEventListener('hrbInput', e => {
  console.log('input', e.detail)
})
```

## Method Examples

Every exposed methods return a `Promise`.

```js
const selectMenus = form.querySelectorAll('hrb-select')

// get the main input element inside the `hrb-select`
const element = await selectMenus[0].getElement()

// set the focus on the element
await selectMenus[0].setFocus()
```

<!-- Auto Generated Below -->


## Properties

| Property     | Attribute     | Description       | Type      | Default     |
| ------------ | ------------- | ----------------- | --------- | ----------- |
| `disabled`   | `disabled`    | Disabled          | `boolean` | `false`     |
| `errorLabel` | `error-label` | Error label       | `string`  | `undefined` |
| `hasError`   | `has-error`   | Input has error   | `boolean` | `false`     |
| `helperText` | `helper-text` | Input helper text | `string`  | `undefined` |
| `label`      | `label`       | Label             | `string`  | `''`        |
| `loading`    | `loading`     | Input is loading  | `boolean` | `false`     |
| `value`      | `value`       | Select value      | `string`  | `undefined` |


## Events

| Event       | Description | Type               |
| ----------- | ----------- | ------------------ |
| `hrbBlur`   |             | `CustomEvent<any>` |
| `hrbChange` |             | `CustomEvent<any>` |
| `hrbFocus`  |             | `CustomEvent<any>` |
| `hrbInput`  |             | `CustomEvent<any>` |


## Methods

### `getElement() => Promise<HTMLElement>`



#### Returns

Type: `Promise<HTMLElement>`



### `setFocus() => Promise<void>`



#### Returns

Type: `Promise<void>`




## Dependencies

### Depends on

- [hrb-select-native](../select-native)
- [hrb-select-custom](../select-custom)

### Graph
```mermaid
graph TD;
  hrb-select --> hrb-select-native
  hrb-select --> hrb-select-custom
  hrb-select-native --> hrb-loader
  hrb-select-native --> hrb-icon
  hrb-select-custom --> hrb-loader
  hrb-select-custom --> hrb-icon
  hrb-select-custom --> hrb-select-option
  hrb-select-option --> hrb-icon
  style hrb-select fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
