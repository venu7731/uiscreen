export type TOptionListObject = {
  isOptGroup?: boolean
  isSelected?: boolean
  text: string
  value?: string
}
