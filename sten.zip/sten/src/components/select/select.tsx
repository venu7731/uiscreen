import {
  Component,
  Element,
  Event,
  EventEmitter,
  h,
  Host,
  Listen,
  Method,
  Prop,
} from '@stencil/core'

import { isMobileOrTablet } from '@src/utils/browser-tests'

import Constants from './constants'

@Component({
  tag: 'hrb-select',
  styleUrl: 'select.scss',
})
export class Select {
  @Element() el: HTMLElement

  @Event() hrbBlur: EventEmitter

  @Event() hrbChange: EventEmitter

  @Event() hrbFocus: EventEmitter

  @Event() hrbInput: EventEmitter

  @Method() async getElement(): Promise<HTMLElement> {
    const target = this.el.querySelector(
      '[data-hrb-select-input]',
    ) as HTMLElement

    return target
  }

  @Method() async setFocus(): Promise<void> {
    const target = this.el.querySelector(
      '[data-hrb-select-focus-target]',
    ) as HTMLElement

    target.focus()
  }

  /**
   * Disabled
   */
  @Prop() disabled = false

  /**
   * Error label
   */
  @Prop() errorLabel: string

  /**
   * Input has error
   */
  @Prop() hasError = false

  /**
   * Input helper text
   */
  @Prop() helperText: string

  /**
   * Label
   */
  @Prop() label = ''

  /**
   * Input is loading
   */
  @Prop() loading = false

  /**
   * Select value
   */
  @Prop({ mutable: true }) value: string

  @Listen('hrbSelectChange') handleChange(event: CustomEvent): void {
    this.hrbChange.emit(event.detail)
  }

  @Listen('hrbSelectBlur') handleBlur(event: CustomEvent): void {
    this.hrbBlur.emit(event.detail)
  }

  @Listen('hrbSelectFocus') handleFocus(event: CustomEvent): void {
    this.hrbFocus.emit(event.detail)
  }

  @Listen('hrbSelectInput') handleInput(event: CustomEvent): void {
    const { detail } = event

    this.value = detail.value
    this.hrbInput.emit(detail)
  }

  renderNativeSelect = (): JSX.Element => {
    const { disabled, errorLabel, hasError, label, loading, value } = this

    return (
      <hrb-select-native
        disabled={disabled}
        errorLabel={errorLabel}
        hasError={hasError}
        label={label}
        loading={loading}
        value={value}
      >
        <slot />
      </hrb-select-native>
    )
  }

  renderCustomSelect = (): JSX.Element => {
    const { disabled, errorLabel, hasError, label, loading, value } = this

    return (
      <hrb-select-custom
        disabled={disabled}
        errorLabel={errorLabel}
        hasError={hasError}
        label={label}
        loading={loading}
        value={value}
      >
        <slot />
      </hrb-select-custom>
    )
  }

  render(): JSX.Element {
    const { renderCustomSelect, renderNativeSelect, value } = this

    return (
      <Host value={value} class={Constants.baseClassname}>
        {isMobileOrTablet ? renderNativeSelect() : renderCustomSelect()}
      </Host>
    )
  }
}
