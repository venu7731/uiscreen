import { newSpecPage } from '@stencil/core/testing'

import { Select } from '../select'

describe('Select', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [Select],
      html: `
      <hrb-select label="My First Label">
              <optgroup label="Theropods">
                <option>Tyrannosaurus</option>
                <option>Velociraptor</option>
                <option>Deinonychus</option>
                <option>Dino</option>
              </optgroup>
              <optgroup label="Other">
                <option value="anotherOption">Another option</option>
                <option value="anOption">An option</option>
                <option value="last">The default selected option</option>
              </optgroup>
            </hrb-select>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-select class="hrb-select" label="My First Label">
      <hrb-select-custom label="My First Label">
        <optgroup label="Theropods">
          <option>
            Tyrannosaurus
          </option>
          <option>
            Velociraptor
          </option>
          <option>
            Deinonychus
          </option>
          <option>
            Dino
          </option>
        </optgroup>
        <optgroup label="Other">
          <option value="anotherOption">
            Another option
          </option>
          <option value="anOption">
            An option
          </option>
          <option value="last">
            The default selected option
          </option>
        </optgroup>
      </hrb-select-custom>
    </hrb-select>
    `)
  })
})
