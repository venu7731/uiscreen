import { boolean, text, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import { groupIds, reset } from '@src/constants/storybook'

import * as readme from './readme.md'

const slot = `
  <optgroup label="Theropods">
    <option>Tyrannosaurus</option>
    <option>Velociraptor</option>
    <option>Deinonychus</option>
    <option>Megalosaurus</option>
  </optgroup>
  <optgroup label="Other">
    <option value="anotherOption">Another option</option>
    <option value="anOption">An option</option>
    <option value="last">The last option</option>
  </optgroup>
`

/* eslint-disable-next-line */
const selects = (disabled, errorLabel, hasError, label, loading, value) => `
  <hrb-select label="${label}" disabled="${disabled}" has-error="${hasError}" error-label="${errorLabel}" loading="${loading}" value="${value}">
    ${slot}
  </hrb-select>
`

const wrapperOpen = `${reset}<div style="margin-top: 30px; padding: 30px">`
const wrapperClose = `</div>`

storiesOf('Forms/Selects', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-select'],
    notes: { markdown: readme },
  })
  .add('Select', () => {
    return `${wrapperOpen}
    
    ${selects(
      boolean('Disabled', false, groupIds.testable),
      text('Error Label', 'Invalid selection', groupIds.testable),
      boolean('Has Error', false, groupIds.testable),
      text('Label', 'My First Label', groupIds.testable),
      boolean('Loading', false, groupIds.testable),
      text('Value', '', groupIds.additional),
    )}
    
    ${wrapperClose}`
  })
