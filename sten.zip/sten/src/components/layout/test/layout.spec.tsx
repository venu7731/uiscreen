import { newSpecPage } from '@stencil/core/testing'

import { HrbLayout } from '../layout'

describe('HrbLayout', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbLayout],
      html: `
      <hrb-layout layout="1col"
        layout-small="2col"
        layout-medium="4col"
        layout-large="2col">
        <div style="background: #e2e2e2; border-radius: 16px; padding: 32px;">Col</div>
        <div style="background: #e2e2e2; border-radius: 16px; padding: 32px;">Col</div>
        <div style="background: #e2e2e2; border-radius: 16px; padding: 32px;">Col</div>
        <div style="background: #e2e2e2; border-radius: 16px; padding: 32px;">Col</div>
      </hrb-layout>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-layout class="hrb-layout hrb-layout__layout-1col--base hrb-layout__layout-2col--large hrb-layout__layout-2col--small hrb-layout__layout-4col--medium" layout="1col" layout-large="2col" layout-medium="4col" layout-small="2col">
      <div style="background: #e2e2e2; border-radius: 16px; padding: 32px;">
        Col
      </div>
      <div style="background: #e2e2e2; border-radius: 16px; padding: 32px;">
        Col
      </div>
      <div style="background: #e2e2e2; border-radius: 16px; padding: 32px;">
        Col
      </div>
      <div style="background: #e2e2e2; border-radius: 16px; padding: 32px;">
        Col
      </div>
    </hrb-layout>
    `)
  })
})
