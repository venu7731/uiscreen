import * as readme from './readme.md'

export default {
  component: 'hrb-layout',
  title: 'Layouts/Generic Layouts',
  parameters: {
    notes: { markdown: readme },
  },
}

export const OneColumn = (): string =>
  `
  <hrb-layout layout="1col">
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
  </hrb-layout>
  `

export const TwoColumn = (): string =>
  `
  <hrb-layout layout="2col">
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
  </hrb-layout>
  `

export const ThreeColumn = (): string =>
  `
  <hrb-layout layout="3col">
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
  </hrb-layout>
  `

export const FourColumn = (): string =>
  `
  <hrb-layout layout="4col">
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
  </hrb-layout>
  `

export const FiveColumn = (): string =>
  `
  <hrb-layout layout="5col">
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
  </hrb-layout>
  `

export const ThreeToOne = (): string =>
  `
  <hrb-layout layout="3to1">
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
  </hrb-layout>
  `

export const OneToThree = (): string =>
  `
  <hrb-layout layout="1to3">
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
  </hrb-layout>
  `

export const ThreeToTwo = (): string =>
  `
  <hrb-layout layout="3to2">
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
  </hrb-layout>
  `

export const TwoToThree = (): string =>
  `
  <hrb-layout layout="2to3">
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
    <hrb-card theme="medium-light-yellow">
      <hrb-card-content>
        <hrb-text>Placeholder card</hrb-text>
      </hrb-card-content>
    </hrb-card>
  </hrb-layout>
  `
