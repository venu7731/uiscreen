import { Component, h, Host, Prop } from '@stencil/core'

import { getClassnames } from '@src/utils/misc'

import { TLayoutTypes } from './layouts'

const Constants = {
  baseClassname: 'hrb-layout',
}

@Component({
  tag: 'hrb-layout',
  styleUrl: 'layout.scss',
})
export class HrbLayout {
  /**
   * Base layout will work across all break points unless overridden by a more specific layout property outlined below.
   */
  @Prop() layout: TLayoutTypes = ''

  /**
   * Large layout will work 1200px and above
   */
  @Prop() layoutLarge: TLayoutTypes = ''

  /**
   * Medium layout will work 900px and above
   */
  @Prop() layoutMedium: TLayoutTypes = ''

  /**
   * Small layout will work 500px and above
   */
  @Prop() layoutSmall: TLayoutTypes = ''

  /**
   * Has transition.
   * This will add a "has-transition" class to the element.
   */
  @Prop() hasTransition = false

  /**
   * Setting to true will remove the gap between columns
   */
  @Prop() isGapless = 'false'

  /**
   * Setting to true will remove the negative margin on the outsides
   */
  @Prop() isFlush = 'false'

  render(): JSX.Element {
    const {
      layout,
      layoutLarge,
      layoutMedium,
      layoutSmall,
      isGapless,
      isFlush,
      hasTransition,
    } = this

    const classes = getClassnames([
      `${Constants.baseClassname}`,
      layout && `${Constants.baseClassname}__layout-${layout}--base`,
      layoutSmall && `${Constants.baseClassname}__layout-${layoutSmall}--small`,
      layoutMedium &&
        `${Constants.baseClassname}__layout-${layoutMedium}--medium`,
      layoutLarge && `${Constants.baseClassname}__layout-${layoutLarge}--large`,
      isGapless === 'true' && `${Constants.baseClassname}__is-gapless`,
      isFlush === 'true' && `${Constants.baseClassname}__is-flush`,
      hasTransition && `${Constants.baseClassname}__has-transition`,
    ])

    return <Host class={classes}></Host>
  }
}
