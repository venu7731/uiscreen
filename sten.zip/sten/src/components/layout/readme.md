# hrb-layout

Layouts are there to make the layout of the page a simpler experience. Wrapping a group of sibling block-level elements in a layout component will produce the number of columns, or the layout, specified by the `layout` attribute.

The goal is simplify the laying out of screens by utilizing the modern layout capabilities of the browser.

## Examples

**The following will produce a two column layout:**

```
<hrb-layout layout="2col">
    <div>...</div>
    <div>...</div>
</hrb-layout>
```

**The following will produce a two column layout where the third item wrapes to the next line:**

```
<hrb-layout layout="2col">
    <div>...</div>
    <div>...</div>
    <div>...</div> //Wraps to the next line
</hrb-layout>
```

**Different layouts at different breakpoints**
You can also determine if your layout needs to change at one of our predefined three breakpoints. The corresponding attributes are `layout-large, layout-medium, layout-small`. When you use any one of these, you will override the base attribute `layout` at that breakpoint **and above** since our breakpoints are mobile first (using min-widths).

**Here we increase the number of columns as the available realestate grows.**

```
<hrb-layout layout="2col" layout-medium="3col" layout-large="5col">
    <div>...</div>
    <div>...</div>
    <div>...</div>
    <div>...</div>
    <div>...</div>
</hrb-layout>
```

**Gutters**
The default gutter (space between columns and rows) is 40px. It can be removed by setting the attribute `is-gapless=:"true"` (defaults to "false").

```
<hrb-layout layout="2col" is-gapless="true">
    <div>...</div>
    <div>...</div>
    <div>...</div>
    <div>...</div>
    <div>...</div>
</hrb-layout>
```

## Current Generic Layouts

- `<hrb-layout layout="1col">`
- `<hrb-layout layout="2col">`
- `<hrb-layout layout="3col">`
- `<hrb-layout layout="4col">`
- `<hrb-layout layout="5col">`
- `<hrb-layout layout="3to1">`
- `<hrb-layout layout="1to3">`

## Current Specific Layouts

**Cards** currently represent a specific challenge when laying them out in a grid. Accordingly, we have made "specific layouts" to deal with those elements:

- `<hrb-layout layout="card-list">`
- `<hrb-layout layout="card-grid">`

---

<!-- Auto Generated Below -->


## Properties

| Property        | Attribute        | Description                                                                                                        | Type                                                                                                                         | Default   |
| --------------- | ---------------- | ------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------- | --------- |
| `hasTransition` | `has-transition` | Has transition. This will add a "has-transition" class to the element.                                             | `boolean`                                                                                                                    | `false`   |
| `isFlush`       | `is-flush`       | Setting to true will remove the negative margin on the outsides                                                    | `string`                                                                                                                     | `'false'` |
| `isGapless`     | `is-gapless`     | Setting to true will remove the gap between columns                                                                | `string`                                                                                                                     | `'false'` |
| `layout`        | `layout`         | Base layout will work across all break points unless overridden by a more specific layout property outlined below. | `"" \| "1col" \| "1to3" \| "2col" \| "2to3" \| "3col" \| "3to1" \| "3to2" \| "4col" \| "5col" \| "card-grid" \| "card-list"` | `''`      |
| `layoutLarge`   | `layout-large`   | Large layout will work 1200px and above                                                                            | `"" \| "1col" \| "1to3" \| "2col" \| "2to3" \| "3col" \| "3to1" \| "3to2" \| "4col" \| "5col" \| "card-grid" \| "card-list"` | `''`      |
| `layoutMedium`  | `layout-medium`  | Medium layout will work 900px and above                                                                            | `"" \| "1col" \| "1to3" \| "2col" \| "2to3" \| "3col" \| "3to1" \| "3to2" \| "4col" \| "5col" \| "card-grid" \| "card-list"` | `''`      |
| `layoutSmall`   | `layout-small`   | Small layout will work 500px and above                                                                             | `"" \| "1col" \| "1to3" \| "2col" \| "2to3" \| "3col" \| "3to1" \| "3to2" \| "4col" \| "5col" \| "card-grid" \| "card-list"` | `''`      |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
