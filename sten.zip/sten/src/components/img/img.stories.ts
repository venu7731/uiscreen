import { number, select, text, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import { imageLoadingTypes, reset } from '@src/constants/storybook'

import * as readme from './readme.md'

/* eslint-disable-next-line */
const img = (src, srcset, alt, height, width, pLoading) =>
  `<hrb-img
    src="${src}"
    srcset="${srcset}"
    alt="${alt}"
    height="${height}"
    width="${width}"
    p-loading="${pLoading}">
  </hrb-img>`

const wrapperOpen = `${reset}<div style="padding: 30px">`
const wrapperClose = `</div>`

storiesOf('Image', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-img'],
    notes: { markdown: readme },
  })
  .add('Image', () => {
    return `${wrapperOpen}

    ${img(
      text('Src', 'https://picsum.photos/700/400'),
      text(
        'Srcset',
        `https://picsum.photos/700/400 1x, https://picsum.photos/1400/800 2x, https://picsum.photos/2100/1200 3x`,
      ),
      text('Alt', 'Alt text'),
      number('Height', 400),
      number('Width', 700),
      select('P Loading', imageLoadingTypes, imageLoadingTypes[2]),
    )}

    ${wrapperClose}`
  })
