export type TLoadingTypes = 'auto' | 'eager' | 'lazy'
