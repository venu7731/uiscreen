# hrb-img

The `hrb-img` component displays an image with some neat extra features, such as lazyloading and `srcset` support.

📝 Note: Lazyloading is a front-end technique that consists of loading (requesting) and displaying a ressource **only** if the ressource is present in the user's viewport. It saves user bandwidth, and improves performances.

```html
<hrb-img
  src="https://picsum.photos/1400/800"
  alt="some alt text"
  height="400"
  width="700"
></hrb-img>
```

## Examples

The `p-loading` prop aims to implement the new standard `loading` attribute on the `img` generated element, giving control over a ressource to be either lazyloaded (`lazy`, by default in the `hrb-img` component), `eager` (forced not to be lazyloaded, the `img` element requests the ressource immediately, which is a classic behavior) or `auto` (depends of the browser's choice).

```html
<!-- Request the image right away -->
<hrb-img
  src="https://picsum.photos/1400/800"
  alt="some alt text"
  height="400"
  width="700"
  p-loading="eager"
></hrb-img>
```

📝 Note: The Lazyloading technique is based on IO (Intersection Observer), therefore it's really **recommended** to give a `width` and `height` value so the image acts as a container, and doesn't change the layout of the page once the image is loaded.

---

You can use the `srcset` prop to pass a serie of sources, according to the `srcset` specs.

📝 Note: Lazyloading works also with sources specified in `srcset`.

```html
<hrb-img
  src="https://picsum.photos/700/400"
  alt="some alt text"
  height="400"
  width="700"
  srcset="https://picsum.photos/700/400 1x,
            https://picsum.photos/1400/800 2x,
            https://picsum.photos/2100/1200 3x"
></hrb-img>
```

## Event Examples

We've added some custom events to allow developers to listen to the different events happening.
Every custom events return a reference to element, available in `e.detail`.

```js
const image = document.querySelector('hrb-img')

// When the src has been set (starting the load of the ressource)
image.addEventListener('hrbImgWillLoad', e => {
  console.log('image is loading', e.detail)
})

// When the image has been loaded
image.addEventListener('hrbImgDidLoad', e => {
  console.log('image has been loaded', e.detail)
})

// if an error occurs
image.addEventListener('hrbError', e => {
  console.log('image has failed to load', e.detail)
})
```

<!-- Auto Generated Below -->


## Properties

| Property   | Attribute   | Description                                                                        | Type                          | Default     |
| ---------- | ----------- | ---------------------------------------------------------------------------------- | ----------------------------- | ----------- |
| `alt`      | `alt`       | The alternative text for the image                                                 | `string`                      | `undefined` |
| `fit`      | `fit`       | Forcing the image to fit into it's container and maintain ratio (based upon width) | `boolean`                     | `true`      |
| `height`   | `height`    | The height of the image                                                            | `number`                      | `undefined` |
| `pLoading` | `p-loading` | If lazy prop is set the image will be lazy loaded                                  | `"auto" \| "eager" \| "lazy"` | `'lazy'`    |
| `src`      | `src`       | The image url.                                                                     | `string`                      | `undefined` |
| `srcset`   | `srcset`    | The source set values for the image.                                               | `string`                      | `undefined` |
| `width`    | `width`     | The width of the image                                                             | `number`                      | `undefined` |


## Events

| Event            | Description                                 | Type                |
| ---------------- | ------------------------------------------- | ------------------- |
| `hrbError`       | Emitted when the img fails to load          | `CustomEvent<void>` |
| `hrbImgDidLoad`  | Emitted when the image has finished loading | `CustomEvent<void>` |
| `hrbImgWillLoad` | Emitted when the img src has been set       | `CustomEvent<void>` |


## Dependencies

### Used by

 - [hrb-avatar](../avatar)
 - [hrb-card-document](../card composites/card-document)
 - [hrb-data-item](../data-item)
 - [hrb-video](../video)

### Graph
```mermaid
graph TD;
  hrb-avatar --> hrb-img
  hrb-card-document --> hrb-img
  hrb-data-item --> hrb-img
  hrb-video --> hrb-img
  style hrb-img fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
