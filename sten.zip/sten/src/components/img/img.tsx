import {
  Component,
  Element,
  Event,
  EventEmitter,
  h,
  Host,
  Prop,
  State,
  Watch,
} from '@stencil/core'

import { getClassnames } from '@src/utils/misc'
import {
  hasLoadingSupport,
  hasIntersectionObserverSupport,
} from '@src/utils/browser-tests'

import { TLoadingTypes } from './types'

const Constants = {
  baseClassname: 'hrb-img',
  loadingOptions: {
    auto: 'auto',
    eager: 'eager',
    lazy: 'lazy',
  },
}

@Component({
  tag: 'hrb-img',
  styleUrl: 'img.scss',
})
export class Img {
  @Element() el: HTMLElement

  /**
   * Emitted when the img src has been set
   */
  @Event() hrbImgWillLoad: EventEmitter<void>

  /**
   * Emitted when the image has finished loading
   */
  @Event() hrbImgDidLoad: EventEmitter<void>

  /**
   * Emitted when the img fails to load
   */
  @Event() hrbError: EventEmitter<void>

  /**
   * The alternative text for the image
   */
  @Prop() alt: string

  /**
   * The height of the image
   */
  @Prop() height: number

  /**
   * Forcing the image to fit into it's container and maintain ratio (based upon width)
   */
  @Prop() fit = true

  /**
   * If lazy prop is set the image will be lazy loaded
   */
  @Prop({ attribute: 'p-loading' }) pLoading: TLoadingTypes = 'lazy'

  /**
   * The image url.
   */
  @Prop() src: string

  /**
   * The source set values for the image.
   */
  @Prop() srcset: string

  /**
   * The width of the image
   */
  @Prop() width: number

  @State() hasLoaded: boolean

  @State() loadSrc: string

  @State() loadSrcset: string

  private io: IntersectionObserver

  private fallbackTimeout = null

  private isLazy = this.pLoading === Constants.loadingOptions.lazy

  @Watch('src')
  srcChanged(): void {
    const { addIO, isLazy, src, srcset } = this

    if (src && isLazy && !srcset && !hasLoadingSupport) {
      addIO()
    }
  }

  componentDidLoad(): void {
    const { addIO, isLazy, src, srcset, validateLoadingProp } = this

    validateLoadingProp()

    if (src && isLazy && !srcset && !hasLoadingSupport) {
      addIO()
    }
  }

  componentDidUnload(): void {
    this.removeIO()
    this.clearFallbackTimeout()
  }

  validateLoadingProp = (): void => {
    const { pLoading } = this

    const loadingOptions = Object.values(Constants.loadingOptions)

    if (!loadingOptions.includes(pLoading)) {
      // eslint-disable-next-line no-console
      console.error(
        `<hrb-img /> : "${pLoading}" is not a valid p-loading value`,
      )
    }
  }

  clearFallbackTimeout = (): void => {
    const { fallbackTimeout } = this

    if (fallbackTimeout) {
      clearTimeout(fallbackTimeout)
      this.fallbackTimeout = null
    }
  }

  addIO = (): void => {
    const { load, removeIO } = this

    if (hasIntersectionObserverSupport) {
      removeIO()

      this.io = new IntersectionObserver(data => {
        if (data[0].isIntersecting) {
          load()
          removeIO()
        }
      })

      this.io.observe(this.el)
    } else {
      // fall back to setTimeout browsers that don't support IntersectionObserver
      this.fallbackTimeout = setTimeout(() => load(), 200)
    }
  }

  removeIO = (): void => {
    const { io } = this

    if (io) {
      io.disconnect()
      this.io = undefined
    }
  }

  load = (): void => {
    const { hrbImgWillLoad, src, srcset } = this

    this.loadSrc = src
    this.loadSrcset = srcset
    hrbImgWillLoad.emit()
  }

  onLoad = (): void => {
    const { hrbImgDidLoad } = this

    this.hasLoaded = true
    hrbImgDidLoad.emit()
  }

  onError = (): void => {
    const { hrbError } = this

    hrbError.emit()
  }

  render(): JSX.Element {
    const {
      alt,
      fit,
      hasLoaded,
      height,
      isLazy,
      loadSrc,
      loadSrcset,
      onLoad,
      onError,
      pLoading,
      src,
      srcset,
      width,
    } = this
    const { baseClassname } = Constants
    const imgContainerClasses = getClassnames([
      `${baseClassname}`,
      hasLoaded && `${baseClassname}--is-loaded`,
    ])

    const imgClasses = getClassnames([
      `${baseClassname}__img`,
      hasLoaded && `${baseClassname}__img--is-loaded`,
      // fit && (!height && !width) ? `${baseClassname}__img--fit` : '',
      fit ? `${baseClassname}__img--fit` : `${baseClassname}__img--fit-false`,
    ])

    const willLazyLoad = isLazy && !srcset && !hasLoadingSupport

    return (
      <Host class={imgContainerClasses}>
        <img
          src={willLazyLoad ? loadSrc : src}
          // Force to render the alt attribute, even empty
          alt={alt || ''}
          onLoad={onLoad}
          onError={onError}
          class={imgClasses}
          srcset={willLazyLoad ? loadSrcset : srcset}
          loading={pLoading}
          height={height}
          width={width}
        />
      </Host>
    )
  }
}
