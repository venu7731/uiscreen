# hrb-select-native

<!-- Auto Generated Below -->


## Properties

| Property     | Attribute     | Description       | Type      | Default     |
| ------------ | ------------- | ----------------- | --------- | ----------- |
| `disabled`   | `disabled`    | Input is disabled | `boolean` | `undefined` |
| `errorLabel` | `error-label` | Error label       | `string`  | `undefined` |
| `hasError`   | `has-error`   | Input has error   | `boolean` | `false`     |
| `helperText` | `helper-text` | Input helper text | `string`  | `undefined` |
| `label`      | `label`       | Label             | `string`  | `undefined` |
| `loading`    | `loading`     | Input is loading  | `boolean` | `false`     |
| `value`      | `value`       | Value             | `string`  | `''`        |


## Events

| Event             | Description | Type               |
| ----------------- | ----------- | ------------------ |
| `hrbSelectBlur`   |             | `CustomEvent<any>` |
| `hrbSelectChange` |             | `CustomEvent<any>` |
| `hrbSelectFocus`  |             | `CustomEvent<any>` |
| `hrbSelectInput`  |             | `CustomEvent<any>` |


## Dependencies

### Used by

 - [hrb-select](../select)

### Depends on

- [hrb-loader](../loader)
- [hrb-icon](../icon)

### Graph
```mermaid
graph TD;
  hrb-select-native --> hrb-loader
  hrb-select-native --> hrb-icon
  hrb-select --> hrb-select-native
  style hrb-select-native fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
