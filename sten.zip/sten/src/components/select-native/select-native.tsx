import {
  Component,
  Event,
  EventEmitter,
  h,
  Host,
  Prop,
  State,
  Element,
} from '@stencil/core'

import { getClassnames, generateSimpleID } from '@src/utils/misc'
import { observeDOM } from '@src/utils/mutationObserver'

import Constants from '../select/constants'

@Component({
  tag: 'hrb-select-native',
  styleUrl: 'select-native.scss',
})
export class SelectNative {
  @Element() el: HTMLElement

  @Event() hrbSelectBlur: EventEmitter

  @Event() hrbSelectChange: EventEmitter

  @Event() hrbSelectFocus: EventEmitter

  @Event() hrbSelectInput: EventEmitter

  /**
   * Input is disabled
   */
  @Prop() disabled: boolean

  /**
   * Error label
   */
  @Prop() errorLabel: string

  /**
   * Input has error
   */
  @Prop() hasError = false

  /**
   * Input helper text
   */
  @Prop() helperText: string

  /**
   * Label
   */
  @Prop() label: string

  /**
   * Input is loading
   */
  @Prop() loading = false

  /**
   * Value
   */
  @Prop({ mutable: true }) value = ''

  @State() isActive = false

  @State() isFocused = false

  @State() optionValue = ''

  private baseId = `${generateSimpleID()}__${Constants.baseId}`

  componentDidLoad(): void {
    this.setSelectedOption()
    const selEl = this.getElement()
    if (!selEl) {
      return
    }
    observeDOM(selEl, m => {
      this.onOptionsRemovedChangeSection(m)
    })
  }

  /**
   * By mutation observers, we are listening for slot changes (options come as slot to the element)
   * and if any of the current selected option is removed we need to refresh the select to change the value it is bind to
   * @param m
   */
  onOptionsRemovedChangeSection = (m): void => {
    const removedNodes = []
    m.forEach(
      record =>
        record.removedNodes.length && removedNodes.push(...record.removedNodes),
    )

    const removedOptionValues = []
    removedNodes.forEach((node: HTMLElement) => {
      if (node.tagName.toLowerCase() === 'option') {
        removedOptionValues.push((node as HTMLOptionElement).value)
      }
    })

    this.setSelectedOption(removedOptionValues)
  }

  setSelectedOption(removedOptionValues = []): void {
    const selectRef = this.getElement()
    const options = selectRef.querySelectorAll('option')

    const val = this.value
    const { hrbSelectChange } = this

    if (!val) {
      selectRef.options.selectedIndex = -1
      selectRef.selectedIndex = -1
      selectRef.value = null
      this.optionValue = ''
      return
    }

    const optionsArr = Array.from(options)

    let selectedIndex = optionsArr.findIndex(
      (option: HTMLOptionElement) => option.value === val,
    )
    let selected: HTMLOptionElement

    // if the value which is selected is in the removedlist, make selectedIndex as -1
    if (removedOptionValues.includes(val)) {
      selectedIndex = -1
    }
    if (selectedIndex > -1) {
      selected = options[selectedIndex]
    }

    if (selectedIndex === -1) {
      this.value = ''
      this.optionValue = ''
    }

    let selValue = ''
    if (selected) {
      selValue = selected.value
    }
    selectRef.value = selValue
    selectRef.options.selectedIndex = selectedIndex
    selectRef.selectedIndex = selectedIndex
    this.optionValue = selValue
    hrbSelectChange.emit(this)
  }

  onBlur = (): void => {
    this.isActive = false
    this.isFocused = false
    this.hrbSelectBlur.emit(this)
  }

  onChange = (): void => {
    const { hrbSelectChange } = this
    const selectElm = this.getElement()

    if (!selectElm) {
      return
    }

    const { selectedIndex } = selectElm
    const options = selectElm.querySelectorAll('option')
    if (selectedIndex > -1) {
      selectElm.options.selectedIndex = selectedIndex
      const selectedOption = options[selectedIndex]
      if (selectedOption && selectedOption.value) {
        this.value = selectedOption.value
        /* eslint-disable no-param-reassign */
        Array.from(options).forEach(opt => {
          opt.selected = false
        })
        /* eslint-enable no-param-reassign */
        selectedOption.selected = true
        selectElm.value = this.value
        selectElm.selectedIndex = selectedIndex

        this.optionValue = selectElm.value

        hrbSelectChange.emit(this)
      }
    }

    this.isActive = false
  }

  getElement = (): HTMLSelectElement => {
    const target = this.el.querySelector('select') as HTMLSelectElement
    return target
  }

  onClick = (): void => {
    this.isActive = true
  }

  onFocus = (): void => {
    this.isFocused = true
    this.hrbSelectFocus.emit(this)
  }

  onInput = (): CustomEvent => this.hrbSelectInput.emit(this)

  renderLoader = (): JSX.Element => {
    return (
      <span
        class={`${Constants.baseClassnameNative}__loader`}
        aria-hidden="true"
      >
        <hrb-loader></hrb-loader>
      </span>
    )
  }

  renderError = (): JSX.Element => {
    const { errorLabel } = this
    const { baseClassnameNative } = Constants

    return (
      <span class={`${baseClassnameNative}__error`} role="alert">
        {errorLabel}
      </span>
    )
  }

  renderHelper = (): JSX.Element => {
    const { helperText, baseId } = this
    const { baseClassnameCustom } = Constants

    return (
      <div id={`${baseId}__helper`} class={`${baseClassnameCustom}__helper`}>
        {helperText}
      </div>
    )
  }

  getContainerClasses(): string {
    const { baseClassnameNative } = Constants
    const { value, isActive, isFocused, hasError, disabled, loading } = this

    const containerClasses = getClassnames([
      baseClassnameNative,
      !!value && `${baseClassnameNative}--has-text`,
      isActive && `${baseClassnameNative}--is-active`,
      isFocused && `${baseClassnameNative}--is-focused`,
      hasError && `${baseClassnameNative}--has-error`,
      disabled && `${baseClassnameNative}--is-disabled`,
      loading && `${baseClassnameNative}--is-loading`,
    ])

    return containerClasses
  }

  render(): JSX.Element {
    const {
      disabled,
      errorLabel,
      hasError,
      helperText,
      loading,
      onBlur,
      onChange,
      onClick,
      onFocus,
      onInput,
      renderError,
      renderHelper,
      renderLoader,
      optionValue,
    } = this

    const {
      baseClassnameNative,
      inputIcons: { chevronDown, chevronUp },
    } = Constants

    const iconBaseClassname = `${baseClassnameNative}__icon`
    const containerClasses = this.getContainerClasses()

    return (
      <Host>
        <span class={containerClasses}>
          <span class={`${baseClassnameNative}__label`}>{this.label}</span>
          <span class={`${baseClassnameNative}__faux-select`}>
            <span class={`${baseClassnameNative}__value`}>{optionValue}</span>
            <span class={`${iconBaseClassname}-container`}>
              <hrb-icon
                name={chevronUp}
                class={`${iconBaseClassname} ${iconBaseClassname}-up`}
              ></hrb-icon>
              <hrb-icon
                name={chevronDown}
                class={`${iconBaseClassname} ${iconBaseClassname}-down`}
              ></hrb-icon>
            </span>
            {loading && renderLoader()}
          </span>
          <select
            class={`${baseClassnameNative}__select`}
            disabled={disabled}
            onBlur={onBlur}
            onChange={onChange}
            onClick={onClick}
            onFocus={onFocus}
            onInput={onInput}
            data-hrb-select-focus-target
            data-hrb-select-input
          >
            <slot />
          </select>
        </span>
        {hasError && !!errorLabel && renderError()}
        {helperText && renderHelper()}
      </Host>
    )
  }
}
