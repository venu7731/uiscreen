import { select, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import { reset } from '@src/constants/storybook'

import * as readme from './readme.md'

const wrapperOpen = `${reset}<div style="padding: 30px">`
const wrapperClose = `</div>`

const themes = ['border', 'none']

storiesOf('Data List', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-data-list'],
    notes: { markdown: readme },
  })
  .add('Data List', () => {
    return `${wrapperOpen}

    <hrb-data-list
    theme=${select('Theme', themes, themes[2])}>
        <li>
            <hrb-data-item term="My Term" metadata="My Meta Data" def="My Definition Goes Here" note="Notes can go down here" as="button" icon="edit">
            </hrb-data-item>
        </li>
        <li>
            <hrb-data-item term="My Term" metadata="My Meta Data" def="My Definition Goes Here" note="Notes can go down here" as="button" icon="calendar">
            </hrb-data-item>
        </li>
        <li>
            <hrb-data-item term="My Term" metadata="My Meta Data" def="My Definition Goes Here" note="Notes can go down here" as="button">
            </hrb-data-item>
        </li>
    </hrb-data-list>

        
    
    ${wrapperClose}`
  })
