# <hrb-data-list>

`<hrb-data-list>` are elements that generally contain `<hrb-data-items>`. They group this content logicially in a list format, and accepts two default themes (border, zebra). These two themes help make distinction between the line items.

Please wrap the items inside of the list in `<li>` if you don't change the 'as' attribute to something other than the default `<ul>` component.

## Examples

```html
<hrb-data-list>
  <li>
    ...My Content Here...
  </li>
</hrb-data-list>
```

<!-- Auto Generated Below -->


## Properties

| Property | Attribute | Description     | Type     | Default     |
| -------- | --------- | --------------- | -------- | ----------- |
| `theme`  | `theme`   | Applies a theme | `string` | `undefined` |


## Dependencies

### Depends on

- [hrb-data-item](../data-item)

### Graph
```mermaid
graph TD;
  hrb-data-list --> hrb-data-item
  hrb-data-item --> hrb-img
  hrb-data-item --> hrb-text
  hrb-data-item --> hrb-icon
  style hrb-data-list fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
