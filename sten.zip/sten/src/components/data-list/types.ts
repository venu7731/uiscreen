import { TButtonTypes } from '@src/components/buttons/button/types'

export type TDataItemObject = {
  as?: TButtonTypes
  icon?: 'none'
  thumbSrc?: 'none'
  thumbAlt?: 'none'
  pAriaLabel?: string
  pAriaLabelledby?: string
  pAriaRole?: string
  target?: string
  rel?: string
  href?: string
  disabled?: false
  type?: string
  term?: null
  label?: null
  data?: null
  metadata?: null
  def?: null
  note?: null
}
