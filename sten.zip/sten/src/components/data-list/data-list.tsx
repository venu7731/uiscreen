/* eslint-disable no-console */
import { Component, h, Host, Prop, State } from '@stencil/core'

import { getClassnames } from '@src/utils/misc'

import { TDataItemObject } from './types'

const Constants = {
  baseClassname: 'hrb-data-list',
}

@Component({
  tag: 'hrb-data-list',
  styleUrl: 'data-list.scss',
})
export class DataList {
  private slotContainerRef: HTMLElement

  /**
   * Applies a theme
   */
  @Prop() theme: string

  /**
   * List of data-item state
   */
  @State() dataList: TDataItemObject[]

  getOptionList = (): void => {
    const options = this.slotContainerRef.children
    const optionList = Array.from(options).map((option: any) => {
      const {
        as,
        icon,
        thumbSrc,
        thumbAlt,
        pAriaLabel,
        pAriaLabelledby,
        pAriaRole,
        target,
        rel,
        href,
        disabled,
        type,
        term,
        label,
        data,
        metadata,
        def,
        note,
      } = option
      return {
        as: as,
        icon: icon,
        thumbSrc: thumbSrc,
        thumbAlt: thumbAlt,
        pAriaLabel: pAriaLabel,
        pAriaLabelledby: pAriaLabelledby,
        pAriaRole: pAriaRole,
        target: target,
        rel: rel,
        href: href,
        disabled: disabled,
        type: type,
        term: term,
        label: label,
        data: data,
        metadata: metadata,
        def: def,
        note: note,
      }
    })

    this.dataList = [].concat(...optionList)
  }

  componentDidLoad(): void {
    this.getOptionList()
  }

  render(): JSX.Element {
    const { theme } = this
    const { baseClassname } = Constants
    const classes = getClassnames([
      `${baseClassname}`,
      theme && `${baseClassname}--${theme}`,
    ])
    return (
      <Host class={classes}>
        <div
          class="data-item-container"
          ref={(el): HTMLSpanElement =>
            (this.slotContainerRef = el as HTMLSpanElement)
          }
        >
          <slot />
        </div>
        <ul>
          {!!this.dataList &&
            this.dataList.map(
              (option: TDataItemObject): HTMLElement => {
                return (
                  <li>
                    <hrb-data-item
                      as={option.as}
                      icon={option.icon}
                      thumbSrc={option.thumbSrc}
                      thumbAlt={option.thumbAlt}
                      pAriaLabel={option.pAriaLabel}
                      pAriaLabelledby={option.pAriaLabelledby}
                      pAriaRole={option.pAriaRole}
                      target={option.target}
                      rel={option.rel}
                      href={option.href}
                      disabled={option.disabled}
                      type={option.type}
                      term={option.term}
                      label={option.label}
                      data={option.data}
                      metadata={option.metadata}
                      def={option.def}
                      note={option.note}
                    ></hrb-data-item>
                  </li>
                )
              },
            )}
        </ul>
      </Host>
    )
  }
}
