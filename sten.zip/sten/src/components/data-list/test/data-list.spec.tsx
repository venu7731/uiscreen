import { newSpecPage } from '@stencil/core/testing'

import { DataList } from '../data-list'

describe('DataList', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [DataList],
      html: `
      <hrb-data-list>
          <hrb-data-item as="button" term="My Term" def="My definitionz" metadata="My metadata"
            note="Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nisi dolorem, nemo magni porro ipsam aperiam inventore non totam labore veritatis corporis cum minus similique asperiores? Fugit tempora repellendus consequuntur sapiente.">
          </hrb-data-item>
      </hrb-data-list>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-data-list class="hrb-data-list">
    <div class="data-item-container">
      <hrb-data-item as="button" def="My definitionz" metadata="My metadata" note="Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nisi dolorem, nemo magni porro ipsam aperiam inventore non totam labore veritatis corporis cum minus similique asperiores? Fugit tempora repellendus consequuntur sapiente." term="My Term"></hrb-data-item>
    </div>
    <ul>
      <li>
        <hrb-data-item></hrb-data-item>
      </li>
    </ul>
  </hrb-data-list>
    `)
  })
})
