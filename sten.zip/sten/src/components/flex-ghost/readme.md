# grid-row

## Examples

```html
<grid-row>
  <!-- rest of the grid -->
</grid-row>
```

<!-- Auto Generated Below -->


## Properties

| Property      | Attribute       | Description | Type     | Default    |
| ------------- | --------------- | ----------- | -------- | ---------- |
| `pAriaHidden` | `p-aria-hidden` |             | `string` | `'hidden'` |


## Dependencies

### Depends on

- [hrb-flex-col](../flex-col)
- [hrb-flex-container](../flex-container)
- [hrb-flex-row](../flex-row)

### Graph
```mermaid
graph TD;
  hrb-flex-ghost --> hrb-flex-col
  hrb-flex-ghost --> hrb-flex-container
  hrb-flex-ghost --> hrb-flex-row
  style hrb-flex-ghost fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
