import { Component, h, Host, Prop } from '@stencil/core'

import columns from '@src/constants/columns'

@Component({
  tag: 'hrb-flex-ghost',
  styleUrl: 'flex-ghost.scss',
})
export class HrbFlexGhost {
  @Prop() pAriaHidden = 'hidden'

  generateCols = (): string[] => {
    const cols = [...Array(columns.colL)]
    return cols.map(() => (
      <hrb-flex-col class="hrb-flex-ghost-item" col={1}></hrb-flex-col>
    ))
  }

  render(): JSX.Element {
    return (
      <Host aria-hidden={this.pAriaHidden} class="hrb-flex-ghost">
        <hrb-flex-container class="hrb-flex-ghost--full-height">
          <hrb-flex-row class="hrb-flex-ghost--full-height">
            {this.generateCols()}
          </hrb-flex-row>
        </hrb-flex-container>
      </Host>
    )
  }
}
