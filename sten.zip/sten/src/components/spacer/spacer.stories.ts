import { select, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import { reset } from '@src/constants/storybook'

import { spacing } from '@src/constants/spacing'

import * as readme from './readme.md'

/* eslint-disable-next-line */
const spacerElement = dSpace => `<hrb-spacer d="${dSpace}"></hrb-spacer>`

const wrapperOpen = `${reset}<div padding: 30px">`
const wrapperClose = `</div>`
const placeholderCard = `    <hrb-card theme="medium-light-green"><hrb-card-content>Card used for demo purposes.</hrb-card-content></hrb-card>`

storiesOf('Spacing', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-spacer'],
    notes: { markdown: readme },
  })
  .add('Spacing Element', () => {
    return `${wrapperOpen}
    ${placeholderCard}
    ${spacerElement(select('Spacer Element Size', spacing, spacing[5]))}
    ${placeholderCard}
    ${wrapperClose}`
  })
