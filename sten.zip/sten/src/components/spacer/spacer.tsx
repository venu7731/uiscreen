import { Component, h, Prop, Host } from '@stencil/core'

import { getClassnames } from '@src/utils/misc'

const Constants = {
  baseClassname: 'hrb-spacer',
}

@Component({
  tag: 'hrb-spacer',
  styleUrl: 'spacer.scss',
})
export class Spacer {
  /**
   * Size @ Default
   */
  @Prop() d = ''

  /**
   * Size @ Small
   */
  @Prop() sm = ''

  /**
   * Size @ Medium
   */
  @Prop() md = ''

  /**
   * Size @ Large
   */
  @Prop() lg = ''

  render(): JSX.Element {
    const { d, sm, md, lg } = this
    const { baseClassname } = Constants
    const classes = getClassnames([
      `${baseClassname}--sp-${d}`,
      sm && `${baseClassname}--sm-sp-${sm}`,
      md && `${baseClassname}--md-sp-${md}`,
      lg && `${baseClassname}--lg-sp-${lg}`,
    ])
    return (
      <Host class={classes}>
        <slot></slot>
      </Host>
    )
  }
}
