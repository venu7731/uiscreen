import { newSpecPage } from '@stencil/core/testing'

import { Spacer } from '../spacer'

describe('Spacer', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [Spacer],
      html: `
      <hrb-spacer d="16" sm="32" md="64" lg="200">
      <div></div>
      </hrb-spacer>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-spacer class="hrb-spacer--lg-sp-200 hrb-spacer--md-sp-64 hrb-spacer--sm-sp-32 hrb-spacer--sp-16" d="16" lg="200" md="64" sm="32">
    <div></div>
    </hrb-spacer>
    `)
  })
})
