# <hrb-data-list>

`<hrb-data-list>` are elements that generally contain `<hrb-data-items>`. They group this content logicially in a list format, and accepts two default themes (border, zebra). These two themes help make distinction between the line items.

Please wrap the items inside of the list in `<li>` if you don't change the 'as' attribute to something other than the default `<ul>` component.

## Examples

```html
<hrb-data-list>
  <li>
    ...My Content Here...
  </li>
</hrb-data-list>
```

<!-- Auto Generated Below -->


## Properties

| Property | Attribute | Description    | Type     | Default |
| -------- | --------- | -------------- | -------- | ------- |
| `d`      | `d`       | Size @ Default | `string` | `''`    |
| `lg`     | `lg`      | Size @ Large   | `string` | `''`    |
| `md`     | `md`      | Size @ Medium  | `string` | `''`    |
| `sm`     | `sm`      | Size @ Small   | `string` | `''`    |


## Dependencies

### Used by

 - [hrb-message-card](../card composites/card-message)

### Graph
```mermaid
graph TD;
  hrb-message-card --> hrb-spacer
  style hrb-spacer fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
