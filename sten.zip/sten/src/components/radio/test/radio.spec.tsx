import { newSpecPage } from '@stencil/core/testing'

import { Radio } from '../radio'

describe('Radio', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [Radio],
      html: `
      <hrb-radio name="vehicle"
        has-error
        value="bike"
        checked
        disabled
        id="bike">a bike, already checked</hrb-radio>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-radio aria-checked="true" aria-disabled="true" checked="" disabled="" has-error="" id="bike" name="vehicle" role="radio" value="bike">
      <label class="hrb-radio hrb-radio--disabled hrb-radio--hasError" htmlfor="bike">
        <span>
          <input aria-hidden="true" checked="" class="hrb-radio__input" disabled="" id="bike" name="vehicle" type="radio" value="bike">
          <span aria-hidden="true" class="hrb-radio--light-grey-3 hrb-radio__checkmark">
            <span class="hrb-radio__check"></span>
          </span>
        </span>
        <span class="hrb-radio__label-container">
          <hrb-text>
            a bike, already checked
          </hrb-text>
        </span>
      </label>
    </hrb-radio>
    `)
  })
})
