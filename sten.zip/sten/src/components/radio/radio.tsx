/* eslint-disable no-console */
import {
  Component,
  Element,
  Event,
  EventEmitter,
  h,
  Host,
  Method,
  Prop,
} from '@stencil/core'

import { generateSimpleID } from '@src/utils/misc'

import { TRadioThemes, ThemeConstants } from './types'

const Constants = {
  baseClassname: 'hrb-radio',
}

@Component({
  tag: 'hrb-radio',
  styleUrl: 'radio.scss',
})
export class Radio {
  @Element() el: HTMLElement

  @Event() hrbBlur: EventEmitter

  @Event() hrbChange: EventEmitter

  @Event() hrbFocus: EventEmitter

  @Event() hrbInput: EventEmitter

  @Method() async getElement(): Promise<HTMLElement> {
    return this.inputRef
  }

  @Method() async setFocus(): Promise<void> {
    this.inputRef.focus()
  }

  /**
   * Is the radio disabled?
   */
  @Prop() disabled = false

  /**
   * Is the radio required?
   */
  @Prop() required = false

  /**
   * Possible theme values
   */
  @Prop() theme: TRadioThemes = ThemeConstants.lightGrey3

  /**
   * Is the radio checked?
   */
  @Prop({ mutable: true }) checked = false

  /**
   * value of the radio
   */
  @Prop() value: string

  /**
   * name of the radio
   */
  @Prop() name: string

  /**
   * Input id
   */
  @Prop() inputId = generateSimpleID()

  /**
   * Input has error
   */
  @Prop() hasError = false

  private inputRef: HTMLInputElement

  onBlur = (): CustomEvent => this.hrbBlur.emit(this)

  onChange = (): CustomEvent => this.hrbChange.emit(this)

  onFocus = (): CustomEvent => this.hrbFocus.emit(this)

  onInput = (event: Event): void => {
    const { checked } = event.target as HTMLInputElement

    // We want to make sure other <hrb-radio> elements with the same name have checked=false
    const hrbRadioElements = document.body.querySelectorAll(
      `hrb-radio[name=${this.name}]`,
    )

    hrbRadioElements.forEach((radio: HTMLHrbRadioElement) => {
      if (radio.inputId === this.inputId) return
      // eslint-disable-next-line no-param-reassign
      radio.checked = false
    })

    this.checked = checked
    this.hrbInput.emit(this)
  }

  render(): JSX.Element {
    const {
      name,
      value,
      inputId,
      checked,
      disabled,
      required,
      onBlur,
      onChange,
      onFocus,
      onInput,
      theme,
      hasError,
    } = this

    const sharedID = `${this.el.id !== '' ? `${this.el.id}` : `${inputId}`}`

    return (
      <Host
        role="radio"
        aria-checked={checked.toString()}
        checked={checked}
        aria-disabled={disabled.toString()}
        disabled={disabled}
      >
        <label
          htmlFor={sharedID}
          class={`${Constants.baseClassname} ${
            disabled ? `${Constants.baseClassname}--disabled` : ''
          } ${hasError ? `${Constants.baseClassname}--hasError` : ''}`}
        >
          {/* Input */}
          <span>
            <input
              class={`${Constants.baseClassname}__input`}
              type="radio"
              name={name}
              value={value}
              id={sharedID}
              checked={checked}
              disabled={disabled}
              required={required}
              aria-hidden="true"
              onBlur={onBlur}
              onChange={onChange}
              onFocus={onFocus}
              onInput={onInput}
              ref={(el): HTMLInputElement => (this.inputRef = el)}
            />
            <span
              class={`${Constants.baseClassname}__checkmark ${Constants.baseClassname}--${theme}`}
              aria-hidden="true"
            >
              <span class={`${Constants.baseClassname}__check`}></span>
            </span>
          </span>

          {/* Label */}
          <span class={`${Constants.baseClassname}__label-container`}>
            <hrb-text>
              <slot></slot>
            </hrb-text>

            {/* In case we need to add elements that are not part of <hrb-text> (icons...) */}
            <slot name="other"></slot>
          </span>
        </label>
      </Host>
    )
  }
}
