import { boolean, select, text, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import { groupIds, radioThemes, reset } from '@src/constants/storybook'

import * as readme from './readme.md'

/* eslint-disable-next-line */
const radio = (
  buttonText,
  value,
  theme,
  checked = false,
  disabled = false,
  required = false,
  name = 'choices',
) =>
  `<hrb-radio disabled="${disabled}" required="${required}" name="${name}" theme="${theme}" value="${value}" checked="${checked}">${buttonText}</hrb-radio>`

const wrapperOpen = `${reset}<form style="padding: 30px"><hrb-text>Here's a question with multiple choices:</hrb-text>`
const wrapperClose = `</form>`

storiesOf('Forms/Radio Buttons', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-radio'],
    notes: { markdown: readme },
  })
  .add('Radio', () => {
    return `${wrapperOpen}
      ${radio(
        text('Text', 'choice #01', groupIds.testable),
        text('Value', 'choice-01', groupIds.additional),
        select('Theme', radioThemes, radioThemes[0], groupIds.testable),
        boolean('Checked', true, groupIds.testable),
        boolean('Disabled', false, groupIds.testable),
        boolean('Required', false, groupIds.additional),
        text('Name', 'choices', groupIds.additional),
      )}
      ${radio(
        'choice #02 (grey theme)',
        'choice-02',
        radioThemes[0],
        false,
        false,
        false,
        'choices',
      )}
      ${radio(
        'choice #03 (green theme)',
        'choice-03',
        radioThemes[1],
        false,
        false,
        false,
        'choices',
      )}
      ${radio(
        'choice #04 (yellow theme)',
        'choice-04',
        radioThemes[2],
        false,
        false,
        false,
        'choices',
      )}
      ${radio(
        'choice #05 (blue theme)',
        'choice-05',
        radioThemes[3],
        false,
        false,
        false,
        'choices',
      )}
      ${radio(
        'choice #06 (disabled by default)',
        'choice-06',
        radioThemes[0],
        false,
        true,
        true,
        'choices',
      )}
      ${wrapperClose}`
  })
