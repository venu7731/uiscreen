# hrb-radio

`hrb-radio` are custom `<input type="radio">` elements. They should be used in the context of a `form`.

Even though `name` and `value` are not required, they are strongly recommended to make the `hrb-radio` elements working correctly.

An `id` for the rendered `<input type="radio">` is automatically generated if not provided, but can be provided using `input-id`.

## Examples

`hrb-radio` can use a variety of themes, listed below, with the `theme` prop. By default it uses the `light-grey-3` theme.

```html
<hrb-radio name="transportation" value="car" theme="light-grey-3">
  A car
</hrb-radio>
```

List of themes:

- `light-grey-3`
- `light blue`
- `light-yellow`
- `light-green`

---

An `hrb-radio` element can be "pre" checked, required or disabled by simply passing the `checked`, `required` or `disabled` props.

```html
<hrb-radio name="transportation" value="bike" checked>A bike</hrb-radio>
<hrb-radio name="transportation" value="bus" required>A bus</hrb-radio>
<hrb-radio name="transportation" value="horse" disabled>A horse</hrb-radio>
```

📝 Note: Adding a `required` attribute to one of `hrb-radio` elements will make the whole group required.

## Event Examples

Most of the standard events are available

```js
const radio = form.querySelector('hrb-radio')

radio.addEventListener('change', e => {
  console.log('change', e.target.checked)
})
```

We've added some custom events to expose a consistent API across all the custom inputs and accomodate for specific events that are not available by default on custom elements, such as `focus` and `blur`.

Every custom events return a reference to element, available in `e.detail`.

```js
const radio = form.querySelector('hrb-radio')

// Focus
radio.addEventListener('hrbFocus', e => {
  console.log('focus', e.detail)
})

// Blur
radio.addEventListener('hrbBlur', e => {
  console.log('blur', e.detail)
})

// Change
radio.addEventListener('hrbChange', e => {
  console.log('change', e.detail)
})

// Input
radio.addEventListener('hrbInput', e => {
  console.log('input', e.detail)
})
```

## Method Examples

Every exposed methods return a `Promise`.

```js
const radio = form.querySelector('hrb-radio')

// get the main input element inside the `hrb-radio`
const radioInput = await radio.getElement()

// set the focus on the element
await radio.setFocus()
```

<!-- Auto Generated Below -->


## Properties

| Property   | Attribute   | Description            | Type                                                                                                               | Default                     |
| ---------- | ----------- | ---------------------- | ------------------------------------------------------------------------------------------------------------------ | --------------------------- |
| `checked`  | `checked`   | Is the radio checked?  | `boolean`                                                                                                          | `false`                     |
| `disabled` | `disabled`  | Is the radio disabled? | `boolean`                                                                                                          | `false`                     |
| `hasError` | `has-error` | Input has error        | `boolean`                                                                                                          | `false`                     |
| `inputId`  | `input-id`  | Input id               | `string`                                                                                                           | `generateSimpleID()`        |
| `name`     | `name`      | name of the radio      | `string`                                                                                                           | `undefined`                 |
| `required` | `required`  | Is the radio required? | `boolean`                                                                                                          | `false`                     |
| `theme`    | `theme`     | Possible theme values  | `ThemeConstants.lightGreen \| ThemeConstants.lightGrey3 \| ThemeConstants.ligthBlue \| ThemeConstants.ligthYellow` | `ThemeConstants.lightGrey3` |
| `value`    | `value`     | value of the radio     | `string`                                                                                                           | `undefined`                 |


## Events

| Event       | Description | Type               |
| ----------- | ----------- | ------------------ |
| `hrbBlur`   |             | `CustomEvent<any>` |
| `hrbChange` |             | `CustomEvent<any>` |
| `hrbFocus`  |             | `CustomEvent<any>` |
| `hrbInput`  |             | `CustomEvent<any>` |


## Methods

### `getElement() => Promise<HTMLElement>`



#### Returns

Type: `Promise<HTMLElement>`



### `setFocus() => Promise<void>`



#### Returns

Type: `Promise<void>`




## Dependencies

### Depends on

- [hrb-text](../text)

### Graph
```mermaid
graph TD;
  hrb-radio --> hrb-text
  style hrb-radio fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
