export enum ThemeConstants {
  lightGrey3 = 'light-grey-3',
  ligthYellow = 'light-yellow',
  lightGreen = 'light-green',
  ligthBlue = 'light-blue',
}

export type TRadioThemes =
  | ThemeConstants.lightGrey3
  | ThemeConstants.ligthYellow
  | ThemeConstants.lightGreen
  | ThemeConstants.ligthBlue
