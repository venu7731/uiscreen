# hrb-reset

<!-- Auto Generated Below -->


## Properties

| Property | Attribute | Description | Type     | Default     |
| -------- | --------- | ----------- | -------- | ----------- |
| `theme`  | `theme`   |             | `string` | `undefined` |


## Dependencies

### Used by

 - [hrb-global](../global)

### Graph
```mermaid
graph TD;
  hrb-global --> hrb-reset
  style hrb-reset fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
