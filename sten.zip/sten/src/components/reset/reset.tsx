/* eslint-disable class-methods-use-this */
import { Component, Element, h, Prop } from '@stencil/core'

@Component({
  tag: 'hrb-reset',
  styleUrl: 'reset.scss',
  shadow: false,
})
export class Reset {
  @Element() el

  @Prop() theme: string

  render(): JSX.Element {
    return <slot />
  }
}
