import { select, text, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import { htmlElements, reset } from '@src/constants/storybook'
import { styleTypeOptions } from '@src/constants/text-styles'

import * as readme from './readme.md'

/* eslint-disable-next-line */
const textComponent = (value, styleType, as) =>
  `<hrb-flex-row style="padding-bottom: 20px"><hrb-flex-col><hrb-text style-type=${styleType} as=${as}>${value}</hrb-text><hrb-flex-col></hrb-flex-row>`

const wrapperOpen = `${reset}<div style="padding: 60px 30px 30px; max-width: 800px">`
const wrapperClose = `</div>`

storiesOf('Text', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-text'],
    notes: { markdown: readme },
  })
  .add('Text Styles', () => {
    return `${wrapperOpen}

    ${textComponent(
      text('Text (1)', 'Hello world'),
      select('Type Style (1)', styleTypeOptions, styleTypeOptions[7]),
      select('As (1)', htmlElements, htmlElements[1]),
    )}
      
    ${textComponent(
      text(
        'Text (2)',
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
      ),
      select('Type Style (2)', styleTypeOptions, styleTypeOptions[0]),
      select('As (2)', htmlElements, htmlElements[0]),
    )}

    ${wrapperClose}`
  })
