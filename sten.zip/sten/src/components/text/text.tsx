import { Component, Host, h, Prop } from '@stencil/core'

import { getClassnames } from '@src/utils/misc'
import { getIsValidStyleType } from '@src/utils/validations'

const Constants = {
  baseClassname: 'hrb-text',
}

@Component({
  tag: 'hrb-text',
  styleUrl: 'text.scss',
})
export class Text {
  /**
   * The tag to wrap the text with
   */
  @Prop() as: string

  /**
   * The style type that will be applied
   */
  @Prop() styleType = 'body-copy'

  componentWillLoad(): void {
    this.validateStyleType()
  }

  validateStyleType = (): void => {
    if (!this.styleType) return // styleType is not required so this is valid

    const { styleType } = this
    const hasValidStyleType = getIsValidStyleType(styleType)

    if (!hasValidStyleType) {
      throw new Error(`styleType ${this.styleType} is not a valid option`)
    }
  }

  classnames = (): string =>
    getClassnames([
      `${Constants.baseClassname}`,
      `${Constants.baseClassname}--${this.styleType}`,
    ])

  applyMarkupFromTag = (): JSX.Element => {
    return <this.as class={this.classnames()}>{<slot />}</this.as>
  }

  render(): JSX.Element {
    const hasTag = !!this.as

    return (
      <Host class={!hasTag && this.classnames()}>
        {hasTag ? this.applyMarkupFromTag() : <slot />}
      </Host>
    )
  }
}
