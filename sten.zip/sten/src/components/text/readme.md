# hrb-text

The `hrb-text` component allows developers to easily style any element with a set of text rules directly based on the design guideline.

Each text style (regrouping a set of text rules) are also changing depending of the current viewport width, based on the defined breakpoints (see Wiki).

By default, it does **not** render any semantic element and apply the correct text class on the host element. To render a specific element as a child of the `host`, use the `as` prop.

By default, it renders a `body-copy` style. Here's the list of all the valid `style-type`:

```js
const styleTypeOptions = [
  'body-copy',
  'body-copy-small',
  'card',
  'cta',
  'cta-qualifier',
  'cta-small',
  'jumbo',
  'large',
  'little',
  'medium',
  'metadata',
  'small',
]
```

📝 Note: This package includes a set of global CSS classes to facilitate the basic styling of elements within the library's established styles. Those classes are automatically injected at a global level by the `hrb-global` component. See the Wiki for more information.

# Examples

To render a specific element, use the `as` prop.

```html
<hrb-text as="p"
  >This renders a
  <p>with a body-copy style</p></hrb-text
>
```

---

To render a specific text style, use the `style-type` prop.

```html
<hrb-text style-type="jumbo" as="h1">
  Jumbo: Here is a jumbo headline (h1)
</hrb-text>
```

<!-- Auto Generated Below -->


## Properties

| Property    | Attribute    | Description                         | Type     | Default       |
| ----------- | ------------ | ----------------------------------- | -------- | ------------- |
| `as`        | `as`         | The tag to wrap the text with       | `string` | `undefined`   |
| `styleType` | `style-type` | The style type that will be applied | `string` | `'body-copy'` |


## Dependencies

### Used by

 - [hrb-attachment-list](../attachment-list)
 - [hrb-avatar](../avatar)
 - [hrb-badge-label](../badge-label)
 - [hrb-button](../buttons/button)
 - [hrb-card-document](../card composites/card-document)
 - [hrb-checkbox](../checkbox)
 - [hrb-data-item](../data-item)
 - [hrb-label](../label)
 - [hrb-list-button](../buttons/list-button)
 - [hrb-message-card](../card composites/card-message)
 - [hrb-nav-secondary-item](../nav-secondary/nav-secondary-item)
 - [hrb-navbar-primary-item](../nav-bar/navbar-primary-item)
 - [hrb-navbar-secondary-item](../nav-bar/navbar-secondary-item)
 - [hrb-radio](../radio)

### Graph
```mermaid
graph TD;
  hrb-attachment-list --> hrb-text
  hrb-avatar --> hrb-text
  hrb-badge-label --> hrb-text
  hrb-button --> hrb-text
  hrb-card-document --> hrb-text
  hrb-checkbox --> hrb-text
  hrb-data-item --> hrb-text
  hrb-label --> hrb-text
  hrb-list-button --> hrb-text
  hrb-message-card --> hrb-text
  hrb-nav-secondary-item --> hrb-text
  hrb-navbar-primary-item --> hrb-text
  hrb-navbar-secondary-item --> hrb-text
  hrb-radio --> hrb-text
  style hrb-text fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
