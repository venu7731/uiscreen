import { newSpecPage } from '@stencil/core/testing'

import { Text } from '../text'

describe('Text', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [Text],
      html: `
      <hrb-text style-type="large"
        as="h2">
        Large: Section/Secondary Card(s) level title (h2)
      </hrb-text>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-text as="h2" style-type="large">
      <h2 class="hrb-text hrb-text--large">
        Large: Section/Secondary Card(s) level title (h2)
      </h2>
    </hrb-text>
    `)
  })
})
