import { boolean, text, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import { reset } from '@src/constants/storybook'

import * as readme from './readme.md'

const wrapperOpen = `${reset}<div style="padding: 30px; max-width: 800px; margin: 0 auto;">`
const wrapperClose = `</div>`

storiesOf('Attachment Item', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['test/attachment-item.spec.tsx'],
    notes: { markdown: readme },
  })
  .add('Attachment Item', () => {
    return `
    ${wrapperOpen}
    <hrb-layout layout="1col">
      <hrb-attachment-item
      attachment-name=${text(
        'Attachment Name',
        'Attachment name, this can be long',
      )}
      attachment-size=${text('Attachment Size', '200kb')}
      is-editable=${boolean('Is Editable', false)}>
    </hrb-attachment-item>
    ${wrapperClose}`
  })
