import { Component, h, Prop, State, Event, EventEmitter } from '@stencil/core'

import { getClassnames } from '@src/utils/misc'

const Constants = {
  baseClassname: 'attachment-item',
}

@Component({
  tag: 'hrb-attachment-item',
  styleUrl: 'attachment-item.scss',
})
export class AttachmentItem {
  /**
   * Attachment Name will be truncated if longer than the button
   */
  @Prop() FileName = 'Lorem ipsum dolor sit amet consectetur, adipisicing elit.'

  /**
   * Attachment Size
   */
  @Prop() FileSize = '200 KB'

  /**
   * Is Editable
   */

  @Prop() isEditable = false

  /**
   * Custom event when the Preview Button is clicked
   */
  @Event() removeAttachment: EventEmitter

  removeAttachmentHandler(removeAttachment): void {
    this.removeAttachment.emit(removeAttachment)
  }

  /**
   * Custom event when the Delete Button is clicked
   */
  @Event() deleteAttachment: EventEmitter

  deleteAttachmentHandler(deleteAttachment): void {
    this.deleteAttachment.emit(deleteAttachment)
  }

  /**
   * Editable state, if true, will active the edit button
   */
  @State() editable = this.isEditable

  render(): JSX.Element {
    const classes = getClassnames([
      `${Constants.baseClassname}`,
      !this.editable ? `` : `${Constants.baseClassname}__editable`,
    ])

    return (
      <div class={classes}>
        <hrb-button
          icon-position="left"
          icon="attachment"
          onClick={(e): void => this.removeAttachmentHandler(e)}
          p-aria-label={`preview attachment ${this.FileName}`}
          theme="secondary"
          button-height="small"
          qualifier={this.editable ? `` : `${this.FileSize}`}
        >
          {this.FileName}
        </hrb-button>
        {this.editable && (
          <hrb-button
            onClick={(e): void => this.deleteAttachmentHandler(e)}
            p-aria-label={`remove attachment ${this.FileName}`}
            theme="secondary"
            button-height="small"
          >
            <hrb-icon name="close"></hrb-icon>
          </hrb-button>
        )}
      </div>
    )
  }
}
