# hrb-attachment-item

`hrb-attachment-item` is used to render a list of a customer's tax forms as attachments. The `hrb-attachment-item` has two states: "default" and "editable".

## Examples

```html
<hrb-attachment-item
  attachment-name="Attachment name"
  attachment-size="200kb"
  is-editable="{true}"
></hrb-attachment-item>
```

---

<!-- Auto Generated Below -->


## Properties

| Property     | Attribute     | Description                                                 | Type      | Default                                                       |
| ------------ | ------------- | ----------------------------------------------------------- | --------- | ------------------------------------------------------------- |
| `FileName`   | `file-name`   | Attachment Name will be truncated if longer than the button | `string`  | `'Lorem ipsum dolor sit amet consectetur, adipisicing elit.'` |
| `FileSize`   | `file-size`   | Attachment Size                                             | `string`  | `'200 KB'`                                                    |
| `isEditable` | `is-editable` | Is Editable                                                 | `boolean` | `false`                                                       |


## Events

| Event              | Description                                     | Type               |
| ------------------ | ----------------------------------------------- | ------------------ |
| `deleteAttachment` | Custom event when the Delete Button is clicked  | `CustomEvent<any>` |
| `removeAttachment` | Custom event when the Preview Button is clicked | `CustomEvent<any>` |


## Dependencies

### Used by

 - [hrb-attachment-list](../attachment-list)

### Depends on

- [hrb-button](../buttons/button)
- [hrb-icon](../icon)

### Graph
```mermaid
graph TD;
  hrb-attachment-item --> hrb-button
  hrb-attachment-item --> hrb-icon
  hrb-button --> hrb-loader
  hrb-button --> hrb-text
  hrb-button --> hrb-icon
  hrb-attachment-list --> hrb-attachment-item
  style hrb-attachment-item fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
