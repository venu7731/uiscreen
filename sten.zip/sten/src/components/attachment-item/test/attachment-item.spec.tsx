import { newSpecPage } from '@stencil/core/testing'

import { AttachmentItem } from '../attachment-item'

describe('attachment-item', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [AttachmentItem],
      html: `<hrb-attachment-item></hrb-attachment-item>`,
    })
    expect(page.root).toEqualHtml(`
    <hrb-attachment-item>
      <div class="attachment-item">
        <hrb-button button-height="small" icon="attachment" icon-position="left" p-aria-label="preview attachment Lorem ipsum dolor sit amet consectetur, adipisicing elit." qualifier="200 KB" theme="secondary">
          Lorem ipsum dolor sit amet consectetur, adipisicing elit.
        </hrb-button>
      </div>
    </hrb-attachment-item>
    `)
  })
})
