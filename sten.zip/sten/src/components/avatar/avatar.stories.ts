import icons from '@src/constants/icons'

import * as readme from './readme.md'

export default {
  component: 'hrb-avatar',
  title: 'Avatar',
  parameters: {
    notes: { markdown: readme },
  },
  argTypes: {
    theme: {
      control: {
        type: 'select',
        options: [
          'ui-green',
          'light-green',
          'dark-green',
          'blue',
          'light-grey-2',
          'white',
        ],
        default: 'light-grey-2',
      },
    },
    icons: {
      control: {
        type: 'select',
        options: icons,
        default: 'light-grey-2',
      },
    },
    text: { control: 'text' },
    imgAlt: { control: 'text' },
    size: {
      control: {
        type: 'select',
        options: ['large', 'small'],
        default: 'small',
      },
    },
  },
}

export const Basic = (args): string =>
  `
  <hrb-avatar theme="${args.theme}" text=${args.text}></hrb-avatar>
  `
Basic.args = {
  text: 'gb',
}

export const Text = (args): string =>
  `
  <hrb-avatar theme=${args.theme} text=${args.text}></hrb-avatar>
  `
Text.args = {
  text: 'gb',
}

export const Icon = (args): string =>
  `
  <hrb-avatar theme="${args.theme}" icon="${args.icons}"></hrb-avatar>
  `
Icon.args = {
  icons: 'calendar',
}

export const Img = (args): string =>
  `
  <hrb-avatar image-alt="${args.imgAlt}" image="https://picsum.photos/72/72"></hrb-avatar>
  `
Img.args = {
  imgAlt: 'Default Alt',
}

export const Size = (args): string =>
  `
  <hrb-avatar size=${args.size} image="https://picsum.photos/72/72" ${
    args.size === 'small' ? `text="small"` : `text="large"`
  }></hrb-avatar>
  `

Size.args = {
  size: 'small',
}
