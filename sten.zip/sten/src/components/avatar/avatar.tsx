import { Component, Element, Host, h, Prop } from '@stencil/core'

import { TAvatarSizes, TAvatarThemes } from '../avatar/types'

const Constants = {
  baseClassname: 'hrb-avatar',
}

@Component({
  tag: 'hrb-avatar',
  styleUrl: 'avatar.scss',
})
export class HrbAvatar {
  @Element() el: HTMLElement

  @Prop() theme: TAvatarThemes = 'blue'

  @Prop() size: TAvatarSizes = 'small'

  @Prop() image = null

  @Prop() imageAlt = ''

  @Prop() text = null

  @Prop() icon = null

  render(): JSX.Element {
    return (
      <Host theme={this.theme} class={`${Constants.baseClassname}`}>
        {/* If it's image based */}
        {this.image !== null && this.imageAlt !== '' && (
          <hrb-img src={this.image} alt={this.imageAlt}></hrb-img>
        )}

        {/* If it's icon based */}
        {this.icon !== null && <hrb-icon name={this.icon}></hrb-icon>}

        {/* If it's text based */}
        {this.text !== null && (
          <hrb-text styleType="headline-four">{this.text}</hrb-text>
        )}
      </Host>
    )
  }
}
