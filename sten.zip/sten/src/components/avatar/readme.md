# hrb-avatar

<!-- Auto Generated Below -->


## Properties

| Property   | Attribute   | Description | Type                                                                                                                                                                                                                                                | Default   |
| ---------- | ----------- | ----------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- |
| `icon`     | `icon`      |             | `any`                                                                                                                                                                                                                                               | `null`    |
| `image`    | `image`     |             | `any`                                                                                                                                                                                                                                               | `null`    |
| `imageAlt` | `image-alt` |             | `string`                                                                                                                                                                                                                                            | `''`      |
| `size`     | `size`      |             | `"large" \| "small"`                                                                                                                                                                                                                                | `'small'` |
| `text`     | `text`      |             | `any`                                                                                                                                                                                                                                               | `null`    |
| `theme`    | `theme`     |             | `"blue" \| "dark-green" \| "light-green" \| "light-grey-1" \| "light-grey-2" \| "medium-dark-blue" \| "medium-dark-green" \| "medium-dark-yellow" \| "medium-light-blue" \| "medium-light-green" \| "medium-light-yellow" \| "ui-green" \| "white"` | `'blue'`  |


## Dependencies

### Used by

 - [hrb-badge-label](../badge-label)

### Depends on

- [hrb-img](../img)
- [hrb-icon](../icon)
- [hrb-text](../text)

### Graph
```mermaid
graph TD;
  hrb-avatar --> hrb-img
  hrb-avatar --> hrb-icon
  hrb-avatar --> hrb-text
  hrb-badge-label --> hrb-avatar
  style hrb-avatar fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
