import { newSpecPage } from '@stencil/core/testing'

import { HrbAvatar } from '@src/components/avatar/avatar'

describe('hrb-avatar', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbAvatar],
      html: `<hrb-avatar theme="ui-green" icon="calendar"></hrb-avatar>`,
    })
    expect(page.root).toEqualHtml(`
    <hrb-avatar class="hrb-avatar" icon="calendar" theme="ui-green">
      <hrb-icon name="calendar"></hrb-icon>
    </hrb-avatar>
    `)
  })
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbAvatar],
      html: `<hrb-avatar image-alt="My alt" image="https://hrblock.photos/72/72"></hrb-avatar>`,
    })
    expect(page.root).toEqualHtml(`
    <hrb-avatar class="hrb-avatar" image="https://hrblock.photos/72/72" image-alt="My alt" theme="blue">
      <hrb-img alt="My alt" src="https://hrblock.photos/72/72"></hrb-img>
    </hrb-avatar>
    `)
  })
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbAvatar],
      html: `<hrb-avatar text="gb"></hrb-avatar>`,
    })
    expect(page.root).toEqualHtml(`
      <hrb-avatar class="hrb-avatar" text="gb" theme="blue">
        <hrb-text styletype="headline-four">
          gb
        </hrb-text>
      </hrb-avatar>
    `)
  })
})
