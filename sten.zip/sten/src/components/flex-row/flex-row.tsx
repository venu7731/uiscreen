import { Component, Prop, h, Watch, Host } from '@stencil/core'

@Component({
  tag: 'hrb-flex-row',
  styleUrl: 'flex-row.scss',
})
export class HrbGridRow {
  /**
   *Justify content
   */
  @Prop({ attribute: 'justify-content' }) justifyContent = ''

  @Watch('justifyContent')
  validateJustifyContent(newValue: string): void {
    const classnames = [
      'initial',
      'start',
      'end',
      'flex-start',
      'flex-end',
      'baseline',
      'left',
      'right',
      'center',
      'safe',
      'stretch',
      'space-around',
      'space-between',
      'space-evenly',
      'center-only-mobile',
    ]
    const justifyContentIsValidate = classnames.indexOf(newValue) > -1

    if (!justifyContentIsValidate && newValue.length) {
      // eslint-disable-next-line no-console
      console.info('justify-content: not a valid value')
    }
  }

  /**
   * Align Items
   */
  @Prop({ attribute: 'align-items' }) alignItems = ''

  @Watch('alignItems')
  validateAlignItems(newValue: string): void {
    const classnames = [
      'initial',
      'start',
      'end',
      'flex-start',
      'flex-end',
      'baseline',
      'left',
      'right',
      'center',
      'safe',
      'stretch',
      'space-around',
      'space-between',
      'space-evenly',
    ]
    const alignItemsIsValidate = classnames.indexOf(newValue) > -1

    if (!alignItemsIsValidate && newValue.length) {
      // eslint-disable-next-line no-console
      console.info('align-items: not a valid value')
    }
  }

  /**
   * Is centered
   */
  @Prop({ attribute: 'center' }) isCentered = false

  /**
   * Is reversed
   */
  @Prop({ attribute: 'reverse' }) isReversed = false

  render(): JSX.Element {
    const justifyContent = this.justifyContent
      ? `hrb-flex-row--jc-${this.justifyContent}`
      : ''
    const alignItems = this.alignItems
      ? `hrb-flex-row--ai-${this.alignItems}`
      : ''
    const isCentered = this.isCentered ? `hrb-flex-row--center` : ''
    const isReversed = this.isReversed ? `hrb-flex-row--reverse` : ''

    return (
      <Host
        class={`hrb-flex-row
              ${justifyContent}
              ${alignItems}
              ${isCentered}
              ${isReversed}
            `}
      >
        <slot />
      </Host>
    )
  }
}
