import { newSpecPage } from '@stencil/core/testing'

import { HrbGridRow } from '../flex-row'

describe('HrbGridRow', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbGridRow],
      html: `
      <hrb-flex-container>
        <hrb-flex-row>
          <hrb-flex-col col="5"
            col-s="17"
            col-m="5"
            col-l="15"
            >Left Nav
          </hrb-flex-col>
          <hrb-flex-col col="12"
            col-s="17"
            col-m="12"
            col-l="20"
            >Main
            Content
          </hrb-flex-col>
        </hrb-flex-row>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-flex-row class="hrb-flex-row">
      <hrb-flex-col col="5" col-l="15" col-m="5" col-s="17">
        Left Nav
      </hrb-flex-col>
      <hrb-flex-col col="12" col-l="20" col-m="12" col-s="17">
        Main Content
      </hrb-flex-col>
    </hrb-flex-row>
    `)
  })
})
