import { newSpecPage } from '@stencil/core/testing'

import { Checkbox } from '../checkbox'

describe('Checkbox', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [Checkbox],
      html: `
      <hrb-checkbox id="myCheck" name="vehicle-02" value="no-option" disabled theme="light-grey-3">a disabled option</hrb-checkbox>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-checkbox aria-checked="false" aria-disabled="true" disabled="" id="myCheck" name="vehicle-02" role="checkbox" theme="light-grey-3" value="no-option">
      <label class="hrb-checkbox hrb-checkbox--disabled" htmlfor="myCheck">
        <span>
          <input aria-hidden="true" class="hrb-checkbox__input" disabled="" id="myCheck" name="vehicle-02" type="checkbox" value="no-option">
          <span aria-hidden="true" class="hrb-checkbox--light-grey-3 hrb-checkbox__checkmark">
            <span class="hrb-checkbox__check">
              <hrb-icon name="check"></hrb-icon>
            </span>
          </span>
        </span>
        <span class="hrb-checkbox__label-container">
          <hrb-text>
            a disabled option
          </hrb-text>
        </span>
      </label>
    </hrb-checkbox>
    `)
  })
})
