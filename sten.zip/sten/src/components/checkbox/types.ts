export enum CheckboxConstants {
  lightGrey3 = 'light-grey-3',
  ligthYellow = 'light-yellow',
  lightGreen = 'light-green',
  ligthBlue = 'light-blue',
}

export type TCheckboxThemes =
  | CheckboxConstants.lightGrey3
  | CheckboxConstants.ligthYellow
  | CheckboxConstants.lightGreen
  | CheckboxConstants.ligthBlue
