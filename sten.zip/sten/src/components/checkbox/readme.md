# hrb-checkbox

`hrb-checkbox` are custom `<input type="checkbox">` elements. They should be used in the context of a `form`.

Even though `name` and `value` are not required, they are strongly recommended to make the `hrb-checkbox` elements working correctly.

An `id` for the rendered `<input type="checkbox">` is automatically generated if not provided, but can be provided using `input-id`.

## Examples

`hrb-checkbox` can use a variety of themes, listed below, with the `theme` prop. By default it uses the `light-green` theme.

```html
<hrb-checkbox name="transportation" value="car" theme="light-green">
  A car
</hrb-checkbox>
```

List of themes:

- `light-green`
- `light-grey-3`
- `light blue`
- `light-yellow`

---

An `hrb-checkbox` element can be "pre" checked, required or disabled by simply passing a `checked`, `required` or `disabled` prop.

```html
<hrb-checkbox name="transportation" value="bike" checked>A bike</hrb-checkbox>
<hrb-checkbox name="transportation" value="bus" required>A bus</hrb-checkbox>
<hrb-checkbox name="transportation" value="horse" disabled
  >A horse</hrb-checkbox
>
```

## Event Examples

Most of the standard events are available

```js
const checkbox = form.querySelector('hrb-checkbox')

checkbox.addEventListener('change', e => {
  console.log('change', e.target.checked)
})
```

We've added some custom events to expose a consistent API across all the custom inputs and accomodate for specific events that are not available by default on custom elements, such as `focus` and `blur`.

Every custom events return a reference to element, available in `e.detail`.

```js
const checkbox = form.querySelector('hrb-checkbox')

// Focus
checkbox.addEventListener('hrbFocus', e => {
  console.log('focus', e.detail)
})

// Blur
checkbox.addEventListener('hrbBlur', e => {
  console.log('blur', e.detail)
})

// Change
checkbox.addEventListener('hrbChange', e => {
  console.log('change', e.detail)
})

// Input
checkbox.addEventListener('hrbInput', e => {
  console.log('input', e.detail)
})
```

## Method Examples

Every exposed methods return a `Promise`.

```js
const checkbox = form.querySelector('hrb-checkbox')

// get the main input element inside the `hrb-checkbox`
const checkboxInput = await checkbox.getElement()

// set the focus on the element
await checkbox.setFocus()
```

<!-- Auto Generated Below -->


## Properties

| Property   | Attribute  | Description               | Type                                                                                                                           | Default                        |
| ---------- | ---------- | ------------------------- | ------------------------------------------------------------------------------------------------------------------------------ | ------------------------------ |
| `checked`  | `checked`  | Is the checkbox checked?  | `boolean`                                                                                                                      | `false`                        |
| `disabled` | `disabled` | Is the checkbox disabled? | `boolean`                                                                                                                      | `false`                        |
| `inputId`  | `input-id` | Input id                  | `string`                                                                                                                       | `generateSimpleID()`           |
| `name`     | `name`     | name of the checkbox      | `string`                                                                                                                       | `undefined`                    |
| `required` | `required` | Is the checkbox required? | `boolean`                                                                                                                      | `false`                        |
| `theme`    | `theme`    | Possible theme values     | `CheckboxConstants.lightGreen \| CheckboxConstants.lightGrey3 \| CheckboxConstants.ligthBlue \| CheckboxConstants.ligthYellow` | `CheckboxConstants.lightGrey3` |
| `value`    | `value`    | value of the checkbox     | `string`                                                                                                                       | `undefined`                    |


## Events

| Event       | Description | Type               |
| ----------- | ----------- | ------------------ |
| `hrbBlur`   |             | `CustomEvent<any>` |
| `hrbChange` |             | `CustomEvent<any>` |
| `hrbFocus`  |             | `CustomEvent<any>` |
| `hrbInput`  |             | `CustomEvent<any>` |


## Methods

### `getElement() => Promise<HTMLElement>`



#### Returns

Type: `Promise<HTMLElement>`



### `setFocus() => Promise<void>`



#### Returns

Type: `Promise<void>`




## Dependencies

### Depends on

- [hrb-icon](../icon)
- [hrb-text](../text)

### Graph
```mermaid
graph TD;
  hrb-checkbox --> hrb-icon
  hrb-checkbox --> hrb-text
  style hrb-checkbox fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
