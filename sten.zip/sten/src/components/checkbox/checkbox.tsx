import {
  Component,
  Element,
  Event,
  EventEmitter,
  h,
  Host,
  Method,
  Prop,
} from '@stencil/core'

import { generateSimpleID } from '@src/utils/misc'

import { TCheckboxThemes, CheckboxConstants } from './types'

const Constants = {
  baseClassname: 'hrb-checkbox',
}

@Component({
  tag: 'hrb-checkbox',
  styleUrl: 'checkbox.scss',
})
export class Checkbox {
  @Element() el: HTMLElement

  @Event() hrbBlur: EventEmitter

  @Event() hrbChange: EventEmitter

  @Event() hrbFocus: EventEmitter

  @Event() hrbInput: EventEmitter

  @Method() async getElement(): Promise<HTMLElement> {
    return this.inputRef
  }

  @Method() async setFocus(): Promise<void> {
    this.inputRef.focus()
  }

  /**
   * Is the checkbox required?
   */
  @Prop() required = false

  /**
   * Is the checkbox disabled?
   */
  @Prop() disabled = false

  /**
   * Possible theme values
   */
  @Prop() theme: TCheckboxThemes = CheckboxConstants.lightGrey3

  /**
   * Is the checkbox checked?
   */
  @Prop({ mutable: true }) checked = false

  /**
   * value of the checkbox
   */
  @Prop() value: string

  /**
   * name of the checkbox
   */
  @Prop() name: string

  /**
   * Input id
   */
  @Prop() inputId = generateSimpleID()

  private inputRef: HTMLInputElement

  onBlur = (): CustomEvent => this.hrbBlur.emit(this)

  onChange = (): CustomEvent => this.hrbChange.emit(this)

  onFocus = (): CustomEvent => this.hrbFocus.emit(this)

  onInput = (event: Event): void => {
    const { checked } = event.target as HTMLInputElement

    this.checked = checked
    this.hrbInput.emit(this)
  }

  render(): JSX.Element {
    const {
      name,
      value,
      inputId,
      checked,
      disabled,
      required,
      onBlur,
      onChange,
      onFocus,
      onInput,
      theme,
    } = this

    const InputID = `${this.el.id !== '' ? `${this.el.id}` : `${inputId}`}`

    return (
      <Host
        role="checkbox"
        aria-checked={checked.toString()}
        checked={checked}
        aria-disabled={disabled.toString()}
        disabled={disabled}
      >
        <label
          htmlFor={InputID}
          class={`${Constants.baseClassname} ${
            disabled ? `${Constants.baseClassname}--disabled` : ''
          } `}
        >
          {/* Input */}
          <span>
            <input
              class={`${Constants.baseClassname}__input`}
              type="checkbox"
              name={name}
              value={value}
              id={InputID}
              checked={checked}
              disabled={disabled}
              required={required}
              aria-hidden="true"
              onBlur={onBlur}
              onChange={onChange}
              onFocus={onFocus}
              onInput={onInput}
              ref={(el): HTMLInputElement => (this.inputRef = el)}
            />
            <span
              class={`${Constants.baseClassname}__checkmark ${Constants.baseClassname}--${theme}`}
              aria-hidden="true"
            >
              <span class={`${Constants.baseClassname}__check`}>
                <hrb-icon name="check"></hrb-icon>
              </span>
            </span>
          </span>

          {/* Label */}
          <span class={`${Constants.baseClassname}__label-container`}>
            <hrb-text>
              <slot></slot>
            </hrb-text>

            {/* In case we need to add elements that are not part of <hrb-text> (icons...) */}
            <slot name="other"></slot>
          </span>
        </label>
      </Host>
    )
  }
}
