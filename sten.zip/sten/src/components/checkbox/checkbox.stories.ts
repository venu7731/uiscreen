import { boolean, select, text, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import { checkboxThemes, groupIds, reset } from '@src/constants/storybook'

import * as readme from './readme.md'

/* eslint-disable-next-line */
const checkbox = (
  buttonText,
  value,
  theme,
  checked = false,
  disabled = false,
  required = false,
  name = 'choices',
) =>
  `<hrb-checkbox disabled="${disabled}" required="${required}" name="${name}" theme="${theme}" value="${value}" checked="${checked}">${buttonText}</hrb-checkbox>`

const wrapperOpen = `${reset}<form style="padding: 30px"><hrb-text>Here's a question with multiple choices:</hrb-text>`
const wrapperClose = `</form>`

storiesOf('Forms/Checkboxes', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-checkbox'],
    notes: { markdown: readme },
  })
  .add('Checkbox', () => {
    return `${wrapperOpen}

      ${checkbox(
        text('Text', 'choice #01', groupIds.testable),
        text('Value', 'choice-01', groupIds.additional),
        select(
          'Theme',
          checkboxThemes,
          checkboxThemes[0],
          'Storybook Testable',
        ),
        boolean('Checked', true, groupIds.testable),
        boolean('Disabled', false, groupIds.testable),
        boolean('Required', false, groupIds.additional),
        text('Name', 'choices', groupIds.additional),
      )}
      ${checkbox(
        'choice #02 (grey theme)',
        'choice-02',
        checkboxThemes[0],
        false,
        false,
        false,
        'choices',
      )}
      ${checkbox(
        'choice #03 (green theme)',
        'choice-03',
        checkboxThemes[1],
        false,
        false,
        false,
        'choices',
      )}
      ${checkbox(
        'choice #04 (yellow theme)',
        'choice-04',
        checkboxThemes[2],
        false,
        false,
        false,
        'choices',
      )}
      ${checkbox(
        'choice #05 (blue theme)',
        'choice-05',
        checkboxThemes[3],
        false,
        false,
        false,
        'choices',
      )}
      ${checkbox(
        'choice #06 (disabled by default)',
        'choice-06',
        checkboxThemes[0],
        true,
        true,
        false,
        'choices',
      )}
      
    ${wrapperClose}`
  })
