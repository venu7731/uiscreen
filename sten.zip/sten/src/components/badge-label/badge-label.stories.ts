import { text, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import { reset } from '@src/constants/storybook'

import * as readme from './readme.md'

const wrapperOpen = `${reset}<div style="padding: 30px">`
const wrapperClose = `</div>`

storiesOf('Badge & Label', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-badge-label'],
    notes: { markdown: readme },
  })
  .add('Badge & Label Thumbnail', () => {
    return `${wrapperOpen}
    <hrb-badge-label
        badge-title=${text(`Badge Title`, `Bage Title`)}
        badge-subtitle=${text(`Badge SubTitle`, `Badge SubTitle`)}
        thumbnail=${text(`Badge Thumbnail`, 'https://picsum.photos/40/40')}
        thumb-alt=${text(`Badge Thumb Alt`, `Badge Thumb Alt`)}
        >
    </hrb-badge-label>
    ${wrapperClose}`
  })
  .add('Badge & Label Initials', () => {
    return `${wrapperOpen}
    <hrb-badge-label
        badge-title=${text(`Badge Title`, `Bage Title`)}
        badge-subtitle=${text(`Badge SubTitle`, `Badge SubTitle`)}
        >
    </hrb-badge-label>
    ${wrapperClose}`
  })
