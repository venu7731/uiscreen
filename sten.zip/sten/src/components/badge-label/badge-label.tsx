import { Component, h, Prop } from '@stencil/core'

import { TBadgeThemes, TBadgeSizes } from './types'

@Component({
  tag: 'hrb-badge-label',
  styleUrl: 'badge-label.scss',
})
export class BadgeLabel {
  @Prop() theme: TBadgeThemes = 'blue'

  @Prop() size: TBadgeSizes = 'large'

  @Prop() image = null

  @Prop() imageAlt = ''

  @Prop() text = null

  @Prop() icon = null

  @Prop() badgeTitle: string

  @Prop() badgeSubtitle: string

  renderAvatar = (): JSX.Element => {
    if (this.imageAlt !== '' || this.icon !== null || this.text !== null) {
      return (
        <hrb-avatar
          size={this.size}
          theme={this.theme}
          image={this.image}
          imageAlt={this.imageAlt}
          text={this.text}
          icon={this.icon}
        ></hrb-avatar>
      )
    }
    return <span></span>
  }

  render(): JSX.Element {
    return (
      <div class="badge-label">
        {this.renderAvatar()}
        <div class="badge-label--label">
          <div>
            <hrb-text style-type="headline-three">{this.badgeTitle}</hrb-text>
          </div>
          <div>
            <hrb-text style-type="body-copy-small">
              {this.badgeSubtitle}
            </hrb-text>
          </div>
        </div>
      </div>
    )
  }
}
