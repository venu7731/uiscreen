import { newSpecPage } from '@stencil/core/testing'

import { BadgeLabel } from '../badge-label'

describe('badge-label', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [BadgeLabel],
      html: `
      <hrb-badge-label badge-title="This Title"
        badge-subtitle="This Subtitle"
        thumbnail="https://picsum.photos/40/40"
        thumb-alt="This is an alternative"></hrb-badge-label>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-badge-label badge-subtitle="This Subtitle" badge-title="This Title" thumb-alt="This is an alternative" thumbnail="https://picsum.photos/40/40">
      <div class="badge-label">
        <span></span>
        <div class="badge-label--label">
          <div>
            <hrb-text style-type="headline-three">
              This Title
            </hrb-text>
          </div>
          <div>
            <hrb-text style-type="body-copy-small">
              This Subtitle
            </hrb-text>
          </div>
        </div>
      </div>
    </hrb-badge-label>
    `)
  })
})
