# hrb-badge-label

<!-- Auto Generated Below -->


## Properties

| Property        | Attribute        | Description | Type                                                                                                                                                                                                                                                | Default     |
| --------------- | ---------------- | ----------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------- |
| `badgeSubtitle` | `badge-subtitle` |             | `string`                                                                                                                                                                                                                                            | `undefined` |
| `badgeTitle`    | `badge-title`    |             | `string`                                                                                                                                                                                                                                            | `undefined` |
| `icon`          | `icon`           |             | `any`                                                                                                                                                                                                                                               | `null`      |
| `image`         | `image`          |             | `any`                                                                                                                                                                                                                                               | `null`      |
| `imageAlt`      | `image-alt`      |             | `string`                                                                                                                                                                                                                                            | `''`        |
| `size`          | `size`           |             | `"large" \| "small"`                                                                                                                                                                                                                                | `'large'`   |
| `text`          | `text`           |             | `any`                                                                                                                                                                                                                                               | `null`      |
| `theme`         | `theme`          |             | `"blue" \| "dark-green" \| "light-green" \| "light-grey-1" \| "light-grey-2" \| "medium-dark-blue" \| "medium-dark-green" \| "medium-dark-yellow" \| "medium-light-blue" \| "medium-light-green" \| "medium-light-yellow" \| "ui-green" \| "white"` | `'blue'`    |


## Dependencies

### Used by

 - [hrb-message-card](../card composites/card-message)
 - [hrb-option-card](../card composites/option-card)

### Depends on

- [hrb-avatar](../avatar)
- [hrb-text](../text)

### Graph
```mermaid
graph TD;
  hrb-badge-label --> hrb-avatar
  hrb-badge-label --> hrb-text
  hrb-avatar --> hrb-img
  hrb-avatar --> hrb-icon
  hrb-avatar --> hrb-text
  hrb-message-card --> hrb-badge-label
  hrb-option-card --> hrb-badge-label
  style hrb-badge-label fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
