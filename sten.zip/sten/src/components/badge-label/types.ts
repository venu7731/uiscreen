import { TAvatarThemes, TAvatarSizes } from '../avatar/types'

export type TBadgeThemes = TAvatarThemes

export type TBadgeSizes = TAvatarSizes
