import { newSpecPage } from '@stencil/core/testing'

import { Icon } from '../icon'

describe('Icon', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [Icon],
      html: `
      <hrb-icon name="account"></hrb-icon>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-icon class="hrb-icon" name="account">
      <span class="hrb-icon__container">
        <svg aria-hidden="true" focusable="false" viewBox="0 0 18 18">
          <use xlink:href="#hrb-icon--account"></use>
        </svg>
      </span>
    </hrb-icon>
    `)
  })
})
