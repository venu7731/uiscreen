import { Component, h, Host, Prop } from '@stencil/core'

import { getIsValidIcon } from '@src/utils/validations'

const Constants = {
  baseClassname: 'hrb-icon',
}

@Component({
  tag: 'hrb-icon',
  styleUrl: 'icon.scss',
})
export class Icon {
  /**
   * The name of the icon to be shown
   */
  @Prop({ reflect: true }) name: string

  componentWillLoad(): void {
    this.validateIcon()
  }

  validateIcon(): void {
    const isValidName = getIsValidIcon(this.name)

    if (!isValidName) {
      this.throwConsoleError(this.name, 'name')
    }
  }

  throwConsoleError(val: string, prop: string): void {
    // eslint-disable-next-line no-console
    console.error(`<hrb-icon /> : "${val}" is not a valid icon ${prop}`)
  }

  getSVG(): string {
    return `<svg aria-hidden="true" focusable="false" viewBox="0 0 18 18"><use xlink:href="#${Constants.baseClassname}--${this.name}"></use></svg>`
  }

  render(): JSX.Element {
    const { name } = this
    const { baseClassname } = Constants

    if (!name) return null

    return (
      <Host class={baseClassname}>
        <span
          class={`${baseClassname}__container`}
          innerHTML={this.getSVG()}
        ></span>
      </Host>
    )
  }
}
