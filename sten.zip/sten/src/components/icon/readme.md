# hrb-icon

The `hrb-icon` provides an easy way of rendering an icon. Each icon use an SVG sprite injected by `hrb-global`.

Some of the main advantages of an SVG sprite include:

- Easy to style in CSS.
- Works cross-browser.
- Easy to change SVG shapes.
- Renders all the SVGs once in the sprite, `hrb-icon` use it as a reference

Simply provide a valid `icon` name to render a specific icon.

```html
<hrb-icon name="account"></hrb-icon>
```

Here's the list of all the valid icon names you can use

```js
const icons = [
  'account',
  'add-document',
  'add',
  'arrow-up',
  'attachment',
  'bookmark-filled',
  'bookmark',
  'calculator',
  'calendar-filled',
  'calendar',
  'camera',
  'card',
  'check',
  'chevron-down',
  'chevron-left',
  'chevron-right',
  'chevron-up',
  'close',
  'documents',
  'download',
  'edit',
  'eye-filled',
  'eye',
  'folder',
  'graph',
  'heart-filled',
  'heart',
  'help',
  'history',
  'location-filled',
  'location',
  'lock-unlocked',
  'lock',
  'mail',
  'menu',
  'messages',
  'money',
  'nav-accounts-green-filled',
  'nav-accounts',
  'nav-home-green-filled',
  'nav-home',
  'nav-messages-green-filled',
  'nav-messages',
  'nav-page-green-filled',
  'nav-page',
  'nav-taxes-green-filled',
  'nav-taxes',
  'overflow',
  'phone',
  'refresh',
  'search',
  'settings',
  'star-filled',
  'star',
  'time',
  'transfer',
  'trash',
  'upload',
]
```

---

You can change the color of the SVG (`primary-black` by default) using the `color` prop.

<!-- Auto Generated Below -->


## Properties

| Property | Attribute | Description                      | Type     | Default     |
| -------- | --------- | -------------------------------- | -------- | ----------- |
| `name`   | `name`    | The name of the icon to be shown | `string` | `undefined` |


## Dependencies

### Used by

 - [hrb-accordion-item](../accordion-item)
 - [hrb-attachment-item](../attachment-item)
 - [hrb-avatar](../avatar)
 - [hrb-button](../buttons/button)
 - [hrb-card-expandable](../card composites/card-expandable)
 - [hrb-checkbox](../checkbox)
 - [hrb-circle-button-with-label](../buttons/circle-button-with-label)
 - [hrb-data-item](../data-item)
 - [hrb-dropdown-menu-item](../dropdown-menu/dropdown-menu-item)
 - [hrb-input](../input)
 - [hrb-link](../link)
 - [hrb-list-button](../buttons/list-button)
 - [hrb-message-card](../card composites/card-message)
 - [hrb-modal](../modal)
 - [hrb-nav-bar](../nav-bar)
 - [hrb-nav-link](../nav-bar/nav-link)
 - [hrb-navbar-secondary-item](../nav-bar/navbar-secondary-item)
 - [hrb-option-card](../card composites/option-card)
 - [hrb-overflow-item](../overflow-item)
 - [hrb-overflow-menu](../overflow-menu)
 - [hrb-select-custom](../select-custom)
 - [hrb-select-native](../select-native)
 - [hrb-select-option](../select-option)
 - [hrb-textarea](../textarea)
 - [hrb-video](../video)

### Graph
```mermaid
graph TD;
  hrb-accordion-item --> hrb-icon
  hrb-attachment-item --> hrb-icon
  hrb-avatar --> hrb-icon
  hrb-button --> hrb-icon
  hrb-card-expandable --> hrb-icon
  hrb-checkbox --> hrb-icon
  hrb-circle-button-with-label --> hrb-icon
  hrb-data-item --> hrb-icon
  hrb-dropdown-menu-item --> hrb-icon
  hrb-input --> hrb-icon
  hrb-link --> hrb-icon
  hrb-list-button --> hrb-icon
  hrb-message-card --> hrb-icon
  hrb-modal --> hrb-icon
  hrb-nav-bar --> hrb-icon
  hrb-nav-link --> hrb-icon
  hrb-navbar-secondary-item --> hrb-icon
  hrb-option-card --> hrb-icon
  hrb-overflow-item --> hrb-icon
  hrb-overflow-menu --> hrb-icon
  hrb-select-custom --> hrb-icon
  hrb-select-native --> hrb-icon
  hrb-select-option --> hrb-icon
  hrb-textarea --> hrb-icon
  hrb-video --> hrb-icon
  style hrb-icon fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
