import { select, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import { reset } from '@src/constants/storybook'

import icons from '@src/constants/icons'

import * as readme from './readme.md'

/* eslint-disable-next-line */
const icon = name => `<hrb-icon name="${name}"></hrb-icon>`

const wrapperOpen = `${reset}<hrb-flex-grid><hrb-flex-row><hrb-flex-col style="flex-direction: row; flex-wrap: wrap; padding: 30px">`
const wrapperClose = `</hrb-flex-col></hrb-flex-row></hrb-flex-grid>`

storiesOf('Icons', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-icon'],
    notes: { markdown: readme },
  })
  .add('Icon Select', () => {
    return `${wrapperOpen}${icon(
      select('Name', icons, icons[0]),
    )}${wrapperClose}`
  })
  .add('All Icons', () => {
    return `${wrapperOpen}
    
    ${icons
      .map(ico => {
        return icon(ico)
      })
      .join('')}
      
    ${wrapperClose}`
  })
