import { newSpecPage } from '@stencil/core/testing'

import { ToolTip } from '../tool-tip'

describe('ToolTip', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [ToolTip],
      html: `
      <hrb-tooltip id="toolTipID1"
        tooltip-content="At vero eos et accusamus et iusto odio dignissimos ducimus"
        tooltip-position="right">
        <hrb-button p-aria-labelledby="toolTipID1">Tool Tip Right</hrb-button>
      </hrb-tooltip>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-tooltip class="hrb-tooltip--wrapper" id="toolTipID1" tooltip-content="At vero eos et accusamus et iusto odio dignissimos ducimus" tooltip-position="right">
      <hrb-button p-aria-labelledby="toolTipID1">
        Tool Tip Right
      </hrb-button>
      <div class="hrb-tooltip hrb-tooltip__right" role="tooltip">
        At vero eos et accusamus et iusto odio dignissimos ducimus
      </div>
    </hrb-tooltip>
    `)
  })
})
