/* eslint-disable no-alert */
import { Component, Host, h, Prop, Method, Element } from '@stencil/core'

import { getClassnames } from '@src/utils/misc'

const Constants = {
  baseClassname: 'hrb-tooltip',
}

@Component({
  tag: 'hrb-tooltip',
  styleUrl: 'tool-tip.scss',
})
export class ToolTip {
  @Element() el: HTMLElement

  /**
   * Tool tip content
   */
  @Prop() tooltipContent: string

  /**
   * Position: Applies a position to the tooltip
   */
  @Prop() tooltipPosition: 'top' | 'right' | 'bottom' | 'left' | 'default' =
    'default'

  /**
   * ID: ID is required for the tool tip to work. It ties into the accessibility concerns.
   */
  @Prop() tooltipId: string

  /**
   * Visible: State that can trigger visibility of tooltip.
   * Useful if you're not using hover as your trigger
   */
  @Prop() tooltipVisible = false

  /**
   * Triggers visibility of tooltip
   */
  @Method() async toggleTooltip(): Promise<void> {
    this.tooltipVisible = !this.tooltipVisible
  }

  render(): JSX.Element {
    const { tooltipPosition, tooltipVisible } = this

    const containerClasses = getClassnames([
      `${Constants.baseClassname}--wrapper`,
    ])
    const tipClasses = getClassnames([
      `${Constants.baseClassname}`,
      `${Constants.baseClassname}__${tooltipPosition}`,
      tooltipVisible === true && `${Constants.baseClassname}__show`,
    ])

    return (
      <Host class={containerClasses}>
        <slot></slot>
        <div id={this.tooltipId} role="tooltip" class={tipClasses}>
          {this.tooltipContent}
          <slot name="tooltip-content" />
        </div>
      </Host>
    )
  }
}
