# hrb-tool-tip

An `<hrb-tooltip>` is a label for a control (button, icon, etc...). It should contain descriptive text for that control or element.

An `<hrb-tooltip>` is accessible to users on hover (for sighted/mouse users), and focus (for keyboard/assistive technology users). These should be the primary ways to trigger a tooltip. However, there is a public method offered by the `<hrb-tooltip>` called `toggleTooltip` that toggles the visbility state of the `<hrb-tooltip>`.

Since a tooltip is essentially a label, it utilizes the `aria-labelledby` attribute on the trigger to create the relationship with the id of the `<hrb-tooltip id="...">`.

Examples follow:

```html
<hrb-tooltip
  id="tooltip-id"
  tooltip-content="My Tool Tip"
  tooltip-position="top | right | bottom | left | default"
>
  <hrb-button p-aria-labelledby="tooltip-id">Tool Tip Left</hrb-button>
</hrb-tooltip>
```

<!-- Auto Generated Below -->


## Properties

| Property          | Attribute          | Description                                                                                             | Type                                                  | Default     |
| ----------------- | ------------------ | ------------------------------------------------------------------------------------------------------- | ----------------------------------------------------- | ----------- |
| `tooltipContent`  | `tooltip-content`  | Tool tip content                                                                                        | `string`                                              | `undefined` |
| `tooltipId`       | `tooltip-id`       | ID: ID is required for the tool tip to work. It ties into the accessibility concerns.                   | `string`                                              | `undefined` |
| `tooltipPosition` | `tooltip-position` | Position: Applies a position to the tooltip                                                             | `"bottom" \| "default" \| "left" \| "right" \| "top"` | `'default'` |
| `tooltipVisible`  | `tooltip-visible`  | Visible: State that can trigger visibility of tooltip. Useful if you're not using hover as your trigger | `boolean`                                             | `false`     |


## Methods

### `toggleTooltip() => Promise<void>`

Triggers visibility of tooltip

#### Returns

Type: `Promise<void>`




----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
