import { select, text, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import { reset, tooltipPositions } from '@src/constants/storybook'

import * as readme from './readme.md'

/* eslint-disable-next-line */
const tooltip = (content, position) =>
  `
<hrb-tooltip id="toolTipID"
  tooltip-content="${content}"
  tooltip-position="${position}">
  <hrb-button p-aria-described-by="toolTipID">Tool Tip</hrb-button>
</hrb-tooltip>
`

const wrapperOpen = `${reset}
<div style="display: flex;
align-items: center;
justify-content: center;
height: 100vh;">`
const wrapperClose = `</div>`

storiesOf('Tool Tip', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-tooltip'],
    notes: { markdown: readme },
  })
  .add('Tooltip styles', () => {
    return `${wrapperOpen}

    ${tooltip(
      text('Content', 'Tip Content'),
      select('Position', tooltipPositions, tooltipPositions[1]),
    )}

    ${wrapperClose}`
  })
