# hrb-nav-secondary-item

The `hrb-nav-secondary-item` component renders an icon + text link, meant to be used as a child of an `hrb-nav-bar` component. According to the Design System, they are designed to be used in the `secondary-nav` and `mobile-panel` slot container. See [the hrb-nav readme](../nav-bar) for more information.

```html
<hrb-nav-bar>
  <!-- rest of the nav -->

  <div slot="secondary-nav">
    <hrb-nav-secondary-item
      text="Find an office"
      icon="location"
      href="/find-office"
      hide-on-small
    ></hrb-nav-secondary-item>
    <hrb-nav-secondary-item
      text="Sign in"
      href="/sign-in"
      icon="account"
    ></hrb-nav-secondary-item>
    <hrb-nav-secondary-item
      text="Search"
      href="/search"
      icon="search"
      hide-on-small
    ></hrb-nav-secondary-item>
  </div>

  <!-- rest of the nav -->
</hrb-nav-bar>
```

## Examples

On top of accepting classic link props (`href`, `ref`, `target`), use the `text` prop for the label, and the `icon` prop to indicate which icon should be rendered before the text.

```html
<hrb-nav-secondary-item
  text="Find an office"
  icon="location"
  href="/find-office"
></hrb-nav-secondary-item>
```

---

Use the `hide-on-small` prop if you want the component to be hidden on the S breakpoint (viewport width < 390px)

```html
<hrb-nav-secondary-item
  text="Find an office"
  icon="location"
  href="/find-office"
  hide-on-small
></hrb-nav-secondary-item>
```

<!-- Auto Generated Below -->


## Properties

| Property      | Attribute       | Description                                                    | Type      | Default     |
| ------------- | --------------- | -------------------------------------------------------------- | --------- | ----------- |
| `hideOnSmall` | `hide-on-small` | If set to `true` this item will be hidden on small breakpoints | `boolean` | `undefined` |
| `href`        | `href`          | Applies href attribute                                         | `string`  | `undefined` |
| `icon`        | `icon`          | Adds on icon to the item                                       | `string`  | `undefined` |
| `rel`         | `rel`           | Applies optional rel attribute                                 | `string`  | `undefined` |
| `target`      | `target`        | Applies optional target attribute                              | `string`  | `undefined` |
| `text`        | `text`          | Sets text for secondary item                                   | `string`  | `undefined` |


## Dependencies

### Depends on

- [hrb-icon](../../icon)
- [hrb-text](../../text)

### Graph
```mermaid
graph TD;
  hrb-navbar-secondary-item --> hrb-icon
  hrb-navbar-secondary-item --> hrb-text
  style hrb-navbar-secondary-item fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
