import { Component, Element, Host, h, Prop } from '@stencil/core'

const Constants = {
  baseClassname: 'hrb-nav-secondary-item',
}

@Component({
  tag: 'hrb-navbar-secondary-item',
  styleUrl: 'navbar-secondary-item.scss',
})
export class NavBarSecondaryItem {
  @Element() el: HTMLElement

  /**
   * Adds on icon to the item
   */
  @Prop() icon: string

  /**
   * Applies href attribute
   */
  @Prop() href: string

  /**
   * Applies optional target attribute
   */
  @Prop() target: string

  /**
   * Sets text for secondary item
   */
  @Prop() text: string

  /**
   * Applies optional rel attribute
   */
  @Prop() rel: string

  /**
   * If set to `true` this item will be hidden on small breakpoints
   */
  @Prop({ attribute: 'hide-on-small' }) hideOnSmall: boolean

  render(): JSX.Element {
    const { href, icon, target, text, rel } = this

    return (
      <Host data-hrb-nav-bar-secondary-item>
        <a
          class={`${Constants.baseClassname}__link`}
          href={href}
          target={target}
          rel={rel}
        >
          {icon && (
            <hrb-icon
              class={`${Constants.baseClassname}__icon`}
              name={icon}
            ></hrb-icon>
          )}
          <hrb-text
            class={`${Constants.baseClassname}__text`}
            styleType="cta-small"
          >
            {text}
          </hrb-text>
        </a>
      </Host>
    )
  }
}
