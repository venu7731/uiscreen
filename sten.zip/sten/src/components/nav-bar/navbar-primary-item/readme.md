# hrb-nav-primary-item

The `hrb-nav-primary-item` component essentially renders a text link with an optionnal sub navigation, meant to be used as a children of an `hrb-nav-bar` component, in the `primary-nav` slot container. See [the hrb-nav readme](../nav-bar) for more information.

```html
<hrb-nav-bar>
  <!-- rest of the nav -->

  <div slot="primary-nav">
    <hrb-nav-primary-item text="A simple link" href="/"></hrb-nav-primary-item>
  </div>

  <!-- rest of the nav -->
</hrb-nav-bar>
```

## Examples

To render a simple text link, the component accepts classic link props (`href`, `ref`, `target`), and a `text` prop for the label.

```html
<!-- A link with no children -->
<hrb-nav-primary-item text="A simple link" href="/"></hrb-nav-primary-item>
```

---

To render a link with a subnav appearing on hover (or tab + return key on the generated down carrot button), add a simple list as a child.
The developer is in charge of good semantics and layout of the children of the component.

```html
<!-- A link with children -->
<hrb-nav-primary-item text="Ways to file" href="/ways-to-file">
  <ul>
    <li><hrb-text>File with a Tax Pro</hrb-text></li>
    <li><hrb-link href="/in-store">In-store</hrb-link></li>
  </ul>
</hrb-nav-primary-item>
```

📝 Note: the submenu would appear **only** if the `hrb-nav-primary-item` component is a child of an `hrb-nav-bar` component, in the `primary-nav` slot container.

<!-- Auto Generated Below -->


## Properties

| Property | Attribute | Description                       | Type     | Default     |
| -------- | --------- | --------------------------------- | -------- | ----------- |
| `href`   | `href`    | Applies href attribute            | `string` | `undefined` |
| `rel`    | `rel`     | Applies optional rel attribute    | `string` | `undefined` |
| `target` | `target`  | Applies optional target attribute | `string` | `undefined` |
| `text`   | `text`    | Sets text for primary item        | `string` | `undefined` |


## Dependencies

### Depends on

- [hrb-text](../../text)

### Graph
```mermaid
graph TD;
  hrb-navbar-primary-item --> hrb-text
  style hrb-navbar-primary-item fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
