import { Component, Element, Host, h, Prop, State } from '@stencil/core'

import { generateSimpleID } from '@src/utils/misc'

const Constants = {
  baseClassname: 'hrb-nav-bar',
  ariaLabel: 'dropdown',
}

@Component({
  tag: 'hrb-navbar-primary-item',
  styleUrl: 'navbar-primary-item.scss',
})
export class HrbNavPrimaryItem {
  /**
   * Sets text for primary item
   */
  @Prop() text: string

  /**
   * Applies href attribute
   */
  @Prop() href: string

  /**
   * Applies optional target attribute
   */
  @Prop() target: string

  /**
   * Applies optional rel attribute
   */
  @Prop() rel: string

  @Element() el: HTMLElement

  @State() hasFilledSlot = true

  private panelId = generateSimpleID()

  componentDidLoad(): void {
    const navPanel = this.el.querySelector(`[data-hrb-nav-bar-panel-content]`)
    this.hasFilledSlot = !!navPanel && !!navPanel.children.length
  }

  render(): JSX.Element {
    const { hasFilledSlot, href, panelId, target, text, rel } = this
    const { ariaLabel, baseClassname } = Constants
    const screenReaderAriaLabel = hasFilledSlot ? `${text} ${ariaLabel}` : text

    return (
      <Host>
        <a
          aria-controls={panelId}
          aria-expanded="false"
          aria-haspopup={hasFilledSlot}
          aria-label={screenReaderAriaLabel}
          class={`${baseClassname}__primary-item-link`}
          data-hrb-nav-bar-primary-item
          href={href}
          target={target}
          rel={rel}
        >
          <hrb-text styleType="body-copy-small">{text}</hrb-text>
        </a>
        {hasFilledSlot && (
          <div
            class={`${baseClassname}__panel`}
            data-hrb-nav-bar-panel
            id={panelId}
            role="menu"
          >
            <div
              data-hrb-nav-bar-panel-content
              class={`${baseClassname}__panel-content`}
            >
              <slot></slot>
            </div>
          </div>
        )}
      </Host>
    )
  }
}
