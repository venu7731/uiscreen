# hrb-nav-link

The `hrb-nav-link` component is very similar to the `hrb-link` component, but its design and different available style types make it unique.
Its main prupose is to be used as a child of a footer module (see Design Guidelines).

```html
<hrb-nav-link href="/">Link 1</hrb-nav-link>
```

📝 Note: see the [hrb-link readme](../link) to find more documentation about the main properties.

## Examples

Different styles are available using the `style-type` prop.

```html
<hrb-nav-link href="/" style-type="medium">Link 1</hrb-nav-link>
```

<!-- Auto Generated Below -->


## Properties

| Property          | Attribute           | Description                                                        | Type                                                        | Default       |
| ----------------- | ------------------- | ------------------------------------------------------------------ | ----------------------------------------------------------- | ------------- |
| `as`              | `as`                | Sets tag for link (defaults to <a />)                              | `"a" \| "button" \| "span"`                                 | `'a'`         |
| `disabled`        | `disabled`          | Sets link to disabled                                              | `boolean`                                                   | `false`       |
| `href`            | `href`              | Applies href attribute                                             | `string`                                                    | `undefined`   |
| `pAriaLabel`      | `p-aria-label`      | Applies `aria-label` to link                                       | `string`                                                    | `undefined`   |
| `pAriaLabelledby` | `p-aria-labelledby` | Applies `aria-labelledby` to link                                  | `string`                                                    | `undefined`   |
| `pAriaRole`       | `p-aria-role`       | Applies `aria-role` to link                                        | `string`                                                    | `undefined`   |
| `rel`             | `rel`               | Applies optional rel attribute                                     | `string`                                                    | `undefined`   |
| `styleType`       | `style-type`        | The font style type that will be applied (defaults to 'body copy') | `"body-copy" \| "large" \| "little" \| "medium" \| "small"` | `'body-copy'` |
| `target`          | `target`            | Applies optional target attribute                                  | `string`                                                    | `undefined`   |
| `type`            | `type`              | Applies type attribute                                             | `string`                                                    | `undefined`   |


## Dependencies

### Depends on

- [hrb-icon](../../icon)

### Graph
```mermaid
graph TD;
  hrb-nav-link --> hrb-icon
  style hrb-nav-link fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
