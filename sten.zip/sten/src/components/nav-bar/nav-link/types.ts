export type TNavLinkStyleTypes =
  | 'body-copy'
  | 'large'
  | 'little'
  | 'medium'
  | 'small'

export type TNavLinkButtonTypes = 'a' | 'button' | 'span'
