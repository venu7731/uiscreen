import { Component, h, Host, Prop } from '@stencil/core'

import {
  getIsValidButtonType,
  getIsValidNavLinkStyleType,
} from '@src/utils/validations'
import { getClassnames } from '@src/utils/misc'

import buttonTypes from '@src/constants/button-types'

import { TNavLinkStyleTypes, TNavLinkButtonTypes } from './types'

const Constants = {
  baseClassname: 'hrb-nav-link',
}

@Component({
  tag: 'hrb-nav-link',
  styleUrl: 'nav-link.scss',
})
export class NavLink {
  /**
   * Applies `aria-label` to link
   */
  @Prop({ attribute: 'p-aria-label' }) pAriaLabel: string

  /**
   * Applies `aria-labelledby` to link
   */
  @Prop({ attribute: 'p-aria-labelledby' }) pAriaLabelledby: string

  /**
   * Applies `aria-role` to link
   */
  @Prop({ attribute: 'p-aria-role' }) pAriaRole: string

  /**
   * Sets tag for link (defaults to <a />)
   */
  @Prop() as: TNavLinkButtonTypes = 'a'

  /**
   * Applies optional target attribute
   */
  @Prop() target: string

  /**
   * Applies optional rel attribute
   */
  @Prop() rel: string

  /**
   * Applies href attribute
   */
  @Prop() href: string

  /**
   * Sets link to disabled
   */
  @Prop() disabled = false

  /**
   * Applies type attribute
   */
  @Prop() type: string

  /**
   * The font style type that will be applied (defaults to 'body copy')
   */
  @Prop() styleType: TNavLinkStyleTypes = 'body-copy'

  componentWillLoad(): void {
    this.validateLinkType()
    this.validateStyleType()
  }

  validateLinkType(): void {
    if (!this.as) return // button type is not required so this is valid

    const { as } = this
    const isValidLinkType = getIsValidButtonType(as)

    if (!isValidLinkType) {
      this.throwConsoleError(as, 'type')
    }
  }

  validateStyleType(): void {
    if (!this.styleType) return // styleType is not required so this is valid

    const { styleType } = this
    const isValidStyleType = getIsValidNavLinkStyleType(styleType)

    if (!isValidStyleType) {
      this.throwConsoleError(styleType, 'style type')
    }
  }

  throwConsoleError(val: string, prop: string): void {
    // eslint-disable-next-line no-console
    console.error(`<hrb-nav-link /> : "${val}" is not a valid nav link ${prop}`)
  }

  getProps = (): object => {
    const {
      pAriaLabel,
      pAriaLabelledby,
      pAriaRole,
      as,
      disabled,
      href,
      rel,
      target,
      type,
    } = this

    const isAnchor = as === buttonTypes.anchor
    const isButton = as === buttonTypes.button

    const sharedProps = {
      'aria-label': pAriaLabel,
      'aria-labelledby': pAriaLabelledby,
      'aria-role': pAriaRole,
      'aria-disabled': disabled,
    }

    if (isAnchor) {
      return {
        ...sharedProps,
        href,
        rel,
        target,
      }
    }

    if (isButton) {
      return {
        ...sharedProps,
        type,
        disabled,
      }
    }

    return {
      ...sharedProps,
    }
  }

  render(): JSX.Element {
    const props = this.getProps()
    const { baseClassname } = Constants

    const classnames = getClassnames([
      `${baseClassname}`,
      `${baseClassname}--${this.styleType}`,
    ])

    return (
      <Host>
        <this.as class={classnames} {...props} data-hrb-nav-link>
          <span class={`${baseClassname}__text`}>
            <slot></slot>
          </span>
          <span class={`${baseClassname}__arrow`}>
            <hrb-icon name="chevron-right"></hrb-icon>
          </span>
        </this.as>
      </Host>
    )
  }
}
