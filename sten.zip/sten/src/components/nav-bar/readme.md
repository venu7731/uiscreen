# hrb-nav-bar

The `hrb-nav-bar` component provides a complete navigation system, composed of 2 main areas:

- A top navigation bar, containing the HRB logo, navigation links and a menu button.
- A mobile panel area containing navigation links as well, displayed when toggling the menu button.

We've created "sub" web components to be used as children of the `hrb-nav-bar` component:

- `hrb-nav-logo`: Host of the HRB logo. See [the hrb-nav-logo readme](../nav-logo) for more information.
- `hrb-nav-primary-item`: Simple text links. Can contain children links (works as a sub-menu). See [the hrb-nav-primary-item readme](../nav-primary-item) for more information.
- `hrb-nav-secondary-item`: Icon with text links. See [the hrb-nav-secondary-item readme](../nav-secondary-item) for more information.

We've also created specific areas (`slot`) to accomodate for the design across the different breakpoints and provide enough flexibility in terms of layout and functionalities.

```html
<hrb-nav-bar>
  <!-- #1 - Logo container, left of the navigation bar -->
  <div slot="logo"></div>

  <!-- #2 - Navigation bar links, left of the navigation bar -->
  <div slot="primary-nav"></div>

  <!-- #3 - Navigation bar links, right of the navigation bar -->
  <div slot="secondary-nav"></div>

  <!-- #4 - Mobile panel, displayed when the menu button is toggled -->
  <div slot="mobile-panel"></div>
</hrb-nav-bar>
```

## slot="logo"

Contains the logo, placed on the left of the navigation top bar container. A `hrb-nav-logo` component should be used to display the logo.

📝 The "logo" `slot` is visible across all the breakpoints.

```html
<hrb-nav-bar>
  <div slot="logo">
    <hrb-nav-logo href="https://www.hrblock.com">
      <!-- logo.svg -->
    </hrb-nav-logo>
  </div>

  <!-- rest of the nav -->
</hrb-nav-bar>
```

## slot="primary-nav"

Contains `hrb-nav-primary-item` children, placed on the left of the navigation top bar container, on the right of the logo `slot`.

While a `hrb-nav-primary-item` component display a simple text link, it can also host children, therefore acting as a submenu. When a user hovers a `hrb-nav-primary-item` component that has children, the top nav extends to show them.
The developer is in charge for the good semantic and layout of the children.

📝The "primary-nav" `slot` content is visible and functional only on the L breakpoint (viewport width > 1560px).

📝If an `hrb-nav-primary-item` component has a sub navigation, it should be an unordered list (`ul/li`) for accessibility purposes.

```html
<hrb-nav-bar>
  <!-- rest of the nav -->

  <div slot="primary-nav">
    <!-- A link with no children -->
    <hrb-nav-primary-item text="A simple link" href="/"></hrb-nav-primary-item>

    <!-- A link with children -->
    <hrb-nav-primary-item text="Ways to file" href="/ways-to-file">
      <ul>
        <li><hrb-text>File with a Tax Pro</hrb-text></li>
        <li><hrb-link href="/in-store">In-store</hrb-link></li>
      </ul>
    </hrb-nav-primary-item>
  </div>

  <!-- rest of the nav -->
</hrb-nav-bar>
```

## slot="secondary-nav"

Contains `hrb-nav-secondary-item` children, placed on the right of the navigation top bar container, previous to the menu icon (generated autonatically).

A `hrb-nav-secondary-item` component is composed by an icon + text. As opposed to a `hrb-nav-primary-item`, it cannot contained child elements.

📝The "secondary-nav" `slot` content is visible across all breakpoints, it is up to the developers to hide specific `hrb-nav-secondary-item` components using the `hide-on-small` prop.

```html
<hrb-nav-bar>
  <!-- rest of the nav -->

  <div slot="secondary-nav">
    <hrb-nav-secondary-item
      text="Find an office"
      icon="location"
      href="/find-office"
      hide-on-small
    ></hrb-nav-secondary-item>
    <hrb-nav-secondary-item
      text="Sign in"
      href="/sign-in"
      icon="account"
    ></hrb-nav-secondary-item>
    <hrb-nav-secondary-item
      text="Search"
      href="/search"
      icon="search"
      hide-on-small
    ></hrb-nav-secondary-item>
  </div>

  <!-- rest of the nav -->
</hrb-nav-bar>
```

## slot="mobile-panel"

A container displayed/hidden when the menu button is toggled. It's an "opened" container for developers to implement, layout as they wish.

```html
<hrb-nav-bar>
  <!-- rest of the nav -->

  <div slot="mobile-panel">
    <!-- main mobile panel link -->
    <ul class="mobile-main-links">
      <li><hrb-link href="/ways-to-file">Ways to file</hrb-link></li>
      <li><hrb-link href="/in-store">In-store</hrb-link></li>
    </ul>

    <!-- Bottom -->
    <ul class="mobile-secondary-links">
      <li>
        <hrb-nav-secondary-item
          text="Search"
          icon="search"
          href="/search"
          hide-on-small
        ></hrb-nav-secondary-item>
      </li>
      <li>
        <hrb-nav-secondary-item
          text="Find an office"
          icon="location"
          href="/find-an-office"
          hide-on-small
        ></hrb-nav-secondary-item>
      </li>
    </ul>
  </div>

  <!-- rest of the nav -->
</hrb-nav-bar>
```

<!-- Auto Generated Below -->


## Properties

| Property                | Attribute                  | Description                                    | Type     | Default  |
| ----------------------- | -------------------------- | ---------------------------------------------- | -------- | -------- |
| `currentMobileMenuIcon` | `current-mobile-menu-icon` | Sets icon for mobile menu (defaults to 'menu') | `string` | `'menu'` |


## Dependencies

### Depends on

- [hrb-circled](../circled)
- [hrb-icon](../icon)

### Graph
```mermaid
graph TD;
  hrb-nav-bar --> hrb-circled
  hrb-nav-bar --> hrb-icon
  style hrb-nav-bar fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
