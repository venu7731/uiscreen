import { Component, Element, Host, h, Prop, State } from '@stencil/core'

import { getClassnames } from '@src/utils/misc'

const Constants = {
  baseClassname: 'hrb-nav-bar',
  disableVerticalScroll: 'hrb-util--disable-vertical-scroll',
  mobileMenuAriaLabel: 'Mobile menu',
  mobileMenu: 'hrb-mobile-menu',
}

@Component({
  tag: 'hrb-nav-bar',
  styleUrl: 'nav-bar.scss',
})
export class NavBar {
  @Element() el: HTMLElement

  @State() isOpen = false

  @State() currentlySelectedDropdown = ''

  /**
   * Sets icon for mobile menu (defaults to 'menu')
   */
  @Prop({ mutable: true }) currentMobileMenuIcon = 'menu'

  private hasMobilePanelSlot: boolean

  componentWillLoad(): void {
    this.hasMobilePanelSlot = !!this.el.querySelector('[slot="mobile-panel"]')
  }

  componentDidLoad(): void {
    this.addPrimaryNavItemsFromSlots()
    this.addSecondaryNavItemsFromSlots()
  }

  addPrimaryNavItemsFromSlots = (): void => {
    const primaryNavItems = this.el.querySelectorAll(
      `[slot="primary-nav"] hrb-nav-primary-item`,
    )

    const primaryNav = this.el.querySelector('.hrb-nav-bar__primary-items')

    primaryNavItems.forEach(item => {
      const li = document.createElement('li')

      li.className = 'hrb-nav-bar__primary-item'
      li.appendChild(item)

      const link = li.querySelector('[data-hrb-nav-bar-primary-item]')

      link.addEventListener('click', this.toggleDropdown)
      link.addEventListener('mouseenter', this.removeAllActiveClasses)
      link.addEventListener('mouseleave', this.addActiveClass)

      primaryNav.appendChild(li)
    })
  }

  addActiveClass = (e: Event): void => {
    const { parentNode } = e.currentTarget as HTMLElement
    const currentPanel = parentNode.querySelector('[data-hrb-nav-bar-panel]')
    const primaryLink = parentNode.querySelector(
      '[data-hrb-nav-bar-primary-item]',
    )

    if (primaryLink && currentPanel) {
      const currentPanelId = currentPanel.getAttribute('id')
      const isCurrentlySelected =
        currentPanelId && currentPanelId === this.currentlySelectedDropdown

      if (isCurrentlySelected) {
        primaryLink.classList.add(
          `${Constants.baseClassname}__primary-item-link--active`,
        )
      }
    }
  }

  removeAllActiveClasses = (): void => {
    const primaryLinks = this.el.querySelectorAll(
      '[data-hrb-nav-bar-primary-item]',
    )

    if (primaryLinks && this.currentlySelectedDropdown === '') {
      primaryLinks.forEach(link => {
        link.classList.remove(
          `${Constants.baseClassname}__primary-item-link--active`,
        )
      })
    }
  }

  addSecondaryNavItemsFromSlots = (): void => {
    const secondaryNavItems = this.el.querySelectorAll(
      '[slot="secondary-nav"] [data-hrb-nav-bar-secondary-item]',
    )

    const secondaryNav = this.el.querySelector('[data-hrb-nav-bar-secondary]')
    const mobileNav = this.el.querySelector('[data-hrb-nav-bar-mobile-menu]')

    secondaryNavItems.forEach(item => {
      const li = document.createElement('li')
      const shouldHideOnSmall = item.hasAttribute('hide-on-small')

      li.className = `${Constants.baseClassname}__secondary-item`
      if (shouldHideOnSmall) {
        li.className = `${li.className} ${li.className}--hidden-small`
      }

      li.appendChild(item)
      secondaryNav.insertBefore(li, mobileNav)
    })
  }

  openDropdown = (e: Event): void => {
    const { parentNode } = e.currentTarget as HTMLElement
    const currentPanel = parentNode.querySelector('[data-hrb-nav-bar-panel]')
    const currentLink = parentNode.querySelector(
      '[data-hrb-nav-bar-primary-item]',
    )
    const currentPanelId = currentPanel.getAttribute('id')
    const overlay = this.el.querySelector('[data-hrb-nav-bar-overlay]')

    if (currentPanel && currentPanelId && currentLink) {
      currentPanel.classList.add(`${Constants.baseClassname}__panel--is-open`)

      if (overlay) {
        overlay.classList.add(`${Constants.baseClassname}__overlay--is-open`)
      }

      this.currentlySelectedDropdown = currentPanelId
      this.isOpen = true

      if (
        this.isOpen &&
        this.currentlySelectedDropdown === Constants.mobileMenu
      ) {
        const iconCircle = parentNode.querySelector(
          '[data-hrb-nav-bar-mobile-menu-circle]',
        )
        iconCircle.setAttribute('theme', 'light-grey-1')
        this.currentMobileMenuIcon = 'close'
        document
          .querySelector('body')
          .classList.add(Constants.disableVerticalScroll)
      }
    }
  }

  closeDropdown = (): void => {
    if (!this.isOpen) return

    const overlay = this.el.querySelector('[data-hrb-nav-bar-overlay]')
    const panels = this.el.querySelectorAll('[data-hrb-nav-bar-panel]')

    panels.forEach(panel => {
      panel.classList.remove(`${Constants.baseClassname}__panel--is-open`)
    })

    overlay.classList.remove(`${Constants.baseClassname}__overlay--is-open`)

    this.currentlySelectedDropdown = ''
    this.isOpen = false

    this.removeAllActiveClasses()

    if (this.currentlySelectedDropdown !== Constants.mobileMenu) {
      const iconCircle = this.el.querySelector(
        '[data-hrb-nav-bar-mobile-menu-circle]',
      )
      iconCircle.setAttribute('theme', '')
      this.currentMobileMenuIcon = 'menu'
      document
        .querySelector('body')
        .classList.remove(Constants.disableVerticalScroll)
    }
  }

  toggleDropdown = (e: Event): void => {
    const { parentNode } = e.currentTarget as HTMLElement
    const currentItem = parentNode.querySelector(
      '[data-hrb-nav-bar-primary-item]',
    )
    const currentPanel = parentNode.querySelector('[data-hrb-nav-bar-panel]')
    const primaryItems = this.el.querySelectorAll(
      '[data-hrb-nav-bar-primary-item]',
    )

    if (primaryItems) {
      primaryItems.forEach(button => {
        this.setAriaExpanded(button, false)
      })
    }

    // If the target has a panel to show, show it, else close whatever panel is open
    if (currentItem && currentPanel) {
      const currentPanelId = currentPanel.getAttribute('id')
      const isCurrentDropdownOpen =
        this.isOpen && this.currentlySelectedDropdown === currentPanelId

      // Only prevent default if there's a panel for this nav item
      e.preventDefault()

      // Close any panel that's currently open
      this.closeDropdown()

      if (!isCurrentDropdownOpen) {
        this.openDropdown(e)
        this.setAriaExpanded(currentItem)
      }
    } else {
      this.closeDropdown()
    }
  }

  setAriaExpanded = (button, shouldExpand = true): void => {
    if (button) {
      button.setAttribute('aria-expanded', shouldExpand)
    }
  }

  render(): JSX.Element {
    const {
      currentMobileMenuIcon,
      currentlySelectedDropdown,
      hasMobilePanelSlot,
      isOpen,
    } = this

    const { baseClassname, mobileMenu, mobileMenuAriaLabel } = Constants

    const classnames = getClassnames([
      `${baseClassname}__container`,
      isOpen && `${baseClassname}__container--is-open`,
    ])

    return (
      <Host>
        <nav class={classnames}>
          <div class={`${baseClassname}__primary`}>
            <slot name="logo"></slot>

            <ul
              class={`${baseClassname}__primary-items`}
              data-hrb-nav-bar-primary
              role="menubar"
            ></ul>
          </div>

          <ul class={`${baseClassname}__secondary`} data-hrb-nav-bar-secondary>
            {hasMobilePanelSlot && (
              <li
                class={`${baseClassname}__secondary-item ${baseClassname}__secondary-item--mobile-menu`}
                data-hrb-nav-bar-mobile-menu
              >
                <button
                  aria-haspopup="true"
                  aria-label={mobileMenuAriaLabel}
                  aria-controls="hrb-mobile-menu"
                  aria-expanded={
                    isOpen && currentlySelectedDropdown === mobileMenu
                  }
                  class={`${baseClassname}__secondary-item-link`}
                  onClick={this.toggleDropdown}
                  data-hrb-nav-bar-primary-item
                >
                  <hrb-circled data-hrb-nav-bar-mobile-menu-circle>
                    <hrb-icon
                      class={`${baseClassname}__secondary-item-icon`}
                      name={currentMobileMenuIcon}
                    ></hrb-icon>
                  </hrb-circled>
                </button>
                <div
                  id="hrb-mobile-menu"
                  class={`${baseClassname}__panel ${baseClassname}__panel--mobile`}
                  data-hrb-nav-bar-panel
                >
                  <div
                    data-hrb-nav-bar-panel-content
                    class={`${baseClassname}__panel-content`}
                  >
                    <slot name="mobile-panel"></slot>
                  </div>
                </div>
              </li>
            )}
          </ul>
          <div class={`${baseClassname}__hidden-slots`}>
            <slot name="primary-nav"></slot>
            <slot name="secondary-nav"></slot>
          </div>
        </nav>
        <div
          aria-hidden
          data-hrb-nav-bar-overlay
          class={`${baseClassname}__overlay`}
          onClick={this.closeDropdown}
        ></div>
      </Host>
    )
  }
}
