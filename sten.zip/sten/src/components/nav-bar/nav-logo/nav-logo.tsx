import { Component, Host, h, Prop } from '@stencil/core'

@Component({
  tag: 'hrb-nav-logo',
  styleUrl: 'nav-logo.scss',
})
export class NavLogo {
  /**
   * Applies `aria-label` to logo (default to 'Home')
   */
  @Prop({ attribute: 'p-aria-label' }) pAriaLabel = 'Home'

  /**
   * Applies href attribute
   */
  @Prop() href: string

  /**
   * Applies optional target attribute
   */
  @Prop() target: string

  /**
   * Applies optional rel attribute
   */
  @Prop() rel: string

  /**
   * If no height is passed, height defaults to 40px in css
   */
  @Prop() height: string

  /**
   * If no width is passed, height defaults to 40px in css
   */
  @Prop() width: string

  render(): JSX.Element {
    const { href, pAriaLabel, rel, target } = this

    const height = `${this.height}px`
    const width = `${this.width}px`

    return (
      <Host>
        <a
          style={{ height, width }}
          href={href}
          target={target}
          rel={rel}
          aria-label={pAriaLabel}
          class="hrb-nav-bar__primary-item-link hrb-nav-bar__primary-logo"
        >
          <slot />
        </a>
      </Host>
    )
  }
}
