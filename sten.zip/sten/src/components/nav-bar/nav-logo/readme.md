# hrb-nav-logo

The `hrb-nav-logo` component is made to host the logo element (SVG, PNG...) in the context of `hrb-nav-bar` component.
It renders the logo element inside a link element, usually used to point to the homepage. Therefore, the `hrb-nav-logo` component accepts classic link props: `href`, `ref`, `target`.

## Examples

```html
<hrb-nav-bar>
  <div slot="logo">
    <hrb-nav-logo href="https://www.hrblock.com">
      <img src="/assets/logo.png" alt="H&R block" />
    </hrb-nav-logo>
  </div>

  <!-- rest of the nav -->
</hrb-nav-bar>
```

<!-- Auto Generated Below -->


## Properties

| Property     | Attribute      | Description                                            | Type     | Default     |
| ------------ | -------------- | ------------------------------------------------------ | -------- | ----------- |
| `height`     | `height`       | If no height is passed, height defaults to 40px in css | `string` | `undefined` |
| `href`       | `href`         | Applies href attribute                                 | `string` | `undefined` |
| `pAriaLabel` | `p-aria-label` | Applies `aria-label` to logo (default to 'Home')       | `string` | `'Home'`    |
| `rel`        | `rel`          | Applies optional rel attribute                         | `string` | `undefined` |
| `target`     | `target`       | Applies optional target attribute                      | `string` | `undefined` |
| `width`      | `width`        | If no width is passed, height defaults to 40px in css  | `string` | `undefined` |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
