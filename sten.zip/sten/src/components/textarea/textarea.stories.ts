import * as readme from './readme.md'

export default {
  component: 'hrb-textarea',
  title: 'Forms/TextArea',
  parameters: {
    notes: { markdown: readme },
  },
  argTypes: {
    label: { control: 'text' },
    errorLabel: { control: 'text' },
    helperText: { control: 'text' },
    hasError: { control: 'boolean' },
    icon: { control: 'text' },
    forceIconVisibility: { control: 'boolean' },
    type: {
      control: {
        type: 'select',
        options: ['text', 'number', 'date', 'password', 'email'],
      },
    },
  },
}

export const Basic = (args): string =>
  `
    <hrb-textarea required
      label="${args.label}"
      ${!!args.helperText && `helper-text="${args.helperText}"`}
      ${!!args.hasError && `has-error`}
      error-label="${args.errorLabel}"></hrb-textarea>
  `

Basic.args = {
  label: 'Basic Textarea',
  hasError: false,
}

export const HasError = (args): string =>
  `
    <hrb-textarea required
      label="${args.label}"
      ${!!args.helperText && `helper-text="${args.helperText}"`}
      ${!!args.hasError && `has-error`}
      error-label="${args.errorLabel}"></hrb-textarea>
  `

HasError.args = {
  label: 'Basic Textarea',
  errorLabel:
    'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.',
  hasError: true,
}

export const HasHelperAndError = (args): string =>
  `
    <hrb-textarea required
      label="${args.label}"
      ${!!args.helperText && `helper-text="${args.helperText}"`}
      ${!!args.hasError && `has-error`}
      error-label="${args.errorLabel}"></hrb-textarea>
  `

HasHelperAndError.args = {
  label: 'Basic Textarea',
  helperText:
    'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat',
  errorLabel: 'Kuis nostrud exercitation ullamco laboris nisi ut aliquips.',
  hasError: true,
}
