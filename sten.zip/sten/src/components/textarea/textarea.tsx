import {
  Component,
  Element,
  Event,
  EventEmitter,
  h,
  Host,
  Method,
  Prop,
  State,
} from '@stencil/core'

import { generateSimpleID, getClassnames } from '@src/utils/misc'

const Constants = {
  baseClassname: 'hrb-textarea',
}

@Component({
  tag: 'hrb-textarea',
  styleUrl: 'textarea.scss',
})
export class Textarea {
  @Element() el: HTMLElement

  @Event() hrbBlur: EventEmitter

  @Event() hrbChange: EventEmitter

  @Event() hrbFocus: EventEmitter

  @Event() hrbInput: EventEmitter

  @Method() async getElement(): Promise<HTMLElement> {
    return this.textareaRef
  }

  @Method() async setFocus(): Promise<void> {
    this.onFocus()
  }

  /**
   * Autocomplete
   */
  @Prop() autocomplete = 'on'

  /**
   * Textarea columns
   */
  @Prop() cols: number

  /**
   * Disabled
   */
  @Prop() disabled = false

  /**
   * Disable textarea resizing
   */
  @Prop() disableResize: boolean

  /**
   * Error label
   */
  @Prop() errorLabel: string

  /**
   * Textarea has error
   */
  @Prop() hasError = false

  /**
   * Helper text
   */
  @Prop() helperText: string

  /**
   * Textarea is loading
   */
  @Prop() loading = false

  /**
   * Textarea rows
   */
  @Prop() rows = 6

  /**
   * Textarea id
   */
  @Prop() textareaId = generateSimpleID()

  /**
   * Label
   */
  @Prop() label = ''

  /**
   * Name
   */
  @Prop() name = ''

  /**
   * Maximum value length
   */
  @Prop() maxlength: string

  /**
   * Minimum value length
   */
  @Prop() minlength: string

  /**
   * Pattern
   */
  @Prop() pattern = ''

  /**
   * Readonly
   */
  @Prop() readonly: boolean

  /**
   * Required
   */
  @Prop() required = false

  /**
   * Default value
   */
  @Prop({ mutable: true }) value: string

  /**
   * current focus state
   */
  @State() isFocused = false

  private textareaRef: HTMLTextAreaElement

  onChange = (): CustomEvent => this.hrbChange.emit(this)

  onInput = (event: Event): void => {
    const { value } = event.target as HTMLInputElement

    this.value = value
    this.hrbInput.emit(this)
  }

  onBlur = (): void => {
    this.isFocused = false
    this.hrbBlur.emit(this)
  }

  onFocus = (): void => {
    this.isFocused = true
    this.hrbFocus.emit(this)
  }

  renderLoader = (): JSX.Element => {
    return (
      <span class={`${Constants.baseClassname}__loader`} aria-hidden="true">
        <hrb-loader></hrb-loader>
      </span>
    )
  }

  renderError = (): JSX.Element => {
    const { errorLabel } = this
    const { baseClassname } = Constants

    return (
      <span class={`${baseClassname}__error`} role="alert">
        <hrb-icon name="error"></hrb-icon>
        {errorLabel}
      </span>
    )
  }

  renderHelper = (): JSX.Element => {
    const { helperText, textareaId } = this
    const { baseClassname } = Constants

    return (
      <div id={`${textareaId}__helper`} class={`${baseClassname}__helper`}>
        {helperText}
      </div>
    )
  }

  render(): JSX.Element {
    const { baseClassname } = Constants
    const {
      cols,
      disabled,
      disableResize,
      errorLabel,
      hasError,
      helperText,
      isFocused,
      label,
      loading,
      maxlength,
      minlength,
      onBlur,
      onChange,
      onFocus,
      onInput,
      name,
      readonly,
      renderError,
      renderHelper,
      renderLoader,
      required,
      rows,
      textareaId,
      value,
    } = this

    const containerClassnames = getClassnames([
      baseClassname,
      disabled && `${baseClassname}--is-disabled`,
      disableResize && `${baseClassname}--has-disabled-resize`,
      hasError && `${baseClassname}--has-error`,
      isFocused && `${baseClassname}--is-focused`,
      loading && `${baseClassname}--is-loading`,
      !!value && `${baseClassname}--has-text`,
    ])

    return (
      <Host>
        <span class={containerClassnames}>
          <label htmlFor={textareaId} class={`${baseClassname}__label`}>
            {label}
          </label>
          <textarea
            aria-required={required.toString()}
            class={`${baseClassname}__textarea`}
            cols={cols}
            disabled={disabled}
            id={textareaId}
            minlength={minlength}
            maxlength={maxlength}
            name={name}
            onBlur={onBlur}
            onFocus={onFocus}
            onChange={onChange}
            onInput={onInput}
            readonly={readonly}
            required={required}
            rows={rows}
            value={value}
            ref={(el): HTMLTextAreaElement => (this.textareaRef = el)}
          />
          {loading && renderLoader()}
        </span>
        {hasError && !!errorLabel && renderError()}
        {helperText && renderHelper()}
      </Host>
    )
  }
}
