import { newSpecPage } from '@stencil/core/testing'

import { Textarea } from '../textarea'

describe('Textarea', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [Textarea],
      html: `
      <hrb-textarea label="My label" textarea-id="myId"></hrb-textarea>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-textarea label="My label" textarea-id="myId">
      <span class="hrb-textarea">
        <label class="hrb-textarea__label" htmlfor="myId">
          My label
        </label>
        <textarea aria-required="false" class="hrb-textarea__textarea" id="myId" rows="6"></textarea>
      </span>
    </hrb-textarea>
    `)
  })
})
