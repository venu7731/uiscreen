# hrb-textarea

<!-- Auto Generated Below -->


## Properties

| Property        | Attribute        | Description               | Type      | Default              |
| --------------- | ---------------- | ------------------------- | --------- | -------------------- |
| `autocomplete`  | `autocomplete`   | Autocomplete              | `string`  | `'on'`               |
| `cols`          | `cols`           | Textarea columns          | `number`  | `undefined`          |
| `disableResize` | `disable-resize` | Disable textarea resizing | `boolean` | `undefined`          |
| `disabled`      | `disabled`       | Disabled                  | `boolean` | `false`              |
| `errorLabel`    | `error-label`    | Error label               | `string`  | `undefined`          |
| `hasError`      | `has-error`      | Textarea has error        | `boolean` | `false`              |
| `helperText`    | `helper-text`    | Helper text               | `string`  | `undefined`          |
| `label`         | `label`          | Label                     | `string`  | `''`                 |
| `loading`       | `loading`        | Textarea is loading       | `boolean` | `false`              |
| `maxlength`     | `maxlength`      | Maximum value length      | `string`  | `undefined`          |
| `minlength`     | `minlength`      | Minimum value length      | `string`  | `undefined`          |
| `name`          | `name`           | Name                      | `string`  | `''`                 |
| `pattern`       | `pattern`        | Pattern                   | `string`  | `''`                 |
| `readonly`      | `readonly`       | Readonly                  | `boolean` | `undefined`          |
| `required`      | `required`       | Required                  | `boolean` | `false`              |
| `rows`          | `rows`           | Textarea rows             | `number`  | `6`                  |
| `textareaId`    | `textarea-id`    | Textarea id               | `string`  | `generateSimpleID()` |
| `value`         | `value`          | Default value             | `string`  | `undefined`          |


## Events

| Event       | Description | Type               |
| ----------- | ----------- | ------------------ |
| `hrbBlur`   |             | `CustomEvent<any>` |
| `hrbChange` |             | `CustomEvent<any>` |
| `hrbFocus`  |             | `CustomEvent<any>` |
| `hrbInput`  |             | `CustomEvent<any>` |


## Methods

### `getElement() => Promise<HTMLElement>`



#### Returns

Type: `Promise<HTMLElement>`



### `setFocus() => Promise<void>`



#### Returns

Type: `Promise<void>`




## Dependencies

### Depends on

- [hrb-loader](../loader)
- [hrb-icon](../icon)

### Graph
```mermaid
graph TD;
  hrb-textarea --> hrb-loader
  hrb-textarea --> hrb-icon
  style hrb-textarea fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
