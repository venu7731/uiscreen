import { Component, h, Host, Prop } from '@stencil/core'

@Component({
  tag: 'hrb-rule',
  styleUrl: 'hrb-rule.scss',
})
export class HrbRule {
  @Prop() vertical = false

  render(): JSX.Element {
    return (
      <Host class="hrb-rule">
        <hr />
      </Host>
    )
  }
}
