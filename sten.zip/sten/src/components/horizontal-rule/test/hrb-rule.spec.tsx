import { newSpecPage } from '@stencil/core/testing'

import { HrbRule } from '../hrb-rule'

describe('hrb-rule', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbRule],
      html: `<hrb-rule></hrb-rule>`,
    })
    expect(page.root).toEqualHtml(`
     <hrb-rule class="hrb-rule">
        <hr>
     </hrb-rule>
    `)
  })
})

describe('hrb-rule vertical', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbRule],
      html: `<hrb-rule vertical></hrb-rule>`,
    })
    expect(page.root).toEqualHtml(`
    <hrb-rule class="hrb-rule" vertical="">
      <hr>
    </hrb-rule>
    `)
  })
})
