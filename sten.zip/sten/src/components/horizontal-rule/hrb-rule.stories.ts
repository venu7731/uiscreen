export default {
  component: 'hrb-rule',
  title: 'Rule',
}

export const Basic = (): string =>
  `
  <div style="height: 200px; width: 200px; margin: 0 auto;">
    <hrb-rule></hrb-rule>
  </div>
  `

export const Vertical = (): string =>
  `
  <div style="height: 200px; width: 200px; margin: 0 auto;">
    <hrb-rule vertical></hrb-rule>
  </div>
  `
