# <hrb-data-item>

`<hrb-data-item>` are elements that are generally found in data-lists. They typically contain line-item type data (term + definition) such as "Category --- Individual Income Tax Return". This pattern is found through out several of Block's applications.

`<hrb-data-item>` can be `<button>`, `<a>`, but default to `<span>` to make their use as flexible as possible. You can use the attribute "as" to assign the role to the element. `<hrb-data-item as="button">` for example.

The default use of a `<hrb-data-item>`, as mentioned above, is in a line-item context. As such there are three default attributes that you can assign your data to: `term`, `def`, and `metadata`, with an additional `note` attribute available. This will layout out this common information consistently across all screen sizes. If, however, you need a free-form spot to put in other kinds of content, you can do so just by adding content between the opening and closing tags like normal. However, if you discover another common pattern, it should become a component.

The `<hrb-data-item>` can also take a `thumb-src` attribute. It will plug in a thumbnail image of whatever you put in it. However, if you want it to display, you will also need to plug in a `thumb-alt` attribute. Yes, the `thumb-alt` attribute is required.

## Examples

### Using the default attributes:

```html
<hrb-data-item
  def="My Definition"
  term="My Term"
  thumb-alt="..."
  thumb-src="..."
  metadata="My Metadata"
  note="My Note"
>
</hrb-data-item>
```

### Free Form:

```html
<hrb-data-item>
  ...My Content...
</hrb-data-item>
```

### As a Button:

```html
<hrb-data-item
  as="button"
  def="My Definition"
  metadata="My Metadata"
  note="My Note"
  term="My Term"
>
</hrb-data-item>
```

### Disabled:

```html
<hrb-data-item
  disabled
  as="button"
  def="My Definition"
  metadata="My Metadata"
  note="My Note"
  term="My Term"
>
</hrb-data-item>
```

### As an anchor:

```html
<hrb-data-item
  as="a"
  def="My Definition"
  metadata="My Metadata"
  note="My Note"
  term="My Term"
>
</hrb-data-item>
```

<!-- Auto Generated Below -->


## Properties

| Property          | Attribute           | Description                                                       | Type                        | Default     |
| ----------------- | ------------------- | ----------------------------------------------------------------- | --------------------------- | ----------- |
| `as`              | `as`                | Sets tag for item (defaults to span)                              | `"a" \| "button" \| "span"` | `'span'`    |
| `data`            | `data`              | Term: The data or item to be defined                              | `any`                       | `null`      |
| `def`             | `def`               | Def: The definition or explanation of the term                    | `any`                       | `null`      |
| `disabled`        | `disabled`          | Sets button to disabled                                           | `boolean`                   | `false`     |
| `href`            | `href`              | Applies optional href attribute                                   | `string`                    | `undefined` |
| `icon`            | `icon`              | Adds icon to item                                                 | `string`                    | `'none'`    |
| `label`           | `label`             | Term: The label or item to be defined                             | `any`                       | `null`      |
| `metadata`        | `metadata`          | Metadata: The meta-data that goes with the term                   | `any`                       | `null`      |
| `note`            | `note`              | Note: A note that displays under the data item but still attached | `any`                       | `null`      |
| `pAriaLabel`      | `p-aria-label`      | Applies `aria-label`                                              | `string`                    | `undefined` |
| `pAriaLabelledby` | `p-aria-labelledby` | Applies `aria-labelledby`                                         | `string`                    | `undefined` |
| `pAriaRole`       | `p-aria-role`       | Applies `aria-role`                                               | `string`                    | `undefined` |
| `rel`             | `rel`               | Applies optional rel attribute                                    | `string`                    | `undefined` |
| `target`          | `target`            | Applies optional target attribute                                 | `string`                    | `undefined` |
| `term`            | `term`              | Term: The term or item to be defined                              | `any`                       | `null`      |
| `thumbAlt`        | `thumb-alt`         | Adds Thumbnail to item                                            | `string`                    | `'none'`    |
| `thumbSrc`        | `thumb-src`         | Adds Thumbnail source to item                                     | `string`                    | `'none'`    |
| `type`            | `type`              | Applies type attribute                                            | `string`                    | `undefined` |


## Dependencies

### Used by

 - [hrb-data-list](../data-list)

### Depends on

- [hrb-img](../img)
- [hrb-text](../text)
- [hrb-icon](../icon)

### Graph
```mermaid
graph TD;
  hrb-data-item --> hrb-img
  hrb-data-item --> hrb-text
  hrb-data-item --> hrb-icon
  hrb-data-list --> hrb-data-item
  style hrb-data-item fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
