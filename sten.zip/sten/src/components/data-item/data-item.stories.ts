import { select, text, boolean, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import { buttonTypes, reset } from '@src/constants/storybook'
import icons from '@src/constants/icons'

import * as readme from './readme.md'

const wrapperOpen = `${reset}<div style="padding: 30px">`
const wrapperClose = `</div>`

storiesOf('Data Item', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-data-item'],
    notes: { markdown: readme },
  })
  .add('Data Item', () => {
    return `${wrapperOpen}
        <hrb-data-item
          icon=${
            boolean('Has Icon', false)
              ? select('Icon', icons, icons[15])
              : 'none'
          }
          thumb-src=${
            boolean('Has Thumb Nail', false)
              ? text('Thumb Source', 'https://picsum.photos/200')
              : 'none'
          }
          thumb-alt=${
            boolean('Has Thumb Alt', false)
              ? text('Thumb Source', 'Required Thumbnail Alt Text')
              : 'none'
          }
          as=${select('As', buttonTypes, buttonTypes[2])}
          def=${text('Item Definition', 'Def')}
          metadata=${text('Metadata', 'Meta')}
          note=${text('Item Note', 'Note.')}
          term=${text('Item Term', 'Term')}>
        </hrb-data-item>
    ${wrapperClose}`
  })
