import { newSpecPage } from '@stencil/core/testing'

import { DataItem } from '../data-item'

describe('DataItem', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [DataItem],
      html: `
      <hrb-data-item thumb-src="https://picsum.photos/200"
        thumb-alt="Alt Text"
        as='button'
        term="My Term"
        def="My Def"
        metadata="My Meta"
        icon="arrow-right"
        note="This is a note about the data item to be used later.">
      </hrb-data-item>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-data-item as="button" def="My Def" icon="arrow-right" metadata="My Meta" note="This is a note about the data item to be used later." term="My Term" thumb-alt="Alt Text" thumb-src="https://picsum.photos/200">
      <button class="hrb-data-item">
        <div class="hrb-data-item__content">
          <div class="hrb-data-item__flex">
            <div class="hrb-data-item__label">
              <div class="hrb-data-item__thumbSrc">
                <hrb-img alt="Alt Text" src="https://picsum.photos/200"></hrb-img>
              </div>
              <hrb-text>
                My Term
              </hrb-text>
            </div>
            <div class="hrb-data-item__data">
              <hrb-text>
                My Def
              </hrb-text>
              <span class="hrb-data-item__icon">
                <hrb-icon name="arrow-right"></hrb-icon>
              </span>
            </div>
          </div>
          <div class="hrb-data-item__term-meta">
            <div class="hrb-data-item__metadata">
              <hrb-text style-type="metadata">
                My Meta
              </hrb-text>
            </div>
          </div>
          <hrb-text class="hrb-data-item__note" style-type="body-copy">
            This is a note about the data item to be used later.
          </hrb-text>
        </div>
      </button>
    </hrb-data-item>
    `)
  })
})
