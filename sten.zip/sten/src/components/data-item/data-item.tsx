import { Component, Prop, Element, Host, h } from '@stencil/core'
import buttonTypes from '@src/constants/button-types'

import { TButtonTypes } from '../buttons/button/types'

const Constants = {
  baseClassname: 'hrb-data-item',
}

@Component({
  tag: 'hrb-data-item',
  styleUrl: 'data-item.scss',
})
export class DataItem {
  @Element() el: HTMLElement

  /**
   * Sets tag for item (defaults to span)
   */
  @Prop() as: TButtonTypes = 'span'

  /**
   * Adds icon to item
   */
  @Prop() icon = 'none'

  /**
   * Adds Thumbnail source to item
   */
  @Prop() thumbSrc = 'none'

  /**
   * Adds Thumbnail to item
   */
  @Prop() thumbAlt = 'none'

  /**
   * Applies `aria-label`
   */
  @Prop({ attribute: 'p-aria-label' }) pAriaLabel: string

  /**
   * Applies `aria-labelledby`
   */
  @Prop({ attribute: 'p-aria-labelledby' }) pAriaLabelledby: string

  /**
   * Applies `aria-role`
   */
  @Prop({ attribute: 'p-aria-role' }) pAriaRole: string

  /**
   * Applies optional target attribute
   */
  @Prop() target: string

  /**
   * Applies optional rel attribute
   */
  @Prop() rel: string

  /**
   * Applies optional href attribute
   */
  @Prop() href: string

  /**
   * Sets button to disabled
   */
  @Prop() disabled = false

  /**
   * Applies type attribute
   */
  @Prop() type: string

  /**
   * Term: The term or item to be defined
   */
  @Prop() term = null

  /**
   * Term: The label or item to be defined
   */
  @Prop() label = null

  /**
   * Term: The data or item to be defined
   */
  @Prop() data = null

  /**
   * Metadata: The meta-data that goes with the term
   */
  @Prop() metadata = null

  /**
   * Def: The definition or explanation of the term
   */
  @Prop() def = null

  /**
   * Note: A note that displays under the data item but still attached
   */
  @Prop() note = null

  getProps = (): object => {
    const {
      pAriaLabel,
      pAriaLabelledby,
      pAriaRole,
      as,
      disabled,
      href,
      rel,
      target,
      type,
    } = this

    const isAnchor = as === buttonTypes.anchor
    const isButton = as === buttonTypes.button

    const sharedProps = {
      'aria-label': pAriaLabel,
      'aria-labelledby': pAriaLabelledby,
      'aria-role': pAriaRole,
      'aria-disabled': disabled,
    }

    if (isAnchor) {
      return {
        ...sharedProps,
        href,
        rel,
        target,
      }
    }

    if (isButton) {
      return {
        ...sharedProps,
        type,
        disabled,
      }
    }

    return {
      ...sharedProps,
    }
  }

  render(): JSX.Element {
    const {
      icon,
      term,
      data,
      label,
      metadata,
      def,
      note,
      thumbSrc,
      thumbAlt,
    } = this
    const hasIcon = icon !== 'none'
    const hasThumbAlt = thumbAlt !== 'none'
    const props = this.getProps()
    return (
      <Host>
        <this.as class={`${Constants.baseClassname}`} {...props}>
          <div class={`${Constants.baseClassname}__content`}>
            <div class={`${Constants.baseClassname}__flex`}>
              <div class={`${Constants.baseClassname}__label`}>
                {hasThumbAlt && (
                  <div class={`${Constants.baseClassname}__thumbSrc`}>
                    <hrb-img src={thumbSrc} alt={thumbAlt}></hrb-img>
                  </div>
                )}
                {term !== null && <hrb-text>{term}</hrb-text>}
                {label !== null && <hrb-text>{label}</hrb-text>}
              </div>
              <div class={`${Constants.baseClassname}__data`}>
                {data !== null && <hrb-text>{data}</hrb-text>}
                {def !== null && <hrb-text>{def}</hrb-text>}
                {/* Icon as Attribute */}
                {hasIcon && (
                  <span class={`${Constants.baseClassname}__icon`}>
                    <hrb-icon name={icon}></hrb-icon>
                  </span>
                )}
              </div>
            </div>
            <div class="hrb-data-item__term-meta">
              {metadata !== null && (
                <div class={`${Constants.baseClassname}__metadata`}>
                  <hrb-text style-type="metadata">{metadata}</hrb-text>
                </div>
              )}
            </div>
            {note !== null && (
              <hrb-text
                class={`${Constants.baseClassname}__note`}
                style-type="body-copy"
              >
                {note}
              </hrb-text>
            )}
            <slot></slot>
          </div>
        </this.as>
      </Host>
    )
  }
}
