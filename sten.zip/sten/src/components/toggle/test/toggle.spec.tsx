import { newSpecPage } from '@stencil/core/testing'

import { HrbToggle } from '../toggle'

describe('HrbToggle', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbToggle],
      html: `
      <hrb-toggle disabled theme="green" checked>My Toggle</hrb-toggle>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-toggle checked="" class="hrb-toggle hrb-toggle--on" disabled="" theme="green">
      <button aria-checked="true" class="hrb-toggle__button" disabled="" role="switch" type="button">
        <hrb-circled class="hrb-toggle__circled" size="small"></hrb-circled>
        <span class="hrb-toggle__label">
          My Toggle
        </span>
        <svg class="toggle-expand" xmlns="http://www.w3.org/2000/svg">
          <circle cx="50" cy="50" r="50" />
        </svg>
      </button>
    </hrb-toggle>
    `)
  })
})
