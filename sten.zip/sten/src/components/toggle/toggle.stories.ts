import * as readme from './readme.md'

export default {
  component: 'hrb-toggle',
  title: 'Forms/Toggle',
  parameters: {
    notes: { markdown: readme },
    actions: {
      handles: [
        {
          hrbChange: 'hrbChange',
          hrbBlur: 'hrbBlur',
          hrbFocus: 'hrbFocus',
          hrbInput: 'hrbInput',
        },
      ],
    },
  },
  argTypes: {
    hiddenText: { control: 'text' },
    checked: { control: 'boolean' },
    disabled: { control: 'boolean' },
  },
}

export const Basic = (args): string =>
  `
  <hrb-toggle ${args.checked ? 'checked' : ''} ${
    args.disabled ? 'disabled' : ''
  }>${args.hiddenText}</hrb-toggle>
  `

Basic.args = {
  hiddenText: 'My Hidden Text Here',
}

export const ToggleChecked = (): string =>
  `
  <hrb-toggle checked>My hidden label</hrb-toggle>
  `

export const ToggleDisabled = (): string =>
  `
  <hrb-toggle disabled>My hidden label</hrb-toggle>
  `
