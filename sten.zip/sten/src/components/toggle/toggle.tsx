import {
  Component,
  Element,
  Event,
  EventEmitter,
  Host,
  h,
  Method,
  Prop,
} from '@stencil/core'

import { getClassnames } from '@src/utils/misc'

const Constants = {
  baseClassname: 'hrb-toggle',
}

@Component({
  tag: 'hrb-toggle',
  styleUrl: 'toggle.scss',
})
export class HrbToggle {
  @Element() el: HTMLElement

  @Event() hrbBlur: EventEmitter

  @Event() hrbChange: EventEmitter

  @Event() hrbFocus: EventEmitter

  @Event() hrbInput: EventEmitter

  @Method() async getElement(): Promise<HTMLElement> {
    return this.buttonRef
  }

  @Method() async setFocus(): Promise<void> {
    this.buttonRef.focus()
  }

  /**
   * Sets the toggle button to 'disabled'
   */
  @Prop() disabled = false

  /**
   * Sets the toggle to 'checked' state (defaults to false)
   */
  @Prop({ mutable: true, reflect: true }) checked = false

  private buttonRef: HTMLButtonElement

  onBlur = (): CustomEvent => this.hrbBlur.emit(this)

  onFocus = (): CustomEvent => this.hrbFocus.emit(this)

  handleButtonClicked = (): void => {
    const { checked } = this
    this.checked = !checked

    this.hrbChange.emit(this)
    this.hrbInput.emit(this)
  }

  render(): JSX.Element {
    const { checked, disabled, handleButtonClicked, onBlur, onFocus } = this
    const classes = getClassnames([
      `${Constants.baseClassname}`,
      checked && `${Constants.baseClassname}--on`,
    ])

    return (
      <Host class={classes}>
        <button
          aria-checked={checked.toString()}
          class={`${Constants.baseClassname}__button`}
          disabled={disabled}
          onBlur={onBlur}
          onFocus={onFocus}
          onClick={handleButtonClicked}
          role="switch"
          type="button"
          ref={(el): HTMLButtonElement => (this.buttonRef = el)}
        >
          <hrb-circled
            size="small"
            class={`${Constants.baseClassname}__circled`}
          ></hrb-circled>
          <span class={`${Constants.baseClassname}__label`}>
            <slot></slot>
          </span>
          <svg class="toggle-expand" xmlns="http://www.w3.org/2000/svg">
            <circle cx="50" cy="50" r="50" />
          </svg>
        </button>
      </Host>
    )
  }
}
