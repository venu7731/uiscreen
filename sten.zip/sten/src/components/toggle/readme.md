# hrb-toggle

The `hrb-toggle` element renders an accessible and nice toggle `button`, exposing a `checked` prop similar to a `checkbox`.

The direct child of an `hrb-toggle` element is not visually rendered and should be used for accessibility purpose.

## Examples

`hrb-toggle` can use a variety of themes, listed below, with the `theme` prop. By default it uses the `green` theme.

```html
<hrb-toggle theme="blue">A car</hrb-toggle>
```

Available themes:

- `green`
- `blue`
- `medium-dark-green`
- `yellow`

---

You can "pre" toggle an `hrb-toggle` element using the `checked` prop.

```html
<hrb-toggle checked>A car</hrb-toggle>
```

## Event Examples

Most of the standard events are available

```js
const toggle = form.querySelector('hrb-toggle')

toggle.addEventListener('click', e => {
  console.log('click')
})
```

We've added some custom events to expose a consistent API across all the customs inputs and accomodate for specific events that are not available by default on custom elements, such as `focus` and `blur`.

Every custom events return a reference to element, available in `e.detail`.

```js
const toggle = form.querySelector('hrb-toggle')

// Focus
toggle.addEventListener('hrbFocus', e => {
  console.log('focus', e.detail)
})

// Blur
toggle.addEventListener('hrbBlur', e => {
  console.log('blur', e.detail)
})

// Change
toggle.addEventListener('hrbChange', e => {
  console.log('change', e.detail)
})

// Input
toggle.addEventListener('hrbInput', e => {
  console.log('input', e.detail)
})
```

## Method Examples

Every methods exposed return a `Promise`.

```js
const toggle = form.querySelector('hrb-toggle')

// get the main button element inside the `hrb-toggle`
const toggleButton = await checkbox.getElement()

// set the focus on the element
await toggle.setFocus()
```

<!-- Auto Generated Below -->


## Properties

| Property   | Attribute  | Description                                            | Type      | Default |
| ---------- | ---------- | ------------------------------------------------------ | --------- | ------- |
| `checked`  | `checked`  | Sets the toggle to 'checked' state (defaults to false) | `boolean` | `false` |
| `disabled` | `disabled` | Sets the toggle button to 'disabled'                   | `boolean` | `false` |


## Events

| Event       | Description | Type               |
| ----------- | ----------- | ------------------ |
| `hrbBlur`   |             | `CustomEvent<any>` |
| `hrbChange` |             | `CustomEvent<any>` |
| `hrbFocus`  |             | `CustomEvent<any>` |
| `hrbInput`  |             | `CustomEvent<any>` |


## Methods

### `getElement() => Promise<HTMLElement>`



#### Returns

Type: `Promise<HTMLElement>`



### `setFocus() => Promise<void>`



#### Returns

Type: `Promise<void>`




## Dependencies

### Depends on

- [hrb-circled](../circled)

### Graph
```mermaid
graph TD;
  hrb-toggle --> hrb-circled
  style hrb-toggle fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
