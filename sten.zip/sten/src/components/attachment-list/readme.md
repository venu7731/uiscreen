# hrb-attachment-list

<!-- Auto Generated Below -->


## Properties

| Property      | Attribute    | Description                                              | Type      | Default                   |
| ------------- | ------------ | -------------------------------------------------------- | --------- | ------------------------- |
| `attachments` | --           | Attachment Array                                         | `any[]`   | `[]`                      |
| `collapsed`   | `collapsed`  | collapsed defaults to true                               | `boolean` | `true`                    |
| `edit`        | `edit`       | Edit will set the attachment items into their edit state | `boolean` | `false`                   |
| `itemCount`   | `item-count` |                                                          | `number`  | `this.attachments.length` |


## Events

| Event                  | Description                               | Type               |
| ---------------------- | ----------------------------------------- | ------------------ |
| `attachmentListToggle` | Event that fires when the element toggles | `CustomEvent<any>` |


## Methods

### `toggleList() => Promise<void>`

Public method to toggle the Attachment list
emits the attachmentListToggle event

#### Returns

Type: `Promise<void>`




## Dependencies

### Used by

 - [hrb-message-card](../card composites/card-message)

### Depends on

- [hrb-attachment-item](../attachment-item)
- [hrb-text](../text)

### Graph
```mermaid
graph TD;
  hrb-attachment-list --> hrb-attachment-item
  hrb-attachment-list --> hrb-text
  hrb-attachment-item --> hrb-button
  hrb-attachment-item --> hrb-icon
  hrb-button --> hrb-loader
  hrb-button --> hrb-text
  hrb-button --> hrb-icon
  hrb-message-card --> hrb-attachment-list
  style hrb-attachment-list fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
