import { withKnobs, boolean } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import { reset } from '@src/constants/storybook'

import * as readme from './readme.md'

const wrapperOpen = `${reset}<div style="padding: 30px; max-width: 800px; margin: 0 auto;">`
const wrapperClose = `</div>`

storiesOf('Attachment List', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['test/attachment-list.spec.tsx'],
    notes: { markdown: readme },
  })
  .add('Attachment List', () => {
    return `
    ${wrapperOpen}
    <hrb-layout layout="1col">
      <hrb-attachment-list
        attachments=${[
          {
            AttachmentId: 'e2a714cd-52d4-4078-88ce-4fed67060407',
            MessageId: '67946835-eb79-48ee-9106-e3b7aeca05ae',
            FileName: '022-0150-dl-wh-man-11-2019.pdf',
            FileSize: 109233,
            MimeType: null,
            Created: '2020-07-16T20:56:45.62',
            Updated: '2020-07-16T20:56:46.373',
            AttachmentLocation: null,
            DocumentSource: 'WC',
          },
          {
            AttachmentId: 'e2a714cd-52d4-4078-88ce-4fed67060407',
            MessageId: '67946835-eb79-48ee-9106-e3b7aeca05ae',
            FileName: '022-0150-dl-wh-man-11-2017.pdf',
            FileSize: 109233,
            MimeType: null,
            Created: '2020-07-16T20:56:45.62',
            Updated: '2020-07-16T20:56:46.373',
            AttachmentLocation: null,
            DocumentSource: 'WC',
          },
          {
            AttachmentId: 'e2a714cd-52d4-4078-88ce-4fed67060407',
            MessageId: '67946835-eb79-48ee-9106-e3b7aeca05ae',
            FileName: '022-0150-dl-wh-man-11-2018.pdf',
            FileSize: 109233,
            MimeType: null,
            Created: '2020-07-16T20:56:45.62',
            Updated: '2020-07-16T20:56:46.373',
            AttachmentLocation: null,
            DocumentSource: 'WC',
          },
        ]}
        collapsed=${boolean('Is Collapsed', false)}>
      </hrb-attachment-list>
    </hrb-layout>
    ${wrapperClose}`
  })
