import { newSpecPage } from '@stencil/core/testing'

import { AttachmentList } from '../attachment-list'

describe('attachment-item', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [AttachmentList],
      html: `
      <hrb-attachment-item>
        <div></div>
      </hrb-attachment-item>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-attachment-item>
      <div></div>
    </hrb-attachment-item>
    `)
  })
})
