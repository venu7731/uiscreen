/* eslint-disable no-console */
import {
  Component,
  Element,
  Event,
  EventEmitter,
  Host,
  h,
  Prop,
  State,
  Method,
} from '@stencil/core'

import { getClassnames } from '@src/utils/misc'

const Constants = {
  baseClassname: 'attachment-list',
}

@Component({
  tag: 'hrb-attachment-list',
  styleUrl: 'attachment-list.scss',
})
export class AttachmentList {
  /**
   * Get the element as an HTML Element
   */
  @Element() el: HTMLElement

  /**
   * Event that fires when the element toggles
   */
  @Event() attachmentListToggle: EventEmitter

  /**
   * Attachment Array
   */
  @Prop() attachments = []

  /*
  Grabbing the length of the array
  */
  @Prop() itemCount = this.attachments.length

  /**
   * collapsed defaults to true
   */
  @Prop() collapsed = true

  /**
   * State state to the property "collapsed"
   */
  @State() isCollapsed = this.collapsed

  /**
   * Edit will set the attachment items into their edit state
   */
  @Prop() edit = false

  /**
   * Public method to toggle the Attachment list
   * emits the attachmentListToggle event
   */
  @Method()
  async toggleList(): Promise<void> {
    this.toggle()
    this.attachmentListToggle.emit()
  }

  /* 
  Toggle method called on ComponentDidLoad
  emits the toggleEvent
  */
  private toggle = (): void => {
    this.collapsed = !this.collapsed
  }

  render(): JSX.Element {
    const classes = getClassnames([
      `${Constants.baseClassname}`,
      !this.collapsed
        ? `${Constants.baseClassname}__open`
        : `${Constants.baseClassname}__closed`,
    ])

    const attachmentListClasses = getClassnames([
      `attachment-list-container`,
      this.collapsed
        ? `attachment-list__collapsed`
        : `${Constants.baseClassname}__expanded`,
    ])
    const attachmentContainerClasses = getClassnames([
      `attachment-list`,
      this.collapsed ? `` : `slide-elements-left`,
    ])

    const moreItems = this.itemCount - 1

    return (
      <Host class={classes}>
        {this.itemCount > 1 && (
          <div class={attachmentListClasses}>
            <div class={attachmentContainerClasses}>
              {this.attachments.map(attachment => (
                <hrb-attachment-item
                  FileName={attachment.FileName}
                  FileSize={attachment.FileSize}
                  isEditable={this.edit}
                ></hrb-attachment-item>
              ))}
            </div>
            <span class="additional-attachments">
              <hrb-text>
                + {moreItems} <span>more attachments</span>
              </hrb-text>
            </span>
          </div>
        )}
        {this.itemCount <= 1 && (
          <div class={attachmentListClasses}>
            <div>
              <slot></slot>
            </div>
          </div>
        )}
      </Host>
    )
  }
}
