# hrb-overflow-menu

`hrb-overflow-menu` is something that can be added to a card. Add it to the top of the card outside of the `hrb-card-content`.

Inside of the `hrb-overflow-menu`, you will add `hrb-overflow-item`s. `hrb-overflow-item` elements take two attributes: `label` and `action`. The `hrb-overflow-item` is a link with the `role="button"` attribute applied. Hence, the action is placed inside of the `href` attribute.

`hrb-overflow-menu` takes a single attribute `as`. Like our other elements this allows you to set the tag used by the `hrb-overflow-menu`.

## Example

```html
<hrb-overflow-menu>
  <hrb-overflow-item
    label="Item One"
    action="https://www.gog.com"
  ></hrb-overflow-item>
  <hrb-overflow-item
    label="Item Two"
    action="https://www.gog.com"
  ></hrb-overflow-item>
</hrb-overflow-menu>
```

<!-- Auto Generated Below -->


## Properties

| Property     | Attribute     | Description                           | Type                          | Default              |
| ------------ | ------------- | ------------------------------------- | ----------------------------- | -------------------- |
| `as`         | `as`          | Sets tag for list (defaults to <a />) | `"" \| "div" \| "ol" \| "ul"` | `'div'`              |
| `overflowId` | `overflow-id` | Unique ID                             | `string`                      | `generateSimpleID()` |


## Events

| Event       | Description | Type               |
| ----------- | ----------- | ------------------ |
| `hrbBlur`   |             | `CustomEvent<any>` |
| `hrbChange` |             | `CustomEvent<any>` |
| `hrbFocus`  |             | `CustomEvent<any>` |
| `hrbInput`  |             | `CustomEvent<any>` |


## Methods

### `getElement() => Promise<HTMLElement>`



#### Returns

Type: `Promise<HTMLElement>`



### `setFocus() => Promise<void>`



#### Returns

Type: `Promise<void>`



### `toggle() => Promise<void>`



#### Returns

Type: `Promise<void>`




## Dependencies

### Depends on

- [hrb-circle-button](../buttons/circle-button)
- [hrb-icon](../icon)

### Graph
```mermaid
graph TD;
  hrb-overflow-menu --> hrb-circle-button
  hrb-overflow-menu --> hrb-icon
  hrb-circle-button --> hrb-circled
  style hrb-overflow-menu fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
