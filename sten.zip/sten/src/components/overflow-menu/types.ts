export type TListTypes = 'ul' | 'ol' | 'div' | ''
