import {
  Component,
  Element,
  Host,
  h,
  Method,
  Prop,
  EventEmitter,
  Event,
  State,
} from '@stencil/core'

import { generateSimpleID } from '@src/utils/misc'

import { TListTypes } from './types'

@Component({
  tag: 'hrb-overflow-menu',
  styleUrl: 'overflow-menu.scss',
})
export class OverflowMenu {
  @Element() el!: HTMLElement

  /**
   * Unique ID
   */
  @Prop() overflowId?: string = generateSimpleID()

  /**
   * Sets tag for list (defaults to <a />)
   */
  @Prop() as: TListTypes = 'div'

  @Event() hrbBlur: EventEmitter

  @Event() hrbChange: EventEmitter

  @Event() hrbFocus: EventEmitter

  @Event() hrbInput: EventEmitter

  @Method() async getElement(): Promise<HTMLElement> {
    return this.buttonRef
  }

  @Method() async setFocus(): Promise<void> {
    this.buttonRef.focus()
  }

  private buttonRef: HTMLButtonElement

  onBlur = (): CustomEvent => this.hrbBlur.emit(this)

  onFocus = (): CustomEvent => this.hrbFocus.emit(this)

  @State() menuOpen = false

  handleButtonClicked = (): void => {
    this.menuOpen = !this.menuOpen
    this.hrbChange.emit(this)
    this.hrbInput.emit(this)
  }

  @Method()
  async toggle(): Promise<void> {
    this.handleButtonClicked()
  }

  buttonID = `${
    this.el.id !== ''
      ? `${this.el.id}-overflow-button`
      : `${this.overflowId}-overflow-button`
  }`

  contentID = `${
    this.el.id !== ''
      ? `${this.el.id}-overflow-content`
      : `${this.overflowId}-overflow-content`
  }`

  renderOverflowButton = (handleButtonClicked): JSX.Element => (
    <hrb-circle-button
      aria-controls={this.contentID}
      aria-expanded={this.menuOpen.toString()}
      id={this.buttonID}
      class="overflow-button"
      onClick={handleButtonClicked}
      p-aria-label={
        !this.menuOpen ? 'Open Overflow Menu' : 'Close Overflow Menu'
      }
      theme={!this.menuOpen ? 'default' : 'ui-green'}
    >
      <hrb-icon name={!this.menuOpen ? 'overflow' : 'close'}></hrb-icon>
    </hrb-circle-button>
  )

  render(): JSX.Element {
    return (
      <Host class="overflow-menu-component">
        {this.renderOverflowButton(this.handleButtonClicked)}
        <div
          aria-hidden={(!this.menuOpen).toString()}
          aria-labelledby={this.buttonID}
          class={`overflow-wrap ${this.menuOpen ? 'open' : 'closed'}`}
          id={this.contentID}
          role="region"
        >
          <this.as class={`overflow-menu ${this.menuOpen ? 'open' : 'closed'}`}>
            <slot></slot>
          </this.as>
        </div>
        <svg
          class={`circle-expand ${this.menuOpen ? 'open' : 'closed'}`}
          viewBox="0 0 80 80"
          xmlns="http://www.w3.org/2000/svg"
        >
          <circle cx="40" cy="40" r="40" />
        </svg>
      </Host>
    )
  }
}
