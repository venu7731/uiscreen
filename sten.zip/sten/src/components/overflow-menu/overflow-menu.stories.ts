import { withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import { reset } from '@src/constants/storybook'

import * as readme from './readme.md'

/* eslint-disable-next-line */
const cardDocument = () => {
  return `
  <hrb-card-document  
    file-name="Card Title" 
    category-name="Card Sub-title"
    added-by="Added by Gabe" 
    upload-date="Feb, 23rd 2020" 
    thumb-alt="Thumb Alternative Text" 
    thumb-src="https://picsum.photos/200">
    <hrb-overflow-menu>
        <hrb-overflow-item as="button" label="Item One" action="https://www.gog.com"></hrb-overflow-item>
        <hrb-overflow-item label="Item Two" action="https://www.gog.com"></hrb-overflow-item>
    </hrb-overflow-menu>
  </hrb-card-document>
  `
}

const wrapperOpen = `${reset}<div style="padding: 30px">`
const wrapperClose = `</div>`

storiesOf('Overflow menu', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-overflow-menu'],
    notes: { markdown: readme },
  })
  .add('Overflow Menu', () => {
    return `${wrapperOpen}

    ${cardDocument()}

    ${wrapperClose}`
  })
