import { newSpecPage } from '@stencil/core/testing'

import { OverflowMenu } from '../overflow-menu'

describe('OverflowMenu', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [OverflowMenu],
      html: `
      <hrb-overflow-menu id="my-menu">
        <div></div>
      </hrb-overflow-menu>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-overflow-menu class="overflow-menu-component" id="my-menu">
      <hrb-circle-button aria-controls="my-menu-overflow-content" aria-expanded="false" class="overflow-button" id="my-menu-overflow-button" p-aria-label="Open Overflow Menu" theme="default">
        <hrb-icon name="overflow"></hrb-icon>
      </hrb-circle-button>
      <div aria-hidden="true" aria-labelledby="my-menu-overflow-button" class="closed overflow-wrap" id="my-menu-overflow-content" role="region">
        <div class="closed overflow-menu">
          <div></div>
        </div>
      </div>
      <svg class="circle-expand closed" viewBox="0 0 80 80" xmlns="http://www.w3.org/2000/svg">
        <circle cx="40" cy="40" r="40"></circle>
      </svg>
    </hrb-overflow-menu>
    `)
  })
})
