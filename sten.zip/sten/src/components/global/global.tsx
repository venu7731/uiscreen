import { Component, h, Host, Prop } from '@stencil/core'

import SVGSprite from '../../assets/svg-sprite/symbol/svg/sprite.symbol.svg'

@Component({
  tag: 'hrb-global',
  styleUrl: 'global.scss',
})
export class Global {
  /**
   * Inject reset globally
   */
  @Prop() reset = false

  render(): JSX.Element {
    return (
      <Host>
        <span class="hrb-icon-sprite" innerHTML={SVGSprite}></span>
        {this.reset && <hrb-reset />}
        <slot />
      </Host>
    )
  }
}
