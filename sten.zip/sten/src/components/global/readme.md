# global

<!-- Auto Generated Below -->


## Properties

| Property | Attribute | Description           | Type      | Default |
| -------- | --------- | --------------------- | --------- | ------- |
| `reset`  | `reset`   | Inject reset globally | `boolean` | `false` |


## Dependencies

### Depends on

- [hrb-reset](../reset)

### Graph
```mermaid
graph TD;
  hrb-global --> hrb-reset
  style hrb-global fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
