# hrb-accordion-item

The `hrb-accordion-item` component is meant to be a direct child of a `hrb-accordion` component, which tracks the state of all the accordion items in it.

It renders an accordion item that expands/collapses when the header is clicked on.

The `header-as` props can be used to change the element wrapping the header.

An optional string can be passed via the `preview-text` prop.

📝 Please note this prop can only be used in `content` type accordions and will throw an error if used with the `subnav` type.

## Examples

```html
<hrb-accordion>
  <hrb-accordion-item
    header-as="h2"
    header-text="Accordion title"
    preview-text="Preview text"
  >
    <!-- accordion content -->
  </hrb-accordion-item>
</hrb-accordion>
```

---

When the `hrb-accordion` parent is of type `subnav`, the `subnav-header-style` prop can be used to change the style from its default `standard` to `large`.

```html
<hrb-accordion type="subnav">
  <hrb-accordion-item
    header-as="h2"
    header-text="Accordion title"
    subnav-header-style="large"
  >
    <!-- accordion content -->
  </hrb-accordion-item>
</hrb-accordion>
```

<!-- Auto Generated Below -->


## Properties

| Property                  | Attribute             | Description                                                 | Type                                    | Default                  |
| ------------------------- | --------------------- | ----------------------------------------------------------- | --------------------------------------- | ------------------------ |
| `accordionId`             | `accordion-id`        | Unique ID                                                   | `string`                                | `generateSimpleID()`     |
| `disabled`                | `disabled`            | Sets accordion item and associated web controls to disabled | `boolean`                               | `false`                  |
| `headerAs`                | `header-as`           | The tag to wrap header text with                            | `string`                                | `'h3'`                   |
| `headerText` _(required)_ | `header-text`         | Text that displays in the header                            | `string`                                | `undefined`              |
| `previewText`             | `preview-text`        | The tag to wrap the text with                               | `string`                                | `undefined`              |
| `subnavHeaderStyle`       | `subnav-header-style` | Style prop for the subnav type                              | `Constants.large \| Constants.standard` | `EnumConstants.standard` |
| `type`                    | `type`                | The accordion type                                          | `Constants.content \| Constants.subnav` | `EnumConstants.content`  |


## Events

| Event              | Description | Type               |
| ------------------ | ----------- | ------------------ |
| `accordionToggled` |             | `CustomEvent<any>` |


## Methods

### `setIsExpanded(isExpanded: boolean) => Promise<void>`



#### Returns

Type: `Promise<void>`




## Dependencies

### Depends on

- [hrb-circled](../circled)
- [hrb-icon](../icon)

### Graph
```mermaid
graph TD;
  hrb-accordion-item --> hrb-circled
  hrb-accordion-item --> hrb-icon
  style hrb-accordion-item fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
