export enum Constants {
  content = 'content',
  large = 'large',
  standard = 'standard',
  subnav = 'subnav',
}

export type TAccordionTypes = Constants.content | Constants.subnav
export type TSubnavHeaderTypes = Constants.standard | Constants.large
