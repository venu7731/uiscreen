import {
  Component,
  Element,
  Event,
  EventEmitter,
  Host,
  h,
  Listen,
  Method,
  Prop,
  State,
} from '@stencil/core'

import { generateSimpleID, getClassnames } from '@src/utils/misc'

import {
  Constants as EnumConstants,
  TAccordionTypes,
  TSubnavHeaderTypes,
} from './types'

const Constants = {
  baseClassname: 'hbr-accordion-item',
}

@Component({
  tag: 'hrb-accordion-item',
  styleUrl: 'accordion-item.scss',
})
export class HrbAccordionItem {
  @Element() el: HTMLElement

  /**
   * Unique ID
   */
  @Prop() accordionId?: string = generateSimpleID()

  /**
   * The tag to wrap header text with
   */
  @Prop() headerAs?: string = 'h3'

  /**
   * Text that displays in the header
   */
  @Prop() headerText!: string

  /**
   * The tag to wrap the text with
   */
  @Prop() previewText?: string

  /**
   * Style prop for the subnav type
   */
  @Prop() subnavHeaderStyle?: TSubnavHeaderTypes = EnumConstants.standard

  /**
   * The accordion type
   */
  @Prop() type?: TAccordionTypes = EnumConstants.content

  /**
   * Sets accordion item and associated web controls to disabled
   */
  @Prop() disabled = false

  @Event() accordionToggled: EventEmitter

  accordionToggledHandler = (): CustomEvent =>
    this.accordionToggled.emit(!this.state.isExpanded)

  @Listen('resize', { target: 'window' })
  handleScroll(): void {
    this.updateHeightStates()
  }

  innerElement!: HTMLElement

  previewElement!: HTMLElement

  @Method()
  async setIsExpanded(isExpanded: boolean): Promise<void> {
    this.state = { ...this.state, isExpanded }
  }

  @State()
  state = {
    innerHeight: 0,
    isExpanded: false,
    // Use null to avoid animated height on load
    previewHeight: null,
  }

  componentWillLoad(): void {
    this.validateProps()
  }

  componentDidLoad(): void {
    this.updateHeightStates()
  }

  componentWillUpdate(): void {
    this.updateHeightStates()
  }

  updateHeightStates = (): void => {
    const { innerElement, isContent, previewElement, previewText } = this
    const innerHeight = innerElement.clientHeight
    const previewHeight =
      isContent && previewText && previewElement
        ? previewElement.clientHeight
        : 0

    this.state = { ...this.state, innerHeight, previewHeight }
  }

  isContent = (): boolean => this.type === 'content'

  validateProps = (): void => {
    const { isContent, previewText } = this

    if (!isContent() && previewText) {
      throw new Error(
        '<hrb-accordion-item /> : `preview-text` can only be used with accordion type of `content`',
      )
    }
  }

  render(): JSX.Element {
    const { innerHeight, isExpanded, previewHeight } = this.state
    const {
      accordionId,
      accordionToggledHandler,
      disabled,
      headerText,
      isContent,
      previewText,
      subnavHeaderStyle,
    } = this

    const collapsedHeight = isContent() ? previewHeight : 0
    const containerHeight = isExpanded ? innerHeight : collapsedHeight

    // const buttonID = `${accordionId}-accordion-button`

    const buttonID = `${
      this.el.id !== ''
        ? `${this.el.id}-accordion-button`
        : `${accordionId}-accordion-button`
    }`

    // const contentID = `${accordionId}-accordion-content`

    const contentID = `${
      this.el.id !== ''
        ? `${this.el.id}-accordion-content`
        : `${accordionId}-accordion-content`
    }`

    const classes = getClassnames([
      isExpanded ? `${Constants.baseClassname}--open` : '',
      this.disabled ? `${Constants.baseClassname}--disable` : '',
    ])

    return (
      <Host class={classes}>
        <this.headerAs
          class={`${Constants.baseClassname}__header ${
            !isContent()
              ? `${Constants.baseClassname}__header--${subnavHeaderStyle}`
              : ''
          }`}
        >
          <button
            aria-controls={contentID}
            aria-expanded={isExpanded.toString()}
            aria-disabled={disabled.toString()}
            disabled={disabled}
            id={buttonID}
            onClick={accordionToggledHandler}
            class={`${Constants.baseClassname}__button`}
          >
            <span class={`${Constants.baseClassname}__button-inner`}>
              {headerText}

              <hrb-circled
                size="small"
                theme={isContent() ? 'light-grey-1' : null}
              >
                <hrb-icon
                  name="chevron-down"
                  class={`${Constants.baseClassname}__icon`}
                ></hrb-icon>
                <hrb-icon
                  name="chevron-up"
                  class={`${Constants.baseClassname}__icon`}
                ></hrb-icon>
              </hrb-circled>
            </span>

            {previewText && isContent() && (
              <span
                class={`${Constants.baseClassname}__preview`}
                ref={(el: HTMLElement): void => {
                  this.previewElement = el
                }}
              >
                {previewText}
              </span>
            )}
          </button>
        </this.headerAs>

        <div
          aria-hidden={(!isExpanded).toString()}
          aria-labelledby={buttonID}
          class={`${Constants.baseClassname}__content`}
          id={contentID}
          role="region"
          style={{ maxHeight: `${containerHeight}px` }}
        >
          <div
            ref={(el: HTMLElement): void => {
              this.innerElement = el
            }}
          >
            <slot></slot>
          </div>
        </div>
      </Host>
    )
  }
}
