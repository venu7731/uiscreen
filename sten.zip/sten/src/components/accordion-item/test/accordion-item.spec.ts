import { newSpecPage } from '@stencil/core/testing'

import { HrbAccordionItem } from '../accordion-item'

describe('Accordion Item', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbAccordionItem],
      html: `
        <hrb-accordion-item header-as="h1" header-text="Open Accordion Now" id="my-item">
          <a href="/">A link</a>
          <p class="hrb-text--body-copy hrb-color--blue">
            Morbi consectetur purus mollis efficitur elementum. Suspendisse at
            neque augue. Nulla facilisi. Donec suscipit est a mauris rhoncus
            euismod. Quisque leo sapien, dapibus ut erat a, gravida commodo leo.
            Proin in pellentesque diam, a scelerisque velit. Ut molestie elit eget
            diam sollicitudin luctus.
          </p>
          <p class="hrb-text--body-copy hrb-color--blue">
            In egestas metus tellus, id blandit diam viverra pretium. Sed leo
            risus, fermentum ac luctus ac, malesuada quis odio. Nam sagittis
            efficitur ante, et volutpat arcu sodales pharetra. Vestibulum ante
            ipsum primis in faucibus orci luctus et ultrices posuere cubilia
            Curae; Aliquam erat volutpat. In vel dictum diam, at eleifend tellus.
            Aliquam ullamcorper, urna in bibendum fringilla, lectus lacus semper
            sapien, in sollicitudin nibh purus vitae ex.
          </p>
        </hrb-accordion-item>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-accordion-item header-as="h1" header-text="Open Accordion Now" id="my-item">
      <h1 class="hbr-accordion-item__header">
        <button aria-controls="my-item-accordion-content" aria-disabled="false" aria-expanded="false" class="hbr-accordion-item__button" id="my-item-accordion-button">
          <span class="hbr-accordion-item__button-inner">
            Open Accordion Now
            <hrb-circled size="small" theme="light-grey-1">
              <hrb-icon class="hbr-accordion-item__icon" name="chevron-down"></hrb-icon>
              <hrb-icon class="hbr-accordion-item__icon" name="chevron-up"></hrb-icon>
            </hrb-circled>
          </span>
        </button>
      </h1>
      <div aria-hidden="true" aria-labelledby="my-item-accordion-button" class="hbr-accordion-item__content" id="my-item-accordion-content" role="region" style="max-height: 0px;">
        <div>
          <a href="/">
            A link
          </a>
          <p class="hrb-color--blue hrb-text--body-copy">
            Morbi consectetur purus mollis efficitur elementum. Suspendisse at neque augue. Nulla facilisi. Donec suscipit est a mauris rhoncus euismod. Quisque leo sapien, dapibus ut erat a, gravida commodo leo. Proin in pellentesque diam, a scelerisque velit. Ut molestie elit eget diam sollicitudin luctus.
          </p>
          <p class="hrb-color--blue hrb-text--body-copy">
            In egestas metus tellus, id blandit diam viverra pretium. Sed leo risus, fermentum ac luctus ac, malesuada quis odio. Nam sagittis efficitur ante, et volutpat arcu sodales pharetra. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aliquam erat volutpat. In vel dictum diam, at eleifend tellus. Aliquam ullamcorper, urna in bibendum fringilla, lectus lacus semper sapien, in sollicitudin nibh purus vitae ex.
          </p>
        </div>
      </div>
    </hrb-accordion-item>
    `)
  })
})
