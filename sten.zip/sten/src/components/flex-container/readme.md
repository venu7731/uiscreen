# grid-row

## Examples

```html
<grid-row>
  <!-- rest of the grid -->
</grid-row>
```

<!-- Auto Generated Below -->


## Properties

| Property     | Attribute      | Description | Type     | Default     |
| ------------ | -------------- | ----------- | -------- | ----------- |
| `pAriaLabel` | `p-aria-label` |             | `string` | `undefined` |


## Dependencies

### Used by

 - [hrb-flex-ghost](../flex-ghost)

### Graph
```mermaid
graph TD;
  hrb-flex-ghost --> hrb-flex-container
  style hrb-flex-container fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
