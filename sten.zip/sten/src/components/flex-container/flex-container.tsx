import { Component, h, Host, Prop } from '@stencil/core'

@Component({
  tag: 'hrb-flex-container',
  styleUrl: 'flex-container.scss',
})
export class HrbFlexContainer {
  @Prop() pAriaLabel: string

  render(): JSX.Element {
    return (
      <Host aria-label={this.pAriaLabel} class="hrb-flex-container">
        <slot />
      </Host>
    )
  }
}
