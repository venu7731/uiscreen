export type TListTypes = 'li' | ''
