# hrb-overflow-item

<!-- Auto Generated Below -->


## Properties

| Property          | Attribute           | Description                                                  | Type                        | Default                    |
| ----------------- | ------------------- | ------------------------------------------------------------ | --------------------------- | -------------------------- |
| `as`              | `as`                | Sets tag for link (defaults to <a />)                        | `"a" \| "button" \| "span"` | `'button'`                 |
| `disabled`        | `disabled`          | Sets link to disabled                                        | `boolean`                   | `false`                    |
| `href`            | `href`              | Applies href attribute                                       | `string`                    | `undefined`                |
| `icon`            | `icon`              | Icon: This will add an icon to the left of the overflow item | `string`                    | `''`                       |
| `label`           | `label`             | The visible text of the overflow item                        | `string`                    | `''`                       |
| `pAriaLabel`      | `p-aria-label`      | Applies `aria-label` to link                                 | `string`                    | `undefined`                |
| `pAriaLabelledby` | `p-aria-labelledby` | Applies `aria-labelledby` to link                            | `string`                    | `undefined`                |
| `pAriaRole`       | `p-aria-role`       | Applies `aria-role` to link                                  | `string`                    | `undefined`                |
| `rel`             | `rel`               | Applies optional rel attribute                               | `string`                    | `undefined`                |
| `target`          | `target`            | Applies optional target attribute                            | `string`                    | `undefined`                |
| `theme`           | `theme`             | Applies color theme (defaults to dark green)                 | `"" \| ThemeConstants`      | `ThemeConstants.darkGreen` |
| `type`            | `type`              | Applies type attribute                                       | `string`                    | `undefined`                |


## Dependencies

### Depends on

- [hrb-link](../link)
- [hrb-icon](../icon)

### Graph
```mermaid
graph TD;
  hrb-overflow-item --> hrb-link
  hrb-overflow-item --> hrb-icon
  hrb-link --> hrb-icon
  style hrb-overflow-item fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
