import { newSpecPage } from '@stencil/core/testing'

import { OverflowItem } from '../overflow-item'

describe('OverflowItem', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [OverflowItem],
      html: `
      <hrb-overflow-item as="button" label="Item One" action="https://www.gog.com"></hrb-overflow-item>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-overflow-item action="https://www.gog.com" as="button" class="overflow-item" label="Item One">
      <hrb-link as="button" class="overflow-link" theme="dark-green">
        Item One
      </hrb-link>
    </hrb-overflow-item>
    `)
  })
})
