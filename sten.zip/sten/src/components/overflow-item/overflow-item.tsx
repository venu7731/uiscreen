import { Component, Host, h, Prop } from '@stencil/core'

import { ThemeConstants, TLinkThemes, TLinkTypes } from '../link/types'

@Component({
  tag: 'hrb-overflow-item',
  styleUrl: 'overflow-item.scss',
})
export class OverflowItem {
  /**
   * The visible text of the overflow item
   */
  @Prop() label = ''

  /**
   * Icon: This will add an icon to the left of the overflow item
   */

  @Prop() icon = ''

  /**
   * Applies `aria-label` to link
   */
  @Prop({ attribute: 'p-aria-label' }) pAriaLabel: string

  /**
   * Applies `aria-labelledby` to link
   */
  @Prop({ attribute: 'p-aria-labelledby' }) pAriaLabelledby: string

  /**
   * Applies `aria-role` to link
   */
  @Prop({ attribute: 'p-aria-role' }) pAriaRole: string

  /**
   * Sets tag for link (defaults to <a />)
   */
  @Prop() as: TLinkTypes = 'button'

  /**
   * Applies optional target attribute
   */
  @Prop() target: string

  /**
   * Applies optional rel attribute
   */
  @Prop() rel: string

  /**
   * Applies href attribute
   */
  @Prop() href: string

  /**
   * Sets link to disabled
   */
  @Prop() disabled = false

  /**
   * Applies type attribute
   */
  @Prop() type: string

  /**
   * Applies color theme (defaults to dark green)
   */
  @Prop() theme: TLinkThemes = ThemeConstants.darkGreen

  render(): JSX.Element {
    return (
      <Host class="overflow-item">
        <hrb-link
          class="overflow-link"
          as={this.as}
          rel={this.rel}
          pAriaLabel={this.pAriaLabel}
          pAriaLabelledby={this.pAriaLabelledby}
          pAriaRole={this.pAriaRole}
          target={this.target}
          disabled={this.disabled}
          type={this.type}
          theme={this.theme}
        >
          {this.icon !== '' && (
            <hrb-icon class="overflow-icon" name={this.icon}></hrb-icon>
          )}
          {this.label}
        </hrb-link>
      </Host>
    )
  }
}
