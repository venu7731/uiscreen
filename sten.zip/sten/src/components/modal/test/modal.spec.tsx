import { newSpecPage } from '@stencil/core/testing'

import { HrbModal } from '../modal'

describe('HrbModal', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbModal],
      html: `
      <hrb-modal modal-id="medium-modal"
    type='medium'
    theme="blue">
    <div style="margin-bottom: 40px;"
      slot="hrb-modal-header">
      <hrb-text as='span'
        style-type='little'>More about</hrb-text>
      <hrb-text style-type="medium"
        as="h2"
        class="modal__title">
        California State disability insurance contributions (CASDI / CAVPDI)
      </hrb-text>
    </div>

    <div class="divider hrb-background-color--light-grey-1"></div>

    <hrb-text as='p'
      style-type='body-copy'>
      Etiam porta sem malesuada magna mollis euismod. Donec ullamcorper nulla non metus auctor fringilla. Morbi leo
      risus,
      porta ac consectetur ac, vestibulum at eros. Curabitur blandit tempus porttitor. Sed posuere consectetur est at
      lobortis. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean lacinia
      bibendum
      nulla sed consectetur.
    </hrb-text>

    <hrb-text as='p'
      style-type='body-copy'>
      Cras mattis consectetur purus sit amet fermentum. Praesent commodo cursus magna, vel scelerisque nisl consectetur
      et.
      Aenean lacinia bibendum nulla sed consectetur. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis
      vestibulum. Donec ullamcorper nulla non metus auctor fringilla.
    </hrb-text>
  </hrb-modal>
    `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-modal modal-id="medium-modal" theme="blue" type="medium">
      <div aria-hidden="true" class="hrb-modal hrb-modal--blue hrb-modal--medium" id="medium-modal">
        <div class="hrb-modal__overlay" data-micromodal-close tabindex="-1">
          <div class="hrb-modal__scroll-container" data-micromodal-close>
            <main aria-labelledby="medium-modal-title" aria-modal="true" class="hrb-modal__main" role="dialog">
              <hrb-circle-button class="hrb-modal__close-button" p-aria-label="Close Modal" size="small">
                <hrb-icon name="close"></hrb-icon>
              </hrb-circle-button>
              <div class="hrb-modal__content" id="medium-modal-content">
                <header class="hrb-modal__header" id="medium-modal-title">
                  <div slot="hrb-modal-header" style="margin-bottom: 40px;">
                    <hrb-text as="span" style-type="little">
                      More about
                    </hrb-text>
                    <hrb-text as="h2" class="modal__title" style-type="medium">
                      California State disability insurance contributions (CASDI / CAVPDI)
                    </hrb-text>
                  </div>
                </header>
                <div class="divider hrb-background-color--light-grey-1"></div>
                <hrb-text as="p" style-type="body-copy">
                  Etiam porta sem malesuada magna mollis euismod. Donec ullamcorper nulla non metus auctor fringilla. Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Curabitur blandit tempus porttitor. Sed posuere consectetur est at lobortis. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean lacinia bibendum nulla sed consectetur.
                </hrb-text>
                <hrb-text as="p" style-type="body-copy">
                  Cras mattis consectetur purus sit amet fermentum. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Aenean lacinia bibendum nulla sed consectetur. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Donec ullamcorper nulla non metus auctor fringilla.
                </hrb-text>
              </div>
            </main>
          </div>
        </div>
      </div>
    </hrb-modal>
    `)
  })
})
