import { storiesOf } from '@storybook/html'
import { select, withKnobs } from '@storybook/addon-knobs'
import { useEffect } from '@storybook/client-api'

import { modalThemes, modalTypes, reset } from '@src/constants/storybook'

import * as readme from './readme.md'

/* eslint-disable-next-line */
const openButton = () => `
<hrb-button id="open-button">Open Modal</hrb-button>
`
/* eslint-disable-next-line */
const modal = (theme, type) => `
 <hrb-modal id="modal-element" theme="${theme}" type="${type}">
    <hrb-text style-type="medium" as="h2" class="modal__title" slot="hrb-modal-header">
      Are you sure you want to exit?
    </hrb-text>

    <div style="margin-top: 30px">
      <hrb-text>Your changes won't be saved.</hrb-text>

      <hrb-text as='p' style-type='body-copy'>
        Etiam porta sem malesuada magna mollis euismod. Donec ullamcorper nulla non metus auctor fringilla. Morbi leo
        risus,
        porta ac consectetur ac, vestibulum at eros. Curabitur blandit tempus porttitor. Sed posuere consectetur est at
        lobortis. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean lacinia
        bibendum
        nulla sed consectetur.
      </hrb-text>

      <hrb-text as='p' style-type='body-copy'>
        Cras mattis consectetur purus sit amet fermentum. Praesent commodo cursus magna, vel scelerisque nisl consectetur
        et.
        Aenean lacinia bibendum nulla sed consectetur. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis
        vestibulum. Donec ullamcorper nulla non metus auctor fringilla.
      </hrb-text>
    </div>

  </hrb-modal>
`

const wrapperOpen = `${reset}<div style="padding: 30px">`
const wrapperClose = `</div>`

storiesOf('Modal', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-modal'],
    notes: { markdown: readme },
  })
  .add('Modal styles', () => {
    useEffect(() => {
      const modalElement = document.querySelector('#modal-element')
      const button = document.querySelector('#open-button')

      button.addEventListener('click', () => {
        /* eslint-disable-next-line */
        // @ts-ignore
        modalElement.show()
      })
    })
    return `${wrapperOpen}

      ${openButton()}
      ${modal(
        select('Theme', modalThemes, modalThemes[0]),
        select('Type', modalTypes, modalTypes[0]),
      )}

      ${wrapperClose}`
  })
