import {
  Component,
  Element,
  Event,
  EventEmitter,
  h,
  Method,
  Prop,
} from '@stencil/core'
import MicroModal from 'micromodal'

import { generateSimpleID, getClassnames } from '@src/utils/misc'

import { TModalThemes, TModalTypes } from './types'

const Constants = {
  baseClassname: 'hrb-modal',
  themesMap: {
    'light-blue': 'medium-light-blue',
    'light-green': 'medium-light-green',
    'light-yellow': 'medium-light-yellow',
    blue: 'medium-dark-blue',
    green: 'medium-dark-green',
    grey: 'light-grey-2',
    white: 'light-grey-1',
    yellow: 'medium-dark-yellow',
  },
}

interface MicroModalConfig {
  awaitCloseAnimation: boolean
  onClose: () => CustomEvent
  onShow: () => CustomEvent
}

@Component({
  tag: 'hrb-modal',
  styleUrl: 'modal.scss',
})
export class HrbModal {
  /**
   * Adds an ID to the components (defaults to randomly generated ID)
   */
  @Prop() modalId: string = generateSimpleID()

  /**
   * Sets modal to small, medium or large variety (defaults to small)
   */
  @Prop() type: TModalTypes = 'small'

  /**
   * Applies color theme (defaults to 'white')
   */
  @Prop() theme: TModalThemes = 'white'

  /**
   * Background Closes configures if tapping/clicking the background closes the modal
   */
  @Prop() disableBackground = false

  @Element() el: HTMLElement

  @Event() hrbClose: EventEmitter

  @Event() hrbOpen: EventEmitter

  // MicroModal accepts an optional configuration object. For more information visit the library's
  // documentation https://micromodal.now.sh/#configuration
  getConfig = (): MicroModalConfig => ({
    awaitCloseAnimation: true,
    onClose: (): CustomEvent => this.hrbClose.emit(this),
    onShow: (): CustomEvent => this.hrbOpen.emit(this),
  })

  handleClose = (): void => MicroModal.close(this.modalId)

  private containerAriaLabel = `${this.modalId}-title`

  private isLarge = this.type === 'large'

  private noClose = this.isLarge || this.disableBackground

  private hasHeader = !!this.el.querySelector('[slot="hrb-modal-header"]')

  @Method()
  async close(): Promise<void> {
    this.handleClose()
  }

  @Method()
  async show(): Promise<void> {
    MicroModal.show(this.modalId, this.getConfig())
  }

  componentDidRender(): void {
    const { getConfig } = this
    MicroModal.init(getConfig())
  }

  renderCloseButton = (closeButtonSize, handleClose): JSX.Element => (
    <hrb-circle-button
      class={`${Constants.baseClassname}__close-button`}
      onClick={handleClose}
      p-aria-label="Close Modal"
      size={closeButtonSize}
    >
      <hrb-icon name="close"></hrb-icon>
    </hrb-circle-button>
  )

  render(): JSX.Element {
    const {
      containerAriaLabel,
      handleClose,
      noClose,
      hasHeader,
      isLarge,
      modalId,
      renderCloseButton,
      theme,
      type,
    } = this
    const closeButtonSize = isLarge ? 'medium' : 'small'

    const modalClass = getClassnames([
      `${Constants.baseClassname}`,
      `${Constants.baseClassname}--${type}`,
      !hasHeader && `${Constants.baseClassname}--no-header`,
      !!theme && `${Constants.baseClassname}--${theme}`,
    ])

    return (
      <div class={modalClass} id={modalId} aria-hidden="true">
        <div
          class={`${Constants.baseClassname}__overlay`}
          tabindex="-1"
          data-micromodal-close={!noClose}
        >
          <div
            class={`${Constants.baseClassname}__scroll-container`}
            data-micromodal-close={!noClose}
          >
            {isLarge && renderCloseButton(closeButtonSize, handleClose)}

            <main
              aria-labelledby={containerAriaLabel}
              aria-modal="true"
              class={`${Constants.baseClassname}__main`}
              role="dialog"
            >
              {!isLarge && renderCloseButton(closeButtonSize, handleClose)}

              <div
                id={`${modalId}-content`}
                class={`${Constants.baseClassname}__content`}
              >
                {hasHeader && (
                  <header
                    class={`${Constants.baseClassname}__header`}
                    id={containerAriaLabel}
                  >
                    <slot name="hrb-modal-header"></slot>
                  </header>
                )}
                <slot></slot>
              </div>
            </main>
          </div>
        </div>
      </div>
    )
  }
}
