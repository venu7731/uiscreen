# hrb-modal

The `hrb-modal` component displays its contents in a modal interface. The modal appears on top of any content of the current page. It's a styled container (depending of the current theme/type) with a close button already implemented.

The modal requires an element with a title to be passed with the `slot="hrb-modal-header"` prop. This allows the component to wrap the element with a `header` parent element and applies spacing style rules and identifies it as the modal's header for accessibility.

It can be one of three different modes which can be set via the `type` prop. Additionally, the `theme` prop can be used to apply different themes.

```html
<hrb-modal type="large" theme="green">
  <div slot="hrb-modal-header">
    <!-- header content -->
  </div>

  <!-- content -->
</hrb-modal>
```

📝 Note: It's built on to the MicroModal library. Please visit the library's documentation for learn more about it https://micromodal.now.sh.

---

A `hrb-modal` element can be bound directly to a button element to be opened on click without having to manually listen to the button element click event.

Add `data-micromodal-trigger="id-of-the-modal"` on the button that opens of the modal, and `modal-id="id-of-the-modal"` on the `hrb-modal` component.

```html
<hrb-button data-micromodal-trigger="small-modal">Show Small Modal</hrb-button>

<hrb-modal modal-id="small-modal">
  <div slot="hrb-modal-header">
    <!-- header content -->
  </div>

  <!-- content -->
</hrb-modal>
```

## Event Examples

A `hrb-modal` component exposes a few custom events:

```js
const modal = form.querySelector('hrb-modal')

// When the modal opens
modal.addEventListener('hrbOpen', e => {
  console.log('Modal opened')
})

// When the modal closes
modal.addEventListener('hrbClose', e => {
  console.log('Modal closed')
})
```

## Method Examples

You can programatically close or open a modal. Every exposed methods return a `Promise`.

```html
<hrb-modal id="small-modal">
  <header modal-title>
    <hrb-text style-type="medium" as="h2">
      Are you sure you want to exit?
    </hrb-text>
  </header>

  <!-- This button is part of the content modal -->
  <hrb-button class="programmatic-close" p-aria-label="Close modal"
    >Exit</hrb-button
  >
</hrb-modal>

<script>
  const closeButtons = document.querySelectorAll('.programmatic-close')
  const smallModal = document.querySelector('#small-modal')

  closeButtons.forEach(button => {
    button.addEventListener('click', async () => {
      await smallModal.close()
    })
  })

  // Opens the modal
  await smallModal.open()
</script>
```

<!-- Auto Generated Below -->


## Properties

| Property            | Attribute            | Description                                                                      | Type                                                                                          | Default              |
| ------------------- | -------------------- | -------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------- | -------------------- |
| `disableBackground` | `disable-background` | Background Closes configures if tapping/clicking the background closes the modal | `boolean`                                                                                     | `false`              |
| `modalId`           | `modal-id`           | Adds an ID to the components (defaults to randomly generated ID)                 | `string`                                                                                      | `generateSimpleID()` |
| `theme`             | `theme`              | Applies color theme (defaults to 'white')                                        | `"blue" \| "green" \| "light-blue" \| "light-green" \| "light-yellow" \| "white" \| "yellow"` | `'white'`            |
| `type`              | `type`               | Sets modal to small, medium or large variety (defaults to small)                 | `"large" \| "medium" \| "small"`                                                              | `'small'`            |


## Events

| Event      | Description | Type               |
| ---------- | ----------- | ------------------ |
| `hrbClose` |             | `CustomEvent<any>` |
| `hrbOpen`  |             | `CustomEvent<any>` |


## Methods

### `close() => Promise<void>`



#### Returns

Type: `Promise<void>`



### `show() => Promise<void>`



#### Returns

Type: `Promise<void>`




## Dependencies

### Depends on

- [hrb-circle-button](../buttons/circle-button)
- [hrb-icon](../icon)

### Graph
```mermaid
graph TD;
  hrb-modal --> hrb-circle-button
  hrb-modal --> hrb-icon
  hrb-circle-button --> hrb-circled
  style hrb-modal fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
