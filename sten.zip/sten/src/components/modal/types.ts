export { TCircleButtonThemes } from '../buttons/circle-button/types'

export type TModalThemes =
  | 'blue'
  | 'green'
  | 'light-blue'
  | 'light-green'
  | 'light-yellow'
  | 'white'
  | 'yellow'

export type TModalTypes = 'small' | 'medium' | 'large'
