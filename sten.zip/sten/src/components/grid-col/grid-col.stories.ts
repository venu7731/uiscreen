import { boolean, number, text, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import { groupIds, reset } from '@src/constants/storybook'

import * as readme from './readme.md'

const slot =
  '<img src="https://via.placeholder.com/1200x1200/fcee0a" alt="Missing Placeholder Image">'

/* eslint-disable-next-line */
const gridCol = (
  defaultSpanValue,
  smallSpanValue,
  mediumSpanValue,
  largeSpanValue,
  defaultRowValue,
  smallRowValue,
  mediumRowValue,
  largeRowValue,
  isGrid,
) =>
  `<hrb-grid-col 
    col-span="${defaultSpanValue}"
    col-span-s="${smallSpanValue}"
    col-span-m="${mediumSpanValue}"
    col-span-l="${largeSpanValue}"
    row="${defaultRowValue}"
    row-s="${smallRowValue}"
    row-m="${mediumRowValue}"
    row-l="${largeRowValue}"
    ${isGrid ? 'is-grid' : ''}>
    ${slot}
  </hrb-grid-col>`

const wrapperOpen = `${reset}<hrb-grid-row>`
const wrapperClose = `</hrb-grid-row>`

storiesOf('Layouts/Grid-Layouts', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-grid-col'],
    notes: { markdown: readme },
  })
  .add('Grid Columns', () => {
    return `${wrapperOpen}

    ${gridCol(
      text('Column Span', '2/17', groupIds.default),
      text('Column Span', '2/17', groupIds.small),
      text('Column Span', '2/17', groupIds.medium),
      text('Column Span', '2/35', groupIds.large),
      number('Number of Rows', 1, {}, groupIds.default),
      number('Number of Rows', 1, {}, groupIds.small),
      number('Number of Rows', 1, {}, groupIds.medium),
      number('Number of Rows', 1, {}, groupIds.large),
      boolean('Is Grid', false, groupIds.default),
    )}

    ${wrapperClose}`
  })
