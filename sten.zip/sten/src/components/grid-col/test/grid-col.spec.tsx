import { newSpecPage } from '@stencil/core/testing'

import { GridCol } from '../grid-col'

describe('GridCol', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [GridCol],
      html: `
      <hrb-grid-col row="1" row-s="1" row-m="1" row-l="1" col-span="2/17" col-span-m="2/6" col-span-l="2/12">
        <hrb-img src="https://picsum.photos/1400/800" alt="some alt text" height="400" width="700"></hrb-img>
        <hrb-text>2x sample without srcset and with lazy load</hrb-text>
      </hrb-grid-col>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-grid-col class="hrb-grid-col hrb-grid-col-end-17 hrb-grid-col-end-l-12 hrb-grid-col-end-m-6 hrb-grid-col-row-1 hrb-grid-col-row-l-1 hrb-grid-col-row-m-1 hrb-grid-col-row-s-1 hrb-grid-col-span-15 hrb-grid-col-span-l-10 hrb-grid-col-span-m-4 hrb-grid-col-start-2 hrb-grid-col-start-l-2 hrb-grid-col-start-m-2" col-span="2/17" col-span-l="2/12" col-span-m="2/6" row="1" row-l="1" row-m="1" row-s="1">
      <hrb-img alt="some alt text" height="400" src="https://picsum.photos/1400/800" width="700"></hrb-img>
      <hrb-text>
        2x sample without srcset and with lazy load
      </hrb-text>
    </hrb-grid-col>
    `)
  })
})
