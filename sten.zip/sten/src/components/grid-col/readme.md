# hrb-grid-col

<!-- Auto Generated Below -->


## Properties

| Property   | Attribute    | Description                                                                           | Type      | Default     |
| ---------- | ------------ | ------------------------------------------------------------------------------------- | --------- | ----------- |
| `colSpan`  | `col-span`   | Col span - Default size.                                                              | `string`  | `undefined` |
| `colSpanL` | `col-span-l` | Col span - Large size.                                                                | `string`  | `undefined` |
| `colSpanM` | `col-span-m` | Col span - Medium size.                                                               | `string`  | `undefined` |
| `colSpanS` | `col-span-s` | Col span - Small size.                                                                | `string`  | `undefined` |
| `isGrid`   | `is-grid`    | Set to `true` if this column will hold a child column. Allows for nested grid layout. | `boolean` | `false`     |
| `row`      | `row`        | Col row - Default size.                                                               | `string`  | `undefined` |
| `rowL`     | `row-l`      | Col row - Large size.                                                                 | `string`  | `undefined` |
| `rowM`     | `row-m`      | Col row - Medium size.                                                                | `string`  | `undefined` |
| `rowS`     | `row-s`      | Col row - Small size.                                                                 | `string`  | `undefined` |


## Dependencies

### Used by

 - [hrb-grid-ghost](../grid-ghost)

### Graph
```mermaid
graph TD;
  hrb-grid-ghost --> hrb-grid-col
  style hrb-grid-col fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
