import { Component, Prop, h, Host } from '@stencil/core'

import { getClassnames } from '@src/utils/misc'
import { numberSlashNumber } from '@src/utils/regex'

const Constants = {
  baseClassname: 'hrb-grid-col',
  classnameTypes: ['start', 'end', 'span'],
}

@Component({
  tag: 'hrb-grid-col',
  styleUrl: 'grid-col.scss',
})
export class GridCol {
  /**
   * Col span - Default size.
   */
  @Prop({ attribute: 'col-span' }) colSpan: string

  /**
   * Col span - Small size.
   */
  @Prop({ attribute: 'col-span-s' }) colSpanS: string

  /**
   * Col span - Medium size.
   */
  @Prop({ attribute: 'col-span-m' }) colSpanM: string

  /**
   * Col span - Large size.
   */
  @Prop({ attribute: 'col-span-l' }) colSpanL: string

  /**
   * Col row - Default size.
   */
  @Prop({ attribute: 'row' }) row: string

  /**
   * Col row - Small size.
   */
  @Prop({ attribute: 'row-s' }) rowS: string

  /**
   * Col row - Medium size.
   */
  @Prop({ attribute: 'row-m' }) rowM: string

  /**
   * Col row - Large size.
   */
  @Prop({ attribute: 'row-l' }) rowL: string

  /**
   * Set to `true` if this column will hold a child column. Allows for nested grid layout.
   */
  @Prop({ attribute: 'is-grid' }) isGrid = false

  componentWillLoad(): void {
    this.validateColSpan()
  }

  validateColSpan = (): void => {
    const colSpans = [
      this.colSpan,
      this.colSpanS,
      this.colSpanM,
      this.colSpanL,
    ].filter(colSpan => !!colSpan)

    colSpans.forEach(colSpan => {
      const isValid = numberSlashNumber.test(colSpan)

      if (!isValid) {
        // eslint-disable-next-line no-console
        console.error(
          `<grid-col /> : "${colSpan}" is not a valid value. Expected format: int/int`,
        )
      }
    })
  }

  getColSpanUnits = (colSpan: string): { colStart: number; colEnd: number } => {
    const [colStart, colEnd] = colSpan.split('/')

    return { colStart: parseInt(colStart, 10), colEnd: parseInt(colEnd, 10) }
  }

  getColClassnameStrings = (
    colStart: number,
    colEnd: number,
    colSpan: number,
    size?: string,
  ): string[] => {
    const { classnameTypes } = Constants
    const eachValues = [colStart, colEnd, colSpan]

    return eachValues.map((value: number, index: number): string => {
      const sizeValue = size ? `${size}-` : ''

      return `${Constants.baseClassname}-${classnameTypes[index]}-${sizeValue}${value}`
    })
  }

  getColClassnames = (): string => {
    const colSpanValues = {
      colSpan: {
        value: this.colSpan,
        size: 'd',
      },
      colSpanS: {
        value: this.colSpanS,
        size: 's',
      },
      colSpanM: {
        value: this.colSpanM,
        size: 'm',
      },
      colSpanL: {
        value: this.colSpanL,
        size: 'l',
      },
    }

    const classnames = Object.keys(colSpanValues)
      .map((colSpanKey: string): string => {
        const { size, value } = colSpanValues[colSpanKey]

        if (!value) return null

        const { colStart, colEnd } = this.getColSpanUnits(value)
        const colSpan = colEnd - colStart
        const classNameSize = size !== 'd' ? size : ''

        const classnamesArray = this.getColClassnameStrings(
          colStart,
          colEnd,
          colSpan,
          classNameSize,
        )

        return classnamesArray.join(' ')
      })
      .join(' ')

    return classnames
  }

  getRowClassnames = (): string => {
    const { row, rowS, rowM, rowL } = this
    const rowClasses = getClassnames([
      row && `${Constants.baseClassname}-row-${row}`,
      rowS && `${Constants.baseClassname}-row-s-${rowS}`,
      rowM && `${Constants.baseClassname}-row-m-${rowM}`,
      rowL && `${Constants.baseClassname}-row-l-${rowL}`,
    ])

    return rowClasses
  }

  render(): JSX.Element {
    const colClassname = this.isGrid
      ? `${Constants.baseClassname}--is-grid`
      : Constants.baseClassname

    const classnames = `${colClassname} ${this.getColClassnames()} ${this.getRowClassnames()}`

    return (
      <Host class={classnames}>
        <slot />
      </Host>
    )
  }
}
