export enum ThemeConstants {
  darkGreen = 'dark-green',
  darkGrey = 'dark-grey',
  primaryBlack = 'primary-black',
  white = 'white',
  primaryButton = 'primary-button',
  primaryButtonSmall = 'primary-button-small',
  primaryButtonMedium = 'primary-button-medium',
  primaryButtonLarge = 'primary-button-large',
  primaryButtonLight = 'primary-button-light',
  primaryButtonLightSmall = 'primary-button-light-small',
  primaryButtonLightMedium = 'primary-button-light-medium',
  primaryButtonLightLarge = 'primary-button-light-large',
  secondaryButton = 'secondary-button',
  secondaryButtonSmall = 'secondary-button-small',
  secondaryButtonMedium = 'secondary-button-medium',
  secondaryButtonLarge = 'secondary-button-large',
  secondaryButtonLight = 'secondary-button-light',
  secondaryButtonLightSmall = 'secondary-button-light-small',
  secondaryButtonLightMedium = 'secondary-button-light-medium',
  secondaryButtonLightLarge = 'secondary-button-light-large',
}

export type TLinkThemes =
  | ''
  | ThemeConstants.darkGreen
  | ThemeConstants.darkGrey
  | ThemeConstants.primaryBlack
  | ThemeConstants.white
  | ThemeConstants.primaryButton
  | ThemeConstants.primaryButtonSmall
  | ThemeConstants.primaryButtonMedium
  | ThemeConstants.primaryButtonLarge
  | ThemeConstants.primaryButtonLight
  | ThemeConstants.primaryButtonLightSmall
  | ThemeConstants.primaryButtonLightMedium
  | ThemeConstants.primaryButtonLightLarge
  | ThemeConstants.secondaryButton
  | ThemeConstants.secondaryButtonSmall
  | ThemeConstants.secondaryButtonMedium
  | ThemeConstants.secondaryButtonLarge
  | ThemeConstants.secondaryButtonLight
  | ThemeConstants.secondaryButtonLightSmall
  | ThemeConstants.secondaryButtonLightMedium
  | ThemeConstants.secondaryButtonLightLarge

export type TLinkTypes = 'a' | 'button' | 'span'
