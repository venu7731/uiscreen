import { newSpecPage } from '@stencil/core/testing'

import { Link } from '../link'

describe('Link', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [Link],
      html: `
      <hrb-link theme="primary-black"
      as="button"
      href="https://www.b&h.com">Primary Black Link as Button</hrb-link>
    `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-link as="button" class="hrb-link hrb-link--is-button hrb-link--primary-black" href="https://www.b&amp;h.com" theme="primary-black">
      <button>
        <span class="link-text">
          Primary Black Link as Button
        </span>
      </button>
    </hrb-link>
    `)
  })
})
