import * as readme from './readme.md'

export default {
  component: 'hrb-link',
  title: 'Links',
  parameters: {
    notes: { markdown: readme },
  },
}

export const Link = (): string =>
  `
  <hrb-global reset></hrb-global>
  <hrb-link>Link</hrb-link>
  `
export const LinkThemesDefault = (): string =>
  `
  <hrb-link>Link</hrb-link>
  `
export const LinkThemesDarkGreen = (): string =>
  `
   <hrb-link theme="dark-green">Link</hrb-link>
  `
export const LinkThemesDarkGrey = (): string =>
  `
  <hrb-link theme="dark-grey">Link</hrb-link>
  `
export const LinkThemesPrimaryBlack = (): string =>
  `
  <hrb-link theme="primary-black">Link</hrb-link>
  `
export const LinkThemesWhite = (): string =>
  `
  <div class="hrb-background-color--ui-green p-sp-8">
    <hrb-link theme="white">Link</hrb-link>
  </div>
  `
export const LinkIcons = (): string =>
  `
  <hrb-link icon="chevron-right">Link</hrb-link>
  `
export const LinkNoUnderline = (): string =>
  `
  <hrb-link underline=false>Link</hrb-link>
  `
export const LinkAsPrimaryButton = (): string =>
  `
  <hrb-link theme="primary-button">Link</hrb-link>
  `
export const LinkAsPrimaryButtonLight = (): string =>
  `
  <div class="hrb-background-color--ui-green p-sp-8">
    <hrb-link theme="primary-button-light">Link</hrb-link>
  </div>
  `
export const LinkAsSecondaryButton = (): string =>
  `
  <hrb-link theme="secondary-button">Link</hrb-link>
  `
export const LinkAsSecondaryButtonLight = (): string =>
  `
  <div class="hrb-background-color--ui-green p-sp-8">
    <hrb-link theme="secondary-button-light">Link</hrb-link>
  </div>
  `
export const LinkAsButtonSmall = (): string =>
  `
  <hrb-link theme="primary-button-small">Link</hrb-link>
  `
export const LinkAsButtonMedium = (): string =>
  `
  <hrb-link theme="primary-button-medium">Link</hrb-link>
  `
export const LinkAsButtonLarge = (): string =>
  `
  <hrb-link theme="primary-button-large">Link</hrb-link>
  `
export const LinkAsButtonFullWidth = (): string =>
  `
  <hrb-link theme="primary-button" full-width>Link</hrb-link>
  `
