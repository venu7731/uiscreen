# hrb-link

The `hrb-link` element can be used to render a simple link (`a` by default). Don't forget to pass the `href`, `target` and `rel` props if needed!

```html
<hrb-link href="/">this is a link</hrb-link>
```

Use the `as` props to change the main rendered element: `button`, `a` or `span`.
We recommend to render a `span` if you only want a styled component with no interactive elements.

```jsx
<Link href="/">
  <hrb-link as="span">this is a link</hrb-link>
</Link>
```

## Examples

In some context, you need aria attributes to make an `hbr-link` more accessible.

We exposed `p-aria-*` props translating to aria attributes on the main `button`, `a` or `span` element (see `as` props): `p-aria-label`, `p-aria-labelledby` and `p-aria-role`.

```html
<hrb-link href="/" p-aria-label="Go to a specific product page">
  Learn More
</hrb-link>
```

---

`hrb-link` can use a variety of themes, listed below, with the `theme` prop (`primary-black` by default).

```html
<hrb-link theme="green">Link Text</hrb-link>
```

---

`hrb-link` can be disabled with the `disabled` prop.

```html
<hrb-link href="/" disabled>
  A disabled Link
</hrb-link>
```

📝 Note: the `disabled` prop also automatically adds `aria-disabled="true"` on to the element.

<!-- Auto Generated Below -->


## Properties

| Property          | Attribute           | Description                             | Type                        | Default     |
| ----------------- | ------------------- | --------------------------------------- | --------------------------- | ----------- |
| `as`              | `as`                | Sets tag for link (defaults to <a />)   | `"a" \| "button" \| "span"` | `'a'`       |
| `disabled`        | `disabled`          | Sets link to disabled                   | `boolean`                   | `false`     |
| `href`            | `href`              | Applies href attribute                  | `string`                    | `undefined` |
| `icon`            | `icon`              | Displays optional icon                  | `string`                    | `undefined` |
| `pAriaLabel`      | `p-aria-label`      | Applies `aria-label` to link            | `string`                    | `undefined` |
| `pAriaLabelledby` | `p-aria-labelledby` | Applies `aria-labelledby` to link       | `string`                    | `undefined` |
| `pAriaRole`       | `p-aria-role`       | Applies `aria-role` to link             | `string`                    | `undefined` |
| `rel`             | `rel`               | Applies optional rel attribute          | `string`                    | `undefined` |
| `target`          | `target`            | Applies optional target attribute       | `string`                    | `undefined` |
| `theme`           | `theme`             | Applies color theme                     | `"" \| ThemeConstants`      | `''`        |
| `type`            | `type`              | Applies type attribute                  | `string`                    | `undefined` |
| `underline`       | `underline`         | Setting to false, removes the underline | `boolean`                   | `true`      |


## Dependencies

### Used by

 - [hrb-overflow-item](../overflow-item)

### Depends on

- [hrb-icon](../icon)

### Graph
```mermaid
graph TD;
  hrb-link --> hrb-icon
  hrb-overflow-item --> hrb-link
  style hrb-link fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
