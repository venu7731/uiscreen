import { Component, Host, h, Prop } from '@stencil/core'

import { getIsValidButtonType } from '@src/utils/validations'
import { isIe11 } from '@src/utils/browser-tests'
import { getClassnames } from '@src/utils/misc'

import buttonTypes from '@src/constants/button-types'

import { TLinkThemes, TLinkTypes } from './types'

const Constants = {
  baseClassname: 'hrb-link',
}

@Component({
  tag: 'hrb-link',
  styleUrl: 'link.scss',
})
export class Link {
  private hrblink?: HTMLElement

  constructor() {
    this.focusLink = this.focusLink.bind(this)
    this.blurLink = this.blurLink.bind(this)
  }

  focusLink(): void {
    this.hrblink.classList.add('tooltip-focus')
  }

  blurLink(): void {
    this.hrblink.classList.remove('tooltip-focus')
  }

  /**
   * Applies `aria-label` to link
   */
  @Prop({ attribute: 'p-aria-label' }) pAriaLabel: string

  /**
   * Applies `aria-labelledby` to link
   */
  @Prop({ attribute: 'p-aria-labelledby' }) pAriaLabelledby: string

  /**
   * Applies `aria-role` to link
   */
  @Prop({ attribute: 'p-aria-role' }) pAriaRole: string

  /**
   * Sets tag for link (defaults to <a />)
   */
  @Prop() as: TLinkTypes = 'a'

  /**
   * Applies optional target attribute
   */
  @Prop() target: string

  /**
   * Applies optional rel attribute
   */
  @Prop() rel: string

  /**
   * Applies href attribute
   */
  @Prop() href: string

  /**
   * Sets link to disabled
   */
  @Prop() disabled = false

  /**
   * Displays optional icon
   */
  @Prop() icon: string

  /**
   * Applies type attribute
   */
  @Prop() type: string

  /**
   * Applies color theme
   */
  @Prop() theme: TLinkThemes = ''

  /**
   * Setting to false, removes the underline
   */
  @Prop() underline = true

  componentWillLoad(): void {
    this.validateLinkType()
  }

  validateLinkType(): void {
    const isValidLinkType = getIsValidButtonType(this.as)

    if (!isValidLinkType) {
      this.throwConsoleError(this.as, 'type')
    }
  }

  throwConsoleError(val: string, prop: string): void {
    // eslint-disable-next-line no-console
    console.error(`<hrb-link /> : "${val}" is not a valid link ${prop}`)
  }

  getProps = (): object => {
    const {
      pAriaLabel,
      pAriaLabelledby,
      pAriaRole,
      as,
      disabled,
      href,
      rel,
      target,
      type,
    } = this

    const isAnchor = as === buttonTypes.anchor
    const isButton = as === buttonTypes.button

    const sharedProps = {
      'aria-label': pAriaLabel,
      'aria-labelledby': pAriaLabelledby,
      'aria-role': pAriaRole,
      'aria-disabled': disabled,
    }

    if (isAnchor) {
      return {
        ...sharedProps,
        href,
        rel,
        target,
      }
    }

    if (isButton) {
      return {
        ...sharedProps,
        type,
        disabled,
      }
    }

    return {
      ...sharedProps,
    }
  }

  render(): JSX.Element {
    const { as, getProps, theme } = this

    const props = getProps()
    const isButton = as === buttonTypes.button
    const buttonStyle = theme.includes('button')

    const classnames = getClassnames([
      `${Constants.baseClassname}`,
      `${Constants.baseClassname}--${theme}`,
      theme.includes('button') && `${Constants.baseClassname}--button`,
      theme.includes('small') && `${Constants.baseClassname}--button-small`,
      theme.includes('medium') && `${Constants.baseClassname}--button-medium`,
      theme.includes('large') && `${Constants.baseClassname}--button-large`,
      !!this.icon && `${Constants.baseClassname}--icon`,
      isIe11 && `${Constants.baseClassname}--is-ie`,
      isButton && `${Constants.baseClassname}--is-button`,
    ])

    return (
      // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
      <Host ref={el => (this.hrblink = el)} class={classnames}>
        <this.as {...props} onFocus={this.focusLink} onBlur={this.blurLink}>
          <span class="link-text">
            <slot></slot>
          </span>
          {!!this.icon && (
            <hrb-icon
              aria-hidden="true"
              name={this.icon}
              class={`${Constants.baseClassname}__icon`}
            ></hrb-icon>
          )}
          {!!buttonStyle && (
            <svg
              aria-hidden="true"
              class="pill-expand"
              xmlns="http://www.w3.org/2000/svg"
            >
              <rect height="100%" width="100%" rx="30" viewBox="0 0 100 100" />
            </svg>
          )}
        </this.as>
      </Host>
    )
  }
}
