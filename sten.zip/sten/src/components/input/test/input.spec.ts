import { newSpecPage, SpecPage } from '@stencil/core/testing'

import { HrbInputConstants } from '@src/constants/input'

import { HrbInput } from '../input'

const tagName = 'hrb-input'

interface HRBInputSpecPage {
  component: HrbInput
  page: SpecPage
}

const createNewSpecPage = async (): Promise<HRBInputSpecPage> => {
  const page = await newSpecPage({
    components: [HrbInput],
    html: `<${tagName}></${tagName}>`,
  })
  return { page, component: page.rootInstance }
}

describe(tagName, () => {
  it('creates a new instance of HrbAccordionItem', () => {
    const componentInstance = new HrbInput()

    expect(componentInstance).toBeTruthy()
  })

  it('renders', async () => {
    const { page } = await createNewSpecPage()
    const nodeName = page.root.nodeName.toLowerCase()

    expect(nodeName).toEqual(tagName)
  })

  describe('copy-paste="false"', () => {
    it('prevents the user from copying content', async () => {
      const { component, page } = await createNewSpecPage()
      let clipboardText = ''
      component.copyPaste = false
      await page.waitForChanges()
      await component.setFocus()

      const inputElement = page.root.querySelector('input')

      inputElement.value = 'Test Content'

      page.doc.addEventListener('copy', clipboardEvent => {
        const clipboardData = clipboardEvent.clipboardData || {
          getData: jest.fn().mockReturnValueOnce(''),
        }
        clipboardText = clipboardData.getData('text/plain')
      })

      page.doc.dispatchEvent(new Event('copy'))
      expect(clipboardText).toEqual('')
    })

    it('prevents the user from cutting content', async () => {
      const { component, page } = await createNewSpecPage()
      const clipboardText = ''
      component.copyPaste = false
      await page.waitForChanges()
      await component.setFocus()

      const inputElement = page.root.querySelector('input')

      inputElement.value = 'Test Content'

      page.doc.addEventListener('cut', clipboardEvent => {
        const clipboardData = clipboardEvent.clipboardData || {
          getData: jest.fn().mockReturnValueOnce(''),
        }
        clipboardData.getData('text/plain')
      })

      page.doc.dispatchEvent(new Event('cut'))

      expect(inputElement.value).toEqual('Test Content')
      expect(clipboardText).toEqual('')
    })

    it('prevents the user from pasting content', async () => {
      const { component, page } = await createNewSpecPage()
      component.copyPaste = false
      await page.waitForChanges()
      await component.setFocus()

      const inputElement = page.root.querySelector('input')

      inputElement.value = ''

      page.doc.addEventListener('paste', clipboardEvent => {
        const clipboardData = clipboardEvent.clipboardData || {
          setData: jest.fn(),
        }
        clipboardData.setData('text/plain', 'Test Content')
      })

      page.doc.dispatchEvent(new Event('paste'))

      expect(inputElement.value).toEqual('')
    })
  })

  describe('sets default properties when no value is provided', () => {
    it('allowPasswordToggle = false', async () => {
      const { component, page } = await createNewSpecPage()
      await page.waitForChanges()

      expect(component.allowPasswordToggle).toEqual(false)
    })

    it('autocomplete = "on"', async () => {
      const { component, page } = await createNewSpecPage()
      await page.waitForChanges()

      expect(component.autocomplete).toEqual('on')
    })

    it('copyPaste = true', async () => {
      const { component, page } = await createNewSpecPage()
      await page.waitForChanges()

      expect(component.copyPaste).toEqual(true)
    })

    it('disabled = false', async () => {
      const { component, page } = await createNewSpecPage()
      await page.waitForChanges()

      expect(component.disabled).toEqual(false)
    })

    it('hasError = false', async () => {
      const { component, page } = await createNewSpecPage()
      await page.waitForChanges()

      expect(component.hasError).toEqual(false)
    })

    it('loading = false', async () => {
      const { component, page } = await createNewSpecPage()
      await page.waitForChanges()

      expect(component.loading).toEqual(false)
    })

    it('type = HrbInputConstants.passwordToggleTypes.text', async () => {
      const { component, page } = await createNewSpecPage()
      await page.waitForChanges()

      expect(component.type).toEqual(HrbInputConstants.passwordToggleTypes.text)
    })
  })
})
