import {
  Component,
  Element,
  Event,
  EventEmitter,
  h,
  Host,
  Method,
  Prop,
  State,
} from '@stencil/core'

import { getIsValidIcon } from '@src/utils/validations'
import { generateSimpleID, getClassnames } from '@src/utils/misc'
import { HrbInputConstants } from '@src/constants/input'
import inputTypes from '@src/constants/input-types'

@Component({
  tag: 'hrb-input',
  styleUrl: 'input.scss',
})
export class HrbInput {
  @Element() el: HTMLElement

  @Event() hrbBlur: EventEmitter

  @Event() hrbChange: EventEmitter

  @Event() hrbFocus: EventEmitter

  @Event() hrbInput: EventEmitter

  @Method() async getElement(): Promise<HTMLElement> {
    return this.inputRef
  }

  @Method() async setFocus(): Promise<void> {
    this.onFocus()
  }

  /**
   * Include password hide/show functionality
   */
  @Prop() allowPasswordToggle = false

  /**
   * Autocomplete
   */
  @Prop() autocomplete = 'on'

  /**
   * Copy-Paste
   */
  @Prop() copyPaste = true

  /**
   * Disabled
   */
  @Prop() disabled = false

  /**
   * Error label
   */
  @Prop() errorLabel: string

  /**
   * Force icon to be visiblie
   */
  @Prop() forceIconVisibility: boolean

  /**
   * Input has error
   */
  @Prop() hasError = false

  /**
   * Helper text
   */
  @Prop() helperText: string = null

  /**
   * Input is loading
   */
  @Prop() loading = false

  /**
   * Icon
   */
  @Prop({ mutable: true }) icon = ''

  /**
   * Input id
   */
  @Prop() inputId = generateSimpleID()

  /**
   * Label
   */
  @Prop() label = ''

  /**
   * Name
   */
  @Prop() name = ''

  /**
   * Maximum value length
   */
  @Prop() maxlength: string

  /**
   * Minimum value length
   */
  @Prop() minlength: string

  @Prop({ mutable: true }) pActivedescendant: string

  @Prop() pAriaAutocomplete: 'list'

  @Prop() pAriaMultiline: string = null

  @Prop() pAriaOwns: string = null

  /**
   * Pattern
   */
  @Prop() pattern = ''

  /**
   * Readonly
   */
  @Prop() readonly: boolean

  /**
   * Required
   */
  @Prop() required: boolean

  /**
   * The type attribute to apply to input.
   */
  @Prop() type = this.allowPasswordToggle
    ? HrbInputConstants.passwordToggleTypes.password
    : HrbInputConstants.passwordToggleTypes.text

  /**
   * Default value
   */
  @Prop({ mutable: true }) value: string

  /**
   * current icon
   */

  @State() currentIcon = this.icon

  /**
   * current type
   */

  @State() currentType = this.type

  /**
   * is animating icon out
   */
  @State() isAnimatingIconOut = false

  /**
   * current focus state
   */
  @State() isFocused = false

  private buttonDataRef: string = generateSimpleID()

  private buttonRef: HTMLButtonElement

  private containerRef: HTMLSpanElement

  private iconAnimationTimeout = null

  private inputRef: HTMLInputElement

  componentDidUpdate(): void {
    const { currentIcon, icon } = this

    if (currentIcon !== icon) {
      this.animateIcon()
    }
  }

  componentWillLoad(): void {
    this.validateProps()
  }

  componentDidUnload(): void {
    this.clearIconAnimationTimeout()
  }

  validateProps = (): void => {
    const { allowPasswordToggle, icon, type } = this

    const hasValidIcon = getIsValidIcon(icon)
    const hasValidAsType = inputTypes.includes(type)

    if (icon && !hasValidIcon) {
      throw new Error(`<hrb-input /> ${icon} is not a valid icon option`)
    }

    if (!hasValidAsType) {
      throw new Error(`<hrb-input /> ${type} is not a valid type option`)
    }

    if (allowPasswordToggle && type !== 'password') {
      throw new Error(
        `<hrb-input /> to include password toggle the input type must be "password"`,
      )
    }
  }

  clearIconAnimationTimeout = (): void => {
    const { iconAnimationTimeout } = this

    if (iconAnimationTimeout) {
      clearTimeout(iconAnimationTimeout)
      this.iconAnimationTimeout = null
    }
  }

  animateIcon = (): void => {
    const { clearIconAnimationTimeout, icon } = this
    const { iconAnimationTimeoutDuration } = HrbInputConstants

    clearIconAnimationTimeout()
    this.isAnimatingIconOut = true

    this.iconAnimationTimeout = setTimeout(() => {
      this.currentIcon = icon
      this.isAnimatingIconOut = false
    }, iconAnimationTimeoutDuration)
  }

  handleTogglePasswordOnClick = (): void => {
    const { currentType, onFocus } = this
    const { passwordToggleTypes } = HrbInputConstants

    if (currentType === passwordToggleTypes.text) {
      this.currentType = passwordToggleTypes.password
    } else {
      this.currentType = passwordToggleTypes.text
    }

    this.buttonRef.focus()
    onFocus()
  }

  onChange = (): CustomEvent => this.hrbChange.emit(this)

  onInput = (event: Event): void => {
    const { value } = event.target as HTMLInputElement

    this.value = value
    this.hrbInput.emit(this)
  }

  // explicitOriginalTarget is a non-standard feature that is
  // not part of the general FocusEvent type so we're extending
  // that type to allow for this usage
  onBlur = (
    event: FocusEvent & { explicitOriginalTarget: HTMLElement },
  ): void => {
    const { buttonDataRef, inputRef } = this

    const relatedTarget = event.relatedTarget as HTMLElement
    const { explicitOriginalTarget } = event

    // if clicking on or tabbing to the internal icon button
    // we want to keep the focus state active
    // relatedTarget is the standard feature that allows us
    // to track this, but Firefox requires the non-standard
    // explicitOriginalTarget to accomplish the same thing
    const isChildButtonRelatedTarget =
      relatedTarget &&
      !!relatedTarget['data-ref'] &&
      relatedTarget['data-ref'] === buttonDataRef

    const isChildButtonExplicitOriginalTarget =
      !!explicitOriginalTarget &&
      explicitOriginalTarget !== inputRef &&
      this.containerRef.contains(explicitOriginalTarget) &&
      (!relatedTarget || relatedTarget === inputRef)

    if (isChildButtonRelatedTarget || isChildButtonExplicitOriginalTarget) {
      return
    }

    this.isFocused = false
    this.hrbBlur.emit(this)
  }

  onFocus = (): void => {
    this.isFocused = true
    this.hrbFocus.emit(this)
  }

  onIconButtonFocus = (): void => {
    this.isFocused = true
  }

  getProps = (): object => {
    const { helperText } = this

    if (helperText !== null) {
      return {
        'aria-describedby': `${this.inputId}__helper`,
      }
    }
    return {}
  }

  renderLoader = (): JSX.Element => {
    return (
      <span
        class={`${HrbInputConstants.baseClassname}__loader`}
        aria-hidden="true"
      >
        <hrb-loader></hrb-loader>
      </span>
    )
  }

  renderError = (): JSX.Element => {
    const { errorLabel, inputId } = this
    const { baseClassname } = HrbInputConstants

    return (
      <div
        id={`${inputId}__error`}
        class={`${baseClassname}__error`}
        role="alert"
        aria-live="assertive"
      >
        <hrb-icon name="error"></hrb-icon>
        {errorLabel}
      </div>
    )
  }

  renderIcon = (): JSX.Element => {
    const {
      allowPasswordToggle,
      buttonDataRef,
      currentIcon,
      currentType,
      handleTogglePasswordOnClick,
      onBlur,
      onIconButtonFocus,
      type,
    } = this
    const {
      baseClassname,
      passwordToggleLabels,
      passwordToggleIcon,
      passwordToggleTypes,
    } = HrbInputConstants

    if (allowPasswordToggle && type === passwordToggleTypes.password) {
      const isCurrentTypePassword = currentType === passwordToggleTypes.password

      return (
        <button
          aria-label={
            isCurrentTypePassword
              ? passwordToggleLabels.showPassword
              : passwordToggleLabels.hidePassword
          }
          class={`${baseClassname}__icon ${baseClassname}__icon-button`}
          data-ref={buttonDataRef}
          onBlur={onBlur}
          onClick={handleTogglePasswordOnClick}
          onFocus={onIconButtonFocus}
          ref={(el): HTMLInputElement =>
            (this.buttonRef = el as HTMLInputElement)
          }
          type="button"
        >
          <hrb-icon
            name={
              isCurrentTypePassword
                ? passwordToggleIcon.eye
                : passwordToggleIcon.eyeFilled
            }
          ></hrb-icon>
        </button>
      )
    }

    return (
      <hrb-icon
        aria-hidden="true"
        name={currentIcon}
        class={`${baseClassname}__icon`}
      ></hrb-icon>
    )
  }

  renderHelper = (): JSX.Element => {
    const { helperText, inputId } = this
    const { baseClassname } = HrbInputConstants

    return (
      <div id={`${inputId}__helper`} class={`${baseClassname}__helper`}>
        {helperText}
      </div>
    )
  }

  render(): JSX.Element {
    const { baseClassname, passwordToggleTypes } = HrbInputConstants
    const {
      allowPasswordToggle,
      autocomplete,
      copyPaste,
      currentIcon,
      currentType,
      disabled,
      errorLabel,
      forceIconVisibility,
      hasError,
      helperText,
      icon,
      inputId,
      isAnimatingIconOut,
      isFocused,
      label,
      loading,
      maxlength,
      minlength,
      onBlur,
      onChange,
      onFocus,
      onInput,
      name,
      pActivedescendant,
      pAriaAutocomplete,
      pAriaMultiline,
      pAriaOwns,
      pattern,
      readonly,
      renderError,
      renderHelper,
      renderIcon,
      renderLoader,
      required,
      type,
      value,
    } = this

    const willRenderIcon =
      !!currentIcon ||
      (allowPasswordToggle && type === passwordToggleTypes.password)

    const containerClassnames = getClassnames([
      baseClassname,
      disabled && `${baseClassname}--is-disabled`,
      forceIconVisibility && `${baseClassname}--has-forced-icon-visibility`,
      hasError && `${baseClassname}--has-error`,
      !!icon && `${baseClassname}--has-icon`,
      isAnimatingIconOut && `${baseClassname}--is-animating-icon-out`,
      isFocused && `${baseClassname}--is-focused`,
      loading && `${baseClassname}--is-loading`,
      !!value && `${baseClassname}--has-text`,
      `${baseClassname}--${type}`,
      !!forceIconVisibility && `${baseClassname}__credit-card`,
    ])

    const props = this.getProps()

    const handleCopyPaste = (event: ClipboardEvent): boolean => {
      if (!copyPaste) {
        event.preventDefault()
      }
      return copyPaste
    }

    return (
      <Host>
        <span
          class={containerClassnames}
          ref={(el): HTMLInputElement =>
            (this.containerRef = el as HTMLInputElement)
          }
        >
          <label
            id={`${inputId}__label`}
            htmlFor={inputId}
            class={`${baseClassname}__label`}
          >
            {label}
          </label>
          <input
            {...props}
            aria-activedescendant={pActivedescendant}
            aria-autocomplete={pAriaAutocomplete}
            aria-invalid={hasError}
            aria-multiline={pAriaMultiline}
            aria-owns={pAriaOwns}
            aria-required={required ? required.toString() : 'false'}
            autocomplete={autocomplete}
            class={`${baseClassname}__input`}
            disabled={disabled}
            id={inputId}
            minlength={minlength}
            maxlength={maxlength}
            name={name}
            onBlur={onBlur}
            onChange={onChange}
            onCopy={handleCopyPaste}
            onCut={handleCopyPaste}
            onFocus={onFocus}
            onInput={onInput}
            onPaste={handleCopyPaste}
            pattern={!!pattern && pattern}
            readonly={readonly}
            required={required}
            type={currentType}
            value={value}
            ref={(el): HTMLInputElement => (this.inputRef = el)}
          />
          {willRenderIcon && renderIcon()}
          {loading && renderLoader()}
        </span>
        {hasError && !!errorLabel && renderError()}
        {helperText && renderHelper()}
      </Host>
    )
  }
}
