import * as readme from './readme.md'

export default {
  component: 'hrb-input',
  title: 'Forms/Input',
  parameters: {
    notes: { markdown: readme },
    actions: {
      handles: [
        {
          hrbChange: 'hrbChange',
          hrbBlur: 'hrbBlur',
          hrbFocus: 'hrbFocus',
          hrbInput: 'hrbInput',
        },
      ],
    },
  },
  argTypes: {
    label: { control: 'text' },
    errorLabel: { control: 'text' },
    helperText: { control: 'text' },
    hasError: { control: 'boolean' },
    loading: { control: 'boolean' },
    icon: { control: 'text' },
    forceIconVisibility: { control: 'boolean' },
    type: {
      control: {
        type: 'select',
        options: ['text', 'number', 'date', 'password', 'email'],
        default: 'text',
      },
    },
  },
}

export const Basic = (args): string =>
  `
    <hrb-input ${!!args.loading && `loading`} ${!!args.helperText &&
    `helper-text="${args.helperText}"`} name="${args.name}" has-error=${
    args.hasError
  } label="${args.label}" error-label="${args.errorLabel}" icon=${
    args.icon
  } type=${
    args.type
  } force-icon-visibility=${!!args.forceIconVisibility}></hrb-input>
  `

Basic.args = {
  label: 'Basic Input',
  hasError: false,
  name: 'Basic Input Name',
}

export const HasError = (args): string =>
  `
  <hrb-input ${!!args.loading && `loading`}  has-error="${
    args.hasError
  }" label="${args.label}" error-label="${args.errorLabel}" icon="${
    args.icon
  }" type="${
    args.type
  }" force-icon-visibility=${!!args.forceIconVisibility}></hrb-input>  `

HasError.args = {
  label: 'Error input',
  errorLabel:
    'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et.',
  hasError: 'true',
}

export const HasHelper = (args): string =>
  `
  <hrb-input ${!!args.loading && `loading`}  label="${
    args.label
  }" helper-text="${args.helperText}"></hrb-input>  `

HasHelper.args = {
  label: 'Helper input',
  helperText:
    'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat',
}

export const HasHelperAndError = (args): string =>
  `
  <hrb-input ${!!args.loading && `loading`}  label="${
    args.label
  }" helper-text="${args.helperText}" has-error="${
    args.hasError
  }" error-label="${args.errorLabel}"></hrb-input>  `

HasHelperAndError.args = {
  label: 'Helper input',
  helperText:
    'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat',
  errorLabel: 'Kuis nostrud exercitation ullamco laboris nisi ut aliquips.',
  hasError: 'true',
}

export const dateInput = (args): string =>
  `
  <hrb-input ${!!args.loading && `loading`}  label="${args.label}" type="${
    args.type
  }"></hrb-input>  `

dateInput.args = {
  label: 'Helper input',
  type: 'date',
}

export const emailInput = (args): string =>
  `
  <hrb-input ${!!args.loading && `loading`}  label="${args.label}" type="${
    args.type
  }"></hrb-input>  `

emailInput.args = {
  label: 'Enter your email',
  type: 'email',
}

export const numberInput = (args): string =>
  `
  <hrb-input ${!!args.loading && `loading`}  label="${args.label}" type="${
    args.type
  }"></hrb-input>  `

numberInput.args = {
  label: 'Number input',
  type: 'number',
}

export const passwordInput = (args): string =>
  `
  <hrb-input ${!!args.loading && `loading`}  label="${args.label}" type="${
    args.type
  }"></hrb-input>  `

passwordInput.args = {
  label: 'Password input',
  type: 'password',
}

export const searchInput = (args): string =>
  `
  <hrb-input ${!!args.loading && `loading`}  label="${args.label}" type="${
    args.type
  }"></hrb-input>  `

searchInput.args = {
  label: 'Search input',
  type: 'search',
}

export const telInput = (args): string =>
  `
  <hrb-input ${!!args.loading && `loading`}  label="${args.label}" type="${
    args.type
  }"></hrb-input>  `

telInput.args = {
  label: 'Tel input',
  type: 'tel',
}

export const urlInput = (args): string =>
  `
  <hrb-input ${!!args.loading && `loading`}  label="${args.label}" type="${
    args.type
  }"></hrb-input>  `

urlInput.args = {
  label: 'URL input',
  type: 'url',
}
