# hrb-input

`hrb-input` elements are custom `input` elements. They should be used in the context of a `form`.

By default, it renders an input type `text`, but can by changed with the `type` prop. The `label` prop is mandatory, which renders a `label` element attached to the `input`.

An `id` for the rendered `input` is automatically generated if not provided, but can be provided using `input-id`.

```html
<hrb-input label="My label" input-id="myId"></hrb-input>
```

---

In the case of a `type="password"`, the `allow-password-toggle` prop renders a show/hide password toggle button if `true`.

```html
<hrb-input
  label="Password"
  type="password"
  required
  allow-password-toggle
></hrb-input>
```

---

An `hrb-input` element can have a default value, and be required, disabled or readonly by simply passing a `value`, `required`, `disabled` or `readonly` prop.

```html
<hrb-input label="Firstname" value="John" required></hrb-input>
```

---

An `hrb-input` element can also be restricted by a `pattern` prop

```html
<hrb-input
  label="Email"
  type="email"
  required
  pattern="(([^<>()\[\]\\.,;:\s@"
  ]+(\.[^<
  >()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))"></hrb-input
>
```

---

An `hrb-input` element can handle errors. To show an error message, use the `error-label` prop for the message and the `has-error` prop to show it.

```html
<hrb-input
  type="email"
  label="Your email"
  error-label="Wrong format for an email"
  has-error
></hrb-input>
```

## Event Examples

Most of the standard events are available

```js
const input = form.querySelector('hrb-input')

input.addEventListener('change', e => {
  console.log('change', e.target.checked)
})
```

We've added some custom events to expose a consistent API across all the custom inputs and accomodate for specific events that are not available by default on custom elements, such as `focus` and `blur`.

Every custom events return a reference to element, available in `e.detail`.

```js
const input = form.querySelector('hrb-input')

// Focus
input.addEventListener('hrbFocus', e => {
  console.log('focus', e.detail)
})

// Blur
input.addEventListener('hrbBlur', e => {
  console.log('blur', e, detail)
})

// Change
input.addEventListener('hrbChange', e => {
  console.log('change', e, detail)
})

// Input
input.addEventListener('hrbInput', e => {
  console.log('input', e, detail)
})
```

## Method Examples

Every exposed methods return a `Promise`.

```js
const input = form.querySelector('hrb-input')

// get the main input element inside the `hrb-input`
const inputInput = await input.getElement()

// set the focus on the element
await input.setFocus()
```

<!-- Auto Generated Below -->


## Properties

| Property              | Attribute               | Description                              | Type      | Default                                                                                                                          |
| --------------------- | ----------------------- | ---------------------------------------- | --------- | -------------------------------------------------------------------------------------------------------------------------------- |
| `allowPasswordToggle` | `allow-password-toggle` | Include password hide/show functionality | `boolean` | `false`                                                                                                                          |
| `autocomplete`        | `autocomplete`          | Autocomplete                             | `string`  | `'on'`                                                                                                                           |
| `copyPaste`           | `copy-paste`            | Copy-Paste                               | `boolean` | `true`                                                                                                                           |
| `disabled`            | `disabled`              | Disabled                                 | `boolean` | `false`                                                                                                                          |
| `errorLabel`          | `error-label`           | Error label                              | `string`  | `undefined`                                                                                                                      |
| `forceIconVisibility` | `force-icon-visibility` | Force icon to be visiblie                | `boolean` | `undefined`                                                                                                                      |
| `hasError`            | `has-error`             | Input has error                          | `boolean` | `false`                                                                                                                          |
| `helperText`          | `helper-text`           | Helper text                              | `string`  | `null`                                                                                                                           |
| `icon`                | `icon`                  | Icon                                     | `string`  | `''`                                                                                                                             |
| `inputId`             | `input-id`              | Input id                                 | `string`  | `generateSimpleID()`                                                                                                             |
| `label`               | `label`                 | Label                                    | `string`  | `''`                                                                                                                             |
| `loading`             | `loading`               | Input is loading                         | `boolean` | `false`                                                                                                                          |
| `maxlength`           | `maxlength`             | Maximum value length                     | `string`  | `undefined`                                                                                                                      |
| `minlength`           | `minlength`             | Minimum value length                     | `string`  | `undefined`                                                                                                                      |
| `name`                | `name`                  | Name                                     | `string`  | `''`                                                                                                                             |
| `pActivedescendant`   | `p-activedescendant`    |                                          | `string`  | `undefined`                                                                                                                      |
| `pAriaAutocomplete`   | `p-aria-autocomplete`   |                                          | `"list"`  | `undefined`                                                                                                                      |
| `pAriaMultiline`      | `p-aria-multiline`      |                                          | `string`  | `null`                                                                                                                           |
| `pAriaOwns`           | `p-aria-owns`           |                                          | `string`  | `null`                                                                                                                           |
| `pattern`             | `pattern`               | Pattern                                  | `string`  | `''`                                                                                                                             |
| `readonly`            | `readonly`              | Readonly                                 | `boolean` | `undefined`                                                                                                                      |
| `required`            | `required`              | Required                                 | `boolean` | `undefined`                                                                                                                      |
| `type`                | `type`                  | The type attribute to apply to input.    | `string`  | `this.allowPasswordToggle     ? HrbInputConstants.passwordToggleTypes.password     : HrbInputConstants.passwordToggleTypes.text` |
| `value`               | `value`                 | Default value                            | `string`  | `undefined`                                                                                                                      |


## Events

| Event       | Description | Type               |
| ----------- | ----------- | ------------------ |
| `hrbBlur`   |             | `CustomEvent<any>` |
| `hrbChange` |             | `CustomEvent<any>` |
| `hrbFocus`  |             | `CustomEvent<any>` |
| `hrbInput`  |             | `CustomEvent<any>` |


## Methods

### `getElement() => Promise<HTMLElement>`



#### Returns

Type: `Promise<HTMLElement>`



### `setFocus() => Promise<void>`



#### Returns

Type: `Promise<void>`




## Dependencies

### Used by

 - [hrb-autocomplete](../autocomplete)

### Depends on

- [hrb-loader](../loader)
- [hrb-icon](../icon)

### Graph
```mermaid
graph TD;
  hrb-input --> hrb-loader
  hrb-input --> hrb-icon
  hrb-autocomplete --> hrb-input
  style hrb-input fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
