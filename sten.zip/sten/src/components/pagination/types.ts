import { TButtonTypes } from '../buttons/button/types'

export type TPageItemObject = {
  as?: TButtonTypes
  pAriaLabel?: string
  pAriaPressed?: string
  active?: boolean
}
