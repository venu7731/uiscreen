# hrb-dot



<!-- Auto Generated Below -->


## Properties

| Property       | Attribute        | Description | Type      | Default     |
| -------------- | ---------------- | ----------- | --------- | ----------- |
| `active`       | `active`         |             | `boolean` | `undefined` |
| `pAriaLabel`   | `p-aria-label`   |             | `string`  | `undefined` |
| `pAriaPressed` | `p-aria-pressed` |             | `string`  | `undefined` |


## Dependencies

### Used by

 - [hrb-dot-nav](..)

### Graph
```mermaid
graph TD;
  hrb-dot-nav --> hrb-dot
  style hrb-dot fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
