import { Component, Host, h, Prop } from '@stencil/core'

@Component({
  tag: 'hrb-dot',
  styleUrl: 'pagination-item.scss',
})
export class PaginationItem {
  @Prop() pAriaLabel: string

  @Prop() pAriaPressed: string

  @Prop() active: boolean

  render(): JSX.Element {
    return (
      <Host class={!this.active ? `is-active` : ``}>
        <button aria-pressed={this.pAriaPressed} aria-label={this.pAriaLabel}>
          <slot></slot>
        </button>
      </Host>
    )
  }
}
