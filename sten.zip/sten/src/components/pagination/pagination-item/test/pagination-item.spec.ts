import { PaginationItem } from '../pagination-item'

describe('pagination-item', () => {
  it('builds', () => {
    expect(new PaginationItem()).toBeTruthy()
  })
})
