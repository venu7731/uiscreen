/* eslint-disable no-irregular-whitespace */
import { Component, Host, h, State, Prop } from '@stencil/core'

import { TPageItemObject } from '../pagination/types'

@Component({
  tag: 'hrb-dot-nav',
  styleUrl: 'pagination.scss',
})
export class Pagination {
  private slotContainerRef: HTMLSpanElement

  @State() buttonList: TPageItemObject[]

  @Prop() pAriaLabel: string

  getButtonList = (): void => {
    const options = this.slotContainerRef.children
    const optionsList = Array.from(options).map((option: any) => {
      const { pAriaLabel, pAriaPressed, active } = option
      return {
        pAriaLabel: pAriaLabel,
        pAriaPressed: pAriaPressed,
        active: active,
      }
    })

    this.buttonList = [].concat(...optionsList)
  }

  componentDidLoad(): void {
    this.getButtonList()
  }

  render(): JSX.Element {
    return (
      <Host>
        <div
          class="hide-this"
          ref={(el): HTMLSpanElement =>
            (this.slotContainerRef = el as HTMLSpanElement)
          }
        >
          <slot />
        </div>
        <nav>
          <ol aria-label={this.pAriaLabel} class="dot-nav-container">
                    
            {!!this.buttonList &&
              this.buttonList.map(
                (option: TPageItemObject): HTMLElement => {
                  return (
                    <li class="dot-container">
                      <hrb-dot
                        pAriaLabel={option.pAriaLabel}
                        pAriaPressed={option.pAriaPressed}
                        active={!option.active}
                      ></hrb-dot>
                    </li>
                  )
                },
              )}
                    
          </ol>
        </nav>
      </Host>
    )
  }
}
