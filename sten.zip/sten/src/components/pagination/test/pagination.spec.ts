import { Pagination } from '../pagination'

describe('pagination', () => {
  it('builds', () => {
    expect(new Pagination()).toBeTruthy()
  })
})
