import { Component, h, Host, Prop } from '@stencil/core'

import { TLoaderColors } from './types'

import { loaderIcon, loaderIconWhite } from './icons'

const Constants = {
  baseClassname: 'hrb-loader',
}

@Component({
  tag: 'hrb-loader',
  styleUrl: 'loader.scss',
})
export class Loader {
  /**
   * Loader color (defaults to 'primary-black')
   */
  @Prop() color: TLoaderColors = 'primary-black'

  renderIcon = (): JSX.Element => {
    const { color } = this

    const icon = color === 'white' ? loaderIconWhite : loaderIcon

    return <span innerHTML={icon}></span>
  }

  render(): JSX.Element {
    const { renderIcon } = this

    return <Host class={Constants.baseClassname}>{renderIcon()}</Host>
  }
}
