export const loaderIcon = `
<?xml version="1.0" encoding="UTF-8"?>

<svg width="100%" height="100%" viewBox="0 0 40 40" focusable="false" aria-hidden="true">
  <defs>
    <linearGradient id="loader-gradient" x1="50%" y1="0%" x2="50%" y2="100%">
      <stop offset="0%" stop-color="#262626" stop-opacity="0"></stop>
      <stop offset="100%" stop-color="#262626" stop-opacity="0.6"></stop>
    </linearGradient>
  </defs>
  <g id="spinner" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
    <path id="spinnerpath" fill="url(#loader-gradient)"
      d="M20,0 C31.045695,0 40,8.954305 40,20 C40,31.045695 31.045695,40 20,40 C8.954305,40 0,31.045695 0,20 C0,19.4740145 0.426395476,19.047619 0.952380952,19.047619 C1.47836643,19.047619 1.9047619,19.4740145 1.9047619,20 C1.9047619,29.993724 10.006276,38.0952381 20,38.0952381 C29.993724,38.0952381 38.0952381,29.993724 38.0952381,20 C38.0952381,10.006276 29.993724,1.9047619 20,1.9047619 C19.4740145,1.9047619 19.047619,1.47836643 19.047619,0.952380952 C19.047619,0.426395476 19.4740145,0 20,0 Z"
      fill-rule="nonzero"></path>
  </g>
</svg>`

export const loaderIconWhite = `
<?xml version="1.0" encoding="UTF-8"?>

<svg width="100%" height="100%" viewBox="0 0 40 40" focusable="false" aria-hidden="true">
  <defs>
    <linearGradient id="loader-white-gradient" x1="50%" y1="0%" x2="50%" y2="100%">
      <stop offset="0%" stop-color="#FFFFFF" stop-opacity="0"></stop>
      <stop offset="100%" stop-color="#FFFFFF" stop-opacity="0.6"></stop>
    </linearGradient>
  </defs>
  <g id="spinner" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
    <path id="spinnerpath" fill="url(#loader-white-gradient)"
      d="M20,0 C31.045695,0 40,8.954305 40,20 C40,31.045695 31.045695,40 20,40 C8.954305,40 0,31.045695 0,20 C0,19.4740145 0.426395476,19.047619 0.952380952,19.047619 C1.47836643,19.047619 1.9047619,19.4740145 1.9047619,20 C1.9047619,29.993724 10.006276,38.0952381 20,38.0952381 C29.993724,38.0952381 38.0952381,29.993724 38.0952381,20 C38.0952381,10.006276 29.993724,1.9047619 20,1.9047619 C19.4740145,1.9047619 19.047619,1.47836643 19.047619,0.952380952 C19.047619,0.426395476 19.4740145,0 20,0 Z"
      fill-rule="nonzero"></path>
  </g>
</svg>
`
