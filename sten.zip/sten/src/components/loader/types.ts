export type TLoaderColors = 'primary-black' | 'white'
