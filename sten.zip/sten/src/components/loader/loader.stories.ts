import { select, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import { loaderColors, reset } from '@src/constants/storybook'

import * as readme from './readme.md'

/* eslint-disable-next-line */
const loader = color => `<hrb-loader color="${color}"></hrb-loader>`

const wrapperOpen = `${reset}<div style="padding: 30px">`
const wrapperClose = `</div>`

storiesOf('Loader', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-loader'],
    notes: { markdown: readme },
  })
  .add('Loader', () => {
    return `${wrapperOpen}${loader(
      select('Loader color', loaderColors, loaderColors[0]),
    )}${wrapperClose}`
  })
