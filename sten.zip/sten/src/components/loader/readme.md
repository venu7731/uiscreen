# hrb-loader

<!-- Auto Generated Below -->


## Properties

| Property | Attribute | Description                                | Type                         | Default           |
| -------- | --------- | ------------------------------------------ | ---------------------------- | ----------------- |
| `color`  | `color`   | Loader color (defaults to 'primary-black') | `"primary-black" \| "white"` | `'primary-black'` |


## Dependencies

### Used by

 - [hrb-button](../buttons/button)
 - [hrb-card-document](../card composites/card-document)
 - [hrb-input](../input)
 - [hrb-select-custom](../select-custom)
 - [hrb-select-native](../select-native)
 - [hrb-textarea](../textarea)
 - [hrb-video](../video)

### Graph
```mermaid
graph TD;
  hrb-button --> hrb-loader
  hrb-card-document --> hrb-loader
  hrb-input --> hrb-loader
  hrb-select-custom --> hrb-loader
  hrb-select-native --> hrb-loader
  hrb-textarea --> hrb-loader
  hrb-video --> hrb-loader
  style hrb-loader fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
