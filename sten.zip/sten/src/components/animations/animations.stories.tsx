import * as readme from './readme.md'

export default {
  component: 'hrb-card',
  title: 'Animations/Named Animations',
  parameters: {
    notes: { markdown: readme },
  },
}

export const SlideElementsLeft = (): string =>
  `
<hrb-global reset></hrb-global>
<hrb-layout hrb-animation="slide-elements-left" layout="card-grid">
  <hrb-card theme="medium-light-blue">
      <hrb-card-content>
        <hrb-spacer d="32"></hrb-spacer>
          <hrb-text style-type="medium">Slide Elements Left</hrb-text>
          <hrb-spacer d="32"></hrb-spacer>
      </hrb-card-content>
  </hrb-card>
  <hrb-card theme="medium-light-blue">
      <hrb-card-content>
        <hrb-spacer d="32"></hrb-spacer>
          <hrb-text style-type="medium">Slide Elements Left</hrb-text>
          <hrb-spacer d="32"></hrb-spacer>
      </hrb-card-content>
  </hrb-card>
  <hrb-card theme="medium-light-blue">
      <hrb-card-content>
        <hrb-spacer d="32"></hrb-spacer>
          <hrb-text style-type="medium">Slide Elements Left</hrb-text>
          <hrb-spacer d="32"></hrb-spacer>
      </hrb-card-content>
  </hrb-card>
</hrb-l
`

export const SlideElementsBottom = (): string =>
  `
<hrb-global reset></hrb-global>
<hrb-layout hrb-animation="slide-elements-bottom" layout="card-grid">
  <hrb-card theme="medium-light-blue">
      <hrb-card-content>
        <hrb-spacer d="32"></hrb-spacer>
          <hrb-text style-type="medium">Slide Elements Bottom</hrb-text>
          <hrb-spacer d="32"></hrb-spacer>
      </hrb-card-content>
  </hrb-card>
  <hrb-card theme="medium-light-blue">
      <hrb-card-content>
        <hrb-spacer d="32"></hrb-spacer>
          <hrb-text style-type="medium">Slide Elements Bottom</hrb-text>
          <hrb-spacer d="32"></hrb-spacer>
      </hrb-card-content>
  </hrb-card>
  <hrb-card theme="medium-light-blue">
      <hrb-card-content>
        <hrb-spacer d="32"></hrb-spacer>
          <hrb-text style-type="medium">Slide Elements Bottom</hrb-text>
          <hrb-spacer d="32"></hrb-spacer>
      </hrb-card-content>
  </hrb-card>
</hrb-l
`

export const ScaleUpCenter = (): string =>
  `
<hrb-global reset></hrb-global>
<hrb-layout layout="card-grid">
  <hrb-card hrb-animation="scale-up-center" theme="medium-light-blue">
      <hrb-card-content>
        <hrb-spacer d="32"></hrb-spacer>
          <hrb-text style-type="medium">Scale Up Center</hrb-text>
          <hrb-spacer d="32"></hrb-spacer>
      </hrb-card-content>
  </hrb-card>
</hrb-l
`

export const Pulsate = (): string =>
  `
<hrb-global reset></hrb-global>
<div style="display: flex; justify-content: center; align-items: center; position: absolute; bottom: 0; top: 0; left: 0; right: 0;">
  <div style="width: 32px; height: 32px; border-radius: 100%; background-color: #11A63D;" hrb-animation="pulsate-fwd" theme="medium-light-blue">
  </div>
</div>
`
