import { newSpecPage } from '@stencil/core/testing'

import { OptionCard } from '../option-card'

describe('option-card', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [OptionCard],
      html: `<option-card></option-card>`,
    })
    expect(page.root).toEqualHtml(`<option-card></option-card>`)
  })
})
