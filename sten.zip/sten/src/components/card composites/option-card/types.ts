import { TAvatarThemes } from '../../avatar/types'

import { TCardThemes } from '../../card/types'

export type TOptionBadgeThemes = TAvatarThemes

export type TOptionThemes = TCardThemes
