/* eslint-disable no-alert */
import {
  Component,
  Event,
  EventEmitter,
  h,
  Host,
  Method,
  Prop,
} from '@stencil/core'

import { getClassnames, generateSimpleID } from '@src/utils/misc'

import { TOptionBadgeThemes, TOptionThemes } from './types'

@Component({
  tag: 'hrb-option-card',
  styleUrl: 'option-card.scss',
})
export class OptionCard {
  // Event emmitted when element is selected
  @Event() isSelected: EventEmitter

  // Event emmitted when element is expanded
  @Event() isExpanded: EventEmitter

  // Setting 'custom' to true will remove the default badge-label. Allow you to put whatever content you want.
  @Prop() custom = false

  // Disables the element
  @Prop() disabled = false

  // If the card can expand, just apply the attribute expands
  @Prop() expands = false

  // The icon shown when the element is not selected
  @Prop() icon = 'add'

  // When true, sets the selected state. Should be used if you need a default selected element
  @Prop() selected = false

  // The icon shown when the element is selected
  @Prop() selectedIcon = 'check'

  // Applies a theme (all themes available to hrb-card)
  @Prop() theme: TOptionThemes

  // Properties needed for the internal badge-label element

  // The title of the card
  @Prop() badgeTitle: string

  // The subtitle of the card
  @Prop() badgeSubtitle: string

  // The thumbnail of the card
  @Prop() badgeImage: string

  // The thumbnail of the card
  @Prop() badgeImageAlt: string

  // The text in the avatar image spot (ex: Initials, or Doc type like "PDF")
  @Prop() badgeText = null

  // The icon of the card
  @Prop() badgeIcon = null

  // Badge Theme (applies background colors to avatar)
  @Prop() badgeTheme: TOptionBadgeThemes = 'light-grey-1'

  // Method allows the external control of the element (if selecting one should close the other)
  @Method()
  async selectOption(): Promise<void> {
    this.select()
  }

  private buttonId = generateSimpleID()

  private expandedId = generateSimpleID()

  private expanded = false

  private select = (): void => {
    this.selected = !this.selected
    if (this.selected === true) {
      this.isSelected.emit(this)
    }
    if (this.expands === true) {
      this.expanded = !this.expanded
      if (this.expanded === true) {
        this.isExpanded.emit(this)
      }
    }
  }

  render(): JSX.Element {
    const primaryClasses = getClassnames([
      `hrb-option-card`,
      this.selected && `hrb-option-card--selected`,
      `hrb-option-card--${this.theme}`,
      this.disabled && `hrb-option-card--disabled`,
    ])

    const expandedClasses = getClassnames([
      `hrb-option-card--expanded-content`,
      this.expanded
        ? `hrb-option-card--expanded`
        : `hrb-option-card--collapsed`,
    ])

    return (
      <Host selected={this.selected} expands={this.expands} tabindex="0">
        <hrb-card theme={this.theme} class={primaryClasses}>
          <button
            id={this.buttonId}
            aria-expanded={
              this.expands === true ? this.expanded.toString() : ``
            }
            aria-controls={this.expands === true ? this.expandedId : ``}
            disabled={this.disabled}
            tabindex={0}
            onClick={this.select}
          >
            <hrb-card-content class="hrb-option-card--content">
              {!this.custom && (
                <hrb-badge-label
                  badgeTitle={this.badgeTitle}
                  badgeSubtitle={this.badgeSubtitle}
                  size="large"
                  image={this.badgeImage}
                  imageAlt={this.badgeImageAlt}
                  text={this.badgeText}
                  icon={this.badgeIcon}
                  theme={this.badgeTheme}
                ></hrb-badge-label>
              )}
              <slot name="custom" />
              <hrb-circled
                theme={this.selected ? 'ui-green' : 'outline'}
                size="x-small"
              >
                {!this.selected && <hrb-icon name={this.icon}></hrb-icon>}
                {this.selected && (
                  <hrb-icon name={this.selectedIcon}></hrb-icon>
                )}
              </hrb-circled>
            </hrb-card-content>
          </button>

          {this.expands && (
            <div
              id={this.expandedId}
              class={expandedClasses}
              aria-hidden={(!this.expanded).toString()}
              aria-labelledby={this.buttonId}
              role="region"
            >
              <slot />
            </div>
          )}
        </hrb-card>
      </Host>
    )
  }
}
