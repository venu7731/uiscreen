# option-card



<!-- Auto Generated Below -->


## Properties

| Property        | Attribute         | Description | Type                                                                                                                                                                                                                                                                              | Default          |
| --------------- | ----------------- | ----------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------- |
| `badgeIcon`     | `badge-icon`      |             | `any`                                                                                                                                                                                                                                                                             | `null`           |
| `badgeImage`    | `badge-image`     |             | `string`                                                                                                                                                                                                                                                                          | `undefined`      |
| `badgeImageAlt` | `badge-image-alt` |             | `string`                                                                                                                                                                                                                                                                          | `undefined`      |
| `badgeSubtitle` | `badge-subtitle`  |             | `string`                                                                                                                                                                                                                                                                          | `undefined`      |
| `badgeText`     | `badge-text`      |             | `any`                                                                                                                                                                                                                                                                             | `null`           |
| `badgeTheme`    | `badge-theme`     |             | `"blue" \| "dark-green" \| "light-green" \| "light-grey-1" \| "light-grey-2" \| "medium-dark-blue" \| "medium-dark-green" \| "medium-dark-yellow" \| "medium-light-blue" \| "medium-light-green" \| "medium-light-yellow" \| "ui-green" \| "white"`                               | `'light-grey-1'` |
| `badgeTitle`    | `badge-title`     |             | `string`                                                                                                                                                                                                                                                                          | `undefined`      |
| `custom`        | `custom`          |             | `boolean`                                                                                                                                                                                                                                                                         | `false`          |
| `disabled`      | `disabled`        |             | `boolean`                                                                                                                                                                                                                                                                         | `false`          |
| `expands`       | `expands`         |             | `boolean`                                                                                                                                                                                                                                                                         | `false`          |
| `icon`          | `icon`            |             | `string`                                                                                                                                                                                                                                                                          | `'add'`          |
| `selected`      | `selected`        |             | `boolean`                                                                                                                                                                                                                                                                         | `false`          |
| `selectedIcon`  | `selected-icon`   |             | `string`                                                                                                                                                                                                                                                                          | `'check'`        |
| `theme`         | `theme`           |             | `"blue" \| "light-blue" \| "light-green" \| "light-grey-1" \| "light-grey-2" \| "light-yellow" \| "medium-dark-blue" \| "medium-dark-green" \| "medium-dark-yellow" \| "medium-light-blue" \| "medium-light-green" \| "medium-light-yellow" \| "ui-green" \| "white" \| "yellow"` | `undefined`      |


## Events

| Event        | Description | Type               |
| ------------ | ----------- | ------------------ |
| `isExpanded` |             | `CustomEvent<any>` |
| `isSelected` |             | `CustomEvent<any>` |


## Methods

### `selectOption() => Promise<void>`



#### Returns

Type: `Promise<void>`




## Dependencies

### Depends on

- [hrb-card](../../card)
- [hrb-card-content](../../card/card-content)
- [hrb-badge-label](../../badge-label)
- [hrb-circled](../../circled)
- [hrb-icon](../../icon)

### Graph
```mermaid
graph TD;
  hrb-option-card --> hrb-card
  hrb-option-card --> hrb-card-content
  hrb-option-card --> hrb-badge-label
  hrb-option-card --> hrb-circled
  hrb-option-card --> hrb-icon
  hrb-badge-label --> hrb-avatar
  hrb-badge-label --> hrb-text
  hrb-avatar --> hrb-img
  hrb-avatar --> hrb-icon
  hrb-avatar --> hrb-text
  style hrb-option-card fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
