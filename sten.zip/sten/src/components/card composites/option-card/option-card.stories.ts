import * as readme from './readme.md'

export default {
  component: 'hrb-option-card',
  title: 'Cards/Option Card',
  parameters: {
    notes: { markdown: readme },
    actions: {
      handles: [
        {
          isSelected: 'Element is selected (isSelected)',
          isExpanded: 'Element is expanded (isExpanded)',
        },
      ],
    },
  },
  argTypes: {
    expands: { control: 'boolean' },
    selected: { control: 'boolean' },
  },
}

export const Basic = (args): string =>
  `
  <hrb-option-card
  ${!!args.expands && `expands`}
  ${!!args.selected && `selected`}>
    <hrb-text>Any content can go here</hrb-text>
  </hrb-option-card>
  `
Basic.args = {
  expands: true,
  selected: false,
}

export const Expands = (): string =>
  `
  <hrb-option-card
    expands>
    <hrb-text>Any content can go here</hrb-text>
  </hrb-option-card>
  `

export const DefaultSelected = (): string =>
  `
  <hrb-option-card
    selected>
  </hrb-option-card>
  `
