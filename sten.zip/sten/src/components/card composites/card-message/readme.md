# hrb-message-card

<!-- Auto Generated Below -->


## Properties

| Property         | Attribute          | Description                                                                                                                                                                                                                       | Type      | Default                  |
| ---------------- | ------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ------------------------ |
| `attachments`    | --                 | Attachment array Defaults to no attachments                                                                                                                                                                                       | `[]`      | `undefined`              |
| `badgeSubtitle`  | `badge-subtitle`   | Label & Badge: Prop Sub Title                                                                                                                                                                                                     | `string`  | `'Badge Sub Title'`      |
| `badgeTitle`     | `badge-title`      | Label & Badge: Prop Title                                                                                                                                                                                                         | `string`  | `'Badge Title'`          |
| `clientFirstNm`  | `client-first-nm`  | Client First Name                                                                                                                                                                                                                 | `string`  | `'Client First Name'`    |
| `clientLastNm`   | `client-last-nm`   | Client Last Name                                                                                                                                                                                                                  | `string`  | `'Client Last Name'`     |
| `collapsed`      | `collapsed`        | Collapsed defaults to false                                                                                                                                                                                                       | `boolean` | `false`                  |
| `draft`          | `draft`            | Draft Status                                                                                                                                                                                                                      | `boolean` | `false`                  |
| `edit`           | `edit`             | Is the message being edited                                                                                                                                                                                                       | `boolean` | `false`                  |
| `latestMessage`  | `latest-message`   | Latest Message boolean that is false by default. If true, it will change the appearance of the "Reply" action. It is also available should other differences need to be made between the latest/newest message and other messages | `boolean` | `false`                  |
| `messageContent` | `message-content`  | Message Content. This needs to come over with it's whitespace intact. The css will maintain it's linebreaks and spacing.                                                                                                          | `string`  | ````                     |
| `read`           | `read`             | Read Status                                                                                                                                                                                                                       | `boolean` | `false`                  |
| `subject`        | `subject`          | Message Subject Line TODO remove                                                                                                                                                                                                  | `string`  | `'Message Subject Line'` |
| `taxProFirstNm`  | `tax-pro-first-nm` | TaxPro First Name                                                                                                                                                                                                                 | `string`  | `'Tax Pro First Name'`   |
| `taxProLastNm`   | `tax-pro-last-nm`  | TaxPro First Name                                                                                                                                                                                                                 | `string`  | `'Tax Pro Last Name'`    |
| `thumbAlt`       | `thumb-alt`        | Label & Badge: Prop Thumbnail Alt Text                                                                                                                                                                                            | `string`  | `undefined`              |
| `thumbNail`      | `thumb-nail`       | Label & Badge: Prop Thumbnail                                                                                                                                                                                                     | `string`  | `undefined`              |


## Events

| Event           | Description                                                                                                                    | Type               |
| --------------- | ------------------------------------------------------------------------------------------------------------------------------ | ------------------ |
| `addAttachment` | Custom event when the Reply Button is clicked TODO this is currently being done with the file upload input (check with Adrian) | `CustomEvent<any>` |
| `replyEvent`    | Custom event when the Reply Button is clicked                                                                                  | `CustomEvent<any>` |
| `toggleEvent`   | Custom event when the Message Card toggles                                                                                     | `CustomEvent<any>` |


## Methods

### `toggleMessage() => Promise<void>`

Public method to toggle the Message Card

#### Returns

Type: `Promise<void>`




## Dependencies

### Depends on

- [hrb-card](../../card)
- [hrb-card-content](../../card/card-content)
- [hrb-circled](../../circled)
- [hrb-icon](../../icon)
- [hrb-spacer](../../spacer)
- [hrb-circle-button](../../buttons/circle-button)
- [hrb-badge-label](../../badge-label)
- [hrb-text](../../text)
- [hrb-attachment-list](../../attachment-list)
- [hrb-button](../../buttons/button)

### Graph
```mermaid
graph TD;
  hrb-message-card --> hrb-card
  hrb-message-card --> hrb-card-content
  hrb-message-card --> hrb-circled
  hrb-message-card --> hrb-icon
  hrb-message-card --> hrb-spacer
  hrb-message-card --> hrb-circle-button
  hrb-message-card --> hrb-badge-label
  hrb-message-card --> hrb-text
  hrb-message-card --> hrb-attachment-list
  hrb-message-card --> hrb-button
  hrb-circle-button --> hrb-circled
  hrb-badge-label --> hrb-avatar
  hrb-badge-label --> hrb-text
  hrb-avatar --> hrb-img
  hrb-avatar --> hrb-icon
  hrb-avatar --> hrb-text
  hrb-attachment-list --> hrb-attachment-item
  hrb-attachment-list --> hrb-text
  hrb-attachment-item --> hrb-button
  hrb-attachment-item --> hrb-icon
  hrb-button --> hrb-loader
  hrb-button --> hrb-text
  hrb-button --> hrb-icon
  style hrb-message-card fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
