import {
  Component,
  Element,
  Event,
  EventEmitter,
  h,
  Host,
  Method,
  Prop,
  State,
} from '@stencil/core'

import { getClassnames, generateSimpleID } from '@src/utils/misc'

const Constants = {
  baseClassname: 'message-card',
}

@Component({
  tag: 'hrb-message-card',
  styleUrl: 'card-message.scss',
})
export class CardMessage {
  expandableContainer!: HTMLElement

  expandMe!: HTMLElement

  expandedSize = ''

  collapsedSize = ''

  elementID: string = generateSimpleID()

  @Element() el: HTMLElement

  /**
   * Draft Status
   */
  @Prop() draft = false

  /**
   * Draft Status
   * Assicaited State
   */
  @State() isDraft = this.draft

  /**
   * Read Status
   */
  @Prop() read = false

  /**
   * Read Status
   * Associated Sate
   */
  @State() isRead = this.read

  /**
   * Attachment array
   * Defaults to no attachments
   */
  @Prop() attachments: []

  /**
   * Attachment array
   * Associated State
   */
  @State() hasAttachments = !!(this.attachments && this.attachments.length > 0)

  /**
   * Client First Name
   */
  @Prop() clientFirstNm = 'Client First Name'

  /**
   * Client Last Name
   */
  @Prop() clientLastNm = 'Client Last Name'

  /**
   * TaxPro First Name
   */
  @Prop() taxProFirstNm = 'Tax Pro First Name'

  /**
   * TaxPro First Name
   */
  @Prop() taxProLastNm = 'Tax Pro Last Name'

  /**
   * Message Subject Line TODO remove
   */
  @Prop() subject = 'Message Subject Line'

  /**
   * Message Content. This needs to come over with it's whitespace intact.
   * The css will maintain it's linebreaks and spacing.
   */
  @Prop()
  messageContent = ``

  /**
   * Collapsed defaults to false
   */
  @Prop() collapsed = false

  /**
   * Latest Message boolean that is false by default.
   * If true, it will change the appearance of the "Reply" action.
   * It is also available should other differences need to be made
   * between the latest/newest message and other messages
   */
  @Prop() latestMessage = false

  /**
   * Is the message being edited
   */
  @Prop() edit = false

  /**
   * Label & Badge: Prop Title
   */
  @Prop() badgeTitle = 'Badge Title'

  /**
   * Label & Badge: Prop Sub Title
   */
  @Prop() badgeSubtitle = 'Badge Sub Title'

  /**
   * Label & Badge: Prop Thumbnail
   */
  @Prop() thumbNail: string

  /**
   * Label & Badge: Prop Thumbnail Alt Text
   */
  @Prop() thumbAlt: string

  /**
   * Custom event when the Message Card toggles
   */
  @Event() toggleEvent: EventEmitter

  /**
   * Custom event when the Reply Button is clicked
   */
  @Event() replyEvent: EventEmitter

  replyHandler(e): void {
    this.replyEvent.emit(e)
  }

  /**
   * Custom event when the Reply Button is clicked
   * TODO this is currently being done with the file upload input (check with Adrian)
   */
  @Event() addAttachment: EventEmitter

  addAttachmentHandler(e): void {
    this.addAttachment.emit(e)
  }

  /**
   * Public method to toggle the Message Card
   */
  @Method()
  async toggleMessage(): Promise<void> {
    this.toggle()
  }

  /*
  Toggle method called on ComponentDidLoad
  emits the toggleEvent
  */
  private toggle = (): void => {
    this.collapsedSize = this.hasAttachments ? '90px' : '30px'

    if (this.collapsed === false) {
      this.expandableContainer.setAttribute(
        'style',
        `height: ${this.collapsedSize}`,
      )
    } else if (this.collapsed === true) {
      this.expandableContainer.setAttribute(
        'style',
        `height: ${this.expandedSize}`,
      )
    }
    this.collapsed = !this.collapsed
    this.toggleEvent.emit()
  }

  /*
  When the component loads, we load it expanded so that we can
  grab it's full height. This allows us to animate the height.
  We can not animate to an unknown height.

  Note: This will throw a warning in the console because the toggle
  method changes the collapsed property from false to true.
  */
  componentDidLoad(): void {
    this.expandedSize = this.expandableContainer.offsetHeight + 'px'
    this.toggle()
  }

  render(): JSX.Element {
    const classes = getClassnames([
      `${Constants.baseClassname}`,
      !this.collapsed
        ? `${Constants.baseClassname}__open`
        : `${Constants.baseClassname}__closed`,
    ])

    return (
      <Host class={classes}>
        <hrb-card has-boot={!this.collapsed && !this.latestMessage}>
          <hrb-card-content>
            <div class="expand-button">
              <input
                id={
                  this.el.id !== ''
                    ? `${this.el.id}-input`
                    : `${this.elementID}-input`
                }
                class="attachment-button-input"
                type="file"
              ></input>
              <label
                htmlFor={
                  this.el.id !== ''
                    ? `${this.el.id}-input`
                    : `${this.elementID}-input`
                }
                class="attachment-button-label"
                onClick={(e): void => this.addAttachmentHandler(e)}
              >
                <hrb-circled size="small">
                  <hrb-icon name="attachment"></hrb-icon>
                </hrb-circled>
                <span class="hidden">Add attachment</span>
              </label>

              <hrb-spacer d="16"></hrb-spacer>
              <hrb-circle-button
                size="small"
                theme="white"
                p-aria-label={
                  this.collapsed ? 'Expand Message' : 'Collapse Message'
                }
                onClick={(): void => this.toggle()}
              >
                <hrb-icon
                  name={this.collapsed ? 'chevron-down' : 'chevron-up'}
                ></hrb-icon>
              </hrb-circle-button>
            </div>

            <div class="badge-label">
              <hrb-badge-label
                badge-title={this.badgeTitle}
                badge-subtitle={this.badgeSubtitle}
                image={this.thumbNail}
                image-alt={this.thumbAlt}
              ></hrb-badge-label>
            </div>

            <div
              ref={(el: HTMLElement): void => {
                this.expandableContainer = el
              }}
              class="expandable-container"
            >
              <div class="expandable-content">
                <div class="message">
                  <hrb-text>{this.messageContent}</hrb-text>
                </div>
                <div class="attachments">
                  <hrb-attachment-list
                    attachments={this.attachments}
                    collapsed={this.collapsed}
                    edit={this.edit}
                  ></hrb-attachment-list>
                  <slot name="attachments" />
                </div>
                {this.latestMessage && (
                  <div class="reply-button">
                    <hrb-button
                      onClick={(e): void => this.replyHandler(e)}
                      id="replyButton"
                    >
                      Reply
                    </hrb-button>
                  </div>
                )}
              </div>
            </div>
          </hrb-card-content>

          {!this.collapsed && !this.latestMessage && !this.edit ? (
            <div class="message-card__boot" slot="boot">
              <hrb-button
                class="reply-button"
                onClick={(e): void => this.replyHandler(e)}
              >
                <span>
                  Click here to <span class="underline">reply</span>
                </span>
              </hrb-button>
            </div>
          ) : (
            ''
          )}
        </hrb-card>
      </Host>
    )
  }
}
