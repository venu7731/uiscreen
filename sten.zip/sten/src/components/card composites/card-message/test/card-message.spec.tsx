import { newSpecPage } from '@stencil/core/testing'

import { CardMessage } from '../card-message'

describe('card-message', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [CardMessage],
      html: `
      <hrb-message-card id="myCard1" message-content="Dear Adrian">
      </hrb-message-card>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-message-card class="message-card message-card__closed" id="myCard1" message-content="Dear Adrian">
      <hrb-card>
        <hrb-card-content>
          <div class="expand-button">
            <input class="attachment-button-input" id="myCard1-input" type="file">
            <label class="attachment-button-label" htmlfor="myCard1-input">
              <hrb-circled size="small">
                <hrb-icon name="attachment"></hrb-icon>
              </hrb-circled>
              <span class="hidden">
                Add attachment
              </span>
            </label>
            <hrb-spacer d="16"></hrb-spacer>
            <hrb-circle-button p-aria-label="Expand Message" size="small" theme="white">
              <hrb-icon name="chevron-down"></hrb-icon>
            </hrb-circle-button>
          </div>
          <div class="badge-label">
            <hrb-badge-label badge-subtitle="Badge Sub Title" badge-title="Badge Title"></hrb-badge-label>
          </div>
          <div class="expandable-container" style="height: 30px;">
            <div class="expandable-content">
              <div class="message">
                <hrb-text>
                  Dear Adrian
                </hrb-text>
              </div>
              <div class="attachments">
                <hrb-attachment-list collapsed=""></hrb-attachment-list>
              </div>
            </div>
          </div>
        </hrb-card-content>
      </hrb-card>
    </hrb-message-card>
    `)
  })
})
