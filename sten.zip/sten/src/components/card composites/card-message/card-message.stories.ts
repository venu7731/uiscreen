/* eslint-disable no-console */
import { withKnobs, text, boolean, object } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import { reset, attachments } from '@src/constants/storybook'

import * as readme from './readme.md'

const wrapperOpen = `${reset}<div style="padding: 30px; background: #333; display: flex; justify-content: center; position: absolute; top: 0; right: 0; bottom: 0; left: 0;">`
const wrapperClose = `</div>`

const slot = (data): string => {
  return JSON.stringify(data)
}

/* eslint-disable-next-line */
const hrbMessageCard = (
  theAttachments,
  badgeTitle,
  badgeSubtitle,
  messageContent,
  latestMessage,
  edit,
) => `
<div style="width: 100%; max-width: 400px;">
  <hrb-message-card id="myCard1"
    attachments=${slot(theAttachments)}
    badge-title="${badgeTitle}"
    badge-subtitle="${badgeSubtitle}"
    message-content="${messageContent}"
    latest-message="${latestMessage}"
    edit="${edit}">
  </hrb-message-card>
</div>

`

storiesOf('Cards/Message Card', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-message-card'],
    notes: { markdown: readme },
  })
  .add('Message Card', () => {
    return `${wrapperOpen}
    ${hrbMessageCard(
      object('The Array', attachments, 'The Array'),
      text('Badge Title', `Badge Title`, 'Primary'),
      text('Badge Subtitle', `Badge Subtitle`, 'Primary'),
      text('Message Content', `Message Content Here`, 'Primary'),
      boolean('Latest Message', false, 'Primary'),
      boolean('Being Edited', false, 'Primary'),
    )}
    ${wrapperClose}`
  })
