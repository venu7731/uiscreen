import {
  Component,
  Prop,
  h,
  Host,
  Element,
  Event,
  EventEmitter,
} from '@stencil/core'

import { getClassnames } from '@src/utils/misc'

import { THeaderTypes } from './types'

const Constants = {
  baseClassname: 'document-card',
}

@Component({
  tag: 'hrb-card-document',
  styleUrl: 'card-document.scss',
})
export class CardDocument {
  @Element() el!: HTMLElement

  /**
   * Thumb Alt: Note: If there isn't an alt, the thumbnail will not display
   */
  @Prop() thumbAlt = ''

  /**
   * Thumb Src
   */
  @Prop() thumbSrc = ''

  /**
   * Header As
   */
  @Prop() headerAs: THeaderTypes = 'h2'

  /**
   * Header Link: If the header needs to lead somewhere. Note: this is not a button.
   */
  @Prop() headerLink = ''

  /**
   * File Name
   */
  @Prop() fileName = ''

  /**
   * Category Name
   */
  @Prop() categoryName = ''

  /**
   * Added By
   */
  @Prop() addedBy = ''

  /**
   * Upload Date
   */
  @Prop() uploadDate = ''

  /**
   * Set this to true if the document's content is loading. Will put the element into a loading state.
   */
  @Prop() isLoading = false

  /**
   * Layout: This element can take a list-view
   */
  @Prop() layout = ''

  /**
   * Header Clicked: event that fires when the header is clicked. Note: you must set the header-as attribute.
   */
  @Event({
    eventName: 'headerClicked',
    composed: true,
    cancelable: true,
    bubbles: true,
  })
  headerClicked: EventEmitter

  renderHeader = (): JSX.Element => {
    if (this.headerAs === 'a') {
      return (
        <this.headerAs
          href={this.headerLink}
          onClick={this.onHeaderClickHandler}
        >
          {this.fileName}
        </this.headerAs>
      )
    }
    if (this.headerAs === 'button') {
      return (
        <this.headerAs onClick={this.onHeaderClickHandler} role="button">
          {this.fileName}
        </this.headerAs>
      )
    }
    return <this.headerAs>{this.fileName}</this.headerAs>
  }

  onHeaderClickHandler = (): CustomEvent => this.headerClicked.emit(true)

  render(): JSX.Element {
    const {
      thumbAlt,
      thumbSrc,
      categoryName,
      addedBy,
      uploadDate,
      isLoading,
      layout,
      renderHeader,
    } = this

    const classes = getClassnames([
      `${Constants.baseClassname}`,
      layout && `${Constants.baseClassname}__${layout}-layout`,
    ])

    let content = (
      <Host class={classes}>
        <hrb-card>
          <hrb-card-content class={`${Constants.baseClassname}__content`}>
            <div
              class={`${Constants.baseClassname}__thumbnail-filename-categoryname`}
            >
              {thumbAlt && (
                <div class={`${Constants.baseClassname}__thumbnail`}>
                  <hrb-img
                    src={thumbSrc}
                    alt={`${thumbAlt} thumbnail`}
                    height={40}
                    width={40}
                  ></hrb-img>
                </div>
              )}
              <div class={`${Constants.baseClassname}__filename-categoryname`}>
                <div class={`${Constants.baseClassname}__filename`}>
                  {renderHeader()}
                </div>
                <div class={`${Constants.baseClassname}__categoryname`}>
                  <hrb-text as="p">{categoryName}</hrb-text>
                </div>
              </div>
            </div>
            <div class={`${Constants.baseClassname}__addedby-date`}>
              <div class={`${Constants.baseClassname}__addedby`}>
                <hrb-text class="document-card__addedby" as="p">
                  {addedBy}
                </hrb-text>
              </div>
              <div class={`${Constants.baseClassname}__date`}>
                <hrb-text as="p">{uploadDate}</hrb-text>
              </div>
            </div>
          </hrb-card-content>
          <slot></slot>
        </hrb-card>
      </Host>
    )

    if (this.isLoading === true) {
      content = (
        <Host class={classes}>
          <hrb-card class={`loading--${isLoading} document-card`}>
            <hrb-card-content>
              <div class="card-loader">
                <div class="card-loader--placeholders">
                  <span class="card-loader--thumbnail"></span>
                  <span class="card-loader--title"></span>
                  <span class="card-loader--metadata"></span>
                  <div class="card-loader--bottom">
                    <span class="card-loader--bottom-1"></span>
                    <span class="card-loader--bottom-2"></span>
                  </div>
                </div>
                <hrb-loader class="card-document-loader"></hrb-loader>
                <div class="card-loader--actions">
                  <slot name="document-actions"></slot>
                </div>
              </div>
            </hrb-card-content>
          </hrb-card>
        </Host>
      )
    }
    return content
  }
}
