import { newSpecPage } from '@stencil/core/testing'

import { CardDocument } from '../card-document'

describe('Card Document', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [CardDocument],
      html: `
      <hrb-card>
        <hrb-card-content>
          <hrb-text style-type="large">My Card Title</hrb-text>
        </hrb-card-content>
        <div slot="boot">Boot!</div>
      </hrb-card>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-card>
      <hrb-card-content>
        <hrb-text style-type="large">
          My Card Title
        </hrb-text>
      </hrb-card-content>
      <div slot="boot">
        Boot!
      </div>
    </hrb-card>
    `)
  })
})
