# hrb-card-document

`hrb-card-document` is used to communicate a user's uploaded documents. The documents maybe tax documents or notes made about tax preparation.

The `hrb-card-document` can take a loading state represented by setting the boolean value of `is-loading`.

```html
<hrb-card-document
  thumb-src="..."
  thumb-alt="..."
  file-name="..."
  category-name="..."
  added-by="..."
  upload-date="..."
  is-loading="..."
>
  <div slot="overlay-menu">
    <ul>
      <li><a href="#">Link</a></li>
      ...etc...
    </ul>
  </div>
</hrb-card-document>
```

<!-- Auto Generated Below -->


## Properties

| Property       | Attribute       | Description                                                                                       | Type                                                              | Default |
| -------------- | --------------- | ------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------- | ------- |
| `addedBy`      | `added-by`      | Added By                                                                                          | `string`                                                          | `''`    |
| `categoryName` | `category-name` | Category Name                                                                                     | `string`                                                          | `''`    |
| `fileName`     | `file-name`     | File Name                                                                                         | `string`                                                          | `''`    |
| `headerAs`     | `header-as`     | Header As                                                                                         | `"a" \| "button" \| "h1" \| "h2" \| "h3" \| "h4" \| "h5" \| "h6"` | `'h2'`  |
| `headerLink`   | `header-link`   | Header Link: If the header needs to lead somewhere. Note: this is not a button.                   | `string`                                                          | `''`    |
| `isLoading`    | `is-loading`    | Set this to true if the document's content is loading. Will put the element into a loading state. | `boolean`                                                         | `false` |
| `layout`       | `layout`        | Layout: This element can take a list-view                                                         | `string`                                                          | `''`    |
| `thumbAlt`     | `thumb-alt`     | Thumb Alt: Note: If there isn't an alt, the thumbnail will not display                            | `string`                                                          | `''`    |
| `thumbSrc`     | `thumb-src`     | Thumb Src                                                                                         | `string`                                                          | `''`    |
| `uploadDate`   | `upload-date`   | Upload Date                                                                                       | `string`                                                          | `''`    |


## Events

| Event           | Description                                                                                              | Type               |
| --------------- | -------------------------------------------------------------------------------------------------------- | ------------------ |
| `headerClicked` | Header Clicked: event that fires when the header is clicked. Note: you must set the header-as attribute. | `CustomEvent<any>` |


## Dependencies

### Depends on

- [hrb-card](../../card)
- [hrb-card-content](../../card/card-content)
- [hrb-img](../../img)
- [hrb-text](../../text)
- [hrb-loader](../../loader)

### Graph
```mermaid
graph TD;
  hrb-card-document --> hrb-card
  hrb-card-document --> hrb-card-content
  hrb-card-document --> hrb-img
  hrb-card-document --> hrb-text
  hrb-card-document --> hrb-loader
  style hrb-card-document fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
