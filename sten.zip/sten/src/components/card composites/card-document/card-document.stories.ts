import { text, withKnobs, select } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import { reset, htmlElements, groupIds } from '@src/constants/storybook'

import * as readme from './readme.md'

/* eslint-disable-next-line */
const cardDocument = (
  fileName,
  categoryName,
  addedBy,
  headerAs,
  headerLink,
  uploadDate,
  thumbAlt,
  thumbSrc,
) => {
  return `
  <hrb-card-document  
    file-name="${fileName}" 
    category-name="${categoryName}"
    added-by="${addedBy}" 
    header-as="${headerAs}"
    header-link="${headerLink}"
    upload-date="${uploadDate}" 
    thumb-alt="${thumbAlt}" 
    thumb-src="${thumbSrc}">
    <hrb-overflow-menu>
      <hrb-overflow-item label="Item One" action="https://www.google.com"></hrb-overflow-item>
      <hrb-overflow-item label="Item Two" action="https://www.google.com"></hrb-overflow-item>
    </hrb-overflow-menu>
  </hrb-card-document>
  `
}

const wrapperOpen = `${reset}<div style="padding: 30px">`
const wrapperClose = `</div>`

storiesOf('Cards/Document Card', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-card-document'],
    notes: { markdown: readme },
  })
  .add('Document Card', () => {
    return `${wrapperOpen}

    ${cardDocument(
      text('fileName', 'File Name', groupIds.testable),
      text('categoryName', 'Category Name', groupIds.testable),
      text('addedBy', 'Name', groupIds.testable),
      select('headerAs', htmlElements, htmlElements[2], groupIds.testable),
      text('headerLink', 'Header Link', groupIds.testable),
      text('uploadDate', '##/##/####', groupIds.testable),
      text(
        'thumbAlt',
        'Alternative attribute for the thumbnail',
        groupIds.testable,
      ),
      text('thumSrc', 'https://picsum.photos/40', groupIds.testable),
    )}

    ${wrapperClose}`
  })
