import { newSpecPage } from '@stencil/core/testing'

import { HrbCardExpand } from '../card-expandable'

describe('Card Expandable', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbCardExpand],
      html: `
      <hrb-card-expandable id="test"
      theme="medium-light-blue"
      close-icon="calendar">
        <hrb-card-content>
          <hrb-text as="h2"
            style-type="jumbo">Card Title</hrb-text>
          My Content
        </hrb-card-content>
        <div slot="card-expanded">
          <hrb-card-content>
            <hrb-text as="h2"
              style-type="jumbo">Update Your Information</hrb-text>
            <hrb-spacer d="32"></hrb-spacer>
            <hrb-card>
              <hrb-card-content>
                <hrb-text>Some text would go here</hrb-text>
              </hrb-card-content>
            </hrb-card>
          </hrb-card-content>
        </div>
      </hrb-card-expandable>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-card-expandable close-icon="calendar" id="test" theme="medium-light-blue">
      <hrb-card class="hrb-card-expandable" theme="medium-light-blue">
        <button aria-controls="test-accordion-content" aria-expanded="false" class="hrb-card-expandable__container" id="[object Object]">
          <hrb-circled class="hrb-card-expandable__icon" size="small">
            <hrb-icon name="edit"></hrb-icon>
          </hrb-circled>
          <div class="hrb-card-expandable__contracted-content">
            <hrb-card-content>
              <hrb-text as="h2" style-type="jumbo">
                Card Title
              </hrb-text>
              My Content
            </hrb-card-content>
          </div>
        </button>
        <div aria-hidden="true" aria-labelledby="test-accordion-button" class="hrb-card-expandable__expanded" id="test-accordion-content" role="region" style="margin-top: -undefinedpx; height: undefinedpx;">
          <div class="hrb-card-expandable__expanded-container">
            <div slot="card-expanded">
              <hrb-card-content>
                <hrb-text as="h2" style-type="jumbo">
                  Update Your Information
                </hrb-text>
                <hrb-spacer d="32"></hrb-spacer>
                <hrb-card>
                  <hrb-card-content>
                    <hrb-text>
                      Some text would go here
                    </hrb-text>
                  </hrb-card-content>
                </hrb-card>
              </hrb-card-content>
            </div>
          </div>
        </div>
        <hrb-circle-button aria-controls="test-accordion-content" class="hrb-card-expandable__close-button" disabled="" p-aria-controls="test-accordion-content" p-aria-expanded="false" p-aria-label="Close" p-tab-index="0">
          <hrb-icon name="calendar"></hrb-icon>
        </hrb-circle-button>
      </hrb-card>
    </hrb-card-expandable>
    `)
  })
})
