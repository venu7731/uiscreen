# hrb-card-expandable

The `hrb-card-expandable` component is a 2 states card: default, and expanded.
Its original purpose is to allow a user to visualize information in the card default state, then edit them in its expanded state.
A user can toggle those two states by cliking anywhere on the form (default state), or by clicking on the close icon (expanded state).

A card is composed by two main areas (`slot`), representing the two states:

- `header`: Container for the default state
- `expanded`: Container for the expanded state

To keep a consistent header title between the two states, use the `header-text` prop .

```html
<hrb-card-expandable header-text="Employer info">
  <div slot="header">
    <hrb-text>Employer identification number (EIN)</hrb-text>
    <hrb-text>12-3456789</hrb-text>
  </div>
  <div slot="expanded">
    <form method="post" action="/employer-info">
      <hrb-input
        label="Employer identification number (EIN)"
        value="12-3456789"
      ></hrb-input>
    </form>
  </div>
</hrb-card-expandable>
```

## Examples

The component generates automatically a button icon on top right corner using the `hrb-circled` component. This icon is editable with the `icon` prop.
By default, it uses the `edit` icon.

```html
<hrb-card-expandable header-text="Edit Document" icon="documents">
  <!-- rest of the card --->
</hrb-card-expandable>
```

---

By default, the card has a fixed width per breakpoints. It's possible to adjust the size so the card takes the full width of its container with the `full-width` prop.

```html
<hrb-card-expandable header-text="Employer Document" full-width>
  <!-- rest of the card --->
</hrb-card-expandable>
```

---

You can change the header tag using the `header-as` prop. By default, it generates an `h3`

```html
<hrb-card-expandable header-text="Employer Document" header-as="h2">
  <!-- rest of the card --->
</hrb-card-expandable>
```

## Event Examples

We've added some custom events to allow developers to have control over every state of the card
Every custom event returns a reference to element, available in `e.detail`.

```js
const formCard = document.querySelector('hrb-card-expandable')

// When the card goes from default to expanded state (open)
formCard.addEventListener('hrbOpen', e => {
  console.log('opened', e.detail)
})

// When the card goes from expanded back to default state (close)
formCard.addEventListener('hrbClose', e => {
  console.log('closed', e.detail)
})
```

## Method Examples

Every exposed methods return a `Promise`.

```js
const formCard = document.querySelector('hrb-card-expandable')

// open the card
await formCard.open()

// close the card
await formCard.close()
```

<!-- Auto Generated Below -->


## Properties

| Property    | Attribute    | Description                       | Type     | Default     |
| ----------- | ------------ | --------------------------------- | -------- | ----------- |
| `closeIcon` | `close-icon` | The icon of the close button area | `string` | `'close'`   |
| `icon`      | `icon`       | The icon of the tappable area     | `string` | `'edit'`    |
| `theme`     | `theme`      | Basic Themes                      | `any`    | `undefined` |


## Events

| Event      | Description                                                          | Type               |
| ---------- | -------------------------------------------------------------------- | ------------------ |
| `hrbClose` | When the <hrb-card-expandable> contracts, the 'hrbClose' event fires | `CustomEvent<any>` |
| `hrbOpen`  | When the <hrb-card-expandable> epxands, the 'hrbOpen' event fires    | `CustomEvent<any>` |


## Methods

### `close() => Promise<void>`

Toggles the <hrb-expandable-card> to an `isOpen = false` state

#### Returns

Type: `Promise<void>`



### `controlHeight() => Promise<void>`

Allows child elements that change height (such as an <hrb-accordion>) to
determine the height of the .hrb-card-expandable__expanded child element
of <hrb-card-expandable>.

This method will be used on the child elements height-changing trigger.

Some examples include:
``"<hrb-accordion-item (click)="controlHeight()">"`,
`"<hrb-button (click)="controlHeight()">"`

#### Returns

Type: `Promise<void>`



### `open() => Promise<void>`

Toggles the <hrb-expandable-card> to an `isOpen = true` state

#### Returns

Type: `Promise<void>`




## Dependencies

### Depends on

- [hrb-circled](../../circled)
- [hrb-icon](../../icon)
- [hrb-card](../../card)
- [hrb-circle-button](../../buttons/circle-button)

### Graph
```mermaid
graph TD;
  hrb-card-expandable --> hrb-circled
  hrb-card-expandable --> hrb-icon
  hrb-card-expandable --> hrb-card
  hrb-card-expandable --> hrb-circle-button
  hrb-circle-button --> hrb-circled
  style hrb-card-expandable fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
