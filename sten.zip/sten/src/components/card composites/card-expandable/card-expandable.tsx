import {
  Component,
  Element,
  Event,
  EventEmitter,
  h,
  Listen,
  Method,
  Prop,
  State,
} from '@stencil/core'

import { generateSimpleID, getClassnames } from '@src/utils/misc'

const Constants = {
  baseClassname: 'hrb-card-expandable',
}

@Component({
  tag: 'hrb-card-expandable',
  styleUrl: 'card-expandable.scss',
})
export class HrbCardExpand {
  hrbCardExpandable!: HTMLElement

  closeButton!: HTMLElement

  openButton!: HTMLElement

  expandedContent!: HTMLElement

  contractedContent!: HTMLElement

  elementID: string = generateSimpleID()

  private containerAs = 'button'

  @Element() el: HTMLElement

  /**
   * The icon of the tappable area
   */
  @Prop() icon?: string = 'edit'

  /**
   * The icon of the close button area
   */
  @Prop() closeIcon?: string = 'close'

  /**
   * Basic Themes
   */
  @Prop() theme

  /**
   * Set defaults for states: expandedContentHeight | headerContentHeight | isOpen | hasBeenOpened
   */

  @State() state = {
    expandedContentHeight: 0,
    headerContentHeight: 0,
    isOpen: false,
    hasBeenOpened: false,
  }

  /**
   * When the <hrb-card-expandable> epxands, the 'hrbOpen' event fires
   */

  @Event() hrbOpen: EventEmitter

  /**
   * When the <hrb-card-expandable> contracts, the 'hrbClose' event fires
   */

  @Event() hrbClose: EventEmitter

  // Emits when the card opens or closes (expands or contracts)
  cardToggledHandler = (): void => {
    const { hrbClose, hrbOpen, state } = this
    const openOrCloseEvent = state.isOpen ? hrbOpen : hrbClose

    openOrCloseEvent.emit(this)
  }

  /**
   * When the window resizes, the height of the <hrb-expandable-card__expanded> will update
   */

  @Listen('resize', { target: 'window' })
  handleResize(): void {
    this.updateHeightStates()
  }

  /**
   * Toggles the <hrb-expandable-card> to an `isOpen = false` state
   */

  @Method()
  async close(): Promise<void> {
    this.toggleIsOpen(false)
  }

  /**
   * Toggles the <hrb-expandable-card> to an `isOpen = true` state
   */

  @Method()
  async open(): Promise<void> {
    this.toggleIsOpen(true)
  }

  /**
   * Allows child elements that change height (such as an <hrb-accordion>) to
   * determine the height of the .hrb-card-expandable__expanded child element
   * of <hrb-card-expandable>.
   *
   * This method will be used on the child elements height-changing trigger.
   *
   * Some examples include:
   * ``"<hrb-accordion-item (click)="controlHeight()">"`,
   * `"<hrb-button (click)="controlHeight()">"`
   */

  @Method()
  async controlHeight(): Promise<void> {
    const targetElm = document.getElementsByClassName(
      'hrb-card-expandable__expanded',
    )[0] as HTMLElement

    targetElm.style.height = 'auto'
  }

  // Updates the state of isOpen, updates general state, emits an event
  // of open or close, sets focus
  private toggleIsOpen = (newIsOpen): void => {
    const { closeButton, openButton, state } = this
    const isOpen = typeof newIsOpen === 'boolean' ? newIsOpen : !state.isOpen

    this.state = { ...state, isOpen, hasBeenOpened: true }

    this.cardToggledHandler()

    const elementToFocus = this.state.isOpen
      ? closeButton.querySelector('button')
      : openButton

    setTimeout(() => elementToFocus.focus(), 0)
  }

  // Gets height before the element expands
  private getContractedContentHeight = (): number =>
    this.contractedContent.clientHeight

  // Gets height after the element expands
  private getExpandedContentHeight = (): number =>
    this.expandedContent.clientHeight

  // Gets called on window resize, and certain lifecycle events to get update
  // the height of the elements
  private updateHeightStates = (): void => {
    const { getExpandedContentHeight, getContractedContentHeight, state } = this
    const headerContentHeight = getContractedContentHeight()
    const expandedContentHeight = getExpandedContentHeight()

    this.state = { ...state, headerContentHeight, expandedContentHeight }
  }

  renderIcon = (): JSX.Element => {
    return (
      <hrb-circled size="small" class={`${Constants.baseClassname}__icon`}>
        <hrb-icon name={this.icon}></hrb-icon>
      </hrb-circled>
    )
  }

  // This method renders the .hrb-card-expandable__expanded element
  renderContent = ({ buttonID, contentID }): JSX.Element => {
    const { state } = this
    const { expandedContentHeight, headerContentHeight, isOpen } = state
    const { baseClassname } = Constants

    const contentStyle = {
      marginTop: `-${headerContentHeight}px`,
      height: isOpen
        ? `${expandedContentHeight}px`
        : `${headerContentHeight}px`,
    }

    return (
      <div
        class={`${baseClassname}__expanded`}
        style={contentStyle}
        id={contentID}
        aria-hidden={(!isOpen).toString()}
        aria-labelledby={buttonID}
        role="region"
      >
        <div
          class={`${baseClassname}__expanded-container`}
          ref={(el: HTMLElement): void => {
            this.expandedContent = el
          }}
        >
          <slot name="card-expanded"></slot>
        </div>
      </div>
    )
  }

  componentDidLoad(): void {
    this.updateHeightStates()
  }

  // this is needed for when a card uses the <hrb-image> with lazy loading
  componentWillUpdate(): void {
    this.updateHeightStates()
  }

  render(): JSX.Element {
    const {
      elementID,
      renderContent,
      renderIcon,
      closeIcon,
      state,
      toggleIsOpen,
      theme,
    } = this
    const { baseClassname } = Constants
    const { isOpen, hasBeenOpened } = state

    const classes = getClassnames([
      `${baseClassname}`,
      isOpen && `${baseClassname}--open`,
      hasBeenOpened && `${baseClassname}--has-been-opened`,
    ])

    const buttonID = `${
      this.el.id !== ''
        ? `${this.el.id}-accordion-button`
        : `${elementID}-accordion-button`
    }`

    const contentID = `${
      this.el.id !== ''
        ? `${this.el.id}-accordion-content`
        : `${elementID}-accordion-content`
    }`
    const containerProps = {
      'aria-controls': contentID,
      'aria-expanded': isOpen.toString(),
      disabled: isOpen,
      id: { buttonID },
      onClick: toggleIsOpen,
    }

    return (
      <hrb-card
        ref={(el: HTMLElement): void => {
          this.hrbCardExpandable = el
        }}
        class={classes}
        theme={theme}
      >
        <this.containerAs
          {...containerProps}
          ref={(el: HTMLElement): void => {
            this.openButton = el
          }}
          class={`${baseClassname}__container`}
        >
          {renderIcon()}
          <div
            class={`${baseClassname}__contracted-content`}
            ref={(el: HTMLElement): void => {
              this.contractedContent = el
            }}
          >
            <slot></slot>
          </div>
        </this.containerAs>
        {renderContent({ buttonID, contentID })}
        <hrb-circle-button
          p-aria-expanded={isOpen.toString()}
          disabled={!isOpen}
          p-tab-index={0}
          aria-controls={contentID}
          p-aria-controls={contentID}
          p-aria-label="Close"
          class={`${baseClassname}__close-button`}
          onClick={toggleIsOpen}
          ref={(el: HTMLElement): void => {
            this.closeButton = el
          }}
        >
          <hrb-icon name={closeIcon}></hrb-icon>
        </hrb-circle-button>
      </hrb-card>
    )
  }
}
