import { select, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import { formCardCalloutThemes, reset } from '@src/constants/storybook'

import icons from '@src/constants/icons'

import * as readme from './readme.md'

const slot = `
  <div>
    <hrb-text as="h2" class="mb-sp-32 pl-sp-32" style-type="small">Employment Information</hrb-text>
    <hrb-data-item class="mb-sp-16" term="Tax Id"
      def="1234567">
    </hrb-data-item> 
    <hrb-data-item class="mb-sp-16" term="Employee Id"
      def="89101112">
    </hrb-data-item> 
    <hrb-data-item term="Employer"
      def="H&R Block">
    </hrb-data-item> 
  </div>
  `
const expandedSlot = `
<div class="pt-sp-32">
  <hrb-text as="h2" class="mb-sp-32" style-type="small">Edit Employment Information</hrb-text>
  <hrb-input class="mb-sp-16" label="Employer" value="H&R Block">
  <hrb-input class="mb-sp-16" label="Employee Id" value="89101112">
  <hrb-input class="mb-sp-16" label="Tax Id" value="1234567">
</div>
`

/* eslint-disable-next-line */
const formCard = (icon, theme) =>
  `<hrb-card-expandable
    theme="${theme}
    icon="${icon}">
    <hrb-card-content>
    ${slot}
    </hrb-card-content>
    <div slot="card-expanded">
        ${expandedSlot}
    </div>
  </hrb-card-expandable>`

const wrapperOpen = `${reset}<div style="padding: 30px">`
const wrapperClose = `</div>`

storiesOf('Cards/Expandable Card', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-card-expandable'],
    notes: { markdown: readme },
  })
  .add('Card Expandable', () => {
    return `${wrapperOpen}

    ${formCard(
      select('Icon', icons, icons[0]),
      select('Theme', formCardCalloutThemes, formCardCalloutThemes[0]),
    )}

    ${wrapperClose}`
  })
