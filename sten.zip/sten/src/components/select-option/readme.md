# hrb-select-option

<!-- Auto Generated Below -->


## Properties

| Property                       | Attribute                         | Description                                    | Type                                                                            | Default     |
| ------------------------------ | --------------------------------- | ---------------------------------------------- | ------------------------------------------------------------------------------- | ----------- |
| `baseId`                       | `base-id`                         | ID applied to option                           | `string`                                                                        | `undefined` |
| `currentlyFocusedOptionIndex`  | `currently-focused-option-index`  | Index of the option that is currently in focus | `number`                                                                        | `undefined` |
| `currentlySelectedOptionIndex` | `currently-selected-option-index` | Index of the option that is currently selected | `number`                                                                        | `undefined` |
| `index`                        | `index`                           | Index of this option                           | `number`                                                                        | `undefined` |
| `option`                       | --                                | Object that represents this option             | `{ isOptGroup?: boolean; isSelected?: boolean; text: string; value?: string; }` | `undefined` |


## Events

| Event              | Description | Type               |
| ------------------ | ----------- | ------------------ |
| `optionClick`      |             | `CustomEvent<any>` |
| `optionMouseEnter` |             | `CustomEvent<any>` |


## Dependencies

### Used by

 - [hrb-select-custom](../select-custom)

### Depends on

- [hrb-icon](../icon)

### Graph
```mermaid
graph TD;
  hrb-select-option --> hrb-icon
  hrb-select-custom --> hrb-select-option
  style hrb-select-option fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
