import { Component, Event, EventEmitter, h, Host, Prop } from '@stencil/core'

import { TOptionListObject } from '../select/types'
import Constants from '../select/constants'

@Component({
  tag: 'hrb-select-option',
  styleUrl: 'select-option.scss',
})
export class SelectOption {
  /**
   * ID applied to option
   */
  @Prop() baseId: string

  /**
   * Index of the option that is currently in focus
   */
  @Prop() currentlyFocusedOptionIndex: number

  /**
   * Index of the option that is currently selected
   */
  @Prop() currentlySelectedOptionIndex: number

  /**
   * Index of this option
   */
  @Prop() index: number

  /**
   * Value attribute of option, could be different than text value
   */

  /**
   * Object that represents this option
   */
  @Prop() option: TOptionListObject

  @Event() optionClick: EventEmitter

  @Event() optionMouseEnter: EventEmitter

  private optionCount = this.index + 1

  handleOnClick = (): void => {
    const { optionClick, optionCount } = this

    optionClick.emit(optionCount)
  }

  handleOnMouseEnter = (event: MouseEvent): void => {
    const { currentlyFocusedOptionIndex, optionMouseEnter, optionCount } = this
    const { clientX, clientY } = event

    if (currentlyFocusedOptionIndex === optionCount) return

    const emitObject = {
      clientX,
      clientY,
      optionCount,
    }

    optionMouseEnter.emit(emitObject)
  }

  render(): JSX.Element {
    const {
      baseId,
      currentlyFocusedOptionIndex,
      currentlySelectedOptionIndex,
      option,
      optionCount,
    } = this

    const { baseClassnameOption } = Constants
    const { text, value } = option

    const iconBaseClassname = `${baseClassnameOption}__icon`
    const optionId = `${baseId}__option-${optionCount}`

    const isCurrentlyFocused = currentlyFocusedOptionIndex === optionCount
    const isCurrentlySelected =
      currentlySelectedOptionIndex &&
      currentlySelectedOptionIndex === optionCount

    return (
      <Host class={`${baseClassnameOption}__host`}>
        <div
          aria-selected={isCurrentlyFocused ? 'true' : 'false'}
          class={`${baseClassnameOption}__item ${
            isCurrentlyFocused ? `${baseClassnameOption}__item--is-active` : ''
          }`}
          id={optionId}
          role="option"
        >
          <button
            class={`${baseClassnameOption}__item-button`}
            data-value={value}
            id={`${baseId}__option-button-${optionCount}`}
            onClick={this.handleOnClick}
            onMouseEnter={this.handleOnMouseEnter}
            tabindex={-1}
            type="button"
          >
            {text}

            {isCurrentlySelected && (
              <span class={`${iconBaseClassname}-container`}>
                <hrb-icon class={iconBaseClassname} name={'check'}></hrb-icon>
              </span>
            )}
          </button>
        </div>
      </Host>
    )
  }
}
