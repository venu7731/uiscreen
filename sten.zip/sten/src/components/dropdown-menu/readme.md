# hrb-dropdown-menu

<!-- Auto Generated Below -->


## Properties

| Property       | Attribute       | Description                                         | Type      | Default          |
| -------------- | --------------- | --------------------------------------------------- | --------- | ---------------- |
| `multiselect`  | `multiselect`   | Can have multiple children selected                 | `boolean` | `false`          |
| `triggerValue` | `trigger-value` | Trigger value (the text lable for the main trigger) | `string`  | `'Menu Trigger'` |


## Events

| Event      | Description                                                          | Type               |
| ---------- | -------------------------------------------------------------------- | ------------------ |
| `hrbClose` | When the <hrb-card-expandable> contracts, the 'hrbClose' event fires | `CustomEvent<any>` |
| `hrbOpen`  | When the <hrb-card-expandable> epxands, the 'hrbOpen' event fires    | `CustomEvent<any>` |


## Dependencies

### Depends on

- [hrb-button](../buttons/button)

### Graph
```mermaid
graph TD;
  hrb-dropdown-menu --> hrb-button
  hrb-button --> hrb-loader
  hrb-button --> hrb-text
  hrb-button --> hrb-icon
  style hrb-dropdown-menu fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
