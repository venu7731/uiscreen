import * as readme from './readme.md'

export default {
  component: 'hrb-message-card',
  title: 'Drop Down Menu',
  parameters: {
    actions: {
      handles: ['menuItemClicked', 'hrbOpen', 'hrbClose'],
    },
    notes: { markdown: readme },
  },
}

export const MenuItem = (): string =>
  `
  <hrb-global reset></hrb-global>

    <hrb-dropdown-menu-item
        name="myMenu"
        value="2020"
        type="checkbox"
    ></hrb-dropdown-menu-item>
`

export const ListSingleSelect = (): string =>
  `
  <hrb-global reset></hrb-global>

  <hrb-dropdown-menu trigger-value="Base">
    <hrb-dropdown-menu-item
      name="myMenu"
      value="2020"
      type="checkbox"
    ></hrb-dropdown-menu-item>
    <hrb-dropdown-menu-item
      name="myMenu"
      value="2021"
      type="checkbox"
    ></hrb-dropdown-menu-item>
    <hrb-dropdown-menu-item
      name="myMenu"
      value="2022"
      type="checkbox"
    ></hrb-dropdown-menu-item>
  </hrb-dropdown-menu>`

export const ListMultiSelect = (): string =>
  `
  <hrb-global reset></hrb-global>
  
  <hrb-dropdown-menu multiselect trigger-value="Multiselect">
    <hrb-dropdown-menu-item
      name="myMenu"
      value="2020"
      type="checkbox"
    ></hrb-dropdown-menu-item>
    <hrb-dropdown-menu-item
      name="myMenu"
      value="2021"
      type="checkbox"
    ></hrb-dropdown-menu-item>
    <hrb-dropdown-menu-item
      name="myMenu"
      value="2022"
      type="checkbox"
    ></hrb-dropdown-menu-item>
  </hrb-dropdown-menu>`
