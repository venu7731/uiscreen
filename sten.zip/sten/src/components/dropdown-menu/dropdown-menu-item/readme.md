# hrb-dropdown-menu-item

<!-- Auto Generated Below -->


## Properties

| Property        | Attribute         | Description | Type                    | Default     |
| --------------- | ----------------- | ----------- | ----------------------- | ----------- |
| `PAriaSelected` | `p-aria-selected` |             | `boolean`               | `false`     |
| `elementId`     | `element-id`      |             | `string`                | `''`        |
| `name`          | `name`            |             | `string`                | `'options'` |
| `role`          | `role`            |             | `string`                | `'option'`  |
| `type`          | `type`            |             | `"checkbox" \| "radio"` | `'radio'`   |
| `value`         | `value`           |             | `string`                | `'2020'`    |


## Events

| Event             | Description | Type               |
| ----------------- | ----------- | ------------------ |
| `menuItemClicked` |             | `CustomEvent<any>` |


## Dependencies

### Depends on

- [hrb-icon](../../icon)

### Graph
```mermaid
graph TD;
  hrb-dropdown-menu-item --> hrb-icon
  style hrb-dropdown-menu-item fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
