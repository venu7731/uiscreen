import { newSpecPage } from '@stencil/core/testing'

import { HrbDropdownMenuItem } from '../dropdown-menu-item'

describe('dropdown-menu-item', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbDropdownMenuItem],
      html: `<dropdown-menu-item></dropdown-menu-item>`,
    })
    expect(page.root).toEqualHtml(`<dropdown-menu-item></dropdown-menu-item>`)
  })
})
