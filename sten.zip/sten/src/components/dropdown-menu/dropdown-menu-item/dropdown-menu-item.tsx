/* eslint-disable no-console */
/* eslint-disable no-alert */
import { Component, Element, Event, EventEmitter, h, Prop } from '@stencil/core'

import { generateSimpleID } from '@src/utils/misc'

@Component({
  tag: 'hrb-dropdown-menu-item',
  styleUrl: 'dropdown-menu-item.scss',
})
export class HrbDropdownMenuItem {
  elementID: string = generateSimpleID()

  @Element() el: HTMLElement

  @Prop() PAriaSelected = false

  @Prop() elementId = ''

  @Prop() name = 'options'

  @Prop() role = 'option'

  @Prop() type: 'checkbox' | 'radio' = 'radio'

  @Prop() value = '2020'

  @Event() menuItemClicked: EventEmitter

  private selectItem = (): void => {
    this.PAriaSelected = !this.PAriaSelected
    this.menuItemClicked.emit()
  }

  render(): JSX.Element {
    return (
      <div class="dropdown-item">
        <input
          aria-selected={this.PAriaSelected}
          id={this.el.id !== '' ? this.el.id : this.elementID}
          class="dropdown-item--input"
          name={this.name}
          onClick={this.selectItem}
          role={this.role}
          type={this.type}
          value={this.value}
        />
        <label class="dropdown-item--label" htmlFor={this.elementID}>
          {this.value}
          <div class="selected-check">
            <hrb-icon name="check"></hrb-icon>
          </div>
        </label>
      </div>
    )
  }
}
