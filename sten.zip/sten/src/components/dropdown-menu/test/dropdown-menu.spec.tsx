import { newSpecPage } from '@stencil/core/testing'

import { HrbDropdownMenu } from '../dropdown-menu'

describe('Dropdown Menu', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbDropdownMenu],
      html: `<hrb-dropdown-menu id="test"></hrb-dropdown-menu>`,
    })
    expect(page.root).toEqualHtml(`
    <hrb-dropdown-menu id="test">
      <div class="dropdown">
        <hrb-button aria-expanded="false" aria-haspopup="true" aria-labelledby="trigger-label" icon="chevron-down" id="test" secondary="">
          <span class="trigger-label" id="trigger-label">
            Choose an option:
          </span>
          Menu Trigger
        </hrb-button>
        <fieldset aria-hidden="true" aria-labelledby="test" class="dropdown-menu dropdown-menu--hasNotOpened"></fieldset>
      </div>
    </hrb-dropdown-menu>
    `)
  })
})
