/* eslint-disable no-console */
/* eslint-disable no-alert */
import {
  Component,
  State,
  h,
  Element,
  Event,
  EventEmitter,
  Listen,
  Prop,
} from '@stencil/core'

import { generateSimpleID, getClassnames } from '@src/utils/misc'

@Component({
  tag: 'hrb-dropdown-menu',
  styleUrl: 'dropdown-menu.scss',
})
export class HrbDropdownMenu {
  elementID: string = generateSimpleID()

  toggleButton!: HTMLElement

  firstItem!: HTMLElement

  menuContainer!: HTMLElement

  @Element() el: HTMLElement

  /**
   * Trigger value (the text lable for the main trigger)
   */
  @Prop() triggerValue = 'Menu Trigger'

  /**
   * Can have multiple children selected
   */
  @Prop() multiselect = false

  /**
   * Set defaults for states: isOpen | hasBeenOpened
   */
  @State() state = {
    isOpen: false,
    hasBeenOpened: false,
    selectedOptions: [],
  }

  /**
   * When the <hrb-card-expandable> epxands, the 'hrbOpen' event fires
   */
  @Event() hrbOpen: EventEmitter

  /**
   * When the <hrb-card-expandable> contracts, the 'hrbClose' event fires
   */
  @Event() hrbClose: EventEmitter

  private menuOpenHandler = (): void => {
    const { hrbClose, hrbOpen, state } = this
    const openOrCloseEvent = state.isOpen ? hrbOpen : hrbClose
    openOrCloseEvent.emit(this)
  }

  private toggleIsOpen = (newIsOpen): void => {
    const { state } = this
    const isOpen = typeof newIsOpen === 'boolean' ? newIsOpen : !state.isOpen

    if (this.state.isOpen === true && this.state.hasBeenOpened === true) {
      console.log(this.state.isOpen + 'Setting display none')
      setTimeout(() => {
        this.menuContainer.style.display = 'none'
      }, 750)
    } else if (this.state.isOpen === false) {
      console.log(this.state.isOpen + 'Setting display block')
      setTimeout(() => {
        this.menuContainer.style.display = 'block'
      }, 0)
    }

    this.state = { ...state, isOpen, hasBeenOpened: true }
    this.menuOpenHandler()
  }

  private makeLabel = (): void => {
    this.state.selectedOptions.push(this.triggerValue)
  }

  @Listen('menuItemClicked') updateValue(e): void {
    const currentOptions = this.state.selectedOptions
    if (this.multiselect && e.target.PAriaSelected === true) {
      this.state.selectedOptions.push(e.target.value)
      this.triggerValue =
        currentOptions.length === 0
          ? this.triggerValue
          : currentOptions.join(' , ')

      console.log(this.state.selectedOptions)
    } else if (e.target.PAriaSelected === false) {
      const index = currentOptions.indexOf(e.target.value)
      if (index > -1) {
        currentOptions.splice(index, 1)
      }
      this.triggerValue =
        currentOptions.length === 0
          ? this.triggerValue
          : currentOptions.join(' , ')
    }
    if (this.multiselect === false) {
      this.triggerValue = e.target.value
      this.toggleIsOpen(false)
    }
  }

  componentDidLoad(): void {
    this.makeLabel()
  }

  render(): JSX.Element {
    const classes = getClassnames([
      `dropdown-menu`,
      this.state.hasBeenOpened
        ? `dropdown-menu--hasOpened`
        : 'dropdown-menu--hasNotOpened',
    ])

    return (
      <div class="dropdown">
        <hrb-button
          secondary
          icon={this.state.isOpen ? `chevron-up` : `chevron-down`}
          id={this.el.id !== '' ? this.el.id : this.elementID}
          aria-haspopup="true"
          aria-expanded={this.state.isOpen.toString()}
          aria-labelledby="trigger-label"
          onClick={this.toggleIsOpen}
          ref={(el: HTMLElement): void => {
            this.toggleButton = el
          }}
        >
          <span class="trigger-label" id="trigger-label">
            Choose an option:
          </span>
          {this.triggerValue}
        </hrb-button>
        <fieldset
          class={classes}
          aria-hidden={(!this.state.isOpen).toString()}
          aria-labelledby={this.el.id !== '' ? this.el.id : this.elementID}
          ref={(el: HTMLElement): void => {
            this.menuContainer = el
          }}
        >
          <slot />
        </fieldset>
      </div>
    )
  }
}
