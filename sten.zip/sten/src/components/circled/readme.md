# hrb-circled

<!-- Auto Generated Below -->


## Properties

| Property | Attribute | Description                                                                 | Type                                                                                                                                                                                                                                                     | Default     |
| -------- | --------- | --------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------- |
| `size`   | `size`    | Sets circle to, x-small, small, medium or large variety (defaults to small) | `"large" \| "medium" \| "small" \| "x-small"`                                                                                                                                                                                                            | `'small'`   |
| `theme`  | `theme`   | Applies color theme                                                         | `"blue" \| "default" \| "light-grey-1" \| "light-grey-2" \| "medium-dark-blue" \| "medium-dark-green" \| "medium-dark-yellow" \| "medium-light-blue" \| "medium-light-green" \| "medium-light-yellow" \| "outline" \| "ui-green" \| "white" \| "yellow"` | `undefined` |


## Dependencies

### Used by

 - [hrb-accordion-item](../accordion-item)
 - [hrb-card-expandable](../card composites/card-expandable)
 - [hrb-circle-button](../buttons/circle-button)
 - [hrb-circle-button-with-label](../buttons/circle-button-with-label)
 - [hrb-list-button](../buttons/list-button)
 - [hrb-message-card](../card composites/card-message)
 - [hrb-nav-bar](../nav-bar)
 - [hrb-option-card](../card composites/option-card)
 - [hrb-toggle](../toggle)
 - [hrb-video](../video)

### Graph
```mermaid
graph TD;
  hrb-accordion-item --> hrb-circled
  hrb-card-expandable --> hrb-circled
  hrb-circle-button --> hrb-circled
  hrb-circle-button-with-label --> hrb-circled
  hrb-list-button --> hrb-circled
  hrb-message-card --> hrb-circled
  hrb-nav-bar --> hrb-circled
  hrb-option-card --> hrb-circled
  hrb-toggle --> hrb-circled
  hrb-video --> hrb-circled
  style hrb-circled fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
