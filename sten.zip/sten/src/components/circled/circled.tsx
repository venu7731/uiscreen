import { Component, h, Host, Prop } from '@stencil/core'

import { getClassnames } from '@src/utils/misc'

import { TCircledThemes, TCircledSizes } from './types'

const Constants = {
  baseClassname: 'hrb-circled',
}

@Component({
  tag: 'hrb-circled',
  styleUrl: 'circled.scss',
})
export class HrbCircled {
  /**
   * Sets circle to, x-small, small, medium or large variety (defaults to small)
   */
  @Prop() size: TCircledSizes = 'small'

  /**
   * Applies color theme
   */
  @Prop() theme: TCircledThemes

  render(): JSX.Element {
    const classes = getClassnames([`${Constants.baseClassname}`])

    return (
      <Host class={classes} theme={this.theme} size={this.size}>
        <slot />
      </Host>
    )
  }
}
