import * as readme from './readme.md'

export default {
  component: 'hrb-circled',
  title: 'Circle + Icon',
  parameters: {
    notes: { markdown: readme },
  },
}

export const CircleIconSizes = (): string =>
  `
<hrb-global reset></hrb-global>
<hrb-layout layout='4col'>
  <div>
  <hrb-label theme="tooltip">x-small</hrb-label>
  <hrb-spacer d="16"></hrb-spacer>
    <hrb-circled theme="ui-green" size="x-small">
      <hrb-icon name="heart"></hrb-icon>
    </hrb-circled>
  </div>
  <div>
  <hrb-label theme="tooltip">small</hrb-label>
  <hrb-spacer d="16"></hrb-spacer>
    <hrb-circled theme="ui-green" size="small">
      <hrb-icon name="heart"></hrb-icon>
    </hrb-circled>
  </div>
  <div>
  <hrb-label theme="tooltip">medium</hrb-label>
  <hrb-spacer d="16"></hrb-spacer>
    <hrb-circled theme="ui-green" size="medium">
      <hrb-icon name="heart"></hrb-icon>
    </hrb-circled>
  </div>
  <div>
  <hrb-label theme="tooltip">large</hrb-label>
  <hrb-spacer d="16"></hrb-spacer>
    <hrb-circled theme="ui-green" size="large">
      <hrb-icon name="heart"></hrb-icon>
    </hrb-circled>
  </div>
</hrb-layout>

`
export const CircleIconThemes = (): string =>
  `
<hrb-global reset></hrb-global>
<hrb-layout layout='4col'>
  <div>
  <hrb-label theme="tooltip">default</hrb-label>
  <hrb-spacer d="16"></hrb-spacer>
    <hrb-circled theme="default" size="medium">
      <hrb-icon name="heart"></hrb-icon>
    </hrb-circled>
  </div>
  <div>
  <hrb-label theme="tooltip">outline</hrb-label>
  <hrb-spacer d="16"></hrb-spacer>
    <hrb-circled theme="outline" size="medium">
      <hrb-icon name="heart"></hrb-icon>
    </hrb-circled>
  </div>
  <div>
  <hrb-label theme="tooltip">blue</hrb-label>
  <hrb-spacer d="16"></hrb-spacer>
    <hrb-circled theme="blue" size="medium">
      <hrb-icon name="heart"></hrb-icon>
    </hrb-circled>
  </div>
  <div>
  <hrb-label theme="tooltip">light-grey-1</hrb-label>
  <hrb-spacer d="16"></hrb-spacer>
    <hrb-circled theme="light-grey-1" size="medium">
      <hrb-icon name="heart"></hrb-icon>
    </hrb-circled>
  </div>
  <div>
  <hrb-label theme="tooltip">light-grey-2</hrb-label>
  <hrb-spacer d="16"></hrb-spacer>
    <hrb-circled theme="light-grey-2" size="medium">
      <hrb-icon name="heart"></hrb-icon>
    </hrb-circled>
  </div>
  <div>
  <hrb-label theme="tooltip">medium-dark-blue</hrb-label>
  <hrb-spacer d="16"></hrb-spacer>
    <hrb-circled theme="medium-dark-blue" size="medium">
      <hrb-icon name="heart"></hrb-icon>
    </hrb-circled>
  </div>
  <div>
  <hrb-label theme="tooltip">medium-light-blue</hrb-label>
  <hrb-spacer d="16"></hrb-spacer>
    <hrb-circled theme="medium-light-blue" size="medium">
      <hrb-icon name="heart"></hrb-icon>
    </hrb-circled>
  </div>
  <div>
  <hrb-label theme="tooltip">medium-dark-green</hrb-label>
  <hrb-spacer d="16"></hrb-spacer>
    <hrb-circled theme="medium-dark-green" size="medium">
      <hrb-icon name="heart"></hrb-icon>
    </hrb-circled>
  </div>
  <div>
  <hrb-label theme="tooltip">medium-light-green</hrb-label>
  <hrb-spacer d="16"></hrb-spacer>
    <hrb-circled theme="medium-light-green" size="medium">
      <hrb-icon name="heart"></hrb-icon>
    </hrb-circled>
  </div>
  <div>
  <hrb-label theme="tooltip">ui-green</hrb-label>
  <hrb-spacer d="16"></hrb-spacer>
    <hrb-circled theme="ui-green" size="medium">
      <hrb-icon name="heart"></hrb-icon>
    </hrb-circled>
  </div>
  <div>
  <hrb-label theme="tooltip">yellow</hrb-label>
  <hrb-spacer d="16"></hrb-spacer>
    <hrb-circled theme="yellow" size="medium">
      <hrb-icon name="heart"></hrb-icon>
    </hrb-circled>
  </div>
</hrb-layout>

`
