import { newSpecPage } from '@stencil/core/testing'

import { HrbCircled } from '../circled'

describe('HrbCircled', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbCircled],
      html: `
      <hrb-circled size="small" theme="medium-dark-yellow">
        <hrb-icon name="heart"></hrb-icon>
      </hrb-circled>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-circled class="hrb-circled" size="small" theme="medium-dark-yellow">
      <hrb-icon name="heart"></hrb-icon>
    </hrb-circled>
    `)
  })
})
