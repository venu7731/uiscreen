export type TLabelThemes = 'green' | 'yellow' | 'blue' | 'red' | 'tooltip'

export type TLabelTypes = 'a' | 'button' | 'span'
