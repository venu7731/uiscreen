# hrb-label

An `hrb-label` element is similar to an `hrb-button` element, but it's meant to represent a "tag", or a "keyword" that could be clickable.

`hrb-label` can be used to render a `button` (default). Use the `as` props to change the main rendered element: `button`, `a` or `span`.

📝 Note:

- If you want to render an `a` element, don't forget to pass the `href`, `target` and `rel` props.
- We recommend to render a `span` if you only want a styled component with no interactive elements.

## Examples

In some context, you need aria attributes to make an `hbr-label` more accessible.

We exposed `p-aria-*` props translating to aria attributes on the main `button`, `a` or `span` element (see `as` props): `p-aria-label`, `p-aria-labelledby` and `p-aria-role`.

```html
<hrb-label p-aria-label="Go to a specific product page">Learn More</hrb-label>
```

---

`hrb-label` can use a variety of themes, listed below, with the `theme` prop.

```html
<hrb-label theme="blue">A blue keyword</hrb-label>
```

---

`hrb-label` can be disabled with the `disabled` prop.

```html
<hrb-label disabled>A blue keyword</hrb-label>
```

📝 Note: the `disabled` prop also automatically adds `aria-disabled="true"` on to the element.

---

To render an `a` tag, use the `as` prop.

```html
<hrb-label as="a">Keyword</hrb-label>
```

`hrb-label` rendering an `a` element can be passed `href`, `target` and `rel` props.

```html
<hrb-label
  as="a"
  href="https://www.hrblock.com"
  target="_blank"
  rel="noreferrer noopener"
>
  Keyword
</hrb-label>
```

<!-- Auto Generated Below -->


## Properties

| Property          | Attribute           | Description                                                             | Type                                                  | Default     |
| ----------------- | ------------------- | ----------------------------------------------------------------------- | ----------------------------------------------------- | ----------- |
| `as`              | `as`                | Sets tag for button \| span \| a (defaults to <span>)                   | `"a" \| "button" \| "span"`                           | `'span'`    |
| `disabled`        | `disabled`          | Sets label to disabled                                                  | `boolean`                                             | `false`     |
| `href`            | `href`              | if `is-button` is false (`a` element), this should be mandatory         | `string`                                              | `undefined` |
| `pAriaLabel`      | `p-aria-label`      | `aria-label` attribute used by the button/a child element               | `string`                                              | `undefined` |
| `pAriaLabelledby` | `p-aria-labelledby` | `aria-labelledby` attribute used by the button/a child element          | `string`                                              | `undefined` |
| `pAriaRole`       | `p-aria-role`       | `aria-role` attribute used by the button/a child element                | `string`                                              | `undefined` |
| `rel`             | `rel`               | Applies optional rel attribute                                          | `string`                                              | `undefined` |
| `target`          | `target`            | if `is-button` is false (`a` element), this should be mandatory         | `string`                                              | `undefined` |
| `theme`           | `theme`             | Theme of the label. Options: `green` (default), `yellow`, `blue`, `red` | `"blue" \| "green" \| "red" \| "tooltip" \| "yellow"` | `'green'`   |
| `type`            | `type`              | Applies type attribute                                                  | `string`                                              | `undefined` |


## Dependencies

### Depends on

- [hrb-text](../text)

### Graph
```mermaid
graph TD;
  hrb-label --> hrb-text
  style hrb-label fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
