import { newSpecPage } from '@stencil/core/testing'

import { Label } from '../label'

describe('Label', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [Label],
      html: `
      <hrb-label theme="red">label item y L 4</hrb-label>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-label theme="red">
      <span class="hrb-label hrb-label--red">
        <span class="hrb-label__container">
          <hrb-text class="hrb-label__text" style-type="cta">
            label item y L 4
          </hrb-text>
        </span>
      </span>
    </hrb-label>
    `)
  })
})
