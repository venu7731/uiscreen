import { Component, h, Host, Prop } from '@stencil/core'

import { getClassnames } from '@src/utils/misc'
import { getIsValidButtonType } from '@src/utils/validations'

import buttonTypes from '@src/constants/button-types'

import { TLabelThemes, TLabelTypes } from './types'

const Constants = {
  baseClassname: 'hrb-label',
}

@Component({
  tag: 'hrb-label',
  styleUrl: 'label.scss',
})
export class Label {
  /**
   * `aria-label` attribute used by the button/a child element
   */
  @Prop({ attribute: 'p-aria-label' }) pAriaLabel: string

  /**
   * `aria-labelledby` attribute used by the button/a child element
   */

  @Prop({ attribute: 'p-aria-labelledby' }) pAriaLabelledby: string

  /**
   * Sets tag for button | span | a (defaults to <span>)
   */
  @Prop() as: TLabelTypes = 'span'

  /**
   * `aria-role` attribute used by the button/a child element
   */
  @Prop({ attribute: 'p-aria-role' }) pAriaRole: string

  /**
   * if `is-button` is false (`a` element), this should be mandatory
   */
  @Prop() target: string

  /**
   * Applies optional rel attribute
   */
  @Prop() rel: string

  /**
   * if `is-button` is false (`a` element), this should be mandatory
   */
  @Prop() href: string

  /**
   * Sets label to disabled
   */
  @Prop() disabled = false

  /**
   * Applies type attribute
   */
  @Prop() type: string

  /**
   * Theme of the label. Options: `green` (default), `yellow`, `blue`, `red`
   */
  @Prop() theme: TLabelThemes = 'green'

  componentWillLoad(): void {
    this.validateLinkType()
  }

  validateLinkType(): void {
    const isValidLinkType = getIsValidButtonType(this.as)

    if (!isValidLinkType) {
      this.throwConsoleError(this.as, 'type')
    }
  }

  throwConsoleError(val: string, prop: string): void {
    // eslint-disable-next-line no-console
    console.error(`<hrb-label /> : "${val}" is not a valid label ${prop}`)
  }

  getProps = (): object => {
    const {
      pAriaLabel,
      pAriaLabelledby,
      pAriaRole,
      as,
      disabled,
      href,
      rel,
      target,
      type,
    } = this

    const isAnchor = as === buttonTypes.anchor
    const isButton = as === buttonTypes.button

    const sharedProps = {
      'aria-label': pAriaLabel,
      'aria-labelledby': pAriaLabelledby,
      role: pAriaRole,
      disabled: disabled,
    }

    if (isAnchor) {
      return {
        ...sharedProps,
        href,
        rel,
        target,
      }
    }

    if (isButton) {
      return {
        ...sharedProps,
        type,
        disabled,
      }
    }

    return {
      ...sharedProps,
    }
  }

  render(): JSX.Element {
    const { theme, getProps } = this

    const props = getProps()

    const classes = getClassnames([
      `${Constants.baseClassname}`,
      theme && `${Constants.baseClassname}--${theme}`,
    ])

    return (
      <Host>
        <this.as class={classes} {...props}>
          <span class={`${Constants.baseClassname}__container`}>
            <hrb-text
              class={`${Constants.baseClassname}__text`}
              style-type="cta"
            >
              <slot></slot>
            </hrb-text>
          </span>
        </this.as>
      </Host>
    )
  }
}
