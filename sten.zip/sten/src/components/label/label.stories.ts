import * as readme from './readme.md'

export default {
  component: 'hrb-label',
  title: 'Labels',
  parameters: {
    notes: { markdown: readme },
  },
  argTypes: {
    labelText: { control: 'text' },
    theme: {
      control: {
        type: 'select',
        options: ['green', 'yellow', 'blue', 'red', 'tooltip'],
        default: 'green',
      },
    },
    as: {
      control: {
        type: 'select',
        options: ['span', 'a', 'button'],
        default: 'span',
      },
    },
  },
}

export const Label = (args): string =>
  `
  <hrb-label as="${args.as}" theme="${args.theme}">${args.labelText}</hrb-label>
  `

Label.args = {
  labelText: 'Label',
  theme: 'green',
}
