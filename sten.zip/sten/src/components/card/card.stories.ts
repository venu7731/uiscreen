import * as readme from './readme.md'

export default {
  component: 'hrb-card',
  title: 'Cards/Base Card',
  parameters: {
    notes: { markdown: readme },
  },
  argTypes: {
    theme: {
      control: {
        type: 'select',
        options: [
          'medium-light-green',
          'light-green',
          'medium-light-blue',
          'light-blue',
          'medium-light-yellow',
          'light-yellow',
          'ui-green',
          'blue',
          'white',
          'light-grey-1',
          'light-grey-2',
          'medium-dark-green',
          'medium-dark-blue',
          'medium-dark-yellow',
          'yellow',
        ],
        default: 'text',
      },
    },
  },
}

export const BaseCard = (args): string =>
  `
  <hrb-card theme=${args.theme}>
    <hrb-card-content>
      <hrb-text style-type="large">Card Title</hrb-text>
    </hrb-card-content>
  </hrb-card>
`
