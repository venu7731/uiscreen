import { Component, h, Host, Prop } from '@stencil/core'

const Constants = {
  baseClassname: 'hrb-card-content',
}

@Component({
  tag: 'hrb-card-content',
  styleUrl: 'card-content.scss',
})
export class CardContent {
  @Prop() padding: string

  render(): JSX.Element {
    const { baseClassname } = Constants
    return <Host class={` ${baseClassname} `}></Host>
  }
}
