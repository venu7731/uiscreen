import { newSpecPage } from '@stencil/core/testing'

import { CardContent } from '../card-content'

describe('Card Content Container', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [CardContent],
      html: `
        <hrb-card-content></hrb-card-content>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-card-content class="hrb-card-content"></hrb-card-content>
    `)
  })
})
