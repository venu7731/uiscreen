# hrb-card-content

<!-- Auto Generated Below -->


## Properties

| Property  | Attribute | Description | Type     | Default     |
| --------- | --------- | ----------- | -------- | ----------- |
| `padding` | `padding` |             | `string` | `undefined` |


## Dependencies

### Used by

 - [hrb-card-document](../../card composites/card-document)
 - [hrb-message-card](../../card composites/card-message)
 - [hrb-option-card](../../card composites/option-card)

### Graph
```mermaid
graph TD;
  hrb-card-document --> hrb-card-content
  hrb-message-card --> hrb-card-content
  hrb-option-card --> hrb-card-content
  style hrb-card-content fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
