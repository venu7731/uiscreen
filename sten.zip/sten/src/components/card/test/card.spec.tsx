import { newSpecPage } from '@stencil/core/testing'

import { HrbCard } from '../card'

describe('Basic Card', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbCard],
      html: `
      <hrb-card>
        <hrb-card-content>
          <hrb-text style-type="large">My Card Title</hrb-text>
        </hrb-card-content>
        <div slot="boot">Boot!</div>
      </hrb-card>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-card>
      <div hidden="" slot="boot">
        Boot!
      </div>
      <div class="hrb-card hrb-card--static">
        <hrb-card-content>
          <hrb-text style-type="large">
            My Card Title
          </hrb-text>
        </hrb-card-content>
      </div>
    </hrb-card>
    `)
  })
})
