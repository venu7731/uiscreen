# hrb-card

<!-- Auto Generated Below -->


## Properties

| Property      | Attribute      | Description                                  | Type                                                                                                                                                                                                                                                                              | Default     |
| ------------- | -------------- | -------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------- |
| `animateBoot` | `animate-boot` | Animate Boot Will animate the boot of a card | `boolean`                                                                                                                                                                                                                                                                         | `false`     |
| `animateHat`  | `animate-hat`  | Animate Hat Will animate the hat of a card   | `boolean`                                                                                                                                                                                                                                                                         | `false`     |
| `as`          | `as`           | The tag to wrap the content with             | `string`                                                                                                                                                                                                                                                                          | `'div'`     |
| `hasBoot`     | `has-boot`     | Has Boot Will display the boot of a card     | `boolean`                                                                                                                                                                                                                                                                         | `false`     |
| `hasHat`      | `has-hat`      | Has Hat Will display the hat of a card       | `boolean`                                                                                                                                                                                                                                                                         | `false`     |
| `theme`       | `theme`        | Callout color theme                          | `"blue" \| "light-blue" \| "light-green" \| "light-grey-1" \| "light-grey-2" \| "light-yellow" \| "medium-dark-blue" \| "medium-dark-green" \| "medium-dark-yellow" \| "medium-light-blue" \| "medium-light-green" \| "medium-light-yellow" \| "ui-green" \| "white" \| "yellow"` | `undefined` |


## Dependencies

### Used by

 - [hrb-card-document](../card composites/card-document)
 - [hrb-card-expandable](../card composites/card-expandable)
 - [hrb-message-card](../card composites/card-message)
 - [hrb-option-card](../card composites/option-card)

### Graph
```mermaid
graph TD;
  hrb-card-document --> hrb-card
  hrb-card-expandable --> hrb-card
  hrb-message-card --> hrb-card
  hrb-option-card --> hrb-card
  style hrb-card fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
