import { Component, h, Prop, Host } from '@stencil/core'

import { getClassnames } from '@src/utils/misc'

import { TCardThemes } from '../card/types'

const Constants = {
  baseClassname: 'hrb-card',
}

@Component({
  tag: 'hrb-card',
  styleUrl: 'card.scss',
})
export class HrbCard {
  /**
   * The tag to wrap the content with
   */
  @Prop() as = 'div'

  /**
   * Callout color theme
   */
  @Prop() theme: TCardThemes

  /**
   * Has Boot
   * Will display the boot of a card
   */
  @Prop() hasBoot = false

  /**
   * Animate Boot
   * Will animate the boot of a card
   */
  @Prop() animateBoot = false

  /**
   * Has Hat
   * Will display the hat of a card
   */
  @Prop() hasHat = false

  /**
   * Animate Hat
   * Will animate the hat of a card
   */
  @Prop() animateHat = false

  private isTappable = this.as === 'a' || this.as === 'button'

  render(): JSX.Element {
    const { theme, isTappable, animateBoot, animateHat } = this
    const { baseClassname } = Constants

    const classes = getClassnames([
      `${baseClassname}`,
      theme && `${baseClassname}--${theme}`,
      isTappable ? `${baseClassname}--tappable` : `${baseClassname}--static`,
    ])

    const bootClasses = getClassnames([
      `${Constants.baseClassname}__boot`,
      animateBoot && `will-animate`,
    ])

    const hatClasses = getClassnames([
      `${Constants.baseClassname}__hat`,
      animateHat && `will-animate`,
    ])

    return (
      <Host>
        {this.hasHat ? (
          <div class={hatClasses}>
            <slot name="hat" />
          </div>
        ) : (
          ''
        )}
        <this.as class={classes}>
          <slot />
        </this.as>
        {this.hasBoot ? (
          <div class={bootClasses}>
            <slot name="boot" />
          </div>
        ) : (
          ''
        )}
      </Host>
    )
  }
}
