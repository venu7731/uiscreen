# hrb-video

The `hrb-video` component generates an embeded Youtube player based on the `video-id`.
It supports most of the main API options, exposes methods and triggers custom events related to the generated player.

```html
<hrb-video video-id="8q7xy8VYbmU"></hrb-video>
```

## Examples

The container's size can be changed with the `aspect-ratio` prop (16/9 by default).

```html
<hrb-video video-id="70x48ADt0W8" aspect-ratio="1/1"></hrb-video>
```

---

You can autoplay a video with the `autoplay` prop, mute it with the `muted` prop, or remove all the controls at once with `remove-controls`.

```html
<hrb-video video-id="70x48ADt0W8" autoplay muted remove-controls></hrb-video>
```

---

An `hrb-video` component accepts a `poster` and `poster-srcset` prop, which generates an `hrb-img` as a poster.
Use the `p-title` prop to provide an alt attribute to the poster image.

```html
<hrb-video
  poster="https://picsum.photos/560/315"
  poster-srcset="https://picsum.photos/560/315 1x,
                  https://picsum.photos/1120/630 2x,
                  https://picsum.photos/1680/945 3x"
  video-id="8q7xy8VYbmU"
></hrb-video>
```

## Event Examples

We've added custom events to mirror the Youtube events emitted by the player.
All the main details available in `e.detail`.

```js
const video = document.getElementById('play-video')

// When the player is ready
video.addEventListener('hrbReady', () => {
  console.log('player is ready!')
})

// When the state of the player changes
video.addEventListener('hrbStateChange', e => {
  console.log("player's status has changed to", e.detail.status)
})
```

## Method Examples

Every exposed methods return a `Promise`.

```js
const video = document.getElementById('play-video')

// Play the video
await video.play()

// Pause the video
await video.pause()

// Stop the video
await video.stop()
```

<!-- Auto Generated Below -->


## Properties

| Property         | Attribute         | Description                                              | Type      | Default     |
| ---------------- | ----------------- | -------------------------------------------------------- | --------- | ----------- |
| `aspectRatio`    | `aspect-ratio`    | The aspect ratio of the video                            | `string`  | `'16/9'`    |
| `autoplay`       | `autoplay`        | Sets the video to automatically play                     | `boolean` | `false`     |
| `height`         | `height`          | The video height                                         | `number`  | `390`       |
| `muted`          | `muted`           | Sets the video to automatically be muted                 | `boolean` | `false`     |
| `pTitle`         | `p-title`         | The video title, used as the alt tag for the poster      | `string`  | `undefined` |
| `poster`         | `poster`          | The poster image for the video                           | `string`  | `undefined` |
| `posterSrcset`   | `poster-srcset`   | The poster image for the video as srcset                 | `string`  | `undefined` |
| `removeControls` | `remove-controls` | Removes the video players default controls               | `boolean` | `undefined` |
| `videoId`        | `video-id`        | The YouTube video id that will be loaded into the player | `string`  | `undefined` |
| `width`          | `width`           | The video width                                          | `number`  | `640`       |


## Events

| Event            | Description                                  | Type               |
| ---------------- | -------------------------------------------- | ------------------ |
| `hrbReady`       | Triggers when the player is ready            | `CustomEvent<any>` |
| `hrbStateChange` | Triggers when the player's state has changed | `CustomEvent<any>` |


## Methods

### `pause() => Promise<void>`

External method for programatically pausing video

#### Returns

Type: `Promise<void>`



### `play() => Promise<void>`

External method for programatically playing video

#### Returns

Type: `Promise<void>`



### `stop() => Promise<void>`

External method for programatically stopping video

#### Returns

Type: `Promise<void>`




## Dependencies

### Depends on

- [hrb-circled](../circled)
- [hrb-loader](../loader)
- [hrb-icon](../icon)
- [hrb-img](../img)

### Graph
```mermaid
graph TD;
  hrb-video --> hrb-circled
  hrb-video --> hrb-loader
  hrb-video --> hrb-icon
  hrb-video --> hrb-img
  style hrb-video fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
