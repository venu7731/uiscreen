import { boolean, number, text, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import { reset } from '@src/constants/storybook'

import * as readme from './readme.md'

/* eslint-disable-next-line */
const video = (
  aspectRatio,
  autoplay,
  muted,
  height,
  poster,
  posterSrcset,
  pTitle,
  removeControls,
  videoId,
  width,
) =>
  `<hrb-video
    aspect-ratio="${aspectRatio}"
    ${autoplay ? 'autoplay' : ''}
    ${muted ? 'muted' : ''}
    height="${height}"
    poster="${poster}"
    poster-srcset="${posterSrcset}"
    p-title="${pTitle}"
    ${removeControls ? 'remove-controls' : ''}
    video-id="${videoId}"
    width="${width}"
    >
  </hrb-video>`

const wrapperOpen = `${reset}<div style="padding: 30px">`
const wrapperClose = `</div>`

storiesOf('Video', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-video'],
    notes: { markdown: readme },
  })
  .add('Video', () => {
    return `${wrapperOpen}

    ${video(
      text('Aspect Ratio', '4/3'),
      boolean('Autoplay', false),
      boolean('Muted', false),
      number('Height', 390),
      text('Poster', 'https://picsum.photos/560/315'),
      text(
        'Poster Srcset',
        `https://picsum.photos/560/315 1x, https://picsum.photos/1120/630 2x, https://picsum.photos/1680/945 3x`,
      ),
      text('P Title', 'Video Title'),
      boolean('Remove Controls', true),
      text('Video Id', 'vhwMAFdwTP0'),
      number('Width', 640),
    )}

    ${wrapperClose}`
  })
