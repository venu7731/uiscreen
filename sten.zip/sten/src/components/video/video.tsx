import {
  Component,
  Event,
  EventEmitter,
  h,
  Host,
  Method,
  Prop,
  State,
  Watch,
} from '@stencil/core'

import { numberSlashNumber } from '@src/utils/regex'
import {
  functionQueue,
  getClassnames,
  ratioToPercentage,
} from '@src/utils/misc'

const Constants = {
  autoplayQueryParam: 'autoplay=1',
  baseClassname: 'hrb-video',
  buttonAriaLabel: 'play video',
  youtubeApiUrl: '//www.youtube.com/iframe_api',
}

declare global {
  interface Window {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    YT: any
  }
}

@Component({
  tag: 'hrb-video',
  styleUrl: 'video.scss',
})
export class Video {
  /**
   * External method for programatically playing video
   */
  @Method() async play(): Promise<void> {
    this.playVideo()
  }

  /**
   * External method for programatically stopping video
   */
  @Method() async stop(): Promise<void> {
    this.stopVideo()
  }

  /**
   * External method for programatically pausing video
   */
  @Method() async pause(): Promise<void> {
    this.pauseVideo()
  }

  /**
   * Triggers when the player's state has changed
   */
  @Event() hrbStateChange: EventEmitter

  /**
   * Triggers when the player is ready
   */
  @Event() hrbReady: EventEmitter

  /**
   * The aspect ratio of the video
   */
  @Prop({ attribute: 'aspect-ratio' }) aspectRatio = '16/9'

  /**
   * Sets the video to automatically play
   */
  @Prop() autoplay = false

  /**
   * Sets the video to automatically be muted
   */
  @Prop() muted = false

  /**
   * The video height
   */
  @Prop() height = 390

  /**
   * The poster image for the video
   */
  @Prop() poster: string

  /**
   * The poster image for the video as srcset
   */
  @Prop({ attribute: 'poster-srcset' }) posterSrcset: string

  /**
   * The video title, used as the alt tag for the poster
   */
  @Prop({ attribute: 'p-title' }) pTitle: string

  /**
   * Removes the video players default controls
   */
  @Prop({ attribute: 'remove-controls' }) removeControls: boolean

  /**
   * The YouTube video id that will be
   * loaded into the player
   */
  @Prop({ attribute: 'video-id' }) videoId: string

  /**
   * The video width
   */
  @Prop() width = 640

  @Watch('muted')
  watchMutedHandler(muted: boolean): void {
    if (muted) {
      this.muteVideo()
    } else {
      this.unMuteVideo()
    }
  }

  @State() requestedPlay = false

  @State() hasPlayedVideo = false

  private slotContainer: HTMLElement

  private videoContainer: HTMLElement

  private player = null

  componentWillLoad(): void {
    this.validateAspectRatio()
  }

  componentDidLoad(): void {
    const { createVideo, loadYTApiScript } = this

    // In case componentDidLoad() is executed during SSR
    if (typeof window === 'undefined') return

    // Needs both test, as window.YT can exist but window.YT.Player is not ready
    if (window.YT && window.YT.Player) {
      createVideo()
    } else {
      loadYTApiScript()
    }
  }

  // https://developers.google.com/youtube/iframe_api_reference#getPlayerState
  playerStateTypeMap = {
    unstarted: -1,
    ended: 0,
    playing: 1,
    paused: 2,
    buffering: 3,
    videoCued: 5,
  }

  validateAspectRatio = (): void => {
    const { aspectRatio } = this

    const isValid = numberSlashNumber.test(aspectRatio)

    if (!isValid) {
      // eslint-disable-next-line no-console
      console.error(
        `<hrb-video /> : "${aspectRatio}" is not a valid aspect-ratio value. Expected format: int/int`,
      )
    }
  }

  loadYTApiScript = (): void => {
    const firstScriptTag = document.getElementsByTagName('script')[0]

    // Because of the async nature of this process
    // it is possible for multiple video instances
    // to be created before the YouTube api has been loaded.
    // To prevent these video instances from referencing
    // the YT API before it is ready we'll queue them up
    // and call the whole collection on `window.onYouTubeIframeAPIReady`
    const queueFunc = this.createVideo
    functionQueue.push(queueFunc)

    if (
      firstScriptTag.src ===
      `${window.location.protocol}${Constants.youtubeApiUrl}`
    ) {
      return
    }

    // `onYouTubeIframeAPIReady` is injected onto the `window` by the YouTube API
    // therefore it is not part of the standard `window` type definition. We are
    // ignoring the missing type here.

    /* eslint-disable-next-line */
    // @ts-ignore
    window.onYouTubeIframeAPIReady = this.callFunctionQueue

    const tag = document.createElement('script')
    tag.src = `${window.location.protocol}${Constants.youtubeApiUrl}`

    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag)
  }

  callFunctionQueue = (): void => {
    Object.values(functionQueue).forEach((queuedFunction, index) => {
      functionQueue.splice(index, 1)
      queuedFunction()
    })
  }

  setIframeTabindex = (): void => {
    const { hasPlayedVideo, poster, posterSrcset, slotContainer } = this

    const iframe = slotContainer.querySelector('iframe')
    const isActive = hasPlayedVideo || (!poster && !posterSrcset)

    iframe.tabIndex = isActive ? 0 : -1
  }

  onPlayerReady = (event: { target: { getVideoData: Function } }): void => {
    const { autoplay, muted } = this

    if (muted) this.muteVideo()

    // Update iframe title attribute with current video title
    const videoData = event.target.getVideoData()
    this.updateIframeTitle(videoData.title)

    // If autoplay, change play icon to loader if poster displayed
    if (autoplay) this.requestedPlay = true

    this.hrbReady.emit()
  }

  updateIframeTitle = (title: string): void => {
    const iframe = this.slotContainer.querySelector('iframe')

    if (iframe && title) {
      iframe.setAttribute('title', title)
    }
  }

  onPlayerStateChange = (event: { data: number; target: object }): void => {
    const { autoplay, hasPlayedVideo, playerStateTypeMap } = this

    // Add status as a string to make it more clear, based on window.YT.PlayerState constants
    // Example: window.YT.PlayerState.PLAYING value is 1
    // see https://developers.google.com/youtube/iframe_api_reference#Playback_status
    const status = Object.keys(window.YT.PlayerState).reduce(
      (finalState, currentState) =>
        window.YT.PlayerState[currentState] === event.data
          ? currentState
          : finalState,
    )
    const detail = { ...event, status }

    // Emit custom event with details
    this.hrbStateChange.emit(detail)

    if (event.data === playerStateTypeMap.playing && !hasPlayedVideo) {
      this.hasPlayedVideo = true
      this.setIframeTabindex()
    }

    // If autoplay but is not supported by browser (firefox, on mobile..)
    // therefore remove the spinner to display a classic play icon
    if (
      event.data === playerStateTypeMap.unstarted &&
      !hasPlayedVideo &&
      autoplay
    ) {
      this.requestedPlay = false
    }
  }

  createVideo = (): void => {
    const {
      autoplay,
      height,
      removeControls,
      videoContainer,
      videoId,
      width,
    } = this

    if (!window.YT.Player) return

    // https://developers.google.com/youtube/iframe_api_reference

    this.player = new window.YT.Player(videoContainer, {
      height,
      width,
      videoId,
      events: {
        onReady: this.onPlayerReady,
        onStateChange: this.onPlayerStateChange,
      },
      playerVars: {
        autoplay: autoplay ? 1 : 0,
        controls: removeControls ? 0 : 1,
      },
    })

    this.setIframeTabindex()
  }

  playVideo = (): void => {
    if (!this.player) return

    this.requestedPlay = true
    this.setIframeTabindex()
    this.player.playVideo()
  }

  stopVideo = (): void => {
    if (!this.player) return

    this.player.stopVideo()
  }

  pauseVideo = (): void => {
    if (!this.player) return

    this.player.pauseVideo()
  }

  muteVideo = (): void => {
    if (!this.player) return

    this.player.mute()
  }

  unMuteVideo = (): void => {
    if (!this.player) return

    this.player.unMute()
  }

  renderPosterButton = (): JSX.Element => {
    const {
      hasPlayedVideo,
      playVideo,
      poster,
      posterSrcset,
      pTitle,
      requestedPlay,
    } = this
    const { baseClassname, buttonAriaLabel } = Constants

    return (
      <button
        aria-label={buttonAriaLabel}
        class={`${baseClassname}__button`}
        onClick={playVideo}
        type="button"
        tabIndex={hasPlayedVideo ? -1 : 0}
      >
        <span class={`${baseClassname}__button-content`}>
          <hrb-circled
            size="medium"
            class={`${baseClassname}__play-icon`}
            p-aria-label={buttonAriaLabel}
          >
            {requestedPlay ? (
              <hrb-loader></hrb-loader>
            ) : (
              <hrb-icon name="play"></hrb-icon>
            )}
          </hrb-circled>

          <hrb-img
            src={poster}
            srcset={posterSrcset}
            alt={pTitle}
            class={`${baseClassname}__poster`}
          />
        </span>
      </button>
    )
  }

  render(): JSX.Element {
    const {
      aspectRatio,
      hasPlayedVideo,
      poster,
      posterSrcset,
      renderPosterButton,
    } = this
    const { baseClassname } = Constants

    const containerBottomPadding = ratioToPercentage(aspectRatio)
    const willRenderPosterButton = !!poster || !!posterSrcset
    const isActive = hasPlayedVideo || !willRenderPosterButton

    const hostClasses = getClassnames([
      `${baseClassname}`,
      isActive && `${baseClassname}--is-active`,
    ])

    return (
      <Host class={hostClasses}>
        <span
          class={`${baseClassname}__video-container`}
          style={{ 'padding-bottom': `${containerBottomPadding}%` }}
        >
          {willRenderPosterButton && renderPosterButton()}
          <span
            class={`${baseClassname}__video`}
            ref={(el: HTMLElement): void => {
              this.slotContainer = el
            }}
          >
            <span
              ref={(el: HTMLElement): void => {
                this.videoContainer = el
              }}
            ></span>
          </span>
        </span>
      </Host>
    )
  }
}
