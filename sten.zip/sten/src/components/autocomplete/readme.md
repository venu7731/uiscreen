# hrb-autocomplete

<!-- Auto Generated Below -->


## Properties

| Property     | Attribute     | Description                                                   | Type      | Default              |
| ------------ | ------------- | ------------------------------------------------------------- | --------- | -------------------- |
| `debounce`   | `debounce`    | Debounce duration                                             | `number`  | `150`                |
| `disabled`   | `disabled`    | Disabled                                                      | `boolean` | `false`              |
| `errorLabel` | `error-label` | Error label                                                   | `string`  | `undefined`          |
| `hasError`   | `has-error`   | Input has error                                               | `boolean` | `false`              |
| `helperText` | `helper-text` | Input has error                                               | `string`  | `undefined`          |
| `inputId`    | `input-id`    | Input id                                                      | `string`  | `generateSimpleID()` |
| `keys`       | `keys`        | Keys to fetch results from (optional)                         | `string`  | `undefined`          |
| `label`      | `label`       | Label                                                         | `string`  | `''`                 |
| `loading`    | `loading`     | Set input to loading state                                    | `boolean` | `false`              |
| `maxResults` | `max-results` | Maximum number of results to show                             | `number`  | `20`                 |
| `name`       | `name`        | Name                                                          | `string`  | `undefined`          |
| `readonly`   | `readonly`    | Readonly                                                      | `boolean` | `undefined`          |
| `required`   | `required`    | Required                                                      | `boolean` | `undefined`          |
| `threshold`  | `threshold`   | Minimum number of characters to enter before fetching results | `number`  | `3`                  |
| `type`       | `type`        | The type attribute to apply to input.                         | `string`  | `'text'`             |
| `value`      | `value`       | Default value                                                 | `string`  | `undefined`          |


## Methods

### `getElement() => Promise<HTMLElement>`



#### Returns

Type: `Promise<HTMLElement>`



### `setData(data: string[] | object[]) => Promise<void>`



#### Returns

Type: `Promise<void>`



### `setFocus() => Promise<void>`



#### Returns

Type: `Promise<void>`




## Dependencies

### Depends on

- [hrb-input](../input)

### Graph
```mermaid
graph TD;
  hrb-autocomplete --> hrb-input
  hrb-input --> hrb-loader
  hrb-input --> hrb-icon
  style hrb-autocomplete fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
