import { newSpecPage, SpecPage } from '@stencil/core/testing'

import { Input } from '../autocomplete'

const tagName = 'hrb-attachment-list'

interface InputItemSpecPage {
  component: Input
  page: SpecPage
}

const createNewSpecPage = async (): Promise<InputItemSpecPage> => {
  const page = await newSpecPage({
    components: [Input],
    html: `<${tagName}></${tagName}>`,
  })
  return { page, component: page.rootInstance }
}

describe(tagName, () => {
  it('creates a new instance of Autocomplete', () => {
    const componentInstance = new Input()

    expect(componentInstance).toBeTruthy()
  })

  it('renders', async () => {
    const { page } = await createNewSpecPage()
    const nodeName = page.root.nodeName.toLowerCase()

    expect(nodeName).toEqual(tagName)
  })
})
