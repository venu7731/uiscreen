import {
  Component,
  Element,
  h,
  Host,
  Listen,
  Method,
  Prop,
  State,
} from '@stencil/core'
import autoComplete from '@tarekraafat/autocomplete.js'

import { generateSimpleID, getClassnames, sort } from '@src/utils/misc'
import {
  setListboxScrollPosition,
  willElementSitBelowFoldAndFitAboveContainer,
} from '@src/components/select-custom/utils'

import {
  key as keyConstants,
  keyCode as keyCodeConstants,
  upAndDownArrows,
} from '@src/constants/keyboard-events'

const Constants = {
  baseClassname: 'hrb-autocomplete',
  containerId: 'autoComplete_list',
  inputIcons: {
    chevronDown: 'chevron-down',
    chevronUp: 'chevron-up',
  },
  selectedItemClass: 'autoComplete_selected',
}

@Component({
  tag: 'hrb-autocomplete',
  styleUrl: 'autocomplete.scss',
})
export class Input {
  @Element() el: HTMLElement

  @Method() async getElement(): Promise<HTMLElement> {
    return this.hrbInputRef.querySelector('input')
  }

  @Method() async setData(data: string[] | object[]): Promise<void> {
    this.injectedData = data
    this.clearAndReInit()
  }

  @Method() async setFocus(): Promise<void> {
    const target = this.el.querySelector(`#${this.inputId}`) as HTMLInputElement
    target.focus()
  }

  /**
   * Debounce duration
   */
  @Prop() debounce = 150

  /**
   * Disabled
   */
  @Prop() disabled = false

  /**
   * Error label
   */
  @Prop() errorLabel: string

  /**
   * Input has error
   */
  @Prop() hasError = false

  /**
   * Input has error
   */
  @Prop() helperText: string

  /**
   * Set input to loading state
   */
  @Prop() loading = false

  /**
   * Keys to fetch results from (optional)
   */
  @Prop() keys: string

  /**
   * Input id
   */
  @Prop() inputId = generateSimpleID()

  /**
   * Label
   */
  @Prop() label = ''

  /**
   * Maximum number of results to show
   */
  @Prop() maxResults = 20

  /**
   * Name
   */
  @Prop() name: string

  /**
   * Readonly
   */
  @Prop() readonly: boolean

  /**
   * Required
   */
  @Prop() required: boolean

  /**
   * Minimum number of characters to enter before fetching results
   */
  @Prop() threshold = 3

  /**
   * The type attribute to apply to input.
   */
  @Prop() type = 'text'

  /**
   * Default value
   */
  @Prop({ mutable: true }) value: string

  @State() hasResults = false

  @State() showDropdownAboveInput = false

  @State() injectedData: string[] | object[]

  @State() isFocused = false

  @State() activedescendant = ''

  private containerRef: HTMLSpanElement

  private hasCheckedOptionListPosition = false

  private hasInitialized = false

  private resultsContainerRef: HTMLSpanElement

  private slotContainerRef: HTMLSpanElement

  private hrbInputRef: HTMLElement

  @Listen('hrbBlur') handleChange(): void {
    this.isFocused = false
    this.resetOptionListPositionCheck()
  }

  @Listen('hrbFocus') handleBlur(): void {
    const {
      checkOptionListPosition,
      hasCheckedOptionListPosition,
      hasResults,
    } = this

    this.isFocused = true

    if (hasResults && !hasCheckedOptionListPosition) {
      checkOptionListPosition()
    }
  }

  componentDidLoad(): void {
    const { hasInitialized, init, selectData } = this
    const selectedData = selectData()

    if (!hasInitialized && !!selectedData) {
      init()
    }
  }

  componentDidUpdate(): void {
    const { hasInitialized, init, selectData } = this
    const selectedData = selectData()

    if (!hasInitialized && !!selectedData) {
      init()
    }
  }

  componentDidUnload(): void {
    this.resetOptionListPositionCheck()
  }

  clearAndReInit = (): void => {
    this.hasInitialized = false

    const dropdown = this.resultsContainerRef.querySelector(
      `.${Constants.baseClassname}__results-list`,
    )

    if (dropdown) {
      dropdown.remove()
    }

    this.init()
  }

  init = (): void => {
    // Help provided by the autocomplete.js library
    // https://github.com/TarekRaafat/autoComplete.js
    const { debounce, threshold, maxResults } = this
    const { baseClassname } = Constants

    // library is base 0 so subtracting 1 gives us a more sensible count
    const baseThreshold = threshold === 0 ? threshold : threshold - 1

    this.hasInitialized = true

    /* eslint-disable-next-line no-new, new-cap */
    new autoComplete({
      data: {
        src: this.getData,
        cache: false,
      },
      query: {
        manipulate: (query: string): string => {
          if (!query.length || query.length <= baseThreshold) {
            this.hasResults = false
            this.resetOptionListPositionCheck()
          }

          return query
        },
      },
      resultsList: {
        container: (source: HTMLElement): void => {
          source.setAttribute('class', `${baseClassname}__results-list`)
          source.setAttribute('role', 'listbox')
        },
        destination: document.querySelector(`#${this.inputId}__results`),
        position: 'afterbegin',
        render: true,
      },
      resultItem: {
        content: (
          data: { match: string; index: number },
          source: HTMLElement,
        ): void => {
          const {
            checkOptionListPosition,
            hasCheckedOptionListPosition,
            isFocused,
          } = this
          this.hasResults = true

          source.setAttribute('class', `${baseClassname}__results-item`)
          source.setAttribute('aria-selected', 'false')
          source.setAttribute('role', 'option')
          source.setAttribute('tabindex', '-1')
          source.setAttribute('id', `${baseClassname}-option__${data.index}`)
          /* eslint-disable-next-line no-param-reassign */
          source.innerText = data.match

          if (isFocused && !hasCheckedOptionListPosition) {
            checkOptionListPosition()
          }
        },
      },
      noResults: (): void => {
        this.hasResults = false
        this.resetOptionListPositionCheck()
      },
      sort: (valueA: string, valueB: string): number => {
        return sort(valueA, valueB)
      },
      onSelection: (feedback: { selection: { match: string } }): void => {
        const { selection } = feedback

        this.hasResults = false
        this.resetOptionListPositionCheck()

        if (selection && selection.match) {
          this.setValue(selection.match)
        }
      },
      selector: `#${this.inputId}`,
      maxResults,
      threshold: baseThreshold,
      debounce,
    })
  }

  selectData = (): object[] | string[] => {
    const { injectedData } = this

    if (injectedData) {
      return injectedData
    }

    const options = this.slotContainerRef.querySelector('script')
    const optionsJSON = !!options && JSON.parse(options.innerHTML)

    if (optionsJSON) {
      return optionsJSON
    }

    return null
  }

  getObjectDataByKey = (): string[] => {
    const keys = this.getKeys()
    const data = this.selectData() as { data: object }[]

    if (!data) return null

    const optionsByKey = data.map((item: object): string[] => {
      return keys.map((key: string): string => item[key])
    })

    const flattenedArray = [].concat(...optionsByKey)
    return flattenedArray
  }

  getObjectDataAsArray = (): string[] => {
    const data = this.selectData() as { option: string }[]

    if (!data) return null

    const objectDataAsArray = data.map((item: object): string[] => {
      return Object.values(item)
    })

    const flattenedArray = [].concat(...objectDataAsArray)
    return flattenedArray
  }

  getData = (): object => {
    const keys = this.getKeys()
    const data = this.selectData()

    if (!data) return null

    if (keys && keys.length) {
      const dataByKey = this.getObjectDataByKey()
      return dataByKey
    }

    if (!keys && typeof data[0] === 'object') {
      const dataByObect = this.getObjectDataAsArray()
      return dataByObect
    }

    return data
  }

  getKeys = (): string[] => {
    const { keys } = this
    return keys ? keys.replace(/ /g, '').split(',') : null
  }

  setValue = (match: string): void => {
    this.value = '\u00A0'

    window.requestAnimationFrame(() => (this.value = match))
  }

  resetOptionListPositionCheck = (): void => {
    this.hasCheckedOptionListPosition = false
    window.removeEventListener('scroll', this.checkOptionListPosition)
  }

  checkOptionListPosition = (): void => {
    const { containerRef, resultsContainerRef, showDropdownAboveInput } = this
    const { containerId } = Constants

    const resultsContainer = resultsContainerRef.querySelector(
      `#${containerId}`,
    )

    const willPositionDropdownAboveContainer = willElementSitBelowFoldAndFitAboveContainer(
      containerRef,
      resultsContainer as HTMLElement,
    )

    this.hasCheckedOptionListPosition = true
    if (showDropdownAboveInput !== willPositionDropdownAboveContainer) {
      this.showDropdownAboveInput = willPositionDropdownAboveContainer
    }

    window.addEventListener('scroll', this.checkOptionListPosition)
  }

  setOptionItemAccessibilityAttributes = (): void => {
    const { resultsContainerRef } = this
    const { selectedItemClass } = Constants

    const allOptions = resultsContainerRef.querySelectorAll('li')
    const currentlyHighlightedOption = resultsContainerRef.querySelector(
      `.${selectedItemClass}`,
    )

    allOptions.forEach((option: HTMLElement): void => {
      option.setAttribute('aria-selected', 'false')
    })

    currentlyHighlightedOption.setAttribute('aria-selected', 'true')
    this.activedescendant = currentlyHighlightedOption.id
  }

  positionOptionList = (): void => {
    const { resultsContainerRef } = this
    const { containerId, selectedItemClass } = Constants

    const resultsContainer = resultsContainerRef.querySelector(
      `#${containerId}`,
    )
    const currentlyHighlightedOption = resultsContainerRef.querySelector(
      `.${selectedItemClass}`,
    )

    setListboxScrollPosition(
      currentlyHighlightedOption as HTMLElement,
      resultsContainer as HTMLElement,
    )
  }

  onKeyDown = (event: KeyboardEvent): void => {
    const { keyCode, key } = event
    const keyValue = key ? keyConstants[key] : keyCodeConstants[keyCode]

    if (upAndDownArrows.includes(keyValue)) {
      event.preventDefault()
      this.positionOptionList()
      this.setOptionItemAccessibilityAttributes()
    }
  }

  render(): JSX.Element {
    const {
      activedescendant,
      disabled,
      errorLabel,
      hasError,
      hasResults,
      helperText,
      inputId,
      isFocused,
      label,
      loading,
      name,
      onKeyDown,
      readonly,
      required,
      showDropdownAboveInput,
      type,
      value,
    } = this
    const { baseClassname, inputIcons } = Constants

    const icon =
      hasResults && isFocused ? inputIcons.chevronUp : inputIcons.chevronDown

    const isContainerOpen = hasResults && isFocused
    const resultsContainerClasses = getClassnames([
      `${baseClassname}__results-container`,
      isContainerOpen && `${baseClassname}__results-container--is-open`,
      showDropdownAboveInput &&
        `${baseClassname}__results-container--has-top-dropdown`,
    ])

    return (
      <Host>
        <span
          class={baseClassname}
          role="combobox"
          aria-controls={`${inputId}__results`}
          aria-expanded={isContainerOpen ? 'true' : 'false'}
          ref={(el): HTMLSpanElement => (this.containerRef = el)}
        >
          <hrb-input
            autocomplete="off"
            disabled={disabled}
            errorLabel={errorLabel}
            forceIconVisibility={true}
            hasError={hasError}
            helperText={helperText}
            icon={icon}
            onKeyDown={onKeyDown}
            inputId={inputId}
            label={label}
            loading={loading}
            name={name}
            p-activedescendant={activedescendant}
            p-aria-autocomplete="list"
            p-aria-multiline="false"
            p-aria-owns={`${inputId}__results`}
            readonly={readonly}
            required={required}
            type={type}
            value={value}
            ref={(el): HTMLElement => (this.hrbInputRef = el as HTMLElement)}
          ></hrb-input>
          <span
            class={resultsContainerClasses}
            id={`${inputId}__results`}
            aria-hidden={isContainerOpen ? 'false' : 'true'}
            ref={(el): HTMLSpanElement => (this.resultsContainerRef = el)}
          ></span>
        </span>
        <span
          aria-hidden="true"
          class={`${baseClassname}__slots`}
          ref={(el): HTMLSpanElement => (this.slotContainerRef = el)}
        >
          <slot />
        </span>
        <span
          aria-atomic="true"
          aria-live="assertive"
          class={`${baseClassname}__live-region`}
          role="dialog"
        >
          {value}
        </span>
      </Host>
    )
  }
}
