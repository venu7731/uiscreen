import { newSpecPage } from '@stencil/core/testing'

import { HrbAccordion } from '../accordion'

describe('card-message', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [HrbAccordion],
      html: `
      <hrb-accordion type="subnav">
        <hrb-accordion-item header-as="h1" header-text="Open Accordion Now">
          <a href="/">A link</a>
          <p class="hrb-text--body-copy hrb-color--blue">
            Morbi consectetur purus mollis efficitur elementum. Suspendisse at
            neque augue. Nulla facilisi. Donec suscipit est a mauris rhoncus
            euismod. Quisque leo sapien, dapibus ut erat a, gravida commodo leo.
            Proin in pellentesque diam, a scelerisque velit. Ut molestie elit eget
            diam sollicitudin luctus.
          </p>
          <p class="hrb-text--body-copy hrb-color--blue">
            In egestas metus tellus, id blandit diam viverra pretium. Sed leo
            risus, fermentum ac luctus ac, malesuada quis odio. Nam sagittis
            efficitur ante, et volutpat arcu sodales pharetra. Vestibulum ante
            ipsum primis in faucibus orci luctus et ultrices posuere cubilia
            Curae; Aliquam erat volutpat. In vel dictum diam, at eleifend tellus.
            Aliquam ullamcorper, urna in bibendum fringilla, lectus lacus semper
            sapien, in sollicitudin nibh purus vitae ex.
          </p>
        </hrb-accordion-item>
        <hrb-accordion-item header-text="Section header" subnav-header-style="large">
          <hrb-button theme="light-grey-2">Primary</hrb-button>
          <p class="hrb-text--body-copy">
            Morbi consectetur purus mollis efficitur elementum. Suspendisse at
            neque augue. Nulla facilisi. Donec suscipit est a mauris rhoncus
            euismod. Quisque leo sapien, dapibus ut erat a, gravida commodo leo.
            Proin in pellentesque diam, a scelerisque velit. Ut molestie elit eget
            diam sollicitudin luctus.
          </p>
          <p class="hrb-text--body-copy">
            In egestas metus tellus, id blandit diam viverra pretium. Sed leo
            risus, fermentum ac luctus ac, malesuada quis odio. Nam sagittis
            efficitur ante, et volutpat arcu sodales pharetra. Vestibulum ante
            ipsum primis in faucibus orci luctus et ultrices posuere cubilia
            Curae; Aliquam erat volutpat. In vel dictum diam, at eleifend tellus.
            Aliquam ullamcorper, urna in bibendum fringilla, lectus lacus semper
            sapien, in sollicitudin nibh purus vitae ex.
          </p>
        </hrb-accordion-item>
        <hrb-accordion-item accordion-id="acdn3" header-text="Open Accordion Now">
          <p class="hrb-text--body-copy">
            Morbi consectetur purus mollis efficitur elementum at
            neque augue. Nulla facilisi. Donec suscipit est a mauris rhoncus
            euismod. Quisque leo sapien, dapibus ut erat a, gravida commodo leo.
            Proin in pellentesque diam, a scelerisque velit. Ut molestie elit eget
            diam sollicitudin luctus.
          </p>
          <p class="hrb-text--body-copy">
            In egestas metus tellus, id blandit diam viverra pretium. Sed leo
            risus, fermentum ac luctus ac, malesuada quis odio. Nam sagittis
            efficitur ante, et volutpat arcu sodales pharetra. Vestibulum ante
            ipsum primis in faucibus orci luctus et ultrices posuere cubilia
            Curae; Aliquam erat volutpat. In vel dictum diam, at eleifend tellus.
            Aliquam ullamcorper, urna in bibendum fringilla, lectus lacus semper
            sapien, in sollicitudin nibh purus vitae ex.
          </p>
        </hrb-accordion-item>
      </hrb-accordion>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-accordion class="hrb-accordion--subnav" type="subnav">
       <hrb-accordion-item header-as="h1" header-text="Open Accordion Now">
         <a href="/">
           A link
         </a>
         <p class="hrb-color--blue hrb-text--body-copy">
           Morbi consectetur purus mollis efficitur elementum. Suspendisse at neque augue. Nulla facilisi. Donec suscipit est a mauris rhoncus euismod. Quisque leo sapien, dapibus ut erat a, gravida commodo leo. Proin in pellentesque diam, a scelerisque velit. Ut molestie elit eget diam sollicitudin luctus.
         </p>
         <p class="hrb-color--blue hrb-text--body-copy">
           In egestas metus tellus, id blandit diam viverra pretium. Sed leo risus, fermentum ac luctus ac, malesuada quis odio. Nam sagittis efficitur ante, et volutpat arcu sodales pharetra. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aliquam erat volutpat. In vel dictum diam, at eleifend tellus. Aliquam ullamcorper, urna in bibendum fringilla, lectus lacus semper sapien, in sollicitudin nibh purus vitae ex.
         </p>
       </hrb-accordion-item>
       <hrb-accordion-item header-text="Section header" subnav-header-style="large">
         <hrb-button theme="light-grey-2">
           Primary
         </hrb-button>
         <p class="hrb-text--body-copy">
           Morbi consectetur purus mollis efficitur elementum. Suspendisse at neque augue. Nulla facilisi. Donec suscipit est a mauris rhoncus euismod. Quisque leo sapien, dapibus ut erat a, gravida commodo leo. Proin in pellentesque diam, a scelerisque velit. Ut molestie elit eget diam sollicitudin luctus.
         </p>
         <p class="hrb-text--body-copy">
           In egestas metus tellus, id blandit diam viverra pretium. Sed leo risus, fermentum ac luctus ac, malesuada quis odio. Nam sagittis efficitur ante, et volutpat arcu sodales pharetra. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aliquam erat volutpat. In vel dictum diam, at eleifend tellus. Aliquam ullamcorper, urna in bibendum fringilla, lectus lacus semper sapien, in sollicitudin nibh purus vitae ex.
         </p>
       </hrb-accordion-item>
       <hrb-accordion-item accordion-id="acdn3" header-text="Open Accordion Now">
         <p class="hrb-text--body-copy">
           Morbi consectetur purus mollis efficitur elementum at neque augue. Nulla facilisi. Donec suscipit est a mauris rhoncus euismod. Quisque leo sapien, dapibus ut erat a, gravida commodo leo. Proin in pellentesque diam, a scelerisque velit. Ut molestie elit eget diam sollicitudin luctus.
         </p>
         <p class="hrb-text--body-copy">
           In egestas metus tellus, id blandit diam viverra pretium. Sed leo risus, fermentum ac luctus ac, malesuada quis odio. Nam sagittis efficitur ante, et volutpat arcu sodales pharetra. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aliquam erat volutpat. In vel dictum diam, at eleifend tellus. Aliquam ullamcorper, urna in bibendum fringilla, lectus lacus semper sapien, in sollicitudin nibh purus vitae ex.
         </p>
       </hrb-accordion-item>
     </hrb-accordion>
    `)
  })
})
