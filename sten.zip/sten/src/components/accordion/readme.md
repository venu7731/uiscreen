# hrb-accordion

Use the `hrb-accordion` component to render an accessible accordion.

The `hrb-accordion` is basically a container of a set of `hrb-accordion-item` components. This component tracks the state of each accordion item as they are expanded and collapsed.

A user can open only one accordion item at a time, meaning the accordion would close the last expanded item when opening a new one.

## Examples

```html
<hrb-accordion>
  <hrb-accordion-item header-as="h2" header-text="Option 1">
    Content #1
  </hrb-accordion-item>
  <hrb-accordion-item header-as="h2" header-text="Option 2">
    Content #2
  </hrb-accordion-item>
  <hrb-accordion-item header-as="h2" header-text="Option 3">
    Content #3
  </hrb-accordion-item>
</hrb-accordion>
```

---

The accordion can be rendered in two types: `content` (default) or `subnav`, using the `type` prop.

```html
<hrb-accordion type="subnav">
  <!-- accordion items -->
</hrb-accordion>
```

See [the hrb-accordion-item readme](../accordion-item) for more information about the `hrb-accordion-item` component.

<!-- Auto Generated Below -->


## Properties

| Property | Attribute | Description        | Type                                    | Default                 |
| -------- | --------- | ------------------ | --------------------------------------- | ----------------------- |
| `type`   | `type`    | The accordion type | `Constants.content \| Constants.subnav` | `EnumConstants.content` |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
