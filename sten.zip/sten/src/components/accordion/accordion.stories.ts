import { select, text, withKnobs } from '@storybook/addon-knobs'
import { storiesOf } from '@storybook/html'

import {
  accordionTypes,
  accordionHeaderStyles,
  htmlElements,
  reset,
} from '@src/constants/storybook'

import * as readme from './readme.md'

const accordionTitle = 'Accordion title'
const accordionContent =
  'In egestas metus tellus, id blandit diam viverra pretium. Sed leo risus, fermentum ac luctus ac, malesuada quis odio. Nam sagittis efficitur ante, et volutpat arcu sodales pharetra.'

// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
const accordionItem = (
  accordionType = accordionTypes[0],
  subnavHeaderStyle = '',
) => {
  const isSubnav = accordionType === accordionTypes[1]
  const sectionHeader = 'Section header'
  const previewText =
    'Preview text lorem ipsum dolor sit amet, consectetur adipiscing elita.'
  return `
  <hrb-accordion-item 
    header-text="${sectionHeader}" 
    ${!isSubnav && `preview-text="${previewText}"`}
    ${subnavHeaderStyle && `subnav-header-style=${subnavHeaderStyle}`}>
    <p class="hrb-text--body-copy" style="margin-bottom: 20px">
      Morbi consectetur purus mollis efficitur elementum. Suspendisse at
      neque augue. Nulla facilisi. Donec suscipit est a mauris rhoncus
      euismod. Quisque leo sapien, dapibus ut erat a, gravida commodo leo.
      Proin in pellentesque diam, a scelerisque velit. Ut molestie elit eget
      diam sollicitudin luctus.
    </p>
    <hrb-button theme="light-grey-2">Primary</hrb-button>
    <p class="hrb-text--body-copy" style="margin-top: 20px">
      In egestas metus tellus, id blandit diam viverra pretium. Sed leo
      risus, fermentum ac luctus ac, malesuada quis odio. Nam sagittis
      efficitur ante, et volutpat arcu sodales pharetra. Vestibulum ante
      ipsum primis in faucibus orci luctus et ultrices posuere cubilia
      Curae; Aliquam erat volutpat. In vel dictum diam, at eleifend tellus.
      Aliquam ullamcorper, urna in bibendum fringilla, lectus lacus semper
      sapien, in sollicitudin nibh purus vitae ex.
    </p>
  </hrb-accordion-item>
  `
}

// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
const accordion = (headerText, preview, content) => `
  <hrb-accordion>
    <hrb-accordion-item
      header-text="${headerText}"
      preview-text="${preview}">
      <p class="hrb-text--body-copy">${content}</p>
    </hrb-accordion-item>
    ${accordionItem()}
    ${accordionItem()}
  </hrb-accordion>`

// eslint-disable-next-line @typescript-eslint/explicit-function-return-type
const subnav = (headerText, content, headerStyle, headerAs) => `
  <hrb-accordion type='subnav'>
    <hrb-accordion-item
      header-as="${headerAs}"
      header-text="${headerText}"
      subnav-header-style="${headerStyle}">
      <hrb-link href="/">A link</hrb-link>
      <p class="hrb-text--body-copy" style="margin-top: 20px">${content}</p>
    </hrb-accordion-item>
    ${accordionItem(accordionTypes[1], headerStyle)}
    ${accordionItem(accordionTypes[1], headerStyle)}
  </hrb-accordion>`

const wrapperOpen = `${reset}<hrb-grid-row><hrb-grid-col col-span-s="3/16" col-span-s="5/14" col-span-l="9/26">`
const wrapperClose = `</hrb-grid-col></hrb-grid-row>`

storiesOf('Accordion', module)
  .addDecorator(withKnobs)
  .addParameters({
    jest: ['hrb-accordion'],
    notes: { markdown: readme },
  })
  .add('Content', () => {
    return `${wrapperOpen}

    ${accordion(
      text('Title', accordionTitle),
      text('Preview', 'Accordion preview'),
      text('Content', accordionContent),
    )}
    
    ${wrapperClose}`
  })
  .add('Subnav', () => {
    return `${wrapperOpen}

    ${subnav(
      text('Title', accordionTitle),
      text('Content', accordionContent),
      select(
        'Subnav header style',
        accordionHeaderStyles,
        accordionHeaderStyles[0],
      ),
      select('Header As', htmlElements, htmlElements[1]),
    )}
    
    ${wrapperClose}`
  })
