import { Component, Element, Host, h, Listen, Prop } from '@stencil/core'

import {
  Constants as EnumConstants,
  TAccordionTypes,
} from '../accordion-item/types'

interface AccordionItem extends HTMLElement {
  type?: string
}

const Constants = {
  baseClassname: 'hrb-accordion',
}

@Component({
  tag: 'hrb-accordion',
})
export class HrbAccordion {
  activeAccordion = null

  /**
   * The accordion type
   */
  @Prop() type?: TAccordionTypes = EnumConstants.content

  @Element() host: HTMLDivElement

  componentWillLoad(): void {
    const { host, type } = this

    if (host.children && type === 'subnav') {
      const children: Element[] = Array.from(host.children)

      children.forEach((item: AccordionItem) => {
        item.type = type // eslint-disable-line no-param-reassign
      })
    }
  }

  @Listen('accordionToggled')
  accordionToggledHandler(
    event: CustomEvent & {
      target: { setIsExpanded: (isExpanded: boolean) => void }
    },
  ): void {
    const { detail, target } = event

    if (this.activeAccordion) {
      this.activeAccordion.setIsExpanded(false)
    }

    target.setIsExpanded(detail)
    this.activeAccordion = target
  }

  render(): JSX.Element {
    return (
      <Host class={`${Constants.baseClassname}--${this.type}`}>
        <slot></slot>
      </Host>
    )
  }
}
