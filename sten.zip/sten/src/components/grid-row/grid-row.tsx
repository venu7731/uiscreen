import { Component, Element, Host, h, Prop } from '@stencil/core'

const Constants = {
  baseClassname: 'hrb-grid-row',
}

@Component({
  tag: 'hrb-grid-row',
  styleUrl: 'grid-row.scss',
})
export class GridRow {
  @Element() el: HTMLElement

  @Prop() theme: string

  render(): JSX.Element {
    return (
      <Host class={Constants.baseClassname}>
        <slot />
      </Host>
    )
  }
}
