import { newSpecPage } from '@stencil/core/testing'

import { GridRow } from '../grid-row'

describe('GridRow', () => {
  it('renders', async () => {
    const page = await newSpecPage({
      components: [GridRow],
      html: `
      <hrb-grid-row>
        <div></div>
      </hrb-grid-row>
      `,
    })
    expect(page.root).toEqualHtml(`
    <hrb-grid-row class="hrb-grid-row">
      <div></div>
    </hrb-grid-row>
    `)
  })
})
