# hrb-grid-row

The package provides a flexible grid system for developers to use. The grid system uses `css-grid`, as an easy way to implement any type of modern layout.

The concept is simple. To layout elements based on the grid system, the package provides 2 main components:

- `hrb-grid-row`
- `hrb-grid-col`

The `hrb-grid-row` component represents a row, based on the grid system from the design guidelines. It's a simple container using `display:grid` to generate the correct columns template.

```html
<hrb-grid-row>
  <!-- rows -->
</hrb-grid-row>
```

The number of available columns in a row depends of the current viewport width, based on the defined breakpoints. According to the guidelines:

- (default: 0 to 389px) -> 17 columns
- small: 390px to 759px -> 17 columns
- medium 760px to 1559px -> 17 columns
- large: 1560px and beyond -> 35 columns

A `hrb-grid-row` element should only have `hrb-grid-col` direct children.

---

A `hrb-grid-col` element is a container which width and position are based on the grid.

Use the `col-span` prop to determine the width and position of the `hrb-grid-col` element, with a `n1/n2` format.

`n1` is the starting column position, and `n2` is the ending column position. If the format is wrong, a log is generated in the console.

For instance, to make a container start at the column #5 and end at the column #10:

```html
<hrb-grid-row>
  <hrb-grid-col col-span="5/10">
    <!-- content -->
  </hrb-grid-col>
</hrb-grid-row>
```

The `col-span` prop applies the generated starting and ending column position across all the breakpoints and different grid setup.

To override that value, a prop is available for each breakpoint:

- `col-span-s` (similar to `col-span`, from 0px and above)
- `col-span-m` (from 760px and above)
- `col-span-l` (from 1560px and above)

Don't forget, each breakpoint also comes with its own number of column, potentially different from the previous one.

```html
<hrb-grid-row>
  <hrb-grid-col col-span-s="1/5" col-span-m="1/10">
    <!-- content -->
  </hrb-grid-col>
  <hrb-grid-col col-span-s="10/15" col-span-m="15/25">
    <!-- content -->
  </hrb-grid-col>
</hrb-grid-row>
```

---

This approach also allows nested grid. Any `hrb-grid-col` can behave as a grid container by using the `is-grid` prop.

```html
<hrb-grid-row>
  <hrb-grid-col is-grid col-span="6/9" col-span-l="10/14">
    <hrb-grid-col col-span="2/4">
      <!-- content -->
    </hrb-grid-col>
  </hrb-grid-col>
</hrb-grid-row>
```

<!-- Auto Generated Below -->


## Properties

| Property | Attribute | Description | Type     | Default     |
| -------- | --------- | ----------- | -------- | ----------- |
| `theme`  | `theme`   |             | `string` | `undefined` |


## Dependencies

### Used by

 - [hrb-grid-ghost](../grid-ghost)

### Graph
```mermaid
graph TD;
  hrb-grid-ghost --> hrb-grid-row
  style hrb-grid-row fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
