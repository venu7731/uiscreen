declare module '*.md'
declare module '@tarekraafat/autocomplete.js'
declare module 'mkdirp'
declare module 'svg-sprite'
