/**
 * Credits : https://stackoverflow.com/a/14570614
 * @param el
 * @param cb
 */
export const observeDOM = (el, cb): void => {
  if (!el || el.nodeType !== 1) return

  if (window.MutationObserver) {
    // define a new observer
    const mutationObserver = new MutationObserver(cb)

    // have the observer observe foo for changes in children
    mutationObserver.observe(el, { childList: true, subtree: true })
  }

  // browser support fallback
  else if (window.addEventListener) {
    el.addEventListener('DOMNodeInserted', cb, false)
    el.addEventListener('DOMNodeRemoved', cb, false)
  }
}
