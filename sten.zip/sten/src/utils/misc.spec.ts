import { getClassnames } from './misc'

const Constants = {
  false: false,
  true: true,
}

describe('getClassnames', () => {
  it('Formats single class', () => {
    const test = ['classname-one']
    const expected = 'classname-one'

    expect(getClassnames(test)).toEqual(expected)
  })

  it('Formats multiple classes', () => {
    const test = ['classname-one', 'classname-two', 'classname-three']
    const expected = 'classname-one classname-two classname-three'

    expect(getClassnames(test)).toEqual(expected)
  })

  it('Formats truthy classes', () => {
    const test = [
      Constants.true && 'classname-one',
      Constants.true && 'classname-two',
      Constants.true && 'classname-three',
    ]
    const expected = 'classname-one classname-two classname-three'

    expect(getClassnames(test)).toEqual(expected)
  })

  it('Formats falsey classes', () => {
    const test = [
      Constants.false && 'classname-one',
      Constants.false && 'classname-two',
      Constants.false && 'classname-three',
    ]
    const expected = ''

    expect(getClassnames(test)).toEqual(expected)
  })

  it('Formats combination classes', () => {
    const test = [
      Constants.false && 'classname-one',
      Constants.true && 'classname-two',
      'classname-three',
    ]
    const expected = 'classname-two classname-three'

    expect(getClassnames(test)).toEqual(expected)
  })

  it('Formats empty class', () => {
    const test = []
    const expected = ''

    expect(getClassnames(test)).toEqual(expected)
  })
})
