export const stringToDashCase = (str: string): string => {
  const formattedString = str
    .trim()
    .replace(/([A-Z])/g, '-$1')
    .replace(/([0-9]+)/g, '-$1')
    .replace(/[-_\s]+/g, '-')
    .toLowerCase()

  const isFirstCharADash = formattedString.charAt(0) === '-'

  return isFirstCharADash ? formattedString.substr(1) : formattedString
}
