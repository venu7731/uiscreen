export const randomString = (maxLength?: number): string =>
  // Simple pseudo-random string generator. The length of the output is limited
  // by the precision of Math.random() and maxLength.
  Math.random()
    .toString(36)
    .substring(2, maxLength)

export const randomLetter = (): string => {
  const characters = 'abcdefghijklmnopqrstuvwxyz'
  const charactersArray = characters.split('')
  const randLetter =
    charactersArray[Math.floor(Math.random() * charactersArray.length)]

  return randLetter
}

// we're enforcing IDs that start with a letter
// by inserting a random letter
export const generateSimpleID = (): string =>
  `${randomLetter()}${randomString(10)}`

export const difference = (a: number, b: number): number => Math.abs(a - b)

export const sort = (valueA: string, valueB: string): number => {
  if (valueA.match < valueB.match) return -1
  if (valueA.match > valueB.match) return 1

  return 0
}

export const getClassnames = (classArray: string[]): string =>
  classArray
    .filter(classname => !!classname)
    .join(' ')
    .trim()

export const ratioToPercentage = (ratio: string): number => {
  const [first, second] = ratio.split('/')

  const aspectRatioAsPercentage =
    (parseInt(second, 10) / parseInt(first, 10)) * 100

  return aspectRatioAsPercentage
}

export const functionQueue = []
