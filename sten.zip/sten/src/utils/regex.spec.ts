import { numberSlashNumber } from './regex'

describe('numberSlashNumber', () => {
  it('validates 1/1', () => {
    const string = '1/1'

    expect(numberSlashNumber.test(string)).toEqual(true)
  })

  it('validates 01/400', () => {
    const string = '01/400'

    expect(numberSlashNumber.test(string)).toEqual(true)
  })

  it('fails a/400', () => {
    const string = 'a/400'

    expect(numberSlashNumber.test(string)).toEqual(false)
  })

  it('fails 17', () => {
    const string = '17'

    expect(numberSlashNumber.test(string)).toEqual(false)
  })

  it('fails 1/', () => {
    const string = '1/'

    expect(numberSlashNumber.test(string)).toEqual(false)
  })

  it('fails /5', () => {
    const string = '/5'

    expect(numberSlashNumber.test(string)).toEqual(false)
  })
})
