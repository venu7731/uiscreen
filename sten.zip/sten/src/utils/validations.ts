import buttonTypes from '@src/constants/button-types'
import colors from '@src/constants/colors'
import icons from '@src/constants/icons'
import {
  navLinkStyleTypeOptions,
  styleTypeOptions,
} from '@src/constants/text-styles'

export const getIsValidColor = (color: string): boolean =>
  Object.keys(colors).includes(color)

export const getIsValidIcon = (icon: string): boolean => icons.includes(icon)

export const getIsValidButtonType = (type: string): boolean =>
  Object.values(buttonTypes).includes(type)

export const getIsValidNavLinkStyleType = (type: string): boolean =>
  Object.values(navLinkStyleTypeOptions).includes(type)

export const getIsValidStyleType = (type: string): boolean =>
  Object.values(styleTypeOptions).includes(type)
