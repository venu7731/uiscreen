import { getIsValidColor } from './validations'

describe('getIsValidColor', () => {
  it('Fails if the color passed is not valid', () => {
    expect(getIsValidColor('purple')).toBe(false)
  })

  it('Passes if the color passed is valid', () => {
    expect(getIsValidColor('primaryBlack')).toBe(true)
  })
})
