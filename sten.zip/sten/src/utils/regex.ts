export const numberSlashNumber = /\d+\/\d+/
