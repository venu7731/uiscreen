import { stringToDashCase } from './strings'

describe('camelCaseToDashCase', () => {
  it('formats camel case string', () => {
    expect(stringToDashCase('myCamelCaseVariable')).toEqual(
      'my-camel-case-variable',
    )
  })

  it('formats camel case string with single capital letter', () => {
    expect(stringToDashCase('myCamelCaseAVariable')).toEqual(
      'my-camel-case-a-variable',
    )
  })

  it('formats string with capital letter at start', () => {
    expect(stringToDashCase('MyCapitalLetterVariable')).toEqual(
      'my-capital-letter-variable',
    )
  })

  it('formats camel case string with a double digit number', () => {
    expect(stringToDashCase('myCamelCaseVariable50')).toEqual(
      'my-camel-case-variable-50',
    )
  })

  it('formats camel case string with a single digit number', () => {
    expect(stringToDashCase('myCamelCaseVariable5')).toEqual(
      'my-camel-case-variable-5',
    )
  })

  it('formats camel case string with multiple number instance', () => {
    expect(stringToDashCase('myCamel50Case5Variable100')).toEqual(
      'my-camel-50-case-5-variable-100',
    )
  })
})
