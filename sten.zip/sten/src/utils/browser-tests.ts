export const isIe11 = !!window.MSInputMethodContext && !!document.DOCUMENT_NODE

export const isMobileOrTablet =
  typeof window.orientation !== 'undefined' ||
  !!navigator.userAgent.match(/IEMobile/) ||
  !!navigator.userAgent.match(/Android/i) ||
  !!navigator.userAgent.match(/webOS/i) ||
  !!navigator.userAgent.match(/iPhone/i) ||
  !!navigator.userAgent.match(/iPad/i) ||
  !!navigator.userAgent.match(/iPod/i) ||
  !!navigator.userAgent.match(/BlackBerry/i)

export const hasIntersectionObserverSupport = 'IntersectionObserver' in window

export const hasLoadingSupport =
  !!window.HTMLImageElement && 'loading' in window.HTMLImageElement.prototype
