const container = {
  containerPaddingSmall: 5.13,
  containerPaddingMedium: 5.26,
  containerPaddingLarge: 5.13,
}

export default container
