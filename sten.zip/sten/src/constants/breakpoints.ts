const breakpoints = {
  screenSmallMin: 500,
  screenMediumMin: 900,
  screenLargeMin: 1200,
}

export default breakpoints
