const buttonTypes = {
  anchor: 'a',
  button: 'button',
  span: 'span',
}

export default buttonTypes
