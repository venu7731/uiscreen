const columns = {
  colS: 17,
  colM: 17,
  colL: 35,
}

export default columns
