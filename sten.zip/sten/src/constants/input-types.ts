const inputTypes = [
  'date',
  'email',
  'number',
  'password',
  'search',
  'tel',
  'text',
  'url',
]

export default inputTypes
