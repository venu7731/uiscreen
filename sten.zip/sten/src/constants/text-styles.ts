export const styleTypeOptions = [
  'body-copy',
  'body-copy-small',
  'card',
  'cta',
  'cta-qualifier',
  'cta-small',
  'headline-one',
  'headline-three',
  'headline-four',
  'headline-five',
  'jumbo',
  'large',
  'little',
  'medium',
  'metadata',
  'small',
]

export const navLinkStyleTypeOptions = [
  'body-copy',
  'large',
  'little',
  'medium',
  'small',
]
