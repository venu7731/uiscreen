/* eslint-disable @typescript-eslint/camelcase */

import environment from './environment'

const { NODE_ENV } = process.env
const isQaEnv = !!NODE_ENV && NODE_ENV === environment.qa
// `${environment.staticBucketUrl}/${npm_package_version}/fonts/`

const assetUrls = {
  fontSrcBase: isQaEnv
    ? `${environment.staticBucketUrl}/fonts/`
    : '/assets/fonts/',
}

export default assetUrls
