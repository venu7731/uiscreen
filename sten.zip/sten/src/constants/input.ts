export const HrbInputConstants = {
  baseClassname: 'hrb-input',
  iconAnimationTimeoutDuration: 100,
  passwordToggleIcon: {
    eye: 'eye',
    eyeFilled: 'eye-filled',
  },
  passwordToggleTypes: {
    password: 'password',
    text: 'text',
  },
  passwordToggleLabels: {
    hidePassword: 'Hide password',
    showPassword: 'Show password',
  },
}
