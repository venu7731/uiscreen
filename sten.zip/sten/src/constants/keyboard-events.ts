export const key = {
  ArrowDown: 'arrowDown',
  ArrowUp: 'arrowUp',
  Down: 'arrowDown',
  Home: 'home',
  End: 'end',
  Esc: 'escape',
  Escape: 'escape',
  PageDown: 'pageDown',
  PageUp: 'pageUp',
  Enter: 'returnK',
  ' ': 'space',
  Spacebar: 'space',
  Up: 'arrowUp',
}

export const keyCode = {
  40: 'arrowDown',
  38: 'arrowUp',
  36: 'home',
  35: 'end',
  27: 'escape',
  34: 'pageDown',
  33: 'pageUp',
  13: 'returnK',
  32: 'space',
}

export const keysThatOpenDropdown = [
  'arrowDown',
  'arrowUp',
  'pageDown',
  'pageUp',
  'space',
]

export const upAndDownArrows = ['arrowDown', 'arrowUp']
