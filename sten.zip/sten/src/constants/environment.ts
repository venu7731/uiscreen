const environment = {
  prod: 'prod',
  qa: 'qa',
  sandbox: 'sandbox',
  staticBucketUrl: 'https://a3dvbdsuclassets.z19.web.core.windows.net/',
}

export default environment
