# Build and Release Processes

## UCL build, release and NPM package creation process

### NPM package version update

A new version of the NPM package will be created anytime a new release branch is pushed to the repo. Every release requires a unique package version.

1. Get the latest from `master`: `git checkout master && git pull --rebase`
2. Update the package version number in `package.json`. We follow the semantic versioning pattern as described here: [https://docs.npmjs.com/about-semantic-versioning](https://docs.npmjs.com/about-semantic-versioning)
3. Push this update to `master` directly or via a new branch and PR. note: this is the one case in which we would consider pushing directly to `master` but extreme care should be taken.
4. Checkout a release branch from `master`: `git checkout -b releases/v0.1.0`. The branch name MUST start with `releases/` for the Azure pipeline to recognize that this is a release. After `releases/` we follow a naming pattern of `v` and then the version of the current build.
5. Push this newly created release branch to the repo: `git push -u origin releases/v0.1.0`. This will trigger the Azure pipeline build and release.

### Storybook Sandbox

The Storybook sandbox environment is updated everytime the `master` branch is updated.

Sandbox Environment URL: [https://a1sbbdsuclstorybook.z19.web.core.windows.net](https://a1sbbdsuclstorybook.z19.web.core.windows.net)

### Storybook QA

The Storybook QA environment is updated everytime a `releases/` branch is pushed to the repo via the NPM package version update process.

QA Environment URL: [https://a1sbbdsuclstorybookqa.z19.web.core.windows.net](https://a1sbbdsuclstorybookqa.z19.web.core.windows.net)

## RIE build and release

### Updating NPM package version

After each UCL package update the RIE `package.json` needs be updated to include the latest version.

1. Pull the latest from `master`: `git checkout master && git pull --rebase`
2. In `package.json` update the `hrblock-design-system-components` version to match the latest update from the UCL.
3. Run a fresh install to update the `package-lock.json` file: `npm install`
4. Push this update to `master` directly or via a new branch and PR. As with the UCL this is the one instance in which we would consider pushing directly to `master`.

### RIE Sandbox

The RIE sandbox environment is updated each time the `master` branch is updated.

Sandbox Environment URL: [https://a1sbbdsrie.z19.web.core.windows.net](https://a1sbbdsrie.z19.web.core.windows.net)

### RIE QA

The RIE QA environment is updated everytime a `releases/` branch is pushed to the repo:

1. Get the latest from `master`: `git checkout master && git pull --rebase`
2. Checkout a release branch from `master`: `git checkout -b releases/v0.1.0`. The branch names MUST start with `releases/` for the Azure pipeline to recognize that this is a release. After `releases/` we follow a naming pattern of `v` and then the version of the current build.
3. Push this newly created release branch to the repo: `git push -u origin releases/v0.1.0`. This will trigger the Azure pipeline build and release.

QA Environment URL: [https://a1sbbdsrieqa.z19.web.core.windows.net](https://a1sbbdsrieqa.z19.web.core.windows.net)
