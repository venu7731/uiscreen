import { Config } from '@stencil/core'
import {
  angularOutputTarget,
  ValueAccessorConfig,
} from '@stencil/angular-output-target'
import { sass } from '@stencil/sass'
import { inlineSvg } from 'stencil-inline-svg'
import * as process from 'process'

const GLOBAL_SASS_PATH = 'src/sass/styles.scss'

// Value Accessors for form inputs
const angularValueAccessorBindings: ValueAccessorConfig[] = [
  {
    elementSelectors: ['hrb-select'],
    event: 'hrbChange',
    targetAttr: 'value',
    type: 'select',
  },
  {
    elementSelectors: ['hrb-input'],
    event: 'hrbChange',
    targetAttr: 'value',
    type: 'text',
  },
  {
    elementSelectors: ['hrb-radio'],
    event: 'hrbChange',
    targetAttr: 'value',
    type: 'radio',
  },
  {
    elementSelectors: ['hrb-checkbox', 'hrb-toggle'],
    event: 'hrbChange',
    targetAttr: 'value',
    type: 'boolean',
  },
]

export const config: Config = {
  devServer: {
    openBrowser: false,
  },
  globalStyle: GLOBAL_SASS_PATH,
  namespace: 'hrblock-design-system',
  outputTargets: [
    angularOutputTarget({
      componentCorePackage: '@bds/bds-core',
      directivesProxyFile: '../angular/src/directives/generated/proxies.ts',
      valueAccessorConfigs: angularValueAccessorBindings,
    }),
    {
      type: 'dist',
      esmLoaderPath: '../loader',
    },
    {
      type: 'docs-readme',
    },
    {
      copy: [{ src: 'components' }],
      type: 'www',
      serviceWorker: null, // disable service workers
    },
    {
      type: 'dist',
      copy: [
        {
          src: 'assets',
          dest: `../src/assets/${process.env.npm_package_version}`,
        },
        { src: 'assets', dest: '../assets' },
      ],
    },
  ],
  plugins: [
    inlineSvg(),
    sass({
      includePaths: ['src/sass/'],
      injectGlobalPaths: [GLOBAL_SASS_PATH],
    }),
  ],
  testing: {
    moduleNameMapper: {
      '^@src(.*)$': '<rootDir>/src$1',
    },
  },
}
