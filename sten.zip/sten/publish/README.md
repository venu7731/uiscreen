[nvm]: https://github.com/nvm-sh/nvm
[sass]: https://sass-lang.com
[stencil]: https://stenciljs.com
[stencil-genator]: https://stenciljs.com/docs/my-first-component#component-generator
[storybook]: https://storybook.js.org/
[tech-brief]: https://docs.google.com/document/d/1Q4uYSik9WGW1RVx2vdnGTytNxiHzlSFJ_4EfyNmls2g
[typescript]: https://www.typescriptlang.org
[7-1-pattern]: https://sass-guidelin.es/#the-7-1-pattern
[bem-101]: https://css-tricks.com/bem-101

# UI Component Library (UCL)

> This repository hosts the source for H&R Block Design System's UCL. For more details, please refer to the [Tech Brief][tech-brief].

## Contents

- [UI Component Library (UCL)](#ui-component-library-ucl)
  - [Contents](#contents)
  - [Installing the NPM Package](#installing-the-hrblock-design-system-components-package)
  - [Build and Release Process](docs/RELEASES.md)
  - [Build URLs](#build-urls)
    - [QA environment](#qa-environment)
    - [Sandbox environment](#sandbox-environment)
  - [Requirements](#requirements)
  - [Build](#build)
  - [Development](#development)
    - [Generating Components](#generating-components)
  - [Testing](#testing)
  - [Stack](#stack)
  - [CSS](#css)
    - [Architecture](#architecture)
    - [Common Patterns](#common-patterns)
  - [Global Component](#global-component)
  - [Global CSS Classes](#global-css-classes)

## Installing the hrblock-design-system-components package

Running the [release process](docs/RELEASES.md) generates an NPM package to be used outside the UCL environment. Installing this package requires an `.npmrc` configuration which is described in the [Microsoft Azure documentation](https://docs.microsoft.com/en-us/azure/devops/artifacts/npm/npmrc).

## Build URLs

### QA environment

- RIE: [https://a1sbbdsrieqa.z19.web.core.windows.net](https://a1sbbdsrieqa.z19.web.core.windows.net)
- Storybook: [https://a1sbbdsuclstorybookqa.z19.web.core.windows.net](https://a1sbbdsuclstorybookqa.z19.web.core.windows.net)

### Sandbox environment

- RIE: [https://a1sbbdsrie.z19.web.core.windows.net](https://a1sbbdsrie.z19.web.core.windows.net)
- Storybook: [https://a1sbbdsuclstorybook.z19.web.core.windows.net](https://a1sbbdsuclstorybook.z19.web.core.windows.net)

## Requirements

- This project requires Node version `10.17.0`
- Using [nvm][nvm] to specify the exact version in development is encouraged. Once nvm is installed with the correct Node version this command will make sure it's being used in the current terminal instance `nvm use 10.17.0`.

## Build

```bash
$ # Install all dependencies
npm install
$ # Build app
npm run build
```

## Development

To startup a local server:

```bash
npm start
```

### Generating Components

When creating a new component use the `hrb` tag to name it. E.g., `hrb-button` or `hrb-layout`.

1. Use the [Stencil CLI][stencil-genator] to generate a new component.

```bash
npm run generate
```

2. Change the generated style file's extension to `.scss`
3. Update the extension on the reference to that style file in the component's `tsx` file. E.g., from `styleUrl: 'my-component.css'` to `styleUrl: 'my-component.scss'`.
4. Copy the `/src/index.html` file to the new component's directory and change the contents of the `<body>` tag so that the new component is rendered in it
5. Add the `<hrb-global />` component at the top of the body of `index.html` file

## Testing

To run the unit tests for the components, run:

```bash
npm test
```

## Stack

- [Stencil][stencil] as Web Component compiler
- [Storybook] as UI component framework
- [Sass][sass] as CSS precompiler
- [TypeScript][typescript] as programming language

## CSS

- This project uses Sass to style components

### Architecture

- We follow a modified version of the [7/1 Pattern][7-1-pattern]
- We use the [BEM Methodology][bem-101] of naming CSS classes

### Common Patterns

- When using Sass lists, use a comma to divide each item

## Global Component

The `<hrb-global />` global component injects global styles needed by the UCL components to render as designed. This includes a CSS reset, and `@font-face` declarations to import the project's custom fonts.

The CSS Reset portion of this component is optional relies on the `reset` prop being passed to the global component: `<hrb-global reset />`

## Global CSS Classes

This project includes a set of global CSS classes to facilitate the basic styling of elements within the library's established styles.

The following is the list of styles and corresponding Sass files that generate classes for them:

- Color and background color: `src/sass/global/color-classes.scss`
- Font styles: `src/sass/global/type-classes.scss`
