import { select, withKnobs } from '@storybook/addon-knobs'

import { backgroundOptions } from '@src/constants/storybook'
import colors from '@src/constants/colors'

/* eslint-disable-next-line */
const stringToUpperCase = str => str.replace(/([a-z])([A-Z, 0-9])/g, '$1 $2')

const colorArray = Object.keys(colors)

/* eslint-disable-next-line */
const swatch = (label, color) => `
  <div class="hrb-text--body-copy">
    <div
      class="color-swatch__sample"
      style="background: ${color}; height: 120px; width: 100%"
    ></div>
    <span style="display: block; text-transform: capitalize">
    ${stringToUpperCase(label)}
    </span>

    <span style="display: block; text-transform: capitalize">
    ${color}
    </span>
  </div>
`

/* eslint-disable-next-line */
export const colorSwatches = () => {
  return `<div style="display: grid; grid-template-columns: 1fr 1fr 1fr; grid-column-gap: 40px; grid-row-gap: 40px; margin: 0 auto; max-width: 90%; padding: 60px 0;">
  ${colorArray.map(color => swatch(color, colors[color])).join('')}
    </div>`
}

/* eslint-disable-next-line */
export const colorSelect = () => {
  const selects = [
    select('First Color', colorArray, 'green'),
    select('Second Color', colorArray, 'yellow'),
    select('Third Color', colorArray, 'blue'),
  ]

  return `<div style="display: grid; grid-template-columns: 1fr 1fr 1fr; grid-column-gap: 40px; grid-row-gap: 40px; margin: 0 auto; max-width: 90%; padding: 60px 0;">

      ${selects.map(selection => swatch(selection, colors[selection])).join('')}

    </div>`
}

export default {
  decorators: [withKnobs],
  title: 'Theme',
  parameters: { backgrounds: backgroundOptions },
}
