import { ChangeDetectorRef, ElementRef, HostListener } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

export class ValueAccessor implements ControlValueAccessor {

  private onChange: (value: any) => void = () => {/**/ };
  private onTouched: () => void = () => {/**/ };
  protected lastValue: any;

  constructor(protected el: ElementRef, protected cdr: ChangeDetectorRef) { }

  writeValue(value: any) {
    this.el.nativeElement.value = this.lastValue = value == null ? '' : value;
    this.cdr.markForCheck();
  }

  handleChangeWithCheck(value: any) {
    if (value !== this.lastValue) {
      this.lastValue = value;
      this.onChange(value);
    }
  }

  handleChange(value: any){
    console.log(' change value ' + value)
    this.onChange(value);
  }

  @HostListener('focusout')
  _handleBlurEvent() {
    this.onTouched();
  }

  registerOnChange(fn: (value: any) => void) {
    this.onChange = fn;
  }
  registerOnTouched(fn: () => void) {
    this.onTouched = fn;
  }
}
