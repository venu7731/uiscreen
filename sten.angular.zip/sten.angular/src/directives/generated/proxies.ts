/* tslint:disable */
/* auto-generated angular directive proxies */
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, EventEmitter, NgZone } from '@angular/core';
import { fromEvent } from 'rxjs';

export const proxyInputs = (Cmp: any, inputs: string[]) => {
  const Prototype = Cmp.prototype;
  inputs.forEach(item => {
    Object.defineProperty(Prototype, item, {
      get() { return this.el[item]; },
      set(val: any) { this.z.runOutsideAngular(() => (this.el[item] = val)); }
    });
  });
};

export const proxyMethods = (Cmp: any, methods: string[]) => {
  const Prototype = Cmp.prototype;
  methods.forEach(methodName => {
    Prototype[methodName] = function () {
      const args = arguments;
      return this.z.runOutsideAngular(() => this.el[methodName].apply(this.el, args));
    };
  });
};

export const proxyOutputs = (instance: any, el: any, events: string[]) => {
  events.forEach(eventName => instance[eventName] = fromEvent(el, eventName));
}

// tslint:disable-next-line: only-arrow-functions
export function ProxyCmp(opts: { inputs?: any; methods?: any }) {
  const decorator =  function(cls: any){
    if (opts.inputs) {
      proxyInputs(cls, opts.inputs);
    }
    if (opts.methods) {
      proxyMethods(cls, opts.methods);
    }
    return cls;
  };
  return decorator;
}

import { Components } from '@bds/bds-core'

export declare interface HrbAccordion extends Components.HrbAccordion {}
@ProxyCmp({inputs: ['type']})
@Component({ selector: 'hrb-accordion', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['type'] })
export class HrbAccordion {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbAccordionItem extends Components.HrbAccordionItem {}
@ProxyCmp({inputs: ['accordionId', 'disabled', 'headerAs', 'headerText', 'previewText', 'subnavHeaderStyle', 'type'], 'methods': ['setIsExpanded']})
@Component({ selector: 'hrb-accordion-item', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['accordionId', 'disabled', 'headerAs', 'headerText', 'previewText', 'subnavHeaderStyle', 'type'] })
export class HrbAccordionItem {
  accordionToggled!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['accordionToggled']);
  }
}

export declare interface HrbAttachmentItem extends Components.HrbAttachmentItem {}
@ProxyCmp({inputs: ['FileName', 'FileSize', 'isEditable']})
@Component({ selector: 'hrb-attachment-item', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['FileName', 'FileSize', 'isEditable'] })
export class HrbAttachmentItem {
  removeAttachment!: EventEmitter<CustomEvent>;
  deleteAttachment!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['removeAttachment', 'deleteAttachment']);
  }
}

export declare interface HrbAttachmentList extends Components.HrbAttachmentList {}
@ProxyCmp({inputs: ['attachments', 'collapsed', 'edit', 'itemCount'], 'methods': ['toggleList']})
@Component({ selector: 'hrb-attachment-list', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['attachments', 'collapsed', 'edit', 'itemCount'] })
export class HrbAttachmentList {
  attachmentListToggle!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['attachmentListToggle']);
  }
}

export declare interface HrbAutocomplete extends Components.HrbAutocomplete {}
@ProxyCmp({inputs: ['debounce', 'disabled', 'errorLabel', 'hasError', 'helperText', 'inputId', 'keys', 'label', 'loading', 'maxResults', 'name', 'readonly', 'required', 'threshold', 'type', 'value'], 'methods': ['getElement', 'setData', 'setFocus']})
@Component({ selector: 'hrb-autocomplete', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['debounce', 'disabled', 'errorLabel', 'hasError', 'helperText', 'inputId', 'keys', 'label', 'loading', 'maxResults', 'name', 'readonly', 'required', 'threshold', 'type', 'value'] })
export class HrbAutocomplete {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbAvatar extends Components.HrbAvatar {}
@ProxyCmp({inputs: ['icon', 'image', 'imageAlt', 'size', 'text', 'theme']})
@Component({ selector: 'hrb-avatar', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['icon', 'image', 'imageAlt', 'size', 'text', 'theme'] })
export class HrbAvatar {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbBadgeLabel extends Components.HrbBadgeLabel {}
@ProxyCmp({inputs: ['badgeSubtitle', 'badgeTitle', 'icon', 'image', 'imageAlt', 'size', 'text', 'theme']})
@Component({ selector: 'hrb-badge-label', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['badgeSubtitle', 'badgeTitle', 'icon', 'image', 'imageAlt', 'size', 'text', 'theme'] })
export class HrbBadgeLabel {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbButton extends Components.HrbButton {}
@ProxyCmp({inputs: ['disabled', 'fullWidth', 'icon', 'iconPosition', 'loading', 'pAriaLabel', 'pAriaLabelledby', 'pAriaPressed', 'pAriaRole', 'qualifier', 'secondary', 'size', 'theme', 'type']})
@Component({ selector: 'hrb-button', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['disabled', 'fullWidth', 'icon', 'iconPosition', 'loading', 'pAriaLabel', 'pAriaLabelledby', 'pAriaPressed', 'pAriaRole', 'qualifier', 'secondary', 'size', 'theme', 'type'] })
export class HrbButton {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbCard extends Components.HrbCard {}
@ProxyCmp({inputs: ['animateBoot', 'animateHat', 'as', 'hasBoot', 'hasHat', 'theme']})
@Component({ selector: 'hrb-card', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['animateBoot', 'animateHat', 'as', 'hasBoot', 'hasHat', 'theme'] })
export class HrbCard {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbCardContent extends Components.HrbCardContent {}
@ProxyCmp({inputs: ['padding']})
@Component({ selector: 'hrb-card-content', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['padding'] })
export class HrbCardContent {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbCardDocument extends Components.HrbCardDocument {}
@ProxyCmp({inputs: ['addedBy', 'categoryName', 'fileName', 'headerAs', 'headerLink', 'isLoading', 'layout', 'thumbAlt', 'thumbSrc', 'uploadDate']})
@Component({ selector: 'hrb-card-document', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['addedBy', 'categoryName', 'fileName', 'headerAs', 'headerLink', 'isLoading', 'layout', 'thumbAlt', 'thumbSrc', 'uploadDate'] })
export class HrbCardDocument {
  headerClicked!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['headerClicked']);
  }
}

export declare interface HrbCardExpandable extends Components.HrbCardExpandable {}
@ProxyCmp({inputs: ['closeIcon', 'icon', 'theme'], 'methods': ['close', 'open', 'controlHeight']})
@Component({ selector: 'hrb-card-expandable', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['closeIcon', 'icon', 'theme'] })
export class HrbCardExpandable {
  hrbOpen!: EventEmitter<CustomEvent>;
  hrbClose!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['hrbOpen', 'hrbClose']);
  }
}

export declare interface HrbCheckbox extends Components.HrbCheckbox {}
@ProxyCmp({inputs: ['checked', 'disabled', 'inputId', 'name', 'required', 'theme', 'value'], 'methods': ['getElement', 'setFocus']})
@Component({ selector: 'hrb-checkbox', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['checked', 'disabled', 'inputId', 'name', 'required', 'theme', 'value'] })
export class HrbCheckbox {
  hrbBlur!: EventEmitter<CustomEvent>;
  hrbChange!: EventEmitter<CustomEvent>;
  hrbFocus!: EventEmitter<CustomEvent>;
  hrbInput!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['hrbBlur', 'hrbChange', 'hrbFocus', 'hrbInput']);
  }
}

export declare interface HrbCircleButton extends Components.HrbCircleButton {}
@ProxyCmp({inputs: ['as', 'disabled', 'href', 'pAriaControls', 'pAriaExpaned', 'pAriaLabel', 'pAriaLabelledby', 'pAriaRole', 'pTabIndex', 'rel', 'size', 'target', 'theme', 'transparent', 'type']})
@Component({ selector: 'hrb-circle-button', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['as', 'disabled', 'href', 'pAriaControls', 'pAriaExpaned', 'pAriaLabel', 'pAriaLabelledby', 'pAriaRole', 'pTabIndex', 'rel', 'size', 'target', 'theme', 'transparent', 'type'] })
export class HrbCircleButton {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbCircleButtonWithLabel extends Components.HrbCircleButtonWithLabel {}
@ProxyCmp({inputs: ['as', 'disabled', 'href', 'icon', 'pAriaLabel', 'pAriaLabelledby', 'pAriaRole', 'rel', 'target', 'theme', 'type']})
@Component({ selector: 'hrb-circle-button-with-label', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['as', 'disabled', 'href', 'icon', 'pAriaLabel', 'pAriaLabelledby', 'pAriaRole', 'rel', 'target', 'theme', 'type'] })
export class HrbCircleButtonWithLabel {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbCircled extends Components.HrbCircled {}
@ProxyCmp({inputs: ['size', 'theme']})
@Component({ selector: 'hrb-circled', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['size', 'theme'] })
export class HrbCircled {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbContainer extends Components.HrbContainer {}
@ProxyCmp({inputs: ['padding']})
@Component({ selector: 'hrb-container', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['padding'] })
export class HrbContainer {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbDataItem extends Components.HrbDataItem {}
@ProxyCmp({inputs: ['as', 'data', 'def', 'disabled', 'href', 'icon', 'label', 'metadata', 'note', 'pAriaLabel', 'pAriaLabelledby', 'pAriaRole', 'rel', 'target', 'term', 'thumbAlt', 'thumbSrc', 'type']})
@Component({ selector: 'hrb-data-item', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['as', 'data', 'def', 'disabled', 'href', 'icon', 'label', 'metadata', 'note', 'pAriaLabel', 'pAriaLabelledby', 'pAriaRole', 'rel', 'target', 'term', 'thumbAlt', 'thumbSrc', 'type'] })
export class HrbDataItem {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbDataList extends Components.HrbDataList {}
@ProxyCmp({inputs: ['theme']})
@Component({ selector: 'hrb-data-list', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['theme'] })
export class HrbDataList {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbDot extends Components.HrbDot {}
@ProxyCmp({inputs: ['active', 'pAriaLabel', 'pAriaPressed']})
@Component({ selector: 'hrb-dot', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['active', 'pAriaLabel', 'pAriaPressed'] })
export class HrbDot {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbDotNav extends Components.HrbDotNav {}
@ProxyCmp({inputs: ['pAriaLabel']})
@Component({ selector: 'hrb-dot-nav', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['pAriaLabel'] })
export class HrbDotNav {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbDropdownMenu extends Components.HrbDropdownMenu {}
@ProxyCmp({inputs: ['multiselect', 'triggerValue']})
@Component({ selector: 'hrb-dropdown-menu', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['multiselect', 'triggerValue'] })
export class HrbDropdownMenu {
  hrbOpen!: EventEmitter<CustomEvent>;
  hrbClose!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['hrbOpen', 'hrbClose']);
  }
}

export declare interface HrbDropdownMenuItem extends Components.HrbDropdownMenuItem {}
@ProxyCmp({inputs: ['PAriaSelected', 'elementId', 'name', 'role', 'type', 'value']})
@Component({ selector: 'hrb-dropdown-menu-item', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['PAriaSelected', 'elementId', 'name', 'role', 'type', 'value'] })
export class HrbDropdownMenuItem {
  menuItemClicked!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['menuItemClicked']);
  }
}

export declare interface HrbFlexCol extends Components.HrbFlexCol {}
@ProxyCmp({inputs: ['col', 'colL', 'colM', 'colS', 'isCentered', 'offsetL', 'offsetM', 'offsetS']})
@Component({ selector: 'hrb-flex-col', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['col', 'colL', 'colM', 'colS', 'isCentered', 'offsetL', 'offsetM', 'offsetS'] })
export class HrbFlexCol {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbFlexContainer extends Components.HrbFlexContainer {}
@ProxyCmp({inputs: ['pAriaLabel']})
@Component({ selector: 'hrb-flex-container', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['pAriaLabel'] })
export class HrbFlexContainer {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbFlexGhost extends Components.HrbFlexGhost {}
@ProxyCmp({inputs: ['pAriaHidden']})
@Component({ selector: 'hrb-flex-ghost', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['pAriaHidden'] })
export class HrbFlexGhost {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbFlexRow extends Components.HrbFlexRow {}
@ProxyCmp({inputs: ['alignItems', 'isCentered', 'isReversed', 'justifyContent']})
@Component({ selector: 'hrb-flex-row', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['alignItems', 'isCentered', 'isReversed', 'justifyContent'] })
export class HrbFlexRow {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbGlobal extends Components.HrbGlobal {}
@ProxyCmp({inputs: ['reset']})
@Component({ selector: 'hrb-global', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['reset'] })
export class HrbGlobal {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbGridCol extends Components.HrbGridCol {}
@ProxyCmp({inputs: ['colSpan', 'colSpanL', 'colSpanM', 'colSpanS', 'isGrid', 'row', 'rowL', 'rowM', 'rowS']})
@Component({ selector: 'hrb-grid-col', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['colSpan', 'colSpanL', 'colSpanM', 'colSpanS', 'isGrid', 'row', 'rowL', 'rowM', 'rowS'] })
export class HrbGridCol {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbGridGhost extends Components.HrbGridGhost {}
@ProxyCmp({inputs: ['pAriaHidden']})
@Component({ selector: 'hrb-grid-ghost', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['pAriaHidden'] })
export class HrbGridGhost {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbGridRow extends Components.HrbGridRow {}
@ProxyCmp({inputs: ['theme']})
@Component({ selector: 'hrb-grid-row', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['theme'] })
export class HrbGridRow {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbIcon extends Components.HrbIcon {}
@ProxyCmp({inputs: ['name']})
@Component({ selector: 'hrb-icon', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['name'] })
export class HrbIcon {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbImg extends Components.HrbImg {}
@ProxyCmp({inputs: ['alt', 'fit', 'height', 'pLoading', 'src', 'srcset', 'width']})
@Component({ selector: 'hrb-img', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['alt', 'fit', 'height', 'pLoading', 'src', 'srcset', 'width'] })
export class HrbImg {
  hrbImgWillLoad!: EventEmitter<CustomEvent>;
  hrbImgDidLoad!: EventEmitter<CustomEvent>;
  hrbError!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['hrbImgWillLoad', 'hrbImgDidLoad', 'hrbError']);
  }
}

export declare interface HrbInput extends Components.HrbInput {}
@ProxyCmp({inputs: ['allowPasswordToggle', 'autocomplete', 'copyPaste', 'disabled', 'errorLabel', 'forceIconVisibility', 'hasError', 'helperText', 'icon', 'inputId', 'label', 'loading', 'maxlength', 'minlength', 'name', 'pActivedescendant', 'pAriaAutocomplete', 'pAriaMultiline', 'pAriaOwns', 'pattern', 'readonly', 'required', 'type', 'value'], 'methods': ['getElement', 'setFocus']})
@Component({ selector: 'hrb-input', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['allowPasswordToggle', 'autocomplete', 'copyPaste', 'disabled', 'errorLabel', 'forceIconVisibility', 'hasError', 'helperText', 'icon', 'inputId', 'label', 'loading', 'maxlength', 'minlength', 'name', 'pActivedescendant', 'pAriaAutocomplete', 'pAriaMultiline', 'pAriaOwns', 'pattern', 'readonly', 'required', 'type', 'value'] })
export class HrbInput {
  hrbBlur!: EventEmitter<CustomEvent>;
  hrbChange!: EventEmitter<CustomEvent>;
  hrbFocus!: EventEmitter<CustomEvent>;
  hrbInput!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['hrbBlur', 'hrbChange', 'hrbFocus', 'hrbInput']);
  }
}

export declare interface HrbLabel extends Components.HrbLabel {}
@ProxyCmp({inputs: ['as', 'disabled', 'href', 'pAriaLabel', 'pAriaLabelledby', 'pAriaRole', 'rel', 'target', 'theme', 'type']})
@Component({ selector: 'hrb-label', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['as', 'disabled', 'href', 'pAriaLabel', 'pAriaLabelledby', 'pAriaRole', 'rel', 'target', 'theme', 'type'] })
export class HrbLabel {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbLayout extends Components.HrbLayout {}
@ProxyCmp({inputs: ['hasTransition', 'isFlush', 'isGapless', 'layout', 'layoutLarge', 'layoutMedium', 'layoutSmall']})
@Component({ selector: 'hrb-layout', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['hasTransition', 'isFlush', 'isGapless', 'layout', 'layoutLarge', 'layoutMedium', 'layoutSmall'] })
export class HrbLayout {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbLink extends Components.HrbLink {}
@ProxyCmp({inputs: ['as', 'disabled', 'href', 'icon', 'pAriaLabel', 'pAriaLabelledby', 'pAriaRole', 'rel', 'target', 'theme', 'type', 'underline']})
@Component({ selector: 'hrb-link', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['as', 'disabled', 'href', 'icon', 'pAriaLabel', 'pAriaLabelledby', 'pAriaRole', 'rel', 'target', 'theme', 'type', 'underline'] })
export class HrbLink {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbListButton extends Components.HrbListButton {}
@ProxyCmp({inputs: ['as', 'circled', 'disabled', 'href', 'icon', 'metadata', 'outlined', 'pAriaLabel', 'pAriaLabelledby', 'pAriaRole', 'rel', 'target', 'theme', 'type']})
@Component({ selector: 'hrb-list-button', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['as', 'circled', 'disabled', 'href', 'icon', 'metadata', 'outlined', 'pAriaLabel', 'pAriaLabelledby', 'pAriaRole', 'rel', 'target', 'theme', 'type'] })
export class HrbListButton {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbLoader extends Components.HrbLoader {}
@ProxyCmp({inputs: ['color']})
@Component({ selector: 'hrb-loader', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['color'] })
export class HrbLoader {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbMessageCard extends Components.HrbMessageCard {}
@ProxyCmp({inputs: ['attachments', 'badgeSubtitle', 'badgeTitle', 'clientFirstNm', 'clientLastNm', 'collapsed', 'draft', 'edit', 'latestMessage', 'messageContent', 'read', 'subject', 'taxProFirstNm', 'taxProLastNm', 'thumbAlt', 'thumbNail'], 'methods': ['toggleMessage']})
@Component({ selector: 'hrb-message-card', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['attachments', 'badgeSubtitle', 'badgeTitle', 'clientFirstNm', 'clientLastNm', 'collapsed', 'draft', 'edit', 'latestMessage', 'messageContent', 'read', 'subject', 'taxProFirstNm', 'taxProLastNm', 'thumbAlt', 'thumbNail'] })
export class HrbMessageCard {
  toggleEvent!: EventEmitter<CustomEvent>;
  replyEvent!: EventEmitter<CustomEvent>;
  addAttachment!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['toggleEvent', 'replyEvent', 'addAttachment']);
  }
}

export declare interface HrbModal extends Components.HrbModal {}
@ProxyCmp({inputs: ['disableBackground', 'modalId', 'theme', 'type'], 'methods': ['close', 'show']})
@Component({ selector: 'hrb-modal', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['disableBackground', 'modalId', 'theme', 'type'] })
export class HrbModal {
  hrbClose!: EventEmitter<CustomEvent>;
  hrbOpen!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['hrbClose', 'hrbOpen']);
  }
}

export declare interface HrbNavBar extends Components.HrbNavBar {}
@ProxyCmp({inputs: ['currentMobileMenuIcon']})
@Component({ selector: 'hrb-nav-bar', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['currentMobileMenuIcon'] })
export class HrbNavBar {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbNavLink extends Components.HrbNavLink {}
@ProxyCmp({inputs: ['as', 'disabled', 'href', 'pAriaLabel', 'pAriaLabelledby', 'pAriaRole', 'rel', 'styleType', 'target', 'type']})
@Component({ selector: 'hrb-nav-link', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['as', 'disabled', 'href', 'pAriaLabel', 'pAriaLabelledby', 'pAriaRole', 'rel', 'styleType', 'target', 'type'] })
export class HrbNavLink {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbNavLogo extends Components.HrbNavLogo {}
@ProxyCmp({inputs: ['height', 'href', 'pAriaLabel', 'rel', 'target', 'width']})
@Component({ selector: 'hrb-nav-logo', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['height', 'href', 'pAriaLabel', 'rel', 'target', 'width'] })
export class HrbNavLogo {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbNavSecondary extends Components.HrbNavSecondary {}
@ProxyCmp({inputs: ['hiddenTitle']})
@Component({ selector: 'hrb-nav-secondary', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['hiddenTitle'] })
export class HrbNavSecondary {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbNavSecondaryItem extends Components.HrbNavSecondaryItem {}
@ProxyCmp({inputs: ['as', 'disabled', 'href', 'isCurrent', 'linkText', 'rel', 'target']})
@Component({ selector: 'hrb-nav-secondary-item', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['as', 'disabled', 'href', 'isCurrent', 'linkText', 'rel', 'target'] })
export class HrbNavSecondaryItem {
  linkClicked!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['linkClicked']);
  }
}

export declare interface HrbNavbarPrimaryItem extends Components.HrbNavbarPrimaryItem {}
@ProxyCmp({inputs: ['href', 'rel', 'target', 'text']})
@Component({ selector: 'hrb-navbar-primary-item', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['href', 'rel', 'target', 'text'] })
export class HrbNavbarPrimaryItem {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbNavbarSecondaryItem extends Components.HrbNavbarSecondaryItem {}
@ProxyCmp({inputs: ['hideOnSmall', 'href', 'icon', 'rel', 'target', 'text']})
@Component({ selector: 'hrb-navbar-secondary-item', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['hideOnSmall', 'href', 'icon', 'rel', 'target', 'text'] })
export class HrbNavbarSecondaryItem {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbOptionCard extends Components.HrbOptionCard {}
@ProxyCmp({inputs: ['badgeIcon', 'badgeImage', 'badgeImageAlt', 'badgeSubtitle', 'badgeText', 'badgeTheme', 'badgeTitle', 'custom', 'disabled', 'expands', 'icon', 'selected', 'selectedIcon', 'theme'], 'methods': ['selectOption']})
@Component({ selector: 'hrb-option-card', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['badgeIcon', 'badgeImage', 'badgeImageAlt', 'badgeSubtitle', 'badgeText', 'badgeTheme', 'badgeTitle', 'custom', 'disabled', 'expands', 'icon', 'selected', 'selectedIcon', 'theme'] })
export class HrbOptionCard {
  isSelected!: EventEmitter<CustomEvent>;
  isExpanded!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['isSelected', 'isExpanded']);
  }
}

export declare interface HrbOverflowItem extends Components.HrbOverflowItem {}
@ProxyCmp({inputs: ['as', 'disabled', 'href', 'icon', 'label', 'pAriaLabel', 'pAriaLabelledby', 'pAriaRole', 'rel', 'target', 'theme', 'type']})
@Component({ selector: 'hrb-overflow-item', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['as', 'disabled', 'href', 'icon', 'label', 'pAriaLabel', 'pAriaLabelledby', 'pAriaRole', 'rel', 'target', 'theme', 'type'] })
export class HrbOverflowItem {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbOverflowMenu extends Components.HrbOverflowMenu {}
@ProxyCmp({inputs: ['as', 'overflowId'], 'methods': ['getElement', 'setFocus', 'toggle']})
@Component({ selector: 'hrb-overflow-menu', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['as', 'overflowId'] })
export class HrbOverflowMenu {
  hrbBlur!: EventEmitter<CustomEvent>;
  hrbChange!: EventEmitter<CustomEvent>;
  hrbFocus!: EventEmitter<CustomEvent>;
  hrbInput!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['hrbBlur', 'hrbChange', 'hrbFocus', 'hrbInput']);
  }
}

export declare interface HrbRadio extends Components.HrbRadio {}
@ProxyCmp({inputs: ['checked', 'disabled', 'hasError', 'inputId', 'name', 'required', 'theme', 'value'], 'methods': ['getElement', 'setFocus']})
@Component({ selector: 'hrb-radio', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['checked', 'disabled', 'hasError', 'inputId', 'name', 'required', 'theme', 'value'] })
export class HrbRadio {
  hrbBlur!: EventEmitter<CustomEvent>;
  hrbChange!: EventEmitter<CustomEvent>;
  hrbFocus!: EventEmitter<CustomEvent>;
  hrbInput!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['hrbBlur', 'hrbChange', 'hrbFocus', 'hrbInput']);
  }
}

export declare interface HrbReset extends Components.HrbReset {}
@ProxyCmp({inputs: ['theme']})
@Component({ selector: 'hrb-reset', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['theme'] })
export class HrbReset {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbRule extends Components.HrbRule {}
@ProxyCmp({inputs: ['vertical']})
@Component({ selector: 'hrb-rule', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['vertical'] })
export class HrbRule {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbSelect extends Components.HrbSelect {}
@ProxyCmp({inputs: ['disabled', 'errorLabel', 'hasError', 'helperText', 'label', 'loading', 'value'], 'methods': ['getElement', 'setFocus']})
@Component({ selector: 'hrb-select', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['disabled', 'errorLabel', 'hasError', 'helperText', 'label', 'loading', 'value'] })
export class HrbSelect {
  hrbBlur!: EventEmitter<CustomEvent>;
  hrbChange!: EventEmitter<CustomEvent>;
  hrbFocus!: EventEmitter<CustomEvent>;
  hrbInput!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['hrbBlur', 'hrbChange', 'hrbFocus', 'hrbInput']);
  }
}

export declare interface HrbSelectCustom extends Components.HrbSelectCustom {}
@ProxyCmp({inputs: ['disabled', 'errorLabel', 'hasError', 'helperText', 'label', 'loading', 'optionGroupName', 'value'], 'methods': ['updateOptionList']})
@Component({ selector: 'hrb-select-custom', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['disabled', 'errorLabel', 'hasError', 'helperText', 'label', 'loading', 'optionGroupName', 'value'] })
export class HrbSelectCustom {
  hrbSelectBlur!: EventEmitter<CustomEvent>;
  hrbSelectChange!: EventEmitter<CustomEvent>;
  hrbSelectFocus!: EventEmitter<CustomEvent>;
  hrbSelectInput!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['hrbSelectBlur', 'hrbSelectChange', 'hrbSelectFocus', 'hrbSelectInput']);
  }
}

export declare interface HrbSelectNative extends Components.HrbSelectNative {}
@ProxyCmp({inputs: ['disabled', 'errorLabel', 'hasError', 'helperText', 'label', 'loading', 'value']})
@Component({ selector: 'hrb-select-native', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['disabled', 'errorLabel', 'hasError', 'helperText', 'label', 'loading', 'value'] })
export class HrbSelectNative {
  hrbSelectBlur!: EventEmitter<CustomEvent>;
  hrbSelectChange!: EventEmitter<CustomEvent>;
  hrbSelectFocus!: EventEmitter<CustomEvent>;
  hrbSelectInput!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['hrbSelectBlur', 'hrbSelectChange', 'hrbSelectFocus', 'hrbSelectInput']);
  }
}

export declare interface HrbSelectOption extends Components.HrbSelectOption {}
@ProxyCmp({inputs: ['baseId', 'currentlyFocusedOptionIndex', 'currentlySelectedOptionIndex', 'index', 'option']})
@Component({ selector: 'hrb-select-option', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['baseId', 'currentlyFocusedOptionIndex', 'currentlySelectedOptionIndex', 'index', 'option'] })
export class HrbSelectOption {
  optionClick!: EventEmitter<CustomEvent>;
  optionMouseEnter!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['optionClick', 'optionMouseEnter']);
  }
}

export declare interface HrbSpacer extends Components.HrbSpacer {}
@ProxyCmp({inputs: ['d', 'lg', 'md', 'sm']})
@Component({ selector: 'hrb-spacer', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['d', 'lg', 'md', 'sm'] })
export class HrbSpacer {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbText extends Components.HrbText {}
@ProxyCmp({inputs: ['as', 'styleType']})
@Component({ selector: 'hrb-text', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['as', 'styleType'] })
export class HrbText {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbTextarea extends Components.HrbTextarea {}
@ProxyCmp({inputs: ['autocomplete', 'cols', 'disableResize', 'disabled', 'errorLabel', 'hasError', 'helperText', 'label', 'loading', 'maxlength', 'minlength', 'name', 'pattern', 'readonly', 'required', 'rows', 'textareaId', 'value'], 'methods': ['getElement', 'setFocus']})
@Component({ selector: 'hrb-textarea', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['autocomplete', 'cols', 'disableResize', 'disabled', 'errorLabel', 'hasError', 'helperText', 'label', 'loading', 'maxlength', 'minlength', 'name', 'pattern', 'readonly', 'required', 'rows', 'textareaId', 'value'] })
export class HrbTextarea {
  hrbBlur!: EventEmitter<CustomEvent>;
  hrbChange!: EventEmitter<CustomEvent>;
  hrbFocus!: EventEmitter<CustomEvent>;
  hrbInput!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['hrbBlur', 'hrbChange', 'hrbFocus', 'hrbInput']);
  }
}

export declare interface HrbToggle extends Components.HrbToggle {}
@ProxyCmp({inputs: ['checked', 'disabled'], 'methods': ['getElement', 'setFocus']})
@Component({ selector: 'hrb-toggle', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['checked', 'disabled'] })
export class HrbToggle {
  hrbBlur!: EventEmitter<CustomEvent>;
  hrbChange!: EventEmitter<CustomEvent>;
  hrbFocus!: EventEmitter<CustomEvent>;
  hrbInput!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['hrbBlur', 'hrbChange', 'hrbFocus', 'hrbInput']);
  }
}

export declare interface HrbTooltip extends Components.HrbTooltip {}
@ProxyCmp({inputs: ['tooltipContent', 'tooltipId', 'tooltipPosition', 'tooltipVisible'], 'methods': ['toggleTooltip']})
@Component({ selector: 'hrb-tooltip', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['tooltipContent', 'tooltipId', 'tooltipPosition', 'tooltipVisible'] })
export class HrbTooltip {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbVideo extends Components.HrbVideo {}
@ProxyCmp({inputs: ['aspectRatio', 'autoplay', 'height', 'muted', 'pTitle', 'poster', 'posterSrcset', 'removeControls', 'videoId', 'width'], 'methods': ['play', 'stop', 'pause']})
@Component({ selector: 'hrb-video', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['aspectRatio', 'autoplay', 'height', 'muted', 'pTitle', 'poster', 'posterSrcset', 'removeControls', 'videoId', 'width'] })
export class HrbVideo {
  hrbStateChange!: EventEmitter<CustomEvent>;
  hrbReady!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['hrbStateChange', 'hrbReady']);
  }
}
