import { ChangeDetectorRef, Directive, ElementRef } from "@angular/core";
import { NG_VALUE_ACCESSOR } from "@angular/forms";

import { ValueAccessor } from "./value-accessor";

@Directive({
  /* tslint:disable-next-line:directive-selector */
  selector: "hrb-check, hrb-toggle, hrb-checkbox",
  host: {
    "(hrbChange)": "handleCheckedChange($event)",
  },
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: BooleanValueAccessor,
      multi: true,
    },
  ],
})
export class BooleanValueAccessor extends ValueAccessor {
  constructor(el: ElementRef, cdr: ChangeDetectorRef) {
    super(el, cdr);
  }
  writeValue(value: any) {
    this.el.nativeElement.checked = value;
    this.cdr.markForCheck();

  }

  handleCheckedChange($event:any){
    const {target} = $event;
    const val = target ? target.checked : false;
    this.handleChange(val)
  }
}
