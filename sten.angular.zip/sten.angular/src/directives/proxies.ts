/* tslint:disable */
/* auto-generated angular directive proxies */
import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  NgZone,
} from "@angular/core";
import { fromEvent } from "rxjs";

export const proxyInputs = (Cmp: any, inputs: string[]) => {
  const Prototype = Cmp.prototype;
  inputs.forEach((item) => {
    Object.defineProperty(Prototype, item, {
      get() {
        return this.el[item];
      },
      set(val: any) {
        this.z.runOutsideAngular(() => (this.el[item] = val));
      },
    });
  });
};

export const proxyMethods = (Cmp: any, methods: string[]) => {
  const Prototype = Cmp.prototype;
  methods.forEach((methodName) => {
    Prototype[methodName] = function () {
      const args = arguments;
      return this.z.runOutsideAngular(() =>
        this.el[methodName].apply(this.el, args)
      );
    };
  });
};

export const proxyOutputs = (instance: any, el: any, events: string[]) => {
  events.forEach(
    (eventName) => (instance[eventName] = fromEvent(el, eventName))
  );
};

// tslint:disable-next-line: only-arrow-functions
export function ProxyCmp(opts: { inputs?: any; methods?: any }) {
  const decorator = function (cls: any) {
    if (opts.inputs) {
      proxyInputs(cls, opts.inputs);
    }
    if (opts.methods) {
      proxyMethods(cls, opts.methods);
    }
    return cls;
  };
  return decorator;
}

import { Components } from "@bds/bds-core";

export declare interface HrbAccordion extends Components.HrbAccordion {}
@ProxyCmp({ inputs: ["type"] })
@Component({
  selector: "hrb-accordion",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["type"],
})
export class HrbAccordion {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbAccordionItem extends Components.HrbAccordionItem {}
@ProxyCmp({
  inputs: [
    "accordionId",
    "disabled",
    "headerAs",
    "headerText",
    "previewText",
    "subnavHeaderStyle",
    "type",
  ],
  methods: ["setIsExpanded"],
})
@Component({
  selector: "hrb-accordion-item",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: [
    "accordionId",
    "disabled",
    "headerAs",
    "headerText",
    "previewText",
    "subnavHeaderStyle",
    "type",
  ],
})
export class HrbAccordionItem {
  accordionToggled!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ["accordionToggled"]);
  }
}

export declare interface HrbAutocomplete extends Components.HrbAutocomplete {}
@ProxyCmp({
  inputs: [
    "debounce",
    "disabled",
    "errorLabel",
    "hasError",
    "inputId",
    "keys",
    "label",
    "loading",
    "maxResults",
    "name",
    "readonly",
    "required",
    "threshold",
    "type",
    "value",
  ],
  methods: ["getElement", "setData", "setFocus"],
})
@Component({
  selector: "hrb-autocomplete",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: [
    "debounce",
    "disabled",
    "errorLabel",
    "hasError",
    "inputId",
    "keys",
    "label",
    "loading",
    "maxResults",
    "name",
    "readonly",
    "required",
    "threshold",
    "type",
    "value",
  ],
})
export class HrbAutocomplete {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbButton extends Components.HrbButton {}
@ProxyCmp({
  inputs: [
    "as",
    "disabled",
    "fullWidth",
    "href",
    "icon",
    "iconPosition",
    "loading",
    "pAriaLabel",
    "pAriaLabelledby",
    "pAriaPressed",
    "pAriaRole",
    "qualifier",
    "rel",
    "size",
    "target",
    "theme",
    "type",
  ],
})
@Component({
  selector: "hrb-button",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: [
    "as",
    "disabled",
    "fullWidth",
    "href",
    "icon",
    "iconPosition",
    "loading",
    "pAriaLabel",
    "pAriaLabelledby",
    "pAriaPressed",
    "pAriaRole",
    "qualifier",
    "rel",
    "size",
    "target",
    "theme",
    "type",
  ],
})
export class HrbButton {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbCard extends Components.HrbCard {}
@ProxyCmp({ inputs: ["as", "theme"] })
@Component({
  selector: "hrb-card",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["as", "theme"],
})
export class HrbCard {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbCardContent extends Components.HrbCardContent {}

@Component({
  selector: "hrb-card-content",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
})
export class HrbCardContent {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbCardDocument extends Components.HrbCardDocument {}
@ProxyCmp({
  inputs: [
    "addedBy",
    "categoryName",
    "fileName",
    "headerAs",
    "headerLink",
    "isLoading",
    "layout",
    "thumbAlt",
    "thumbSrc",
    "uploadDate",
  ],
})
@Component({
  selector: "hrb-card-document",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: [
    "addedBy",
    "categoryName",
    "fileName",
    "headerAs",
    "headerLink",
    "isLoading",
    "layout",
    "thumbAlt",
    "thumbSrc",
    "uploadDate",
  ],
})
export class HrbCardDocument {
  headerClicked!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ["headerClicked"]);
  }
}

export declare interface HrbCardExpandable
  extends Components.HrbCardExpandable {}
@ProxyCmp({
  inputs: ["closeIcon", "icon", "theme"],
  methods: ["close", "open", "controlHeight"],
})
@Component({
  selector: "hrb-card-expandable",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["closeIcon", "icon", "theme"],
})
export class HrbCardExpandable {
  hrbOpen!: EventEmitter<CustomEvent>;
  hrbClose!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ["hrbOpen", "hrbClose"]);
  }
}

export declare interface HrbCheckbox extends Components.HrbCheckbox {}
@ProxyCmp({
  inputs: [
    "checked",
    "disabled",
    "inputId",
    "name",
    "required",
    "theme",
    "value",
  ],
  methods: ["getElement", "setFocus"],
})
@Component({
  selector: "hrb-checkbox",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: [
    "checked",
    "disabled",
    "inputId",
    "name",
    "required",
    "theme",
    "value",
  ],
})
export class HrbCheckbox {
  hrbBlur!: EventEmitter<CustomEvent>;
  hrbChange!: EventEmitter<CustomEvent>;
  hrbFocus!: EventEmitter<CustomEvent>;
  hrbInput!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, [
      "hrbBlur",
      "hrbChange",
      "hrbFocus",
      "hrbInput",
    ]);
  }
}

export declare interface HrbCircleButton extends Components.HrbCircleButton {}
@ProxyCmp({
  inputs: [
    "as",
    "disabled",
    "href",
    "pAriaControls",
    "pAriaExpaned",
    "pAriaLabel",
    "pAriaLabelledby",
    "pAriaRole",
    "pTabIndex",
    "rel",
    "size",
    "target",
    "theme",
    "transparent",
    "type",
  ],
})
@Component({
  selector: "hrb-circle-button",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: [
    "as",
    "disabled",
    "href",
    "pAriaControls",
    "pAriaExpaned",
    "pAriaLabel",
    "pAriaLabelledby",
    "pAriaRole",
    "pTabIndex",
    "rel",
    "size",
    "target",
    "theme",
    "transparent",
    "type",
  ],
})
export class HrbCircleButton {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbCircleButtonWithLabel
  extends Components.HrbCircleButtonWithLabel {}
@ProxyCmp({
  inputs: [
    "as",
    "disabled",
    "href",
    "icon",
    "pAriaLabel",
    "pAriaLabelledby",
    "pAriaRole",
    "rel",
    "target",
    "theme",
    "type",
  ],
})
@Component({
  selector: "hrb-circle-button-with-label",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: [
    "as",
    "disabled",
    "href",
    "icon",
    "pAriaLabel",
    "pAriaLabelledby",
    "pAriaRole",
    "rel",
    "target",
    "theme",
    "type",
  ],
})
export class HrbCircleButtonWithLabel {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbCircled extends Components.HrbCircled {}
@ProxyCmp({ inputs: ["size", "theme", "transparent"] })
@Component({
  selector: "hrb-circled",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["size", "theme", "transparent"],
})
export class HrbCircled {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbContainer extends Components.HrbContainer {}

@Component({
  selector: "hrb-container",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
})
export class HrbContainer {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbDataItem extends Components.HrbDataItem {}
@ProxyCmp({
  inputs: [
    "as",
    "def",
    "disabled",
    "href",
    "icon",
    "metadata",
    "note",
    "pAriaLabel",
    "pAriaLabelledby",
    "pAriaRole",
    "rel",
    "target",
    "term",
    "thumbAlt",
    "thumbSrc",
    "type",
  ],
})
@Component({
  selector: "hrb-data-item",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: [
    "as",
    "def",
    "disabled",
    "href",
    "icon",
    "metadata",
    "note",
    "pAriaLabel",
    "pAriaLabelledby",
    "pAriaRole",
    "rel",
    "target",
    "term",
    "thumbAlt",
    "thumbSrc",
    "type",
  ],
})
export class HrbDataItem {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbDataList extends Components.HrbDataList {}
@ProxyCmp({ inputs: ["as", "theme"] })
@Component({
  selector: "hrb-data-list",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["as", "theme"],
})
export class HrbDataList {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbFlexCol extends Components.HrbFlexCol {}
@ProxyCmp({
  inputs: [
    "col",
    "colL",
    "colM",
    "colS",
    "isCentered",
    "offsetL",
    "offsetM",
    "offsetS",
  ],
})
@Component({
  selector: "hrb-flex-col",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: [
    "col",
    "colL",
    "colM",
    "colS",
    "isCentered",
    "offsetL",
    "offsetM",
    "offsetS",
  ],
})
export class HrbFlexCol {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbFlexContainer extends Components.HrbFlexContainer {}

@Component({
  selector: "hrb-flex-container",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
})
export class HrbFlexContainer {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbFlexGhost extends Components.HrbFlexGhost {}

@Component({
  selector: "hrb-flex-ghost",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
})
export class HrbFlexGhost {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbFlexRow extends Components.HrbFlexRow {}
@ProxyCmp({
  inputs: ["alignItems", "isCentered", "isReversed", "justifyContent"],
})
@Component({
  selector: "hrb-flex-row",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["alignItems", "isCentered", "isReversed", "justifyContent"],
})
export class HrbFlexRow {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbGlobal extends Components.HrbGlobal {}
@ProxyCmp({ inputs: ["reset"] })
@Component({
  selector: "hrb-global",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["reset"],
})
export class HrbGlobal {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbGridCol extends Components.HrbGridCol {}
@ProxyCmp({
  inputs: [
    "colSpan",
    "colSpanL",
    "colSpanM",
    "colSpanS",
    "isGrid",
    "row",
    "rowL",
    "rowM",
    "rowS",
  ],
})
@Component({
  selector: "hrb-grid-col",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: [
    "colSpan",
    "colSpanL",
    "colSpanM",
    "colSpanS",
    "isGrid",
    "row",
    "rowL",
    "rowM",
    "rowS",
  ],
})
export class HrbGridCol {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbGridGhost extends Components.HrbGridGhost {}

@Component({
  selector: "hrb-grid-ghost",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
})
export class HrbGridGhost {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbGridRow extends Components.HrbGridRow {}

@Component({
  selector: "hrb-grid-row",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
})
export class HrbGridRow {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbIcon extends Components.HrbIcon {}
@ProxyCmp({ inputs: ["name"] })
@Component({
  selector: "hrb-icon",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["name"],
})
export class HrbIcon {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbImg extends Components.HrbImg {}
@ProxyCmp({
  inputs: ["alt", "fit", "height", "pLoading", "src", "srcset", "width"],
})
@Component({
  selector: "hrb-img",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["alt", "fit", "height", "pLoading", "src", "srcset", "width"],
})
export class HrbImg {
  hrbImgWillLoad!: EventEmitter<CustomEvent>;
  hrbImgDidLoad!: EventEmitter<CustomEvent>;
  hrbError!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, [
      "hrbImgWillLoad",
      "hrbImgDidLoad",
      "hrbError",
    ]);
  }
}

export declare interface HrbInput extends Components.HrbInput {}
@ProxyCmp({
  inputs: [
    "allowPasswordToggle",
    "autocomplete",
    "copyPaste",
    "disabled",
    "errorLabel",
    "forceIconVisibility",
    "hasError",
    "icon",
    "inputId",
    "label",
    "loading",
    "maxlength",
    "minlength",
    "name",
    "pActivedescendant",
    "pAriaAutocomplete",
    "pAriaMultiline",
    "pAriaOwns",
    "pattern",
    "readonly",
    "required",
    "type",
    "value",
  ],
  methods: ["getElement", "setFocus"],
})
@Component({
  selector: "hrb-input",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: [
    "allowPasswordToggle",
    "autocomplete",
    "copyPaste",
    "disabled",
    "errorLabel",
    "forceIconVisibility",
    "hasError",
    "icon",
    "inputId",
    "label",
    "loading",
    "maxlength",
    "minlength",
    "name",
    "pActivedescendant",
    "pAriaAutocomplete",
    "pAriaMultiline",
    "pAriaOwns",
    "pattern",
    "readonly",
    "required",
    "type",
    "value",
  ],
})
export class HrbInput {
  hrbBlur!: EventEmitter<CustomEvent>;
  hrbChange!: EventEmitter<CustomEvent>;
  hrbFocus!: EventEmitter<CustomEvent>;
  hrbInput!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, [
      "hrbBlur",
      "hrbChange",
      "hrbFocus",
      "hrbInput",
    ]);
  }
}

export declare interface HrbLabel extends Components.HrbLabel {}
@ProxyCmp({
  inputs: [
    "as",
    "disabled",
    "href",
    "pAriaLabel",
    "pAriaLabelledby",
    "pAriaRole",
    "rel",
    "target",
    "theme",
    "type",
  ],
})
@Component({
  selector: "hrb-label",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: [
    "as",
    "disabled",
    "href",
    "pAriaLabel",
    "pAriaLabelledby",
    "pAriaRole",
    "rel",
    "target",
    "theme",
    "type",
  ],
})
export class HrbLabel {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbLayout extends Components.HrbLayout {}
@ProxyCmp({ inputs: ["layout", "layoutLarge", "layoutMedium", "layoutSmall"] })
@Component({
  selector: "hrb-layout",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["layout", "layoutLarge", "layoutMedium", "layoutSmall"],
})
export class HrbLayout {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbLink extends Components.HrbLink {}
@ProxyCmp({
  inputs: [
    "as",
    "disabled",
    "href",
    "pAriaLabel",
    "pAriaLabelledby",
    "pAriaRole",
    "rel",
    "target",
    "theme",
    "type",
  ],
})
@Component({
  selector: "hrb-link",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: [
    "as",
    "disabled",
    "href",
    "pAriaLabel",
    "pAriaLabelledby",
    "pAriaRole",
    "rel",
    "target",
    "theme",
    "type",
  ],
})
export class HrbLink {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbListButton extends Components.HrbListButton {}
@ProxyCmp({
  inputs: [
    "as",
    "circled",
    "disabled",
    "href",
    "icon",
    "metadata",
    "outlined",
    "pAriaLabel",
    "pAriaLabelledby",
    "pAriaRole",
    "rel",
    "target",
    "theme",
    "type",
  ],
})
@Component({
  selector: "hrb-list-button",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: [
    "as",
    "circled",
    "disabled",
    "href",
    "icon",
    "metadata",
    "outlined",
    "pAriaLabel",
    "pAriaLabelledby",
    "pAriaRole",
    "rel",
    "target",
    "theme",
    "type",
  ],
})
export class HrbListButton {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbLoader extends Components.HrbLoader {}
@ProxyCmp({ inputs: ["color"] })
@Component({
  selector: "hrb-loader",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["color"],
})
export class HrbLoader {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbModal extends Components.HrbModal {}
@ProxyCmp({ inputs: ["modalId", "theme", "type"], methods: ["close", "show"] })
@Component({
  selector: "hrb-modal",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["modalId", "theme", "type"],
})
export class HrbModal {
  hrbClose!: EventEmitter<CustomEvent>;
  hrbOpen!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ["hrbClose", "hrbOpen"]);
  }
}

export declare interface HrbNavBar extends Components.HrbNavBar {}
@ProxyCmp({ inputs: ["currentMobileMenuIcon"] })
@Component({
  selector: "hrb-nav-bar",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["currentMobileMenuIcon"],
})
export class HrbNavBar {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbNavLink extends Components.HrbNavLink {}
@ProxyCmp({
  inputs: [
    "as",
    "disabled",
    "href",
    "pAriaLabel",
    "pAriaLabelledby",
    "pAriaRole",
    "rel",
    "styleType",
    "target",
    "type",
  ],
})
@Component({
  selector: "hrb-nav-link",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: [
    "as",
    "disabled",
    "href",
    "pAriaLabel",
    "pAriaLabelledby",
    "pAriaRole",
    "rel",
    "styleType",
    "target",
    "type",
  ],
})
export class HrbNavLink {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbNavLogo extends Components.HrbNavLogo {}
@ProxyCmp({
  inputs: ["height", "href", "pAriaLabel", "rel", "target", "width"],
})
@Component({
  selector: "hrb-nav-logo",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["height", "href", "pAriaLabel", "rel", "target", "width"],
})
export class HrbNavLogo {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

// export declare interface HrbNavPrimaryItem extends Components.HrbNavPrimaryItem {}
// @ProxyCmp({inputs: ['href', 'rel', 'target', 'text']})
// @Component({ selector: 'hrb-nav-primary-item', changeDetection: ChangeDetectionStrategy.OnPush, template: '<ng-content></ng-content>', inputs: ['href', 'rel', 'target', 'text'] })
// export class HrbNavPrimaryItem {
//   protected el: HTMLElement;
//   constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
//     c.detach();
//     this.el = r.nativeElement;
//   }
// }

export declare interface HrbNavSecondaryItem
  extends Components.HrbNavSecondaryItem {}
@ProxyCmp({ inputs: ["hideOnSmall", "href", "icon", "rel", "target", "text"] })
@Component({
  selector: "hrb-nav-secondary-item",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["hideOnSmall", "href", "icon", "rel", "target", "text"],
})
export class HrbNavSecondaryItem {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbOverflowItem extends Components.HrbOverflowItem {}
@ProxyCmp({
  inputs: [
    "as",
    "disabled",
    "href",
    "icon",
    "label",
    "pAriaLabel",
    "pAriaLabelledby",
    "pAriaRole",
    "rel",
    "target",
    "theme",
    "type",
  ],
})
@Component({
  selector: "hrb-overflow-item",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: [
    "as",
    "disabled",
    "href",
    "icon",
    "label",
    "pAriaLabel",
    "pAriaLabelledby",
    "pAriaRole",
    "rel",
    "target",
    "theme",
    "type",
  ],
})
export class HrbOverflowItem {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbOverflowMenu extends Components.HrbOverflowMenu {}
@ProxyCmp({
  inputs: ["as", "overflowId"],
  methods: ["getElement", "setFocus", "toggle"],
})
@Component({
  selector: "hrb-overflow-menu",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["as", "overflowId"],
})
export class HrbOverflowMenu {
  hrbBlur!: EventEmitter<CustomEvent>;
  hrbChange!: EventEmitter<CustomEvent>;
  hrbFocus!: EventEmitter<CustomEvent>;
  hrbInput!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, [
      "hrbBlur",
      "hrbChange",
      "hrbFocus",
      "hrbInput",
    ]);
  }
}

export declare interface HrbRadio extends Components.HrbRadio {}
@ProxyCmp({
  inputs: [
    "checked",
    "disabled",
    "hasError",
    "inputId",
    "name",
    "required",
    "theme",
    "value",
  ],
  methods: ["getElement", "setFocus"],
})
@Component({
  selector: "hrb-radio",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: [
    "checked",
    "disabled",
    "hasError",
    "inputId",
    "name",
    "required",
    "theme",
    "value",
  ],
})
export class HrbRadio {
  hrbBlur!: EventEmitter<CustomEvent>;
  hrbChange!: EventEmitter<CustomEvent>;
  hrbFocus!: EventEmitter<CustomEvent>;
  hrbInput!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, [
      "hrbBlur",
      "hrbChange",
      "hrbFocus",
      "hrbInput",
    ]);
  }
}

export declare interface HrbReset extends Components.HrbReset {}

@Component({
  selector: "hrb-reset",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
})
export class HrbReset {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbSelect extends Components.HrbSelect {}
@ProxyCmp({
  inputs: ["disabled", "errorLabel", "hasError", "label", "loading", "value"],
  methods: ["getElement", "setFocus"],
})
@Component({
  selector: "hrb-select",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["disabled", "errorLabel", "hasError", "label", "loading", "value"],
})
export class HrbSelect {
  hrbBlur!: EventEmitter<CustomEvent>;
  hrbChange!: EventEmitter<CustomEvent>;
  hrbFocus!: EventEmitter<CustomEvent>;
  hrbInput!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, [
      "hrbBlur",
      "hrbChange",
      "hrbFocus",
      "hrbInput",
    ]);
  }
}

export declare interface HrbSelectCustom extends Components.HrbSelectCustom {}
@ProxyCmp({
  inputs: ["disabled", "errorLabel", "hasError", "label", "loading", "value"],
})
@Component({
  selector: "hrb-select-custom",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["disabled", "errorLabel", "hasError", "label", "loading", "value"],
})
export class HrbSelectCustom {
  hrbSelectBlur!: EventEmitter<CustomEvent>;
  hrbSelectChange!: EventEmitter<CustomEvent>;
  hrbSelectFocus!: EventEmitter<CustomEvent>;
  hrbSelectInput!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, [
      "hrbSelectBlur",
      "hrbSelectChange",
      "hrbSelectFocus",
      "hrbSelectInput",
    ]);
  }
}

export declare interface HrbSelectNative extends Components.HrbSelectNative {}
@ProxyCmp({
  inputs: ["disabled", "errorLabel", "hasError", "label", "loading", "value"],
})
@Component({
  selector: "hrb-select-native",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["disabled", "errorLabel", "hasError", "label", "loading", "value"],
})
export class HrbSelectNative {
  hrbSelectBlur!: EventEmitter<CustomEvent>;
  hrbSelectChange!: EventEmitter<CustomEvent>;
  hrbSelectFocus!: EventEmitter<CustomEvent>;
  hrbSelectInput!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, [
      "hrbSelectBlur",
      "hrbSelectChange",
      "hrbSelectFocus",
      "hrbSelectInput",
    ]);
  }
}

export declare interface HrbSelectOption extends Components.HrbSelectOption {}
@ProxyCmp({
  inputs: [
    "baseId",
    "currentlyFocusedOptionIndex",
    "currentlySelectedOptionIndex",
    "index",
    "option",
  ],
})
@Component({
  selector: "hrb-select-option",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: [
    "baseId",
    "currentlyFocusedOptionIndex",
    "currentlySelectedOptionIndex",
    "index",
    "option",
  ],
})
export class HrbSelectOption {
  optionClick!: EventEmitter<CustomEvent>;
  optionMouseEnter!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ["optionClick", "optionMouseEnter"]);
  }
}

export declare interface HrbSpacer extends Components.HrbSpacer {}
@ProxyCmp({ inputs: ["d", "lg", "md", "sm"] })
@Component({
  selector: "hrb-spacer",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["d", "lg", "md", "sm"],
})
export class HrbSpacer {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbText extends Components.HrbText {}
@ProxyCmp({ inputs: ["as", "styleType"] })
@Component({
  selector: "hrb-text",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["as", "styleType"],
})
export class HrbText {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

export declare interface HrbTextarea extends Components.HrbTextarea {}
@ProxyCmp({
  inputs: [
    "autocomplete",
    "cols",
    "disableResize",
    "disabled",
    "errorLabel",
    "hasError",
    "label",
    "loading",
    "maxlength",
    "minlength",
    "name",
    "pattern",
    "readonly",
    "required",
    "rows",
    "textareaId",
    "value",
  ],
  methods: ["getElement", "setFocus"],
})
@Component({
  selector: "hrb-textarea",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: [
    "autocomplete",
    "cols",
    "disableResize",
    "disabled",
    "errorLabel",
    "hasError",
    "label",
    "loading",
    "maxlength",
    "minlength",
    "name",
    "pattern",
    "readonly",
    "required",
    "rows",
    "textareaId",
    "value",
  ],
})
export class HrbTextarea {
  hrbBlur!: EventEmitter<CustomEvent>;
  hrbChange!: EventEmitter<CustomEvent>;
  hrbFocus!: EventEmitter<CustomEvent>;
  hrbInput!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, [
      "hrbBlur",
      "hrbChange",
      "hrbFocus",
      "hrbInput",
    ]);
  }
}

export declare interface HrbToggle extends Components.HrbToggle {}
@ProxyCmp({
  inputs: ["checked", "disabled", "theme"],
  methods: ["getElement", "setFocus"],
})
@Component({
  selector: "hrb-toggle",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: ["checked", "disabled", "theme"],
})
export class HrbToggle {
  hrbBlur!: EventEmitter<CustomEvent>;
  hrbChange!: EventEmitter<CustomEvent>;
  hrbFocus!: EventEmitter<CustomEvent>;
  hrbInput!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, [
      "hrbBlur",
      "hrbChange",
      "hrbFocus",
      "hrbInput",
    ]);
  }
}

export declare interface HrbVideo extends Components.HrbVideo {}
@ProxyCmp({
  inputs: [
    "aspectRatio",
    "autoplay",
    "height",
    "muted",
    "pTitle",
    "poster",
    "posterSrcset",
    "removeControls",
    "videoId",
    "width",
  ],
  methods: ["play", "stop", "pause"],
})
@Component({
  selector: "hrb-video",
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: "<ng-content></ng-content>",
  inputs: [
    "aspectRatio",
    "autoplay",
    "height",
    "muted",
    "pTitle",
    "poster",
    "posterSrcset",
    "removeControls",
    "videoId",
    "width",
  ],
})
export class HrbVideo {
  hrbStateChange!: EventEmitter<CustomEvent>;
  hrbReady!: EventEmitter<CustomEvent>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ["hrbStateChange", "hrbReady"]);
  }
}
