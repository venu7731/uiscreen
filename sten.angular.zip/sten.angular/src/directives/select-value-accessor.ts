import { ChangeDetectorRef, Directive, ElementRef } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

import { ValueAccessor } from './value-accessor';

@Directive({
  /* tslint:disable-next-line:directive-selector */
  selector: 'hrb-select',
  host: {
    '(hrbChange)': 'handleChange($event.detail.value)',
  },
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: SelectValueAccessor,
      multi: true,
    },
  ],
})
export class SelectValueAccessor extends ValueAccessor {
  constructor(el: ElementRef, protected cdr: ChangeDetectorRef) {
    super(el, cdr);
  }

  writeValue(value: any) {
    this.el.nativeElement.value = value;
    console.log('select write value ' +value);
    this.cdr.markForCheck();
  }

  // writeValue(value: any) {
  //   if (this.el.nativeElement) {
  //     const elem = Array.prototype.slice
  //       .call(this.el.nativeElement.querySelectorAll('option'))
  //       .find((item: any) => item.value == value);
  //     if (elem) {
  //       elem.selected = 'selected';
  //     }
  //   }
  //   super.writeValue(value);
  // }
}
