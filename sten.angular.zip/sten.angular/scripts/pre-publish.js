const fs = require('fs-extra');

function readPackage(err) {
  if (err) return console.log(err);
  fs.readFile('./package.json', modifyPackage);
  fs.copyFileSync('./.npmrc', './publish/.npmrc');
}

function modifyPackage(err, data) {
  if (err) return console.log(err);
  const parsedData = JSON.parse(data);
  delete parsedData.devDependencies;
  delete parsedData.dependencies;
  delete parsedData.scripts;
  fs.writeFileSync(
    './publish/package.json',
    JSON.stringify(parsedData, null, 2)
  );
}

function moveFolders(err) {
  if (err) return console.log(err);
  fs.move(this.src, this.dest, this.callback);
}

fs.mkdir(
  './publish',
  moveFolders.bind({
    src: './dist/',
    dest: './publish/dist/',
    callback: readPackage,
  })
);
