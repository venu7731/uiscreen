import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBReadonlyFormComponent } from './hrb-readonly-form.component';

describe('HRBReadonlyFormComponent', () => {
  let component: HRBReadonlyFormComponent;
  let fixture: ComponentFixture<HRBReadonlyFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBReadonlyFormComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBReadonlyFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
