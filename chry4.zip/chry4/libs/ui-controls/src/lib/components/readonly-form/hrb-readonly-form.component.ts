import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

import { HRBBaseComponent, IHRBFormSection } from '@chrysalis/core';

@Component({
  selector: 'hrb-readonly-form',
  templateUrl: './hrb-readonly-form.component.html',
  styleUrls: ['./hrb-readonly-form.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBReadonlyFormComponent extends HRBBaseComponent {
  /** Dynamic form content */
  @Input() public section: IHRBFormSection;
  /** Dynamic form data */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  @Input() public data: any;

  /** Dummy init */
  protected init(): void { }
  /** Dummy destroy */
  protected destroy(): void {
  }
}
