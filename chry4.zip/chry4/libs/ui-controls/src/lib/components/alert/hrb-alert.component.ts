import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';

import { HRBBaseComponent } from '@chrysalis/core';

import { IHRBButtonAction } from '../button';
import { IHRBAlertContent } from './hrb-alert.interface';

/**
 * Alert component
 */
@Component({
  selector: 'hrb-alert-wrapper',
  templateUrl: './hrb-alert.component.html',
  styleUrls: ['./hrb-alert.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBAlertComponent extends HRBBaseComponent {
  /** Alert content */
  @Input() public item: IHRBAlertContent;
  /** Button click event */
  @Output() public buttonClicked = new EventEmitter<IHRBButtonAction[]>();

  /**
   * Emit button id
   */
  public emitButtonClick(actions: IHRBButtonAction[]) {
    this.buttonClicked.emit(actions);
  }

  /** Dummy init */
  protected init(): void { }
  /** Dummy destroy */
  protected destroy(): void {
  }
}
