import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';

import { HRBBaseComponent } from '@chrysalis/core';

import { IHRBTextInput } from './hrb-text-input.interface';

/**
 * Text input component
 */
@Component({
  selector: 'hrb-text-input-wrapper',
  templateUrl: './hrb-text-input.component.html',
  styleUrls: ['./hrb-text-input.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBTextInputComponent extends HRBBaseComponent {

  /** Text info */
  @Input() public item: IHRBTextInput;
  /** Text data */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  @Input() public data: any;
  /** Emit data changed */
  @Output() public emitDataChanged = new EventEmitter<string>();
  /** Update changes */
  public updateChanges(name: string) {
    this.emitDataChanged.emit(name);
  }
  /** Dummy init */
  protected init(): void {
  }
  /** Dummy destroy */
  protected destroy(): void {
  }

}
