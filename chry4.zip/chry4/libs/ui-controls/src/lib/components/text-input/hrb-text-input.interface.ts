/** Text input meta */
export interface IHRBTextInput {
    /** description */
    description: string;
    /** alias name */
    alias?: string;
    /** error label */
    errorMsg?: string;
    /** error */
    isError?: boolean;
    /** required */
    required?: boolean;
    /** readonly */
    readonly?: boolean;
}
