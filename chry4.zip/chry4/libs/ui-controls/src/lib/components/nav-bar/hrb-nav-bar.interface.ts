/** Nav bar content */
export interface IHRBNavBarContent {
    /** Text */
    text: string;
    /** State */
    state: string;
    /** Is selected */
    isSelected?: boolean;
    /** Icon */
    icon?: string;
    /** disabled */
    disabled?: boolean;
}