import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';

import { HRBBaseComponent } from '@chrysalis/core';

import { IHRBLinkAction, IHRBLinkContent } from './hrb-link.interface';

/**
 * Link component
 */
@Component({
  selector: 'hrb-link-wrapper',
  templateUrl: './hrb-link.component.html',
  styleUrls: ['./hrb-link.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBLinkComponent extends HRBBaseComponent {
  /** Button content */
  @Input() public item: IHRBLinkContent;
  /** Button click event */
  @Output() public linkClicked = new EventEmitter();

  /**
   * Emit button actions
   */
  public emitLinkClick(actions: IHRBLinkAction[]) {
    this.linkClicked.emit(actions);
  }
  /** Dummy init */
  protected init(): void { }
  /** Dummy destroy */
  protected destroy(): void {
  }
}
