import { IHRBCommandAction } from '@chrysalis/core';

import { IHRBButtonContent } from '../button';

/** Link meta */
export type IHRBLinkContent = IHRBButtonContent;
/** Link action */
export type IHRBLinkAction = IHRBCommandAction;
