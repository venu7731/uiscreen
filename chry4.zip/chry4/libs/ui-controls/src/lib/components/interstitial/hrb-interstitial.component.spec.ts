import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { HRBInterstitialComponent } from './hrb-interstitial.component';

xdescribe('HRBInterstitialComponent', () => {
  let component: HRBInterstitialComponent;
  let fixture: ComponentFixture<HRBInterstitialComponent>;

  beforeAll(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBInterstitialComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
      fixture = TestBed.createComponent(HRBInterstitialComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });

});
