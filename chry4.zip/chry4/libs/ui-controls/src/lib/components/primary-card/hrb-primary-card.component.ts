import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';

import { HRBBaseComponent } from '@chrysalis/core';

import { IHRBPrimaryCardContent } from './hrb-primary-card.interface';

/**
 * Primary card component
 */
@Component({
  selector: 'hrb-primary-card',
  templateUrl: './hrb-primary-card.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./hrb-primary-card.component.scss']
})

export class HRBPrimaryCardComponent extends HRBBaseComponent {

  /** Card Content */
  @Input() public cardContent: IHRBPrimaryCardContent;
  /** Card clicked event */
  @Output() public cardClicked = new EventEmitter<string>();

  /** Emit card state */
  public emitClickEvent(state: string) {
    this.cardClicked.emit(state);
  }
  /** Dummy init */
  protected init(): void {
  }
  /** Dummy destroy */
  protected destroy(): void {
  }
}