/** Primary card content */
export interface IHRBPrimaryCardContent {
    /** Primary card text */
    text: string;
    /** Primary card image url */
    imgUrl: string;
    /** Primary card subtext */
    subText?: string;
    /** Primary card state */
    state?: string;
    /** Primary card theme */
    theme?: string;
}