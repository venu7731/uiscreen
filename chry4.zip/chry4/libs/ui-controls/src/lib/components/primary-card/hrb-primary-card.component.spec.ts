import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { HRBPrimaryCardComponent } from './hrb-primary-card.component';

describe('HRBPrimaryCardComponent', () => {
    let component: HRBPrimaryCardComponent;
    let fixture: ComponentFixture<HRBPrimaryCardComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [HRBPrimaryCardComponent],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(HRBPrimaryCardComponent);
        component = fixture.componentInstance;
        component.cardContent = { imgUrl: '', text: '', subText: '' };
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});