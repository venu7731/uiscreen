export * from './hrb-primary-card.component';
export * from './hrb-primary-card.interface';