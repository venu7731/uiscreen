import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { cloneDeep, each, first } from 'lodash-es';

import { getFormattedMessages, HRBBaseComponent, IHRBFormItem } from '@chrysalis/core';
import { HRBProfileTypes, IHRBProfile, IHRBProfileAction } from './hrb-profile.interfaces';
import { ProfileButtonStates } from './hrb-profile.constants';
import { contentMetaData, getMeta, getProps, remapKeys } from '../utilities/hrb-composer-utils';

/**
 * Profile Component
 */
@Component({
  selector: 'hrb-profile',
  templateUrl: './hrb-profile.component.html',
  styleUrls: ['./hrb-profile.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBProfileComponent extends HRBBaseComponent {
  /** Content */
  @Input()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public set content(val: any) {
    if (val) {
      this.originalContent = cloneDeep(val);
    }
  }
  /** Meta data */
  @Input()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public set metaData(val: any) {
    if (val) {
      this.pMetaData = val;
      this.processMetaData();
    }
  }
  public get metaData() {
    return this.pMetaData;
  }
  /** Data */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  @Input() public data: any;
  /** Passing action data  */
  @Output() public actionEvent = new EventEmitter<IHRBProfileAction[]>();
  /** Profile content */
  public profileContent: IHRBProfile;
  /** Original Content */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public originalContent: any;
  /** HRBProfile Types */
  public HRBProfileTypes = HRBProfileTypes;
  /** Is toggleCard expanded */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public toggleState: Record<string, any> = {};

  private state: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private pMetaData: any;

  /** Handle primary button */
  public handlePrimaryButton() {
    this.actionEvent.emit(getMeta<HRBProfileTypes>(this.metaData.items, HRBProfileTypes.PrimaryButton)?.actions);
  }
  /** Handle Footer link */
  public handleFooterLink() {
    this.actionEvent.emit(getMeta<HRBProfileTypes>(this.metaData.items, HRBProfileTypes.FooterLink)?.actions);
  }

  /** Update the button state based on data */
  public updateState() {
    this.state = this.data[getProps<HRBProfileTypes>(this.metaData.items, HRBProfileTypes.SelectionCard, 'alias')] ?
      ProfileButtonStates.Changed : ProfileButtonStates.Unchanged;
    this.profileContent.primaryButton = {
      description: contentMetaData<HRBProfileTypes>(this, HRBProfileTypes.PrimaryButton, 'description'),
      theme: contentMetaData<HRBProfileTypes>(this, HRBProfileTypes.PrimaryButton, 'theme')
    };
  }

  /** Toggle card expand/collapse */
  public toggleCard(fieldName: string) {
    this.toggleState[fieldName] = this.toggleState[fieldName] ?? {};
    this.toggleState[fieldName].isExpanded = !this.toggleState[fieldName].isExpanded;
  }

  /** Dummy init */
  protected init(): void { }
  /** Dummy destroy */
  protected destroy(): void {
    this.data[getProps<HRBProfileTypes>(this.metaData.items, HRBProfileTypes.SelectionCard, 'alias')] = undefined;
  }

  private processMetaData() {
    this.profileContent = {
      headerText: contentMetaData<HRBProfileTypes>(this, HRBProfileTypes.HeaderText, 'headerText'),
      headerSubText: getFormattedMessages(contentMetaData<HRBProfileTypes>(this, HRBProfileTypes.HeaderSubText, 'headerSubText'),
        this.data),
      theme: contentMetaData<HRBProfileTypes>(this, HRBProfileTypes.Default, 'theme'),
      contentText: getFormattedMessages(contentMetaData<HRBProfileTypes>(this, HRBProfileTypes.ContentText, 'contentText'), this.data)
    };
    this.profileContent.profileCard = {
      theme: contentMetaData<HRBProfileTypes>(this, HRBProfileTypes.ProfileCard, 'theme'),
      headerText: contentMetaData<HRBProfileTypes>(this, HRBProfileTypes.ProfileCard, 'headerText'),
      alias: getProps<HRBProfileTypes>(this.metaData.items, HRBProfileTypes.ProfileCard, 'alias')
    };
    this.profileContent.textCard = {
      text: contentMetaData<HRBProfileTypes>(this, HRBProfileTypes.TextCard, 'text'),
      alias: getProps<HRBProfileTypes>(this.metaData.items, HRBProfileTypes.TextCard, 'alias')
    };
    this.processSelectionCards();
    this.processToggleCards();
    this.profileContent.primaryButton = {
      description: contentMetaData<HRBProfileTypes>(this, HRBProfileTypes.PrimaryButton, 'description'),
      theme: contentMetaData<HRBProfileTypes>(this, HRBProfileTypes.PrimaryButton, 'theme')
    };
    this.profileContent.footerLink = {
      description: contentMetaData<HRBProfileTypes>(this, HRBProfileTypes.FooterLink, 'description'),
      theme: contentMetaData<HRBProfileTypes>(this, HRBProfileTypes.FooterLink, 'theme')
    };
  }

  private processToggleCards() {
    this.profileContent.toggleCard = {};
    const toggleItems = this.metaData.items.filter((item) => item.type === HRBProfileTypes.ToggleCard);
    for (const toggleItem of toggleItems) {
      this.profileContent.toggleCard[toggleItem.fieldName] = {
        text: contentMetaData<HRBProfileTypes>(this, HRBProfileTypes.ToggleCard, 'text', toggleItem.fieldName),
        icon: contentMetaData<HRBProfileTypes>(this, HRBProfileTypes.ToggleCard, 'icon', toggleItem.fieldName),
        content: contentMetaData<HRBProfileTypes>(this, HRBProfileTypes.ToggleCard, 'content', toggleItem.fieldName)
      };
      each(toggleItem.items, (item, index) => {
        this.profileContent.toggleCard[toggleItem.fieldName].content[index] =
          remapKeys(this.profileContent.toggleCard[toggleItem.fieldName].content[index],
            first(item.contentMeta)) as IHRBFormItem[];
      });
    }
  }

  private processSelectionCards() {
    this.profileContent.selectionCard = {};
    this.state = this.data[getProps<HRBProfileTypes>(this.metaData.items, HRBProfileTypes.SelectionCard, 'alias')] ?
      ProfileButtonStates.Changed : ProfileButtonStates.Unchanged;
    const selectionItems = this.metaData.items.filter((item) => item.type === HRBProfileTypes.SelectionCard);
    for (const selectionItem of selectionItems) {
      this.profileContent.selectionCard[selectionItem.fieldName] = {
        text: contentMetaData<HRBProfileTypes>(this, HRBProfileTypes.SelectionCard, 'text', selectionItem.fieldName),
        fieldName: contentMetaData<HRBProfileTypes>(this, HRBProfileTypes.SelectionCard, 'fieldName', selectionItem.fieldName),
        value: contentMetaData<HRBProfileTypes>(this, HRBProfileTypes.SelectionCard, 'value', selectionItem.fieldName),
        alias: getProps<HRBProfileTypes>(this.metaData.items, HRBProfileTypes.SelectionCard, 'alias')
      };
    }
  }

}