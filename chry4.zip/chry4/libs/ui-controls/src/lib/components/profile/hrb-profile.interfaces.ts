import { IHRBCommandAction, IHRBFormItem } from '@chrysalis/core';

import { IHRBButtonContent } from '../button';
import { IHRBLinkContent } from '../link';

/** Interface for Profile component */
export interface IHRBProfile {
    /** Header text */
    headerText?: string;
    /** Header subtext */
    headerSubText?: string;
    /** Profile card */
    profileCard?: IHRBProfileCard;
    /** Text card */
    textCard?: IHRBTextCard;
    /** Content text */
    contentText?: string;
    /** Selection card */
    selectionCard?: Record<string, IHRBSelectionCard>;
    /** Toggle card */
    toggleCard?: Record<string, IHRBToggleCard>;
    /** Primary Button */
    primaryButton?: IHRBButtonContent;
    /** Footer Link */
    footerLink?: IHRBLinkContent;
    /** Theme */
    theme?: string;
}

/** Interface for Profile card */
export interface IHRBProfileCard {
    /** Header text */
    headerText?: string;
    /** Theme */
    theme?: string;
    /** Alias */
    alias?: string;
}

/** Interface for text card */
export interface IHRBTextCard {
    /** Text */
    text?: string;
    /** Alias */
    alias?: string;
}

/** Interface for selection card */
export interface IHRBSelectionCard {
    /** Text */
    text?: string;
    /** Value */
    value?: string;
    /** Name */
    fieldName?: string;
    /** Alias */
    alias?: string;
}

/** Interface for toggle card */
export interface IHRBToggleCard {
    /** Text */
    text?: string;
    /** Icon */
    icon?: string;
    /** Icon */
    content?: IHRBFormItem[];
}

/** Profile action */
export type IHRBProfileAction = IHRBCommandAction;

/** Profile component types */
export enum HRBProfileTypes {
    /** Default page */
    Default = 'default',
    /** Header text */
    HeaderText = 'headerText',
    /** Header subtext */
    HeaderSubText = 'headerSubText',
    /** Profile card */
    ProfileCard = 'profileCard',
    /** Text card */
    TextCard = 'textCard',
    /** Content text */
    ContentText = 'contentText',
    /** Selection card */
    SelectionCard = 'selectionCard',
    /** Toggle card */
    ToggleCard = 'toggleCard',
    /** Primary Button */
    PrimaryButton = 'primaryButton',
    /** Footer Link */
    FooterLink = 'footerLink'
}
