import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { getFormattedMessages } from '@chrysalis/core';
import { cloneDeep } from 'lodash-es';
import { IHRBInterstitialAction } from '../interstitial';
import { IHRBPaginationContent } from '../pagination/hrb-pagination.interface';
import { contentGroupedMetaData } from '../utilities/hrb-composer-utils';
import { IHRBFormTask, HRBFormTaskTypes, HRBFormTaskGroups } from './hrb-quick-questions.interface';

@Component({
  selector: 'hrb-quick-questions',
  templateUrl: './hrb-quick-questions.component.html',
  styleUrls: ['./hrb-quick-questions.component.scss']
})
export class HRBQuickQuestionsComponent implements OnInit {

  /** Data */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  @Input() public data: any;

  /** Passing action data  */
  @Output() public actionEvent = new EventEmitter<IHRBInterstitialAction[]>();

  public toggleExpand() {
    this.isExpanded = !this.isExpanded;
  }
  public isExpanded = false;
  public formTaskContent: IHRBFormTask;
  public HRBFormTaskTypes = HRBFormTaskTypes;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public originalContent: any;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public pMetaData: any;

  public currentQuestion = null;
  public questions = null;
  public currentPageIndex = 0;

  public paginationItems: IHRBPaginationContent[] = [
    {
      active: true,
      label: 'first',
      onClick: 'first'
    }, {
      active: false,
      label: 'second',
      onClick: 'second'
    },
    {
      active: false,
      label: 'third',
      onClick: 'third'
    }
  ];
  public selectedItem: IHRBPaginationContent = {
    active: true,
    label: 'first',
    onClick: 'first'
  };

  constructor() {
    console.log('data!', this.data);
  }
  public ngOnInit(): void {

  }

  /** Content */
  @Input()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public set content(val: any) {
    if (val) {
      this.originalContent = cloneDeep(val);
    }
  }
  /** Meta data */
  @Input()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public set metaData(val: any) {
    if (val) {
      this.pMetaData = val;
      this.processMetaData();
    }
  }
  public get metaData() {
    return this.pMetaData;
  }

  public processMetaData() {
    this.currentQuestion = this.pMetaData.questions[0];
    this.questions = this.pMetaData.questions.map((question) => {
      question.active = false;
      return question;
    });
    this.questions[0].active = true;
    this.currentPageIndex = 0;
    console.log('metadata : ', this.metaData)
    this.formTaskContent = {
      theme: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, 
        HRBFormTaskTypes.Default,
        HRBFormTaskGroups.Default, 'theme'),
      headerText: getFormattedMessages(contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.ContentHeader,
        HRBFormTaskGroups.Content, 'text'), this.data),
      headerSubtext: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.ContentHeaderSub,
        HRBFormTaskGroups.Content, 'subText')
    };
    this.setToggleCardContent();
  }

  public onPaginationClicked(pageIndex) {
    // this.questions[this.currentPageIndex].active = false;
    // this.currentPageIndex = pageIndex;
    // this.questions[this.currentPageIndex].active = true;
    const tempQuestions = cloneDeep(this.questions);
    tempQuestions.forEach((question, questionIndex) => {
      tempQuestions[questionIndex].active = questionIndex === pageIndex;
    });
    this.questions = [];
    this.questions = tempQuestions;
    this.currentPageIndex = pageIndex;
    this.currentQuestion = this.questions[pageIndex];

  }
  private setToggleCardContent() {
    this.formTaskContent.toggleCard = {
      text: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.ToggleCard,
        HRBFormTaskGroups.Content, 'text'),
      subText: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.ToggleCard,
        HRBFormTaskGroups.Content, 'subText'),
      img: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.ToggleCard,
        HRBFormTaskGroups.Content, 'img'),
      theme: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.ToggleCard,
        HRBFormTaskGroups.Content, 'theme')
    };
  }

  protected init() { }
  protected destroy() { }
}
