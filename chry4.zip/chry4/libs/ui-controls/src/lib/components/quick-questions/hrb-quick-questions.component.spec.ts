import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBQuickQuestionsComponent } from './hrb-quick-questions.component';

describe('PaginationComponent', () => {
  let component: HRBQuickQuestionsComponent;
  let fixture: ComponentFixture<HRBQuickQuestionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HRBQuickQuestionsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBQuickQuestionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
