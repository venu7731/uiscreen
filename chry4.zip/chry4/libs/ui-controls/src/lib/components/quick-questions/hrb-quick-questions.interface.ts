export interface IHRBFormTask {
    /** Progress content */
    // progressContent?: IHRBProgressContent;
    // /** Header content */
    // headerContent?: IHRBNavBarContent[];
    // /** Header text */
    headerText?: string;
    // /** Header subtext */
    headerSubtext?: string;
    // /** Action Card */
    // actionCard?: IHRBActionCard;
    /** Dynamic form */
    // dynamicForm?: IHRBFormSection;
    /** Toggle Card */
    toggleCard?: IHRBToggleCard;
    /** Footer button */
    // footerButton?: IHRBButtonContent;
    // // /** Footer link */
    // footerLink?: IHRBLinkContent;
    /** theme */
    theme?: string;
}
export interface IHRBToggleCard {
    /** theme */
    theme: string;
    /** Image */
    img: string;
    /** text */
    text: string;
    /** sub text */
    subText: string;
}

export enum HRBFormTaskTypes {
    Default = 'default',
    Header = 'header',
    Progress = 'progress',
    ContentHeader = 'contentHeader',
    ContentHeaderSub = 'contentHeaderSub',
    ToggleCard = 'toggleCard',
    ActionCard = 'actionCard',
    DynamicForm = 'dynamicForm',
    ReadOnlyForm = 'readOnlyForm',
    FooterButton = 'footerButton',
    FooterLink = 'footerLink'
}

export enum HRBFormTaskGroups {
    Header = 'header',
    Content = 'content',
    Footer = 'footer',
    Default = 'default'
}
