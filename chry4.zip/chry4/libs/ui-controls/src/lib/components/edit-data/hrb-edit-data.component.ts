/* eslint-disable @typescript-eslint/no-explicit-any */
import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { cloneDeep } from 'lodash-es';

import { HRBBaseComponent, formatGroup } from '@chrysalis/core';

import { HRBEditDataGroups, HRBEditDataTypes, IHRBEditData, IHRBEditDataAction } from './hrb-edit-data.interfaces';
import { contentGroupedMetaData, getGroupedMeta, getGroups, getProps } from '../utilities/hrb-composer-utils';

/** Edit Popup component */
@Component({
  selector: 'hrb-edit-data',
  templateUrl: './hrb-edit-data.component.html',
  styleUrls: ['./hrb-edit-data.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBEditDataComponent extends HRBBaseComponent {
  /** Content */
  @Input()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public set content(val: any) {
    if (val) {
      this.originalContent = cloneDeep(val);
    }
  }
  /** Meta data */
  @Input()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public set metaData(val: any) {
    if (val) {
      this.pMetaData = val;
      this.processMetaData();
    }
  }
  public get metaData() {
    return this.pMetaData;
  }
  /** Data */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  @Input() public data: any;
  /** Passing action data  */
  @Output() public actionEvent = new EventEmitter<IHRBEditDataAction[]>();
  /** Edit data content */
  public editDataContent: IHRBEditData;
  /** Original Content */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public originalContent: any;
  /** HRBEditData Types */
  public HRBEditDataTypes = HRBEditDataTypes;
  /** HRBEditData Groups */
  public HRBEditDataGroups = HRBEditDataGroups;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private pMetaData: any;

  /** Handle primary button */
  public handlePrimaryButton() {
    this.actionEvent.emit(getGroupedMeta<HRBEditDataGroups, HRBEditDataTypes>(this.metaData.groups, HRBEditDataGroups.Default,
      HRBEditDataTypes.PrimaryButton)?.actions);
  }

  /** Dummy init */
  protected init(): void {
  }
  /** Dummy destroy */
  protected destroy(): void {
  }

  private processMetaData() {
    const { items } = this.metaData.groups.find(grp => grp.name === HRBEditDataGroups.Default);
    this.editDataContent = {
      theme: contentGroupedMetaData<HRBEditDataTypes, HRBEditDataGroups>(this, HRBEditDataTypes.Default,
        HRBEditDataGroups.Default, 'theme'),
      headerText: contentGroupedMetaData<HRBEditDataTypes, HRBEditDataGroups>(this, HRBEditDataTypes.HeaderText,
        HRBEditDataGroups.Default, 'headerText')
    };
    this.editDataContent.infoCard = {
      headerText: contentGroupedMetaData<HRBEditDataTypes, HRBEditDataGroups>(this, HRBEditDataTypes.InfoCard,
        HRBEditDataGroups.Default, 'headerText'),
      alias: getProps<HRBEditDataTypes>(items, HRBEditDataTypes.InfoCard, 'alias')
    };
    this.processDynamicForm(items);
    this.editDataContent.primaryButton = {
      description: contentGroupedMetaData<HRBEditDataTypes, HRBEditDataGroups>(this, HRBEditDataTypes.PrimaryButton,
        HRBEditDataGroups.Default, 'description'),
      theme: contentGroupedMetaData<HRBEditDataTypes, HRBEditDataGroups>(this, HRBEditDataTypes.PrimaryButton,
        HRBEditDataGroups.Default, 'theme'),
    };
  }

  private processDynamicForm(items) {
    const formItem = items.find(item => item.type === HRBEditDataTypes.DynamicForm);
    if (!formItem) {
      return;
    }
    this.editDataContent.dynamicForm = {
      name: getProps<HRBEditDataTypes>(items, HRBEditDataTypes.DynamicForm, 'alias'),
      groups: getGroups<HRBEditDataGroups, HRBEditDataTypes>(this, items, HRBEditDataGroups.Default, HRBEditDataTypes.DynamicForm)
    };
    this.editDataContent.dynamicForm = formatGroup(this.editDataContent.dynamicForm, { section: null }, {}) as any;
  }

}
