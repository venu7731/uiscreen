import { ChangeDetectorRef, Component, Input, NgZone } from '@angular/core';

import { HRBBaseComponent, HRBDataService } from '@chrysalis/core';

import { IHRBGridContent } from './hrb-grid.interface';

/**
 * Grid Component
 */
@Component({
  selector: 'hrb-grid',
  templateUrl: './hrb-grid.component.html',
  styleUrls: ['./hrb-grid.component.scss']
})
export class HRBGridComponent extends HRBBaseComponent {
  /** Grid content */
  @Input() public item: IHRBGridContent;
  /** Grid data */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  @Input() public data: any;
  /** Grid name */
  public gridName: string;

  /** Constructor method */
  constructor(
    cdr: ChangeDetectorRef, ngZone: NgZone,
    private dataService: HRBDataService) {
    super(cdr, ngZone);
  }

  /** Data changed event */
  public updateChangedProps(alias: string, rowNumber: number) {
    this.dataService.addChangedProps(`${this.gridName}-${rowNumber}`, alias);
  }
  /** Set grid name */
  protected init(): void {
    this.gridName = `Grid_${this.item.form}_${this.item.description}`;
  }
  /** Dummy destroy */
  protected destroy(): void {
  }
}