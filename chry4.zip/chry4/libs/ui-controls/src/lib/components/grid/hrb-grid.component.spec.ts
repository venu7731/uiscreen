import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBGridComponent } from './hrb-grid.component';

describe('HRBGridComponent', () => {
  let component: HRBGridComponent;
  let fixture: ComponentFixture<HRBGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBGridComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
