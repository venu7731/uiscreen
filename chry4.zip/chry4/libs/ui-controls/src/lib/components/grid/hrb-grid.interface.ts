import { IHRBFormLayout } from '@chrysalis/core';

/** Checkbox meta */
export interface IHRBGridContent {
    /** description */
    description: string;
    /** form name */
    form?: string;
    /** layouts */
    layouts?: IHRBFormLayout[];
}
