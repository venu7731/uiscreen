import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';

import { HRBBaseComponent } from '@chrysalis/core';

import { IHRBTaskContent } from './hrb-task.interface';

/**
 * Task Component
 */
@Component({
  selector: 'hrb-task',
  templateUrl: './hrb-task.component.html',
  styleUrls: ['./hrb-task.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBTaskComponent extends HRBBaseComponent {

  /** Task content */
  @Input() public content: IHRBTaskContent;
  /** Buttons result */
  @Output() public buttonsResult = new EventEmitter<number>();
  /** Button clicked */
  public emitButtonClick(idx: number) {
    this.buttonsResult.emit(idx);
  }
  /** Dummy init */
  protected init(): void {
  }
  /** Dummy destroy */
  protected destroy(): void {
  }

}
