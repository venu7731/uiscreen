import { IHRBNavBarContent } from '../nav-bar';
import { IHRBProgressContent } from '../radial-progress-meter';

/** Add W2 content */
export interface IHRBTaskContent {
    /** Progress content */
    progressContent: IHRBProgressContent,
    /** Header content */
    headerContent: IHRBNavBarContent[];
    /** Page Title */
    pageTitle: string;
    /** Footer button content */
    footerButtons: IHRBTaskButtonContent[];
}

/** Button content */
export interface IHRBTaskButtonContent {
    /** Button text */
    text: string;
    /** Button theme */
    theme: string;
}