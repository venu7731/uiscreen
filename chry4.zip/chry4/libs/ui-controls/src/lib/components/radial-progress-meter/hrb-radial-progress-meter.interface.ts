/** Progress content */
export interface IHRBProgressContent {
    /** Progress percentage */
    percentage: number;
}