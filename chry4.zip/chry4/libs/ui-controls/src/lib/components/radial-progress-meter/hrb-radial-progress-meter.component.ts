import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import {
  trigger,
  state,
  style,
  animate,
  transition,
} from '@angular/animations';

import { HRBBaseComponent } from '@chrysalis/core';

/**
 * Radial progress meter component
 */
@Component({
  selector: 'hrb-radial-progress-meter',
  templateUrl: './hrb-radial-progress-meter.component.html',
  styleUrls: ['./hrb-radial-progress-meter.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    trigger('setMeterLevel', [
      state('empty', style({
        strokeDashoffset: 94.248,
      })),
      state(
        'currentLevel',
        style({ strokeDashoffset: '{{progressLevel}}' }),
        { params: { progressLevel: 94.248 } }
      ),
      transition('* <=> currentLevel', [
        animate('1s 1s ease-in-out'),
      ])
    ]),
  ],
})
export class HRBRadialProgressMeterComponent extends HRBBaseComponent {
  /**
   * Progress percentage
   */
  @Input() public progressPercentage: number;

  public progressLevel: number;
  public isMeterSet = false;
  public triggerValue = this.isMeterSet ? 'currentLevel' : 'empty';

  public calculateLevel(): void {
    this.progressLevel = 0 <= this.progressPercentage && this.progressPercentage <= 100
      ? 94.248 - (this.progressPercentage / 100 * 94.248)
      : 0;
  }

  public setTriggerValue() {
    this.triggerValue = this.isMeterSet ? 'currentLevel' : 'empty';
  }

  public toggleMeter() {
    this.isMeterSet = !this.isMeterSet;
  }

  /** Init */
  protected init(): void {
    this.calculateLevel();
    this.toggleMeter();
    this.setTriggerValue();
  }
  /** Dummy destroy */
  protected destroy(): void {
  }
}
