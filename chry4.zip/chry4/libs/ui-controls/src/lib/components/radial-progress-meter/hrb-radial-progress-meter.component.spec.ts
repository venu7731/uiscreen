import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import { HRBRadialProgressMeterComponent } from './hrb-radial-progress-meter.component';

describe('ProgressCircleComponent', () => {
  let component: HRBRadialProgressMeterComponent;
  let fixture: ComponentFixture<HRBRadialProgressMeterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NoopAnimationsModule],
      declarations: [ HRBRadialProgressMeterComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBRadialProgressMeterComponent);
    component = fixture.componentInstance;
    component.progressPercentage = 50;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should calculate and set progressLevel', () => {
    component.calculateLevel();
    expect(component.progressLevel).toBe(47.124);
  });

  it('should toggle isMeterSet on toggleMeter', () => {
    const startingMeterSetting = component.isMeterSet;
    component.toggleMeter();
    expect(startingMeterSetting).toBe(!component.isMeterSet);
  });

  it('should set isMeterSet and triggerValue after init', () => {
    expect(component.isMeterSet).toEqual(true);
    expect(component.triggerValue).toEqual('currentLevel');
  });
});
