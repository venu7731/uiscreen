import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { HRBSecondaryCardComponent } from './hrb-secondary-card.component';

describe('HRBSecondaryCardComponent', () => {
  let component: HRBSecondaryCardComponent;
  let fixture: ComponentFixture<HRBSecondaryCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBSecondaryCardComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
      .compileComponents();
    fixture = TestBed.createComponent(HRBSecondaryCardComponent);
    component = fixture.componentInstance;
    component.cardContent = { imgUrl: '', text: '' };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
