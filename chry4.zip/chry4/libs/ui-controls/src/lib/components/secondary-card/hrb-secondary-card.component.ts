import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, NgZone, Output } from '@angular/core';

import { HRBBaseComponent, HRBStateManagerService } from '@chrysalis/core';

import { IHRBSecondaryCardContent } from './hrb-secondary-card.interface';

/**
 * Secondary card component
 */
@Component({
  selector: 'hrb-secondary-card',
  templateUrl: './hrb-secondary-card.component.html',
  styleUrls: ['./hrb-secondary-card.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBSecondaryCardComponent extends HRBBaseComponent {

  /** Secondary card content */
  @Input() public cardContent: IHRBSecondaryCardContent;
  /** Card clicked event */
  @Output() public cardClicked = new EventEmitter<string>();

  constructor(public stateManager: HRBStateManagerService, cdr: ChangeDetectorRef, ngZone: NgZone) {
    super(cdr, ngZone);
  }
  /** Emit card state */
  public emitClickEvent(state: string) {
    this.cardClicked.emit(state);
  }
  /** Dummy init */
  protected init(): void {
  }
  /** Dummy destroy */
  protected destroy(): void {
  }

}
