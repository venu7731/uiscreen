import { IHRBPrimaryCardContent } from '../primary-card/hrb-primary-card.interface';

/** Secondary card content */
export type IHRBSecondaryCardContent = IHRBPrimaryCardContent;