import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { HRBTotalFundComponent } from './hrb-total-fund.component';

describe('HRBTotalFundComponent', () => {
  let component: HRBTotalFundComponent;
  let fixture: ComponentFixture<HRBTotalFundComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBTotalFundComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBTotalFundComponent);
    component = fixture.componentInstance;
    // component.content = { text : '', description: '', totalAmount: 0   };
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
