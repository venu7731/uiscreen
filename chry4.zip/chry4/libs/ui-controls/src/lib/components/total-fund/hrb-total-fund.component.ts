import { ChangeDetectionStrategy, Component, Input } from '@angular/core';

import { desktopQuery, HRBBaseComponent, mobileQuery } from '@chrysalis/core';

import { IHRBTotalRefund } from './hrb-total-fund.interface';

/**
 * Total refund component
 */
@Component({
  selector: 'hrb-total-fund',
  templateUrl: './hrb-total-fund.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./hrb-total-fund.component.scss']
})
export class HRBTotalFundComponent extends HRBBaseComponent {
  /** Total refund content */
  @Input() public content: IHRBTotalRefund;
  /** Desktop media query */
  public desktopQuery = desktopQuery;
  /** Mobile media query */
  public mobileQuery = mobileQuery;

  /** Dummy init */
  protected init(): void {
  }
  /** Dummy destroy */
  protected destroy(): void {
  }
}
