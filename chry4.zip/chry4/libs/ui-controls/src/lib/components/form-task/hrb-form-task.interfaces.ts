import { IHRBCommandAction, IHRBFormSection } from '@chrysalis/core';

import { IHRBButtonContent } from '../button';
import { IHRBLinkContent } from '../link';
import { IHRBNavBarContent } from '../nav-bar';
import { IHRBProgressContent } from '../radial-progress-meter';

/** Interface for Form Task component */
export interface IHRBFormTask {
    /** Progress content */
    progressContent?: IHRBProgressContent;
    /** Header content */
    headerContent?: IHRBNavBarContent[];
    /** Header text */
    headerText?: string;
    /** Header subtext */
    headerSubtext?: string;
    /** Action Card */
    actionCard?: IHRBActionCard;
    /** Dynamic form */
    dynamicForm?: IHRBFormSection;
    /** Toggle Card */
    toggleCard?: IHRBToggleCard;
    /** Footer button */
    footerButton?: IHRBButtonContent;
    /** Footer link */
    footerLink?: IHRBLinkContent;
    /** theme */
    theme?: string;
}

/** Form Task action */
export type IHRBFormTaskAction = IHRBCommandAction;

/** Action card */
export interface IHRBActionCard {
    /** text */
    text: string;
    /** sub text */
    subText: string;
    /** icon */
    icon: string;
    /** theme */
    theme: string;
    /** state */
    state: string;
}
/** Toggle card */
export interface IHRBToggleCard {
    /** theme */
    theme: string;
    /** Image */
    img: string;
    /** text */
    text: string;
    /** sub text */
    subText: string;
}
/** Form Task component groups */
export enum HRBFormTaskGroups {
    Header = 'header',
    Content = 'content',
    Footer = 'footer',
    Default = 'default'
}

/** Form Task component types */
export enum HRBFormTaskTypes {
    Default = 'default',
    Header = 'header',
    Progress = 'progress',
    ContentHeader = 'contentHeader',
    ContentHeaderSub = 'contentHeaderSub',
    ToggleCard = 'toggleCard',
    ActionCard = 'actionCard',
    DynamicForm = 'dynamicForm',
    ReadOnlyForm = 'readOnlyForm',
    FooterButton = 'footerButton',
    FooterLink = 'footerLink'
}
