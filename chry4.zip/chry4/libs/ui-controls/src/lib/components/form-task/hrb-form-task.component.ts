import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { cloneDeep, first } from 'lodash-es';

import { formatGroup, getFormattedMessages, HRBBaseComponent } from '@chrysalis/core';

import { contentGroupedMetaData, getGroupedMeta, getGroups, getProps } from '../utilities/hrb-composer-utils';
import { HRBFormTaskGroups, HRBFormTaskTypes, IHRBFormTask, IHRBFormTaskAction } from './hrb-form-task.interfaces';

/**
 * Form Task component
 */
@Component({
  selector: 'hrb-form-task',
  templateUrl: './hrb-form-task.component.html',
  styleUrls: ['./hrb-form-task.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBFormTaskComponent extends HRBBaseComponent {
  /** Content */
  @Input()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public set content(val: any) {
    if (val) {
      this.originalContent = cloneDeep(val);
    }
  }
  /** Meta data */
  @Input()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public set metaData(val: any) {
    if (val) {
      this.pMetaData = val;
      this.processMetaData();
    }
  }
  public get metaData() {
    return this.pMetaData;
  }
  /** Data */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  @Input() public data: any;
  /** Passing action data  */
  @Output() public actionEvent = new EventEmitter<IHRBFormTaskAction[]>();
  /** Info content */
  public formTaskContent: IHRBFormTask;
  /** Info Groups */
  public HRBFormTaskGroups = HRBFormTaskGroups;
  /** Info Types */
  public HRBFormTaskTypes = HRBFormTaskTypes;
  /** Original Content */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public originalContent: any;
  /** Is toggle card expanded? */
  public isExpanded = false;
  /** State Set Initially */
  protected state;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private pMetaData: any;

  /** Handle menu click */
  public handleNavigation(target: string) {
    const { actions } = getGroupedMeta<HRBFormTaskGroups, HRBFormTaskTypes>(this.metaData.groups, HRBFormTaskGroups.Header,
      HRBFormTaskTypes.Header);
    const action: IHRBFormTaskAction = first(actions);
    action.params = {
      state: target
    };
    this.actionEvent.emit(actions);
  }
  /** Handle menu click */
  public handleAction(target: string) {
    const { actions } = getGroupedMeta<HRBFormTaskGroups, HRBFormTaskTypes>(this.metaData.groups, HRBFormTaskGroups.Content,
      HRBFormTaskTypes.ActionCard);
    const action: IHRBFormTaskAction = first(actions);
    action.params = {
      ...action.params,
      state: target
    };
    this.actionEvent.emit(actions);
  }
  /** Toggle expand */
  public toggleExpand() {
    this.isExpanded = !this.isExpanded;
  }
  /** Handle primary button */
  public handleFooterButton() {
    this.actionEvent.emit(getGroupedMeta<HRBFormTaskGroups, HRBFormTaskTypes>(this.metaData.groups, HRBFormTaskGroups.Footer,
      HRBFormTaskTypes.FooterButton)?.actions);
  }
  /** Handle Footer link */
  public handleFooterLink() {
    this.actionEvent.emit(getGroupedMeta<HRBFormTaskGroups, HRBFormTaskTypes>(this.metaData.groups, HRBFormTaskGroups.Footer,
      HRBFormTaskTypes.FooterLink)?.actions);
  }
  /** Dummy init */
  protected init(): void { }
  /** Dummy destroy */
  protected destroy(): void {
  }

  private processMetaData() {
    this.formTaskContent = {
      theme: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.Default,
        HRBFormTaskGroups.Default, 'theme'),
      headerText: getFormattedMessages(contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.ContentHeader,
        HRBFormTaskGroups.Content, 'text'), this.data),
      headerSubtext: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.ContentHeaderSub,
        HRBFormTaskGroups.Content, 'subText')
    };
    this.formTaskContent.progressContent = {
      percentage: this.data.progressPercent
    };
    this.formTaskContent.headerContent = contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.Header,
      HRBFormTaskGroups.Header, 'options');
    this.setActionCardContent();
    this.setToggleCardContent();
    this.formTaskContent.footerButton = {
      description: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.FooterButton,
        HRBFormTaskGroups.Footer, 'description'),
      theme: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.FooterButton,
        HRBFormTaskGroups.Footer, 'theme')
    };
    this.processDynamicForm();
    this.formTaskContent.footerLink = {
      description: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.FooterLink,
        HRBFormTaskGroups.Footer, 'description'),
      theme: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.FooterLink,
        HRBFormTaskGroups.Footer, 'theme')
    };
  }

  private processDynamicForm() {
    const { items } = this.metaData.groups.find(grp => grp.name === HRBFormTaskGroups.Content);
    const formItem = items.find(item => item.type === HRBFormTaskTypes.DynamicForm || item.type === HRBFormTaskTypes.ReadOnlyForm);
    if (!formItem) {
      return;
    }
    this.formTaskContent.dynamicForm = {
      name: getProps<HRBFormTaskTypes>(items, HRBFormTaskTypes.DynamicForm, 'alias'),
      groups: getGroups<HRBFormTaskGroups, HRBFormTaskTypes>(this, items, HRBFormTaskGroups.Content, HRBFormTaskTypes.DynamicForm)
    };
    if (!this.formTaskContent.dynamicForm.name) {
      this.formTaskContent.dynamicForm = {
        name: getProps<HRBFormTaskTypes>(items, HRBFormTaskTypes.ReadOnlyForm, 'alias'),
        groups: getGroups<HRBFormTaskGroups, HRBFormTaskTypes>(this, items, HRBFormTaskGroups.Content, HRBFormTaskTypes.ReadOnlyForm)
      };
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    this.formTaskContent.dynamicForm = formatGroup(this.formTaskContent.dynamicForm, { section: null }, {}) as any;
  }

  private setActionCardContent() {
    this.formTaskContent.actionCard = {
      text: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.ActionCard,
        HRBFormTaskGroups.Content, 'text'),
      subText: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.ActionCard,
        HRBFormTaskGroups.Content, 'subText'),
      icon: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.ActionCard,
        HRBFormTaskGroups.Content, 'icon'),
      theme: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.ActionCard,
        HRBFormTaskGroups.Content, 'theme'),
      state: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.ActionCard,
        HRBFormTaskGroups.Content, 'state')
    };
  }
  private setToggleCardContent() {
    this.formTaskContent.toggleCard = {
      text: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.ToggleCard,
        HRBFormTaskGroups.Content, 'text'),
      subText: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.ToggleCard,
        HRBFormTaskGroups.Content, 'subText'),
      img: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.ToggleCard,
        HRBFormTaskGroups.Content, 'img'),
      theme: contentGroupedMetaData<HRBFormTaskTypes, HRBFormTaskGroups>(this, HRBFormTaskTypes.ToggleCard,
        HRBFormTaskGroups.Content, 'theme')
    };
  }

}
