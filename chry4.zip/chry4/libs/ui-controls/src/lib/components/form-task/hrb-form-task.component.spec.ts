import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HrbFormTaskComponent } from './hrb-form-task.component';

describe('HrbFormTaskComponent', () => {
  let component: HrbFormTaskComponent;
  let fixture: ComponentFixture<HrbFormTaskComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HrbFormTaskComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HrbFormTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
