import { IHRBCommandAction } from '@chrysalis/core';

import { IHRBButtonContent } from '../button';

/** Interface for Overlay component */
export interface IHRBOverlay {
    /** Header text */
    headerText?: string;
    /** Button List */
    button?: Record<string, IHRBButtonContent>;
}

/** Overlay action */
export type IHRBOverlayAction = IHRBCommandAction;

/** Overlay component types */
export enum HRBOverlayTypes {
    HeaderText = 'headerText',
    Button = 'button'
}