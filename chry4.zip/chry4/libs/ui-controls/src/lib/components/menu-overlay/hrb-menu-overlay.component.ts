import { ChangeDetectionStrategy, ChangeDetectorRef, Component, NgZone, Renderer2 } from '@angular/core';
import { cloneDeep, size } from 'lodash-es';

import {
  CustomEvents, HRBBaseComponent, HRBMetaDataManagerService,
  HRBOverlayService, HRBStateManagerService, HRBCommandManagerService
} from '@chrysalis/core';
import { contentMetaData } from '../utilities/hrb-composer-utils';
import { HRBOverlayTypes, IHRBOverlay, IHRBOverlayAction } from './hrb-menu-overlay.interfaces';

@Component({
  selector: 'hrb-menu-btn-popup',
  templateUrl: './hrb-menu-overlay.component.html',
  styleUrls: ['./hrb-menu-overlay.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBMenuOverlayComponent extends HRBBaseComponent {
  /** is overlay open */
  public overlayOpen = false;
  /** Meta data */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public metaData: any;
  /** Original Content */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public originalContent: any;
  /** HRBOverlay Types */
  public HRBOverlayTypes = HRBOverlayTypes;
  /** Overlay content */
  public overlayContent: IHRBOverlay;
  /**
   * Constructor method
   * @param cdr ChangeDetectorRef
   * @param ngZone NgZone
   * @param overlayService HRBOverlayService
   */
  constructor(
    cdr: ChangeDetectorRef, ngZone: NgZone,
    private metaDataManager: HRBMetaDataManagerService,
    private overlayService: HRBOverlayService,
    private stateManager: HRBStateManagerService,
    private commandManager: HRBCommandManagerService,
    private renderer: Renderer2
  ) {
    super(cdr, ngZone);
  }

  /** Close overlay */
  public closeOverlay() {
    this.overlayService.updateOverlayStatus(false);
  }

  /** Emit clicked button index */
  public async emitButtonClick(actions: IHRBOverlayAction[]) {
    if (size(actions)) {
      await this.commandManager.execute(actions, {});
      this.closeOverlay();
    }
  }
  /** Listen for overlay changes */
  protected init(): void {
    this.addSafeSubscriber(this.stateManager.onContentUpdated, (data) => {
      const appName = 'overlay';
      if (!data || !data[appName]) {
        return;
      }
      const callback = () => {
        this.originalContent = cloneDeep(data);
      };
      this.render(callback);
    });
    this.addSafeSubscriber(this.overlayService.onOverlayStatus, (status: boolean) => {
      const callback = () => {
        this.overlayOpen = status;
      };
      this.render(callback);
    });
    const popupCallback = ({ detail }: CustomEvent) => {
      const screen = detail.screen;
      const appName = 'overlay';
      this.metaDataManager.getMetaData(appName, screen).then((data) => {
        const callback = () => {
          this.metaData = data;
          this.processMetaData();
        };
        this.render(callback);
      });
    };
    this.addSafeListener(this.renderer, document, CustomEvents.OverlayOpen, popupCallback);

  }
  /** Dummy destroy */
  protected destroy(): void {
  }

  private processMetaData() {
    this.overlayContent = {
      headerText: contentMetaData<HRBOverlayTypes>(this, HRBOverlayTypes.HeaderText, 'headerText')
    };
    this.overlayContent.button = {};
    const buttons = this.metaData.items.filter((item) => item.type === HRBOverlayTypes.Button);
    for (const button of buttons) {
      this.overlayContent.button[button.fieldName] = {
        description: contentMetaData<HRBOverlayTypes>(this, HRBOverlayTypes.Button, 'description', button.fieldName),
        icon: contentMetaData<HRBOverlayTypes>(this, HRBOverlayTypes.Button, 'icon', button.fieldName),
        theme: contentMetaData<HRBOverlayTypes>(this, HRBOverlayTypes.Button, 'theme', button.fieldName)
      };
    }
  }
}
