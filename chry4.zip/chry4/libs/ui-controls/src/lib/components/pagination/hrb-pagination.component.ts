import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
// import { IHRBPaginationContent } from './hrb-pagination.interface';

@Component({
  selector: 'hrb-pagination-wrapper',
  templateUrl: './hrb-pagination.component.html',
  styleUrls: ['./hrb-pagination.component.scss']
})
export class HRBPaginationComponent implements OnInit {
  /** Pagination content */
  // @Input() public items: IHRBPaginationContent[];
  public _currentPageIndex = 0;
  public isLoading = false;
  @Input() public items: any;

  @Input() public set currentPageIndex(val: number) {
    if(this._currentPageIndex !== val) {
      this.isLoading = true;
      this._currentPageIndex = val;
      this.isLoading = false;
    }
  }

  /** Emit data changed */
  @Output() public emitDataChanged = new EventEmitter<number>();

  constructor() { }

  public ngOnInit(): void {
    console.log(this.items);
  }

  public onPaginationClicked(itemIndex) {
    this.emitDataChanged.emit(itemIndex);
  }

}
