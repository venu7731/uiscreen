import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBPaginationComponent } from './hrb-pagination.component';

describe('HrbPaginationComponent', () => {
  let component: HRBPaginationComponent;
  let fixture: ComponentFixture<HRBPaginationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HRBPaginationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBPaginationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
