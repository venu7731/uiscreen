/** Pagination meta */
export interface IHRBPaginationContent {
    /** active */
    active?: boolean;
    /** label */
    label: string;
    /** onClick Action */
    onClick: string;
}
