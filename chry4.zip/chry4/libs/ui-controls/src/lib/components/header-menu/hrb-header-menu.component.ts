import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';

import { desktopQuery, HRBBaseComponent, mobileQuery } from '@chrysalis/core';

import { HRBHomeTypes } from '../home';
import { IHRBHeaderMenuContent } from './hrb-header-menu.interface';

/**
 * Home Header component
 */
@Component({
  selector: 'hrb-header-menu',
  templateUrl: './hrb-header-menu.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./hrb-header-menu.component.scss']
})
export class HRBHeaderMenuComponent extends HRBBaseComponent {

  /** Meta data */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  @Input() public items: any[];
  /** Content */
  @Input() public content: IHRBHeaderMenuContent;
  /** Content */
  @Output() public actionEvent = new EventEmitter<string>();
  /** Desktop media query */
  public desktopQuery = desktopQuery;
  /** Mobile media query */
  public mobileQuery = mobileQuery;
  /** Home Types */
  public HRBHomeTypes = HRBHomeTypes;

  /** Handle menu click */
  public handleNavigation(target: string) {
    this.actionEvent.emit(target);
  }
  /** Dummy init */
  protected init(): void {
  }
  /** Dummy destroy */
  protected destroy(): void {
  }
}
