import { IHRBNavBarContent } from '../nav-bar';
import { IHRBProgressContent } from '../radial-progress-meter';
import { IHRBTotalRefund } from '../total-fund';

/** Header menu content */
export interface IHRBHeaderMenuContent {
    /** Progress content */
    progressContent?: IHRBProgressContent,
    /** Header content */
    headerContent?: IHRBNavBarContent[];
    /** Accounct nav content */
    accountContent?: IHRBNavBarContent[];
    /** Refund content */
    refundContent?: IHRBTotalRefund;
}
