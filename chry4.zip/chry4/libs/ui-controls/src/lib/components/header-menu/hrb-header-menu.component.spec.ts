import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { HRBHeaderMenuComponent } from './hrb-header-menu.component';

describe('HRBHeaderMenuComponent', () => {
    let component: HRBHeaderMenuComponent;
    let fixture: ComponentFixture<HRBHeaderMenuComponent>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [HRBHeaderMenuComponent],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(HRBHeaderMenuComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
