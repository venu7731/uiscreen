import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBCheckboxComponent } from './hrb-checkbox.component';

xdescribe('HRBCheckboxComponent', () => {
  let component: HRBCheckboxComponent;
  let fixture: ComponentFixture<HRBCheckboxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBCheckboxComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBCheckboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
