/** Checkbox meta */
export interface IHRBCheckboxContent {
    /** description */
    description: string;
    /** selected */
    selected?: boolean;
    /** alias name */
    alias?: string;
}
