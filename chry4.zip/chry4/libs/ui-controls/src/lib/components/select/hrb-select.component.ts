import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';

import { HRBBaseComponent } from '@chrysalis/core';

import { IHRBSelect } from './hrb-select.interface';

/**
 * Select component
 */
@Component({
  selector: 'hrb-select-wrapper',
  templateUrl: './hrb-select.component.html',
  styleUrls: ['./hrb-select.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBSelectComponent extends HRBBaseComponent {

  /** Text info */
  @Input() public item: IHRBSelect;
  /** Text data */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  @Input() public data: any;
  /** Emit data changed */
  @Output() public emitDataChanged = new EventEmitter<string>();
  /** Update changes */
  public updateChanges(name: string) {
    this.emitDataChanged.emit(name);
  }
  /** Dummy init */
  protected init(): void {
  }
  /** Dummy destroy */
  protected destroy(): void {
  }

}
