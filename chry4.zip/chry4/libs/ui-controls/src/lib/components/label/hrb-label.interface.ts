/** Label meta */
export interface IHRBLabel {
    /** description */
    description: string;
}
