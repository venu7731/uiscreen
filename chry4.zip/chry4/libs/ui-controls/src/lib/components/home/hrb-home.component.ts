import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { cloneDeep, first } from 'lodash-es';

import { desktopQuery, HRBBaseComponent } from '@chrysalis/core';
import { HRBHomeGroups, HRBHomeTypes, IHRBHome, IHRBHomeAction } from './hrb-home.interfaces';
import { contentGroupedMetaData, getGroupedMeta } from '../utilities/hrb-composer-utils';

/**
 * Home component
 */
@Component({
  selector: 'hrb-home-wrapper',
  templateUrl: './hrb-home.component.html',
  styleUrls: ['./hrb-home.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBHomeComponent extends HRBBaseComponent {
  /** Content */
  @Input()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public set content(val: any) {
    if (val) {
      this.originalContent = cloneDeep(val);
    }
  }
  /** Meta data */
  @Input()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public set metaData(val: any) {
    if (val) {
      this.pMetaData = val;
      this.processMetaData();
    }
  }
  public get metaData() {
    return this.pMetaData;
  }
  /** Data */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  @Input() public data: any;
  /** Passing action data  */
  @Output() public actionEvent = new EventEmitter<IHRBHomeAction[]>();
  /** Home content */
  public homeContent: IHRBHome;
  /** Original Content */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public originalContent: any;
  /** Home Groups */
  public HRBHomeGroups = HRBHomeGroups;
  /** Home Types */
  public HRBHomeTypes = HRBHomeTypes;
  /** Desktop query */
  public desktopQuery = desktopQuery;
  /** Component state */
  protected state;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private pMetaData: any;

  /** Handle header navigation */
  public handleHeaderNavClick(target: string) {
    const { actions } = getGroupedMeta<HRBHomeGroups, HRBHomeTypes>(this.metaData.groups, HRBHomeGroups.HeaderMenu,
      HRBHomeTypes.Header);
    const action: IHRBHomeAction = first(actions);
    action.params = {
      state: target
    };
    this.actionEvent.emit(actions);
  }
  /** Handle primary button */
  public handleCardClick(target: string) {
    const { actions } = getGroupedMeta<HRBHomeGroups, HRBHomeTypes>(this.metaData.groups, HRBHomeGroups.Default,
      HRBHomeTypes.PrimaryCard);
    const action: IHRBHomeAction = first(actions);
    action.params = {
      ...action.params,
      state: target
    };
    this.actionEvent.emit(actions);
  }
  /** Dummy init */
  protected init(): void { }
  /** Clear the timeout */
  protected destroy(): void {
  }

  private processMetaData() {
    this.homeContent = {};
    this.setHeaderMenuContent();
    this.setPrimaryCardContent();
    this.setSecondaryCardContent();
  }

  private setHeaderMenuContent() {
    this.homeContent.headerMenu = {};
    this.homeContent.headerMenu.progressContent = {
      percentage: this.data.progressPercent
    };
    this.homeContent.headerMenu.headerContent = contentGroupedMetaData<HRBHomeTypes, HRBHomeGroups>(this, HRBHomeTypes.Header,
      HRBHomeGroups.HeaderMenu, 'options');
    this.homeContent.headerMenu.refundContent = {
      description: contentGroupedMetaData<HRBHomeTypes, HRBHomeGroups>(this, HRBHomeTypes.Refund,
        HRBHomeGroups.HeaderMenu, 'description'),
      text: contentGroupedMetaData<HRBHomeTypes, HRBHomeGroups>(this, HRBHomeTypes.Refund,
        HRBHomeGroups.HeaderMenu, 'text'),
      theme: contentGroupedMetaData<HRBHomeTypes, HRBHomeGroups>(this, HRBHomeTypes.Refund,
        HRBHomeGroups.HeaderMenu, 'theme'),
      totalAmount: this.data.refundAmount
    };
    this.homeContent.headerMenu.accountContent = contentGroupedMetaData<HRBHomeTypes, HRBHomeGroups>(this, HRBHomeTypes.Account,
      HRBHomeGroups.HeaderMenu, 'options');
  }
  private setPrimaryCardContent() {
    this.state = this.data.primaryCardState;
    this.homeContent.primaryCard = {
      imgUrl: contentGroupedMetaData<HRBHomeTypes, HRBHomeGroups>(this, HRBHomeTypes.PrimaryCard,
        HRBHomeGroups.Default, 'imgUrl'),
      text: contentGroupedMetaData<HRBHomeTypes, HRBHomeGroups>(this, HRBHomeTypes.PrimaryCard,
        HRBHomeGroups.Default, 'text'),
      theme: contentGroupedMetaData<HRBHomeTypes, HRBHomeGroups>(this, HRBHomeTypes.PrimaryCard,
        HRBHomeGroups.Default, 'theme'),
      state: contentGroupedMetaData<HRBHomeTypes, HRBHomeGroups>(this, HRBHomeTypes.PrimaryCard,
        HRBHomeGroups.Default, 'state')
    };
  }
  private setSecondaryCardContent() {
    this.state = this.data.secondaryCardState;
    this.homeContent.secondaryCard = contentGroupedMetaData<HRBHomeTypes, HRBHomeGroups>(this, HRBHomeTypes.SecondaryCard,
      HRBHomeGroups.Default, 'options');
  }
}