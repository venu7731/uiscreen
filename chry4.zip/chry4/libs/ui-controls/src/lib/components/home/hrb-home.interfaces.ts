import { IHRBCommandAction } from '@chrysalis/core';

import { IHRBButtonContent } from '../button';
import { IHRBHeaderMenuContent } from '../header-menu';
import { IHRBPrimaryCardContent } from '../primary-card';
import { IHRBSecondaryCardContent } from '../secondary-card';
import { IHRBTotalRefund } from '../total-fund';

/** Interface for Home component */
export interface IHRBHome {
    /** Header menu content */
    headerMenu?: IHRBHeaderMenuContent;
    /** Refund content */
    refund?: IHRBTotalRefund;
    /** Primary card content */
    primaryCard?: IHRBPrimaryCardContent;
    /** Secondary card content */
    secondaryCard?: IHRBSecondaryCardContent[];
    /** Popup menu button list */
    buttonList?: IHRBButtonContent[];
}

/** Home action */
export type IHRBHomeAction = IHRBCommandAction;

/** Home component groups */
export enum HRBHomeGroups {
    Default = 'default',
    HeaderMenu = 'headerMenu'
}

/** Home component types */
export enum HRBHomeTypes {
    Refund = 'refund',
    PrimaryCard = 'primaryCard',
    SecondaryCard = 'secondaryCard',
    ButtonList = 'buttonList',
    Progress = 'progress',
    Header = 'header',
    Account = 'account'
}