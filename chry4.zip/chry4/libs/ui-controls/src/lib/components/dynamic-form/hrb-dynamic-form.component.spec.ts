import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBDynamicFormComponent } from './hrb-dynamic-form.component';

xdescribe('HRBDynamicFormComponent', () => {
  let component: HRBDynamicFormComponent;
  let fixture: ComponentFixture<HRBDynamicFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBDynamicFormComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBDynamicFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
