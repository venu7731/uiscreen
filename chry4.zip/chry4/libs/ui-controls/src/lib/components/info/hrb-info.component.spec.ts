import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBInfoComponent } from './hrb-info.component';

describe('HRBInfoComponent', () => {
  let component: HRBInfoComponent;
  let fixture: ComponentFixture<HRBInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBInfoComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
