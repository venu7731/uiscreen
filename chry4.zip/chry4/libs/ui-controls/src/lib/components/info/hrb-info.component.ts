import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { cloneDeep, each, map } from 'lodash-es';

import { HRBBaseComponent } from '@chrysalis/core';

import { HRBInfoGroups, HRBInfoTypes, IHRBInfo, IHRBInfoAction } from './hrb-info.interfaces';
import { contentGroupedMetaData, getGroupedMeta } from '../utilities/hrb-composer-utils';

/**
 * Info component
 */
@Component({
  selector: 'hrb-info-wrapper',
  templateUrl: './hrb-info.component.html',
  styleUrls: ['./hrb-info.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBInfoComponent extends HRBBaseComponent {
  /** Content */
  @Input()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public set content(val: any) {
    if (val) {
      this.originalContent = cloneDeep(val);
    }
  }
  /** Meta data */
  @Input()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public set metaData(val: any) {
    if (val) {
      this.pMetaData = val;
      this.processMetaData();
    }
  }
  public get metaData() {
    return this.pMetaData;
  }
  /** Data */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  @Input() public data: any;
  /** Passing action data  */
  @Output() public actionEvent = new EventEmitter<IHRBInfoAction[]>();
  /** Info content */
  public infoContent: IHRBInfo;
  /** Info Groups */
  public HRBInfoGroups = HRBInfoGroups;
  /** Info Types */
  public HRBInfoTypes = HRBInfoTypes;
  /** Original Content */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public originalContent: any;
  /** State Set Initially */
  protected state;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private pMetaData: any;

  /** Handle primary button */
  public handlePrimaryButton() {
    this.actionEvent.emit(getGroupedMeta<HRBInfoGroups, HRBInfoTypes>(this.metaData.groups, HRBInfoGroups.Footer,
      HRBInfoTypes.PrimaryButton)?.actions);
  }
  /** Handle secondary button */
  public handleSecondaryButton() {
    this.actionEvent.emit(getGroupedMeta<HRBInfoGroups, HRBInfoTypes>(this.metaData.groups, HRBInfoGroups.Footer,
      HRBInfoTypes.SecondaryButton)?.actions);
  }
  /** Handle Footer link */
  public handleFooterLink() {
    this.actionEvent.emit(getGroupedMeta<HRBInfoGroups, HRBInfoTypes>(this.metaData.groups, HRBInfoGroups.Footer,
      HRBInfoTypes.FooterLink)?.actions);
  }
  /** Dummy init */
  protected init(): void { }
  /** Clear state */
  protected destroy(): void {
    delete this.data.state;
    this.state = undefined;
  }

  private processMetaData() {
    this.state = this.data.state;
    this.infoContent = {
      theme: `container--${contentGroupedMetaData<HRBInfoTypes,
        HRBInfoGroups>(this, HRBInfoTypes.Default, HRBInfoGroups.Default, 'theme')}`,
      headerText: contentGroupedMetaData<HRBInfoTypes, HRBInfoGroups>(this, HRBInfoTypes.HeaderText, HRBInfoGroups.Header, 'headerText'),
      headerSubText: contentGroupedMetaData<HRBInfoTypes, HRBInfoGroups>(this, HRBInfoTypes.HeaderSubText,
        HRBInfoGroups.Header, 'headerSubText'),
      contentText: contentGroupedMetaData<HRBInfoTypes, HRBInfoGroups>(this, HRBInfoTypes.ContentText,
        HRBInfoGroups.Content, 'contentText'),
      contentSubText: contentGroupedMetaData<HRBInfoTypes, HRBInfoGroups>(this, HRBInfoTypes.ContentSubText,
        HRBInfoGroups.Content, 'contentSubText'),
      contentImageUrl: contentGroupedMetaData<HRBInfoTypes, HRBInfoGroups>(this, HRBInfoTypes.ContentImageUrl,
        HRBInfoGroups.Content, 'contentImageUrl'),
      contentImageText: contentGroupedMetaData<HRBInfoTypes, HRBInfoGroups>(this, HRBInfoTypes.ContentImageText,
        HRBInfoGroups.Content, 'contentImageText'),
      footerText: contentGroupedMetaData<HRBInfoTypes, HRBInfoGroups>(this, HRBInfoTypes.FooterText, HRBInfoGroups.Footer, 'footerText')
    };
    this.infoContent.footerLink = {
      description: contentGroupedMetaData<HRBInfoTypes, HRBInfoGroups>(this, HRBInfoTypes.FooterLink, HRBInfoGroups.Footer, 'description'),
      theme: contentGroupedMetaData<HRBInfoTypes, HRBInfoGroups>(this, HRBInfoTypes.FooterLink, HRBInfoGroups.Footer, 'theme')
    };
    this.infoContent.primaryButton = {
      description: contentGroupedMetaData<HRBInfoTypes, HRBInfoGroups>(this, HRBInfoTypes.PrimaryButton,
        HRBInfoGroups.Footer, 'description'),
      theme: contentGroupedMetaData<HRBInfoTypes, HRBInfoGroups>(this, HRBInfoTypes.PrimaryButton, HRBInfoGroups.Footer, 'theme')
    };
    this.infoContent.secondaryButton = {
      description: contentGroupedMetaData<HRBInfoTypes, HRBInfoGroups>(this, HRBInfoTypes.SecondaryButton,
        HRBInfoGroups.Footer, 'description'),
      theme: contentGroupedMetaData<HRBInfoTypes, HRBInfoGroups>(this, HRBInfoTypes.SecondaryButton, HRBInfoGroups.Footer, 'theme')
    };
    // For lists, special processing is needed
    this.infoContent.contentCards = this.processLists(
      contentGroupedMetaData<HRBInfoTypes, HRBInfoGroups>(this, HRBInfoTypes.ContentCards, HRBInfoGroups.Content, 'contentCards.name'),
      getGroupedMeta<HRBInfoGroups, HRBInfoTypes>(this.metaData.groups, HRBInfoGroups.Content, HRBInfoTypes.ContentCards)?.contentCards
    );
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private processLists(list: any[], listMeta: any) {
    if (!list || !listMeta) {
      return null;
    }
    const keys = Object.keys(listMeta);
    const values: string[] = Object.values(listMeta);
    const nameIndex = keys.findIndex(key => key === 'name');
    keys.splice(nameIndex, 1);
    values.splice(nameIndex, 1);

    return map(list, (item) => {
      const returnObj = {};
      each(keys, (key, index) => {
        returnObj[key] = item[values[index]];
      });
      return returnObj;
    });
  }
}
