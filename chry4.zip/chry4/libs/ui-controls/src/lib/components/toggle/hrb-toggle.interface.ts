import { IHRBCommandAction } from '@chrysalis/core';

/** Toggle meta */
export interface IHRBToggle {
    /** description */
    description: string;
    /** state */
    state?: HRBToggleState;
    /** actions */
    actions?: IHRBToggleAction[];
}

/** Toggle State */
export enum HRBToggleState {
    Expanded = 'Expanded',
    Collapsed = 'Collapsed',
}

/** Link action */
export type IHRBToggleAction = IHRBCommandAction;