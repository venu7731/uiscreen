import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HRBDeviceDirective } from './directives/hrb-device.directive';

@NgModule({
    imports: [CommonModule],
    declarations: [HRBDeviceDirective],
    exports: [HRBDeviceDirective]
})
export class CoreModule { }
