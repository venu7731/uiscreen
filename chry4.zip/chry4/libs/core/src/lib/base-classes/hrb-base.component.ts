import { OnInit, OnDestroy, Directive, ChangeDetectorRef, NgZone } from '@angular/core';

import { HRBGenericBase } from './hrb-generic-base';

/**
 * Base class for all HRB components
 */
@Directive()
// eslint-disable-next-line @angular-eslint/directive-class-suffix
export abstract class HRBBaseComponent extends HRBGenericBase implements OnInit, OnDestroy {

    /** Constructor method */
    constructor(protected cdr: ChangeDetectorRef, protected ngZone: NgZone) {
        super();
    }
    /** OnInit Life cycle method
     * @returns void
     */
    public ngOnInit(): void {
        this.init();
    }

    /** OnDestroy Life cycle method
     * @returns void
     */
    public ngOnDestroy(): void {
        super.ngOnDestroy();
        this.destroy();
    }
    /**
     * Default Track by function tracking by index
     * @param index index
     * @returns index
     */
    public trackByFunction(index: number) {
        return index;
    }
    /**
     * Referesh the view using change detection
     * @param callback Callback method
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public render(callback: any) {
        this.ngZone.run(() => {
            callback();
            this.cdr.markForCheck();
        });
    }
    /** Abstract method to be implemented for initialization in all the concrete component classes
     * @returns void
     */
    protected abstract init(): void;

    /** Abstract method to be implemented for exit cleanup in all the concrete component classes
     * @returns void
     */
    protected abstract destroy(): void;

}
