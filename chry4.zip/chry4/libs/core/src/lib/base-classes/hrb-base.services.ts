import { Directive, OnDestroy } from '@angular/core';

import { HRBGenericBase } from './hrb-generic-base';

/**
 * Base class for all HRB Services
 */
@Directive()
// eslint-disable-next-line @angular-eslint/directive-class-suffix
export abstract class HRBBaseService extends HRBGenericBase implements OnDestroy {

    /** OnDestroy Life cycle method
     * @returns void
     */
    public ngOnDestroy(): void {
        super.ngOnDestroy();
        this.destroy();
    }

    /** Abstract method to be implemented for exit cleanup in all the concrete component classes
     * @returns void
     */
    protected abstract destroy(): void;
}
