import { Renderer2, OnDestroy, Directive } from '@angular/core';
import { Subscription, Observable } from 'rxjs';
import { first } from 'rxjs/operators';
import { each } from 'lodash-es';

/**
 * This class can be used to some generic functions
 * All classes should inherit this class
 */
@Directive()
// eslint-disable-next-line @angular-eslint/directive-class-suffix
export abstract class HRBGenericBase implements OnDestroy {
    /**
     * Subscription list for observables
     */
    private subscribers: Subscription[] = [];

    /**
     * Handler list for listeners
     */
    private listeners: (() => void)[] = [];

    /** OnDestroy Life cycle method
     * @returns void
     */
    public ngOnDestroy(): void {
        each(this.subscribers, (subscriber: Subscription) => {
            subscriber.unsubscribe();
        });
        this.subscribers = [];
        each(this.listeners, (deListener: () => void) => {
            deListener();
        });
        this.listeners = [];
    }
    /**
     * This function adds a DOM Event listener safely so that we can prevent memory leakage
     * @param renderer Angular Renderer
     * @param target Target HTML Element for event binding
     * @param eventName DOM Event name
     * @param callback Callback handler
     */
    public addSafeListener(renderer: Renderer2, target: HTMLElement | Document, eventName: string, callback: (evt: Event) => void) {
        this.listeners.push(
            renderer.listen(target, eventName, callback)
        );
    }
    /**
     * This function adds a subscription safely to an observable source so that we can prevent memory leakage
     * @param source Source Observable
     * @param callback Callback to be executed on receiving data
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public addSafeSubscriber(source: Observable<any>, callback: (data?: any) => void) {
        this.subscribers.push(
            source.subscribe(callback)
        );
    }

    /**
     * This function creates a one time subscription which will be unsubscribed after single value emit
     * @param source Source Observable
     * @param callback Callback to be executed on receiving data
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public subscribeOnce(source: Observable<any>, callback: (data?: any) => void) {
        this.subscribers.push(
            source.pipe(first())
                .subscribe(callback)
        );
    }

}
