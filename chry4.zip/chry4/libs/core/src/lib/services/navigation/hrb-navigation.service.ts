import { Injectable } from '@angular/core';

import { HRBBaseService } from '../../base-classes';
import { CustomEvents } from '../../utilities';
import { HRBMetaDataManagerService } from '../form-meta';
import { NavigationConstants } from './hrb-navigation.constants';

/**
 * Platform level Service for navigation.
 */
@Injectable({
    providedIn: 'platform'
})
export class HRBNavigationService extends HRBBaseService {

    /** Constructor method */
    constructor(private metaDataService: HRBMetaDataManagerService) {
        super();
    }

    /** Navigate to routes */
    public navigate({ direction, route, screen }: { direction?: NavigationConstants, route?: string, screen?: string }) {
        let target: string[];
        if (direction) {
            route = this.metaDataService.currentMetaData?.[screen]?.navigation?.[direction];
        }
        if (route?.includes('/')) {
            target = route?.split('/');
        }
        const event = new CustomEvent(CustomEvents.RouteChange, { detail: { route: target } });
        document.dispatchEvent(event);
    }
    /** Dummy destroy */
    protected destroy(): void { }

}
