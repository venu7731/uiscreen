import { Injectable } from '@angular/core';

import { HRBBaseService } from '../../../base-classes';
import { CustomEvents, isMobileOrTablet } from '../../../utilities';
import { HRBMetaDataManagerService } from '../../form-meta';
import { HRBNavigationService } from '../../navigation';
import { NavigationConstants } from '../../navigation/hrb-navigation.constants';
import { HRBOverlayService } from '../../overlay';
import { IHRBCommand } from '../hrb-command.interface';

/**
 * Command for navigation
 */
@Injectable({
    providedIn: 'platform'
})
export class HRBHomeSelectionCommand extends HRBBaseService implements IHRBCommand {

    /** Constructor method */
    constructor(private overlayService: HRBOverlayService, private metaDataService: HRBMetaDataManagerService,
        private navService: HRBNavigationService) {
        super();
    }
    /** Handle navigation to other routes */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public process(params: any): Promise<void> {
        return new Promise((resolve) => {
            if (params?.state) {
                if (params?.state === 'add-w2') {
                    if (isMobileOrTablet) {
                        const screen = this.metaDataService.currentMetaData[params?.screen].navigation[NavigationConstants.Overlay];
                        const event = new CustomEvent(CustomEvents.OverlayOpen, { detail: { screen } });
                        document.dispatchEvent(event);
                        this.overlayService.updateOverlayStatus(true);
                    } else {
                        const screen = this.metaDataService.currentMetaData[params?.screen].navigation[NavigationConstants.Next];
                        this.navService.navigate({ route: screen[params?.state], screen: params?.screen });
                    }
                } else {
                    // TO DO
                }
            }
            resolve();
        });
    }
    /** dummy destroy */
    protected destroy(): void {
    }

}
