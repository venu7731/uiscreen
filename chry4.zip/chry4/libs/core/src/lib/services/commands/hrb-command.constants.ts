import { HRBHomeSelectionCommand } from './implementations/hrb-home-selection-command.service';
import { HRBImportPayrollCommand } from './implementations/hrb-import-payroll-command.service';
import { HRBImportPayrollOnloadCommand } from './implementations/hrb-import-payroll-onload-command.service';
import { HRBNavigationCommand } from './implementations/hrb-navigation-command.service';
import { HRBOnboardingExitCommand } from './implementations/hrb-onboarding-exit-command.service';
import { HRBPayrollProviderCommand } from './implementations/hrb-payroll-provider-command.service';

/** Type of commands */
export enum HRBCommands {
    Navigate = 'navigate',
    OnboardingExit = 'onboarding_exit',
    HomeSelection = 'home_selection',
    GetPayrollProvider = 'get_payroll_provider',
    OnloadImportPayroll = 'onload_import_payroll',
    ImportPayroll = 'import_payroll'
}

/** Command implementations */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const HRBCommandMap = new Map<HRBCommands, any>([
    [HRBCommands.Navigate, HRBNavigationCommand],
    [HRBCommands.OnboardingExit, HRBOnboardingExitCommand],
    [HRBCommands.HomeSelection, HRBHomeSelectionCommand],
    [HRBCommands.GetPayrollProvider, HRBPayrollProviderCommand],
    [HRBCommands.OnloadImportPayroll, HRBImportPayrollOnloadCommand],
    [HRBCommands.ImportPayroll, HRBImportPayrollCommand]
]);