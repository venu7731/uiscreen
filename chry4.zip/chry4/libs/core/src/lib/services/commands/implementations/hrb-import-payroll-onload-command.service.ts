/* eslint-disable @typescript-eslint/no-explicit-any */
import { Injectable } from '@angular/core';
import { first } from 'lodash-es';

import { HRBBaseService } from '../../../base-classes';
import { IHRBCommand } from '../hrb-command.interface';

/**
 * Command for navigation
 */
@Injectable({
    providedIn: 'platform'
})
export class HRBImportPayrollOnloadCommand extends HRBBaseService implements IHRBCommand {

    /** Constructor method */
    constructor() {
        super();
    }
    /** Handle navigation to other routes */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public process(params: any): Promise<any> {
        return new Promise((resolve) => {
            resolve({
                meta: this.createMetadata(params?.props?.meta, params?.data),
                content: this.createContent(params?.props?.content, params?.props?.meta, params?.data)
            });
        });
    }
    /** dummy destroy */
    protected destroy(): void {
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    private createMetadata(meta: any, data: any) {
        const { items } = meta.groups.find(grp => grp.name === 'content');
        const formItem = items.find(item => item.type === 'dynamicForm');
        formItem.items = [];
        formItem.items[0] = [];
        formItem.items[0][0] = data?.authParameterList?.
            filter(element => element.name !== 'TAXYEAR')?.
            map(element => ({
                type: 'Input',
                contentMeta: [
                    {
                        description: 'text'
                    }
                ],
                alias: element.name
            }));
        return meta;
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    private createContent(content: any, meta: any, data: any) {
        const { items } = meta.groups.find(grp => grp.name === 'content');
        const formItem = items.find(itm => itm.type === 'dynamicForm');
        const formName = formItem.contentMeta[0].name;
        const layout: any = first(content[meta.appName][meta.screenName][formName].options);
        const item: any = first(layout.options);
        item.options = data?.authParameterList?.
            filter(element => element.name !== 'TAXYEAR')?.
            map(element => ({
                text: element.description
            }));
        return content;
    }

}
