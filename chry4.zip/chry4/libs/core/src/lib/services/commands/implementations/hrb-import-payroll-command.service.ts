import { Injectable } from '@angular/core';

import { HRBBaseService } from '../../../base-classes';
import { HRBImportPayrollService } from '../../data';
import { IHRBPayrollInfo } from '../../data/hrb-import-payroll.interface';
import { HRBNavigationService } from '../../navigation';
import { IHRBCommand } from '../hrb-command.interface';

/**
 * Command for import payroll
 */
@Injectable({
    providedIn: 'platform'
})
export class HRBImportPayrollCommand extends HRBBaseService implements IHRBCommand {

    /** Constructor method */
    constructor(private navService: HRBNavigationService, private apiService: HRBImportPayrollService) {
        super();
    }
    /** Import payroll */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public process(params: any): Promise<any> {
        const formData = params?.data?.[params?.alias];
        const payload: IHRBPayrollInfo = {
            companyId: formData.companyId,
            fIProfileId: formData.fIProfileId,
            federalEin: formData.federalEin,
            financialInstitutionName: formData.financialInstitutionName,
            taxFormType: formData.taxFormType,
            authData: this.getDynamicData(formData, params?.data)
        };
        return this.apiService.importPayroll(payload)
            .then((data) => {
                this.navService.navigate(params);
                return { data: { [params?.destination]: data } };
            })
            .catch(() => {
                params.direction = 'prev';
                this.navService.navigate(params);
                return {};
            });
    }
    /** dummy destroy */
    protected destroy(): void {
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    private getDynamicData(formData: any, data: any) {
        const returnValue = {};
        data?.authParameterList?.forEach(element => {
            if (element.name === 'TAXYEAR') {
                returnValue[element.name] = formData[element.name];
            } else {
                returnValue[element.name] = formData[element.name].val;
            }
        });
        return returnValue;
    }

}
