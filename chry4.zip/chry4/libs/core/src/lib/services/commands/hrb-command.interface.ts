import { HRBCommands } from './hrb-command.constants';

/**
 * Button Action
 */
export interface IHRBCommandAction {
    /** Type of event */
    type: HRBCommands;
    /** Name of method or prop */
    name: string;
    /** Value of prop */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    value: any;
    /** Params to method */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    params: any;
}

/** Command implementation interface */
export interface IHRBCommand {
    /** Process local command method declaration */
    process(
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        params: any
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
    ): Promise<any>;
}