import { Injectable } from '@angular/core';

import { HRBBaseService } from '../../../base-classes';
import { CustomEvents } from '../../../utilities';
import { HRBMetaDataManagerService } from '../../form-meta';
import { HRBNavigationService } from '../../navigation';
import { NavigationConstants } from '../../navigation/hrb-navigation.constants';
import { HRBOverlayService } from '../../overlay';
import { IHRBCommand } from '../hrb-command.interface';

/**
 * Command for navigation
 */
@Injectable({
    providedIn: 'platform'
})
export class HRBOnboardingExitCommand extends HRBBaseService implements IHRBCommand {

    /** Constructor method */
    constructor(
        private navService: HRBNavigationService, private overlayService: HRBOverlayService,
        private metaDataService: HRBMetaDataManagerService
    ) {
        super();
    }
    /** Handle navigation to other routes */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public process(params: any): Promise<any> {
        let state: string;
        return new Promise((resolve) => {
            if (params?.data[params?.alias]) {
                if (params?.data[params?.alias] === 'instate') {
                    const screen = this.metaDataService.currentMetaData[params?.screen].navigation[NavigationConstants.Popup];
                    const event = new CustomEvent(CustomEvents.PopupOpen, {
                        detail: {
                            screen
                        }
                    });
                    document.dispatchEvent(event);
                    this.overlayService.updatePopupStatus(true);
                } else {
                    state = params?.data[params?.alias];
                    this.navService.navigate({ direction: NavigationConstants.Previous, screen: params?.screen });
                }
            } else {
                this.navService.navigate({ direction: NavigationConstants.Next, screen: params?.screen });
            }
            resolve({ data: { state } });
        });
    }
    /** dummy destroy */
    protected destroy(): void {
    }

}
