import { Injectable } from '@angular/core';
import { size } from 'lodash-es';

import { HRBBaseService } from '../../../base-classes';
import { HRBImportPayrollService } from '../../data';
import { HRBNavigationService } from '../../navigation';
import { HRBReturnStateService } from '../../return-state';
import { IHRBCommand } from '../hrb-command.interface';

/**
 * Command for Get payroll info
 */
@Injectable({
    providedIn: 'platform'
})
export class HRBPayrollProviderCommand extends HRBBaseService implements IHRBCommand {

    /** Constructor method */
    constructor(private navService: HRBNavigationService, private apiService: HRBImportPayrollService,
        private returnState: HRBReturnStateService) {
        super();
    }
    /** Get payroll provider info */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public process(params: any): Promise<any> {
        return this.apiService.getPayrollData(params?.data[params?.alias]?.EIN?.val)
            .then((data) => {
                if (!data?.authParameterList) {
                    return {};
                }
                if (!size(data?.authParameterList)) {
                    params.direction = 'skipimport';
                    this.navService.navigate(params);
                    return {};
                }
                this.navService.navigate(params);
                const returnValue = {
                    data: {
                        [params?.destination]: {
                            federalEin: params?.data[params?.alias]?.EIN?.val,
                            taxFormType: (data?.finInst?.taxFormTypeList)?.[0]?.taxFormType,
                            companyId: data?.finInst?.companyId,
                            fIProfileId: data?.finInst?.profileId,
                            financialInstitutionName: '',
                            ...this.createFormModel(data)
                        },
                        authParameterList: data?.authParameterList
                    }
                };
                return returnValue;
            });
    }
    /** dummy destroy */
    protected destroy(): void {
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    private createFormModel(data: any) {
        const returnValue = {};
        data?.authParameterList?.forEach(element => {
            if (element.name === 'TAXYEAR') {
                returnValue[element.name] = this.returnState.getTaxReturnState().taxYear;
            } else {
                returnValue[element.name] = {};
            }
        });
        return returnValue;
    }

}
