/**
 * Constant values used by HTTP Proxy
 */
export const HTTP_CONSTANTS = {
    HttpRequest_Retry_count: 3
};
