import { HttpHeaders } from '@angular/common/http';

/**
 * Http Request interface
 */
export interface IHRBHttpRequest {
    /**
     * Http Request Headers
     */
    headers?: HttpHeaders;
    /**
     * Http Request Body
     */
    body?: object;
    /**
     * Http Request URL Params
     */
    params?: object;
}
