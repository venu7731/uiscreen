import { HttpHandler, HttpInterceptor, HttpRequest, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';

/**
 * HTTP Interceptor base model
 * @export
 */
export class HRBHttpInterceptorHandler implements HttpHandler {
    /**
     * Creates an instance of HRBHttpInterceptorHandler.
     * @param next next Http Handler
     * @param interceptor Http interceptor
     */
    constructor(private next: HttpHandler, private interceptor: HttpInterceptor) { }

    /**
     * Handle http request
     * @param req Http request
     * @returns Observable of HttpEvent
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public handle(req: HttpRequest<any>): Observable<HttpEvent<any>> {
        return this.interceptor.intercept(req, this.next);
    }
}
