import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

import { HRBBaseService } from '../../base-classes';

/**
 * Platform level Service to open overlay/popup
 */
@Injectable({
    providedIn: 'platform'
})
export class HRBOverlayService extends HRBBaseService {
    /** Open overlay?  */
    public onOverlayStatus: Observable<boolean>;
    /** Open popup?  */
    public onPopupStatus: Observable<boolean>;
    /** Overlay status  */
    private overlayStatus$ = new Subject<boolean>();
    /** Popup status  */
    private popupStatus$ = new Subject<boolean>();

    /**
     * Constructor function
     */
    constructor() {
        super();
        this.onOverlayStatus = this.overlayStatus$.asObservable();
        this.onPopupStatus = this.popupStatus$.asObservable();
    }

    /**
     * Push new overlay status to observers
     * @param status boolean
     */
    public updateOverlayStatus(status: boolean) {
        this.overlayStatus$.next(status);
    }
    /**
     * Push new popup status to observers
     * @param status boolean
     */
    public updatePopupStatus(status: boolean) {
        this.popupStatus$.next(status);
    }
    /** Dummy destroy */
    protected destroy(): void { }

}
