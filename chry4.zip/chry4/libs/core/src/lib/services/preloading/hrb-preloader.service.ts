import { Injectable } from '@angular/core';

import { HRBBaseService } from '../../base-classes';

/**
 * Platform level Service to preload resources.
 */
@Injectable({
    providedIn: 'platform'
})
export class HRBPreloaderService extends HRBBaseService {

    private preloadedUrls: string[] = [];
    /**
     * Constructor function
     */
    constructor() {
        super();
    }

    /**
     * Preload the resource
     * @param type Type of resource
     * @param src Souce Url
     */
    public preload(type: string, src: string) {
        if (this.preloadedUrls.includes(src)) {
            return;
        }
        this.preloadedUrls.push(src);
        const linkElement = document.createElement('link');
        linkElement.rel = 'preload';
        linkElement.as = type;
        linkElement.href = src;
        document.head.appendChild(linkElement);
    }

    /** Dummy destroy */
    protected destroy(): void { }

}
