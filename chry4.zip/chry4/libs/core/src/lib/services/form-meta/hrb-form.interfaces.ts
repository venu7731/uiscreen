/** Form Meta */
export interface IHRBFormMeta {
    /** Form sections */
    sections: IHRBFormSection[];
    /** Screen fields */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    screenFields: Record<string, any>;
}

/** Form section */
export interface IHRBFormSection {
    /** Form section name */
    name: string;
    /** Form section groups */
    groups: IHRBFormGroup[];
    /** is visible? or screen field name used for visibility */
    visible?: boolean | string;
}
/** Form group */
export interface IHRBFormGroup {
    /** Form group title */
    title: string;
    /** Form group theme */
    theme?: string;
    /** Form group layouts */
    layouts: IHRBFormLayout[];
    /** is visible? or screen field name used for visibility */
    visible?: boolean | string;
}
/** Form layout */
export interface IHRBFormLayout {
    /** Form layout size */
    size: string;
    /** Form layout items */
    items: IHRBFormItem[];
    /** is visible? or screen field name used for visibility */
    visible?: boolean | string;
}
/** Form item */
export interface IHRBFormItem {
    /** Form item type */
    type: string;
    /** Form item description */
    description: string;
    /** Form field Alias */
    alias?: string;
    /** button text */
    buttonText?: string;
    /** options */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    options: any[];
    /** is visible? or screen field name used for visibility */
    visible?: boolean | string;
    /** Field name */
    fieldName?: string;
    /** Value for radio button */
    value?: string;
}