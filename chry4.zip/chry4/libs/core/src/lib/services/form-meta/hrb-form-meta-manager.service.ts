import { Injectable } from '@angular/core';
import { each } from 'lodash-es';

import { IHRBFormMeta } from './hrb-form.interfaces';
import { HRBBaseService } from '../../base-classes';
import { HRBHttpProxyService } from '../http/hrb-http-proxy.service';
import { formatData } from './hrb-form.helpers';
import { isMobileOrTablet } from '../../utilities';
import { Devices } from '../device-manager';

/**
 * Platform level Service to share the Content across Micro frontends
 */
@Injectable({
    providedIn: 'platform'
})
export class HRBMetaDataManagerService extends HRBBaseService {

    /** Screen field location */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public screenFieldLocations: any = {};
    /** Meta data */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public currentMetaData: any = {};
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    private screenFields: Record<string, any>;
    /**
     * Constructor function
     */
    constructor(
        private httpService: HRBHttpProxyService
    ) {
        super();
    }
    /** Get Form meta */
    public getFormMeta(appName: string, formName: string) {
        const device = isMobileOrTablet ? Devices.Mobile : Devices.Desktop;
        return this.httpService.get(`/api/form-meta/get/${device}/${appName}/${formName}`).toPromise()
            .then((data: IHRBFormMeta) => {
                this.screenFields = data.screenFields;
                this.createScreenFieldLocationMap();
                return formatData(data, { screenFields: this.screenFields, screenFieldLocations: this.screenFieldLocations });
            });
    }

    /** Get page meta */
    public getMetaData(appName: string, screenName: string) {
        const device = isMobileOrTablet ? Devices.Mobile : Devices.Desktop;
        const url = `/api/form-meta/get/${device}/${appName}/${screenName}`;
        return this.httpService.get(url).toPromise().then((data) => {
            this.currentMetaData[screenName] = data;
            return data;
        });
    }

    /** Dummy destroy */
    protected destroy(): void { }

    private createScreenFieldLocationMap() {
        each(this.screenFields, (val, key) => {
            this.screenFieldLocations[key] = { hide: [], show: [] };
        });
    }
}
