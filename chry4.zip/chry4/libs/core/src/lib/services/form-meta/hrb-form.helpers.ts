import { IHRBFormMeta, IHRBFormSection, IHRBFormGroup, IHRBFormLayout } from './hrb-form.interfaces';

/** Format Section */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function formatData(data: IHRBFormMeta, { screenFields, screenFieldLocations }: any) {
    data.sections.forEach((section, index, list) => {
        if (section.visible) {
            const entries: string[] = (section.visible as string).includes('&&') ? (section.visible as string).split(' && ') :
                [section.visible as string];
            for (const entry of entries) {
                if (entry.startsWith('!')) {
                    screenFieldLocations[entry.substring(1)].hide.push({ section: index });
                    list[index].visible = !!list[index].visible && !screenFields[entry.substring(1)];
                } else {
                    screenFieldLocations[entry].show.push({ section: index });
                    list[index].visible = !!list[index].visible && screenFields[entry];
                }
            }
        } else {
            list[index].visible = true;
        }
        list[index] = formatGroup(section, { section: index }, { screenFields, screenFieldLocations });
    });
    return data;
}

/** Format Group */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function formatGroup(data: IHRBFormSection, { section }, { screenFields, screenFieldLocations }: any) {
    data.groups.forEach((group, index, list) => {
        if (group.visible) {
            const entries: string[] = (group.visible as string).includes('&&') ? (group.visible as string).split(' && ') :
                [group.visible as string];
            for (const entry of entries) {
                if (entry.startsWith('!')) {
                    screenFieldLocations[entry.substring(1)].hide.push({ section, group: index });
                    list[index].visible = !!list[index].visible && !screenFields[entry.substring(1)];
                } else {
                    screenFieldLocations[entry].show.push({ section, group: index });
                    list[index].visible = !!list[index].visible && screenFields[entry];
                }
            }
        } else {
            list[index].visible = true;
        }
        list[index] = formatLayout(group, { section, group: index }, { screenFields, screenFieldLocations });
    });
    return data;
}

/** Format Layout */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function formatLayout(data: IHRBFormGroup, { section, group }, { screenFields, screenFieldLocations }: any) {
    data.layouts.forEach((layout, index, list) => {
        if (layout.visible) {
            const entries: string[] = (layout.visible as string).includes('&&') ? (layout.visible as string).split(' && ') :
                [layout.visible as string];
            for (const entry of entries) {
                if (entry.startsWith('!')) {
                    screenFieldLocations[entry.substring(1)].hide.push({ section, group, layout: index });
                    list[index].visible = !!list[index].visible && !screenFields[entry.substring(1)];
                } else {
                    screenFieldLocations[entry].show.push({ section, group, layout: index });
                    list[index].visible = !!list[index].visible && screenFields[entry];
                }
            }
        } else {
            list[index].visible = true;
        }
        list[index] = formatItem(layout, { section, group, layout: index }, { screenFields, screenFieldLocations });
    });
    return data;
}

/** Format Item */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function formatItem(data: IHRBFormLayout, { section, group, layout }, { screenFields, screenFieldLocations }: any) {
    data.items.forEach((item, index, list) => {
        if ((item.visible as string)) {
            const entries: string[] = (item.visible as string).includes('&&') ? (item.visible as string).split(' && ') :
                [item.visible as string];
            for (const entry of entries) {
                if (entry.startsWith('!')) {
                    screenFieldLocations[entry.substring(1)].hide.push({ section, group, layout, item: index });
                    list[index].visible = !!list[index].visible && !screenFields[entry.substring(1)];
                } else {
                    screenFieldLocations[entry].show.push({ section, group, layout, item: index });
                    list[index].visible = !!list[index].visible && screenFields[entry];
                }
            }
        } else {
            list[index].visible = true;
        }
    });
    return data;
}
