/** Device types */
export const Devices = {
    Desktop: 'desktop',
    Mobile: 'mobile'
};