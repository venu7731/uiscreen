import { TestBed } from '@angular/core/testing';

import { isMobileOrTablet } from '../../utilities';
import { HRBStateManagerService } from '../state/hrb-state-manager.service';
import { HRBDeviceManagerService } from './hrb-device-manager.service';
describe('HRBDeviceManagerService', () => {
    let service: HRBDeviceManagerService;
    beforeEach(async () => {
        await TestBed.configureTestingModule({
            providers: [HRBDeviceManagerService, HRBStateManagerService]
        });
        service = TestBed.inject(HRBDeviceManagerService);
    });

    afterAll(async () => {
        service.ngOnDestroy();
    });
    it('should create the service', () => {
        expect(service).toBeDefined();
    });
    it('should emit device state', () => {
        const stateService = TestBed.inject(HRBStateManagerService);
        const spy = spyOn(stateService, 'emitDeviceState');
        service.init();
        expect(spy).toHaveBeenCalledWith(isMobileOrTablet);
    });
});
