/**
 * Save data interface
 */
export interface IHRBSaveData {
    /** Save Entity */
    Entity: IHRBSaveEntity;
    /** Changed properties */
    ChangedProperties: string[];
}
/**
 * Save entity interface
 */export interface IHRBSaveEntity {
    /** type of entity */
    $type: string;
    /** Entity State */
    EntityState: HRBEntityState;
    /** Other field properties */
    [x: string]: IHRBEntityModel | string | string[];
}

/**
 * Entity States
 */
export enum HRBEntityState {
    Added = 'Added',
    Modified = 'Modified',
    Deleted = 'Deleted',
    Unchanged = 'Unchanged'
}

/**
 * Entity model
 */
export interface IHRBEntityModel {
    /** dtl */
    dtl: boolean;
    /** prf */
    prf: boolean;
    /** prev val */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    pval: any;
    /** val */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    val: any;
}
