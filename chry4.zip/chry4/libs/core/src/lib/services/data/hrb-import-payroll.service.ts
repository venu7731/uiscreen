import { Injectable } from '@angular/core';
import { first } from 'lodash-es';

import { HRBBaseService } from '../../base-classes';
import { HRBHttpProxyService } from '../http/hrb-http-proxy.service';
import { IHRBPayrollInfo } from './hrb-import-payroll.interface';

/** Data service */
@Injectable({
    providedIn: 'platform'
})
export class HRBImportPayrollService extends HRBBaseService {

    /**
     * Constructor method
     * @param http Http
     */
    constructor(
        private http: HRBHttpProxyService
    ) {
        super();
    }
    /** Get payroll provider data */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public getPayrollData(ein: string): Promise<any> {
        return this.http.post(`/shared/payrollImport/providerinfo?EIN=${ein}&companyId=&providerId=`, {}).toPromise();
    }

    /** Get payroll provider data */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public importPayroll(payload: IHRBPayrollInfo): Promise<any> {
        return this.http.post('/shared/payrollImport/w2info', payload).toPromise()
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            .then((data: any[]) => first(data))
            .catch(() => null);
    }

    /** Dummy destroy */
    protected destroy(): void {
    }
}