/** Payroll payload interface */
export interface IHRBPayrollInfo {
    /** Federal EIN */
    federalEin: string;
    /** Tax form type */
    taxFormType: string;
    /** Company id */
    companyId: string;
    /** Financial profile id */
    fIProfileId: string;
    /** Financial institute name */
    financialInstitutionName: string;
    /** Auth data */
    authData: Record<string, string>;
}