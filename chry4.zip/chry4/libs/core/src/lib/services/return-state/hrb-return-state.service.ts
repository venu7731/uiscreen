import { Injectable } from '@angular/core';

import { HRBBaseService } from '../../base-classes';
import { IHRBTaxReturnState } from './hrb-tax-return-state.interface';

/**
 * The state of the tax return is stored in this service
 */
@Injectable({
    providedIn: 'platform'
})
export class HRBReturnStateService extends HRBBaseService {

    private taxReturnState: Partial<IHRBTaxReturnState> = {};

    /** Creates an instance of HRBReturnStateService */
    constructor() {
        super();
    }

    /** Sets the current tab clicked from vertical navigation
     * @param taxGroup Tax Group ('FEDERAL', '${STATENAME}')
     */
    public setTaxGroup(taxGroup: string) {
        this.taxReturnState.taxGroup = taxGroup.toUpperCase().split(' ').join('_');
    }

    /** Sets the return state
     * @param returnState Tax Return State
     */
    public setTaxReturnState(returnState: Partial<IHRBTaxReturnState>) {
        this.taxReturnState = { ...this.taxReturnState, ...returnState };
    }

    /** Get the return state
     * @returns IHRBTaxReturnState
     */
    public getTaxReturnState(): Partial<IHRBTaxReturnState> {
        return this.taxReturnState;
    }

    /**
     * OnDestroy life cycle method, called when service is destroyed
     */
    protected destroy(): void {
        this.taxReturnState = null;
    }
}
