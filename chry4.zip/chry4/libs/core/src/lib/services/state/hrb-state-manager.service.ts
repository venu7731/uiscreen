import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

import { HRBBaseService } from '../../base-classes';

/**
 * Platform level Service to share the State across Micro frontends
 */
@Injectable({
    providedIn: 'platform'
})
export class HRBStateManagerService extends HRBBaseService {

    /** CDN Url */
    public cdnUrl: string;
    /** Bootstrap Micro app details */
    public bootstrap: Record<string, string> = {};

    /** Content data source as an observable  */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public onContentUpdated: Observable<any>;
    /** Device data source as an observable  */
    public onDeviceUpdated: Observable<boolean>;
    /** Content data source with initial state as {}  */
    private contentSource$ = new BehaviorSubject(null);
    /** Device data source with initial state as {}  */
    private deviceSource$ = new BehaviorSubject(false);

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    private content: any = {};
    /**
     * Constructor function
     */
    constructor() {
        super();
        this.onContentUpdated = this.contentSource$.asObservable();
        this.onDeviceUpdated = this.deviceSource$.asObservable();
    }

    /**
     * Push new content to observers
     * @param data State
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public emitContentState(data: any) {
        this.content = { ...this.content, ...data };
        this.contentSource$.next(this.content);
    }
    /**
     * Push new device info to observers
     * @param data State
     */
    public emitDeviceState(data: boolean) {
        this.deviceSource$.next(data);
    }
    /** Dummy destroy */
    protected destroy(): void { }

}
