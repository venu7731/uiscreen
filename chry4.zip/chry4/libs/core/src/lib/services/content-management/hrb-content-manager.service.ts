import { Injectable } from '@angular/core';
import { each } from 'lodash-es';

import { IHRBContent, IHRBScreen, IHRBContentElement } from './hrb-content.interface';
import { HRBBaseService } from '../../base-classes';
import { HRBHttpProxyService } from '../http/hrb-http-proxy.service';
import { HRBPreloaderService } from '../preloading/hrb-preloader.service';
import { HRBStateManagerService } from '../state/hrb-state-manager.service';

/**
 * Platform level Service to share the Content across Micro frontends
 */
@Injectable({
    providedIn: 'platform'
})
export class HRBContentManagerService extends HRBBaseService {

    /**
     * Constructor function
     */
    constructor(
        private httpService: HRBHttpProxyService,
        private stateManager: HRBStateManagerService,
        private preloader: HRBPreloaderService
    ) {
        super();
    }
    /** Initialize the service */
    public init(appName: string) {
        this.addSafeSubscriber(this.httpService.get(`/api/content/get/${appName}`), (data) => {
            this.stateManager.emitContentState(this.formatData(data));
        });
    }
    /** Dummy destroy */
    protected destroy(): void { }

    private formatData(data: IHRBContent) {
        return {
            [data.app]: this.formatScreens(data.screens)
        };
    }

    private formatScreens(data: IHRBScreen[]) {
        const formattedScreens = {};
        data.forEach((screen) => {
            formattedScreens[screen.name] = this.formatElements(screen.elements);
        });
        return formattedScreens;
    }

    private formatElements(data: IHRBContentElement[]) {
        const formattedElements = {};
        data.forEach((element) => {
            element.states.forEach((state) => {
                each(state, (val, key, obj) => {
                    if (key.toLowerCase().includes('imgurl')) {
                        if (obj[key]) {
                            obj[key] = `${this.stateManager.cdnUrl}${obj[key]}`;
                            this.preloader.preload('image', obj[key]);
                        }
                    }
                });
                let name = element.name;
                if (state.state) {
                    name = `${name}-${state.state}`;
                }
                formattedElements[name] = {};
                Object.keys(state).forEach((key) => {
                    formattedElements[name][key] = state[key];
                });
            });
        });
        return formattedElements;
    }
}
