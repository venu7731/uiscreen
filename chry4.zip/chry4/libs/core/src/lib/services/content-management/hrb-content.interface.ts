/**
 * Content
 */
export interface IHRBContent {
    /** App name */
    app: string;
    /** Screen list */
    screens: IHRBScreen[];
}
/**
 * Screen info
 */
export interface IHRBScreen {
    /** Screen name */
    name: string;
    /** Screen theme */
    theme?: string;
    /** Screen duration */
    duration?: number;
    /** Screen element list */
    elements: IHRBContentElement[];
}
/**
 * Screen Element info
 */
export interface IHRBContentElement {
    /** Screen element name */
    name: string;
    /** Screen element state list */
    states: IHRBElementState[]
}
/**
 * Screen Element State info
 */
export interface IHRBElementState {
    /** Screen element state */
    state: string;
    /** Screen element text */
    text: string;
    /** Screen element theme */
    theme: string;
    /** Screen element image url */
    imgUrl: string;
}
