import { each, isUndefined } from 'lodash-es';

import { IHRBFormMeta } from '../services';

/** Set visibility flags in meta */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function setVisibility({ name, value }: { name: string, value: any }, screenFieldLocations: any, metaData: IHRBFormMeta) {
    const { hide: hideLocations, show: showLocations } = screenFieldLocations[name];
    setLocations(hideLocations, metaData, !value);
    setLocations(showLocations, metaData, value);
}

/** Set visibility flags based on locations utility */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function setLocations(locations: any[], metaData: IHRBFormMeta, value: boolean) {
    if (locations.length) {
        each(locations, (entry) => {
            const { section, group, layout, item } = entry;
            if (!isUndefined(item)) {
                metaData.sections[section].groups[group].layouts[layout].items[item].visible = value;
            } else if (!isUndefined(layout)) {
                metaData.sections[section].groups[group].layouts[layout].visible = value;
            } else if (!isUndefined(group)) {
                metaData.sections[section].groups[group].visible = value;
            } else if (!isUndefined(section)) {
                metaData.sections[section].visible = value;
            }
        });
    }
}