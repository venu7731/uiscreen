/** Regex to evaluate mobile or tablet user agent */
export const isMobileOrTablet =
    typeof window.orientation !== 'undefined' ||
    !!navigator.userAgent.match(/IEMobile/) ||
    !!navigator.userAgent.match(/Android/i) ||
    !!navigator.userAgent.match(/webOS/i) ||
    !!navigator.userAgent.match(/iPhone/i) ||
    !!navigator.userAgent.match(/iPad/i) ||
    !!navigator.userAgent.match(/iPod/i) ||
    !!navigator.userAgent.match(/BlackBerry/i);

/** Media query for ipad/mobile */
export const mobileQuery = '(max-width: 899px)';
/** Media query for desktop */
export const desktopQuery = '(min-width: 900px)';
