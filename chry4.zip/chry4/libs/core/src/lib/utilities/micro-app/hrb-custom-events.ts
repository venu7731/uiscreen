/** Custom Events */
export enum CustomEvents {
    RouteChange = 'routeChange',
    OverlayOpen = 'overlayOpen',
    PopupOpen = 'popupOpen'
}
