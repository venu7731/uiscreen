/**
 * Interface for micro UI config
 * @export
 */
export interface IHRBMicroUIConfig {
    /** Micro App configuration */
    [key: string]: IHRBMicroAppConfig;
}

/**
 * Interface for micro app config properties
 * @export
 */
export interface IHRBMicroAppConfig {
    /**
     * name of micro app
     */
    name: string;
    /**
     * path of micro app js
     */
    path: string;
    /**
     * app is loaded?
     */
    loaded?: boolean;
    /**
     * path of micro app css
     */
    cssPath?: string;
}