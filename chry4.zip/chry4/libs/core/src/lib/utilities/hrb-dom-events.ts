/**
 * Creates and dispatches a DOM Event
 * @export
 * @param element HTML element or Document
 * @param eventName eventName
 * @param [data] data for event
 * @param [options] options for event
 */

export function sendEvent(element: HTMLElement | Document, eventName: string, data: object = null, options: object = {}) {
    const event = new CustomEvent(eventName, { detail: data, ...options });
    element.dispatchEvent(event);
}
