import { size, each, map, isObject } from 'lodash-es';

import { get } from './hrb-lodash';

/**
 * Formats message replacing {{}} interpolated variables with value
 * @export
 * @param message Input message object
 * @param data Data
 * @returns formatted message object
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function getFormattedMessages(message: string, data?: any): string {
    if (!message) {
        return;
    }
    const dynamicVariables: string[] = map(message.match(/{{[^{}]*}}/gi), msg => msg.replace(/[{}]/g, ''));
    let result = message;
    if (size(dynamicVariables)) {
        each(dynamicVariables, (dyn) => {
            let value = get(data, dyn);
            if (isObject(value)) {
                value = get(data, `${dyn}.val`);
            }
            result = result.replace(new RegExp(`{{${dyn}}}`, 'ig'), value);
        });
    }
    return result;
}
