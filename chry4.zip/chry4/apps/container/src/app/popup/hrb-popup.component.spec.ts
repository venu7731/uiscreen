import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBPopupComponent } from './hrb-popup.component';

describe('HRBPopupComponent', () => {
  let component: HRBPopupComponent;
  let fixture: ComponentFixture<HRBPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBPopupComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
