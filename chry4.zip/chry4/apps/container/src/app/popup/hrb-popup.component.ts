import { ChangeDetectionStrategy, ChangeDetectorRef, Component, NgZone, Renderer2 } from '@angular/core';

import { CustomEvents, HRBBaseComponent, HRBMetaDataManagerService, HRBStateManagerService } from '@chrysalis/core';

/** Popup container */
@Component({
  selector: 'hrb-popup-container',
  templateUrl: './hrb-popup.component.html',
  styleUrls: ['./hrb-popup.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBPopupComponent extends HRBBaseComponent {
  /** Content data */
  public content: unknown;
  /** Meta data */
  public metaData: unknown;
  /** Data */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public data: any = {
    oldAddress: ['4744 Bryant Irvin Rd', 'Fort Worth, TX 76132'],
    newAddress: {
      Address: {},
      ZIPCd: {},
      CityNm: {},
      StateAbbreviationCd: {}
    }
  };
  /**
   * Constructor function
   */
  constructor(private stateManager: HRBStateManagerService,
    private metaDataManager: HRBMetaDataManagerService,
    private renderer: Renderer2,
    cdr: ChangeDetectorRef,
    ngZone: NgZone) {
    super(cdr, ngZone);
  }

  /** Update the data */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public updateData(data: any) {
    this.data = { ...this.data, ...data };
  }
  /** Subscribe to global state  */
  protected async init() {
    this.addSafeSubscriber(this.stateManager.onContentUpdated, (data) => {
      const appName = 'popup';
      if (!data || !data[appName]) {
        return;
      }
      const callback = () => {
        this.content = data;
      };
      this.render(callback);
    });
    const popupCallback = ({ detail }: CustomEvent) => {
      const { screen } = detail;
      const appName = 'popup';
      this.metaDataManager.getMetaData(appName, screen).then((data) => {
        const callback = () => {
          this.metaData = data;
        };
        this.render(callback);
      });
    };
    this.addSafeListener(this.renderer, document, CustomEvents.PopupOpen, popupCallback);

  }

  /** Dummy destroy */
  protected destroy(): void {
  }

}
