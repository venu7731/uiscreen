import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBHomeComponent } from './home.component';

describe('HRBHomeComponent', () => {
  let component: HRBHomeComponent;
  let fixture: ComponentFixture<HRBHomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBHomeComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
