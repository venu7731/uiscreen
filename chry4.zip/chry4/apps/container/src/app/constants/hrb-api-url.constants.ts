/** Api Urls */
export const HRB_API_URLS = {
    SERVER: '',
    CONFIG_URL: '/api/configuration/get',
};