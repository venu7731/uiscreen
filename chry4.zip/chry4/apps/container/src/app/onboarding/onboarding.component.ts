import { ChangeDetectionStrategy, ChangeDetectorRef, Component, NgZone } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { HRBBaseComponent, HRBMicroUIAppManager } from '@chrysalis/core';

import { microApps } from '../micro/config';

/**
 * Onboarding root route
 */
@Component({
  selector: 'hrb-onboarding-root',
  templateUrl: './onboarding.component.html',
  styleUrls: ['./onboarding.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBOnboardingComponent extends HRBBaseComponent {
  /** App loading done */
  public isLoaded = false;
  /** Screen */
  public screen: string;
  /**
   * Constructor method
   * @param cdr Change detector reference
   */
  constructor(cdr: ChangeDetectorRef,
    ngZone: NgZone,
    private route: ActivatedRoute) {
    super(cdr, ngZone);
  }

  /** Load micro UIs */
  protected init(): void {
    this.addSafeSubscriber(this.route.params, (params) => {
      const cb = () => {
        this.screen = params.screen;
      };
      this.render(cb);
    });
    const appManager = new HRBMicroUIAppManager(microApps['hrb-onboarding']);
    const callback = () => {
      this.isLoaded = true;
    };
    appManager.staticLoad().then(() => {
      this.render(callback);
    }).catch();
  }
  /** Dummy destroy */
  protected destroy(): void { }

}
