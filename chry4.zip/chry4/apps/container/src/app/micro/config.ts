import { IHRBMicroUIConfig } from '@chrysalis/core';

/**
 * Config for micro apps
 */
export const microApps: IHRBMicroUIConfig = {
    'hrb-verify-id': {
        name: 'hrb-verify-id',
        path: 'verify-id/main.js',
        cssPath: 'verify-id/styles.css',
        loaded: false
    },
    'hrb-home': {
        name: 'hrb-home',
        path: 'home/main.js',
        cssPath: 'home/styles.css',
        loaded: false
    },
    'hrb-add-w2': {
        name: 'hrb-add-w2',
        path: 'add-w2/main.js',
        cssPath: 'add-w2/styles.css',
        loaded: false
    },
    'hrb-onboarding': {
        name: 'hrb-onboarding',
        path: 'onboarding/main.js',
        cssPath: 'onboarding/styles.css',
        loaded: false
    }
};
