import { Injectable } from '@angular/core';
import { Params } from '@angular/router';
import { first } from 'lodash-es';

import { IHRBLoggerConfiguration, HRBLogger, HRBLogLevel } from '@hrblock-ocap/logger';
import {
    HRBBaseService, HRBHttpProxyService, HRBReturnStateService,
    HRBStateManagerService, HRBUserDetailsService
} from '@chrysalis/core';

import { HRB_API_URLS } from '../constants';

@Injectable({
    providedIn: 'root'
})
export class HRBConfigService extends HRBBaseService {
    constructor(
        private returnState: HRBReturnStateService,
        private userDetailsService: HRBUserDetailsService,
        private http: HRBHttpProxyService,
        private stateManager: HRBStateManagerService
    ) {
        super();
    }

    public setEnvironment() {
        // Hard coding the Default values
        this.returnState.setTaxReturnState({
            returnId: 'a9c1131c-97c1-4cb5-90e7-4cf35a130011',
            taxGroup: 'FD',
            taxSystem: '1040',
            taxYear: 2020
        });
        this.userDetailsService.setUserDetails({
            officeId: '12345',
            taxProId: '2323232'
        });
    }

    /** Route resolver method which is executed before a route is loaded
     * @param route Activated route
     */
    public initializeApp(params: Params) {
        // Get officeId and taxProId from query params
        const { officeId, taxProId } = params;
        return this.loadAppConfig(officeId, taxProId);
    }

    protected destroy(): void {
    }

    /** Get Application config from server
     * @returns empty promise once data received
     */
    private async loadAppConfig(officeId: string, taxProId: string) {
        const url = `${HRB_API_URLS.SERVER + HRB_API_URLS.CONFIG_URL}?officeId=${officeId}&taxProId=${taxProId}`;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const appConfig: any = await this.http.get(url).toPromise();
        const loggerConfig: IHRBLoggerConfiguration = appConfig?.logger ?? {};
        this.initiateLogger(loggerConfig);
        if (appConfig?.app?.cdnUrl) {
            this.stateManager.cdnUrl = appConfig?.app?.cdnUrl;
        } else {
            HRBLogger.error('Unable to find cdnUrl from configuration.');
        }
        const { cdnUrl, bootstrap } = appConfig?.app;
        if (cdnUrl) {
            this.stateManager.cdnUrl = cdnUrl;
        } else {
            HRBLogger.error('Unable to find cdnUrl from configuration.');
        }
        if (bootstrap) {
            this.stateManager.bootstrap = {
                app: bootstrap, screen: first(appConfig?.appDetails[bootstrap])
            };
        } else {
            HRBLogger.error('Unable to find starting Micro App from configuration.');
        }
        return Promise.resolve();
    }

    /** Initiate logger
     * @param logger logger configuration
     */
    private initiateLogger(logger: IHRBLoggerConfiguration) {
        const { logtype, loglevel, appinsights, eventHub } = logger;
        const { taxProId } = this.userDetailsService.getUserDetails();
        const { returnId } = this.returnState.getTaxReturnState();
        HRBLogger.disableTrace = loglevel !== HRBLogLevel.TRACE;
        HRBLogger.init({
            logtype,
            loglevel,
            appinsights,
            eventHub,
            appname: 'Chrysalis UI'
        }, { userId: `${taxProId}` }, { returnId });
    }
}