import {
    ChangeDetectionStrategy, ChangeDetectorRef,
    Component, ElementRef, NgZone, Renderer2, ViewChild
} from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';

import {
    CustomEvents, HRBBaseComponent, HRBContentManagerService, HRBDeviceManagerService,
    HRBOverlayService, HRBStateManagerService, isMobileOrTablet
} from '@chrysalis/core';
import { HRBConfigService } from './services/hrb-configuration.service';

/** Container App */
@Component({
    selector: 'hrb-chrysalis-root',
    templateUrl: './container.component.html',
    styleUrls: ['./container.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class ContainerComponent extends HRBBaseComponent {

    /** Modal reference */
    @ViewChild('modal') public modalRef: ElementRef;
    /** Check if mobile or tablet */
    public isMobile = isMobileOrTablet;

    /**
     * Constructor method
     * @param contentManager Content manager
     * @param cdr Change detector reference
     * @param ngZone NgZone
     */
    constructor(
        private contentManager: HRBContentManagerService,
        private deviceManager: HRBDeviceManagerService,
        cdr: ChangeDetectorRef,
        ngZone: NgZone,
        private renderer: Renderer2,
        private router: Router,
        private route: ActivatedRoute,
        private appConfigService: HRBConfigService,
        private stateManager: HRBStateManagerService,
        private overlayManager: HRBOverlayService
    ) {
        super(cdr, ngZone);
    }

    /** Handle popup closed */
    public popupClosed() {
        this.renderer.removeClass(document.body, 'setoverflow__hidden');

    }
    /** Dummy init */
    protected init(): void {
        const callback = ({ detail }: CustomEvent) => {
            const { route } = detail;
            this.router.navigate(route);
        };
        this.addSafeListener(this.renderer, document, CustomEvents.RouteChange, callback);
        this.addSafeSubscriber(this.overlayManager.onPopupStatus, (status) => {
            if (status) {
                this.renderer.addClass(document.body, 'setoverflow__hidden');
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                (this.modalRef as any).show();
            }
        });
        this.subscribeToUrlParams();
    }
    /** Dummy destroy */
    protected destroy(): void { }

    private subscribeToUrlParams() {
        const callback = async (params: Params) => {
            // TO DO if (!isEmpty(params)) {
            this.appConfigService.setEnvironment();
            await this.appConfigService.initializeApp(params);
            this.contentManager.init('popup');
            this.contentManager.init('overlay');
            this.deviceManager.init();
            const { app, screen } = this.stateManager.bootstrap;
            this.router.navigate([app, screen]);
            // }
        };
        this.addSafeSubscriber(this.route.queryParams, callback);
    }

}
