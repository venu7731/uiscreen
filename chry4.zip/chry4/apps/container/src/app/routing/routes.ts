import { Routes } from '@angular/router';

import { HRBHomeComponent } from '../home/home.component';
import { HRBAddW2Component } from '../add-w2/add-w2.component';
import { HRBVerifyIdComponent } from '../verify-id/verify-id.component';
import { HRBOnboardingComponent } from '../onboarding/onboarding.component';

export const routes: Routes = [
  // TO DO make all the routes accept params
  { path: 'home/:screen', component: HRBHomeComponent },
  { path: 'add-w2/:screen', component: HRBAddW2Component },
  { path: 'verify-id', component: HRBVerifyIdComponent },
  { path: 'onboarding/:screen', component: HRBOnboardingComponent },
  { path: 'pagination', component: HRBOnboardingComponent },
  { path: '', redirectTo: '/onboarding', pathMatch: 'full' },
  { path: '**', component: HRBOnboardingComponent }
];
