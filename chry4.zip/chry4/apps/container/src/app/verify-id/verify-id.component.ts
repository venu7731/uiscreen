import { ChangeDetectionStrategy, ChangeDetectorRef, Component, NgZone } from '@angular/core';

import { HRBBaseComponent, HRBMicroUIAppManager } from '@chrysalis/core';

import { microApps } from '../micro/config';

/**
 * Verify id root route
 */
@Component({
  selector: 'hrb-verify-id-root',
  templateUrl: './verify-id.component.html',
  styleUrls: ['./verify-id.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HRBVerifyIdComponent extends HRBBaseComponent {
  /** App loading done */
  public isLoaded = false;
  /**
   * Constructor method
   * @param cdr Change detector reference
   */
  constructor(cdr: ChangeDetectorRef,
    ngZone: NgZone) {
    super(cdr, ngZone);
  }

  /** Load micro UIs */
  protected init(): void {
    const appManager = new HRBMicroUIAppManager(microApps['hrb-verify-id']);
    const callback = () => {
      this.isLoaded = true;
    };
    appManager.staticLoad().then(() => {
      this.render(callback);
    }).catch();
  }
  /** Dummy destroy */
  protected destroy(): void { }

}
