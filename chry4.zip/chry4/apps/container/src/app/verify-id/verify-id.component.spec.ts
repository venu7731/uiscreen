import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRBVerifyIdComponent } from './verify-id.component';

describe('HRBVerifyIdComponent', () => {
  let component: HRBVerifyIdComponent;
  let fixture: ComponentFixture<HRBVerifyIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HRBVerifyIdComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRBVerifyIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
