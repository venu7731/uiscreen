import { enableProdMode, Injector } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { HttpClient, HttpHandler } from '@angular/common/http';

import { HRBHttpCustomInterceptHandler } from '@chrysalis/core';

import { ContainerModule } from './app/container.module';
import { environment } from './environments/environment';

if (environment.production) {
    enableProdMode();
}

platformBrowserDynamic([
    { provide: HttpClient, useClass: HttpClient, deps: [HttpHandler] },
    { provide: HttpHandler, useClass: HRBHttpCustomInterceptHandler, deps: [Injector] }
])
    .bootstrapModule(ContainerModule, { ngZoneEventCoalescing: true })
    .catch((err) => console.error(err));
