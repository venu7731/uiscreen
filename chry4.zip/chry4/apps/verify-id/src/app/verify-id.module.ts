import { BrowserModule } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, DoBootstrap, Injector, NgModule } from '@angular/core';
import { createCustomElement } from '@angular/elements';

import { CoreModule } from '@chrysalis/core';
import { UiControlsModule } from '@chrysalis/ui-controls';

import { VerifyIdComponent } from './verify-id.component';

@NgModule({
    declarations: [VerifyIdComponent],
    imports: [BrowserModule, CoreModule, UiControlsModule],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VerifyIdModule implements DoBootstrap {

    constructor(private injector: Injector) { }

    /** Hook for manual bootstrapping of the application */
    public ngDoBootstrap() {

        /** Convert Angular component into a custom element */
        const appElement = createCustomElement(VerifyIdComponent, { injector: this.injector });

        /** Define custom element tag */
        const customElementTag = 'hrb-verify-id';

        /** Verify if custom element is already present in the customElementRegistry */
        if (!customElements.get(customElementTag)) {
            /** Define a new custom element */
            customElements.define(customElementTag, appElement);
        }
    }

}
