/** App name */
export const appName = 'add-w2';
/** Form name */
export const formName = 'AO_TXW2';
