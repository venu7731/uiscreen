/** Screen name */
export const screenName = 'manual_entry';

/** States for footer button */
export const States = {
    Normal: 'normal',
    Final: 'final'
};

/** Current step in W2 */
export const currentStep = 'Add W-2';
/** Footer button prefix */
export const footerButtonsPrefix = 'footer_buttons';
