import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, NgZone } from '@angular/core';

import {
    HRBBaseComponent, HRBCommandManagerService, HRBContentManagerService,
    HRBMetaDataManagerService, HRBStateManagerService
} from '@chrysalis/core';
import { size } from 'lodash-es';

import { appName } from './constants';

/** Add W2 root component */
@Component({
    selector: 'hrb-add-w2',
    templateUrl: './add-w2.component.html',
    styleUrls: ['./add-w2.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AddW2Component extends HRBBaseComponent {
    /** Screen name */
    @Input() public set screen(val: string) {
        if (val) {
            this.metaDataManager.currentMetaData = {};
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            this.metaDataManager.getMetaData(appName, val).then(async (payload: any) => {
                let callback;
                if (payload?.onload) {
                    if (size(payload.onload)) {
                        const result = await this.commandManager.execute(payload.onload,
                            this.data, { meta: payload, content: this.content });
                        callback = () => {
                            const { data, meta, content } = result;
                            if (meta) {
                                this.metaData = { ...meta };
                            }
                            if (content) {
                                this.content = { ...content };
                            }
                            if (data) {
                                this.data = { ...data };
                            }
                        };
                    }
                } else {
                    callback = () => {
                        this.metaData = payload;
                    };
                }
                this.render(callback);
            });
        }
    }
    /** Content data */
    public content: unknown;
    /** Meta data */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public metaData: any;
    /** Data */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public data: any = {
        progressPercent: 33,
        EINForm: {
            EIN: {}
        }
    };
    /**
     * Constructor function
     */
    constructor(private stateManager: HRBStateManagerService,
        private metaDataManager: HRBMetaDataManagerService,
        private contentManager: HRBContentManagerService,
        private commandManager: HRBCommandManagerService,
        cdr: ChangeDetectorRef,
        ngZone: NgZone) {
        super(cdr, ngZone);
    }

    /** Update the data */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public updateData(data: any) {
        this.data = { ...this.data, ...data };
    }
    /** Subscribe to global state  */
    protected async init() {
        this.contentManager.init(appName);
        this.addSafeSubscriber(this.stateManager.onContentUpdated, (data) => {
            if (!data || !data[appName]) {
                return;
            }
            const callback = () => {
                this.content = data;
            };
            this.render(callback);
        });
    }

    /** Dummy destroy */
    protected destroy(): void {
    }

}
