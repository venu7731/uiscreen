import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { AddW2Component } from './add-w2.component';

describe('AddW2Component', () => {
  let component: AddW2Component;
  let fixture: ComponentFixture<AddW2Component>;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AddW2Component],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
      .compileComponents();
    fixture = TestBed.createComponent(AddW2Component);
    component = fixture.componentInstance;
    component.content = { footerIconUrl: '', theme: '', headerText: '' };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

});
