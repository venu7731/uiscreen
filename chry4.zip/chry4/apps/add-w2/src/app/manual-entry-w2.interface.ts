import { IHRBNavBarContent, IHRBTaskContent } from '@chrysalis/ui-controls';

/** Add W2 content */
export interface IHRBAddW2Content {
    /** Task content */
    taskContent: IHRBTaskContent;
    /** Form Header content */
    formHeaderContent: IHRBNavBarContent[];
}