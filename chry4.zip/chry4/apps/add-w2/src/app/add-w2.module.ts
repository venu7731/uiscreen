import { BrowserModule } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, DoBootstrap, Injector, NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { createCustomElement } from '@angular/elements';
import { BdsNgModule } from '@bds/bds-ng';

import { CoreModule } from '@chrysalis/core';
import { UiControlsModule } from '@chrysalis/ui-controls';

import { AddW2Component } from './add-w2.component';

@NgModule({
    declarations: [
        AddW2Component
    ],
    imports: [BrowserModule, BrowserAnimationsModule, CoreModule, UiControlsModule, BdsNgModule],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AddW2Module implements DoBootstrap {

    constructor(private injector: Injector) { }

    /** Hook for manual bootstrapping of the application */
    public ngDoBootstrap() {

        /** Convert Angular component into a custom element */
        const appElement = createCustomElement(AddW2Component, { injector: this.injector });

        /** Define custom element tag */
        const customElementTag = 'hrb-add-w2';

        /** Verify if custom element is already present in the customElementRegistry */
        if (!customElements.get(customElementTag)) {
            /** Define a new custom element */
            customElements.define(customElementTag, appElement);
        }
    }
}
