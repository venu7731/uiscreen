import { ChangeDetectionStrategy, ChangeDetectorRef, Component, NgZone } from '@angular/core';
import { cloneDeep, first } from 'lodash-es';

import {
    desktopQuery, HRBBaseComponent, HRBStateManagerService, mobileQuery,
    HRBMetaDataManagerService, IHRBFormSection, HRBDataService, IHRBFormMeta, setVisibility, HRBContentManagerService
} from '@chrysalis/core';
import { IHRBButtonAction, IHRBNavBarContent, addRowUtil } from '@chrysalis/ui-controls';

import { appName, formName } from './constants/hrb-app.constants';
import { IHRBAddW2Content } from './manual-entry-w2.interface';
import { currentStep, footerButtonsPrefix, screenName, States } from './manual-entry.constants';

/**
 * Add W2 root component
 */
@Component({
    selector: 'hrb-manual-entry',
    templateUrl: './manual-entry-w2.component.html',
    styleUrls: ['./manual-entry-w2.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class ManualEntryComponent extends HRBBaseComponent {
    /** Mobile query */
    public mobileQuery = mobileQuery;
    /** Desktop query */
    public desktopQuery = desktopQuery;
    /** Content */
    public content: IHRBAddW2Content;
    /** current section selected */
    public currentSection: IHRBFormSection;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public data: any;

    private metaData: IHRBFormMeta;
    private state = States.Normal;
    private currentSectionIndex = 0;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    private originalContent: any;
    private footerButtonActionMap = new Map([
        [0, this.saveState.bind(this)],
        [1, this.saveLater.bind(this)]
    ]);

    /**
     * Constructor method
     * @param cdr Change detector reference
     * @param ngZone NgZone
     * @param stateManager State manager
     * @param formMetaService Form meta service
     */
    constructor(
        protected cdr: ChangeDetectorRef, ngZone: NgZone, private stateManager: HRBStateManagerService,
        private contentManager: HRBContentManagerService,
        private formMetaService: HRBMetaDataManagerService, private dataService: HRBDataService) {
        super(cdr, ngZone);
        this.addSafeSubscriber(this.stateManager.onDeviceUpdated, async () => {
            this.metaData = await this.formMetaService.getFormMeta(appName, formName);
            this.currentSection = this.metaData.sections[0];
            cdr.markForCheck();
        });
        this.contentManager.init(appName);
    }
    /**
     * Select a Form Section
     * @param idx Index
     */
    public selectFormSection(idx: number) {
        this.currentSectionIndex = idx;
        this.refreshContents();
    }
    /**
     * Perform button action
     * @param idx Index of clicked button
     */
    public buttonAction(idx: number) {
        this.footerButtonActionMap.get(idx)();
    }
    /**
     * Perform button action
     * @param action of clicked button
     */
    public handleButtonClick(actions: IHRBButtonAction[]) {
        const action = first(actions);
        this[action.name](action.params);
    }
    /** Get content data and pass it to child components */
    protected async init() {
        this.addSafeSubscriber(this.stateManager.onContentUpdated, (data) => {
            if (!data || !data[appName]) {
                return;
            }
            this.originalContent = data;
            const callback = () => {
                // set the current tab as selected
                const currentTab: IHRBNavBarContent =
                    data[appName][screenName]?.navbar_header?.options?.find(item => item.text === currentStep);
                currentTab.isSelected = true;
                // set the first form section as selected
                data[appName][screenName].form_nav_header.options[0].isSelected = true;
                const content: IHRBAddW2Content = {
                    taskContent: {
                        headerContent: data[appName][screenName].navbar_header.options,
                        progressContent: data[appName][screenName].progress_circle,
                        pageTitle: data[appName][screenName].page_title.text,
                        footerButtons: data[appName][screenName][`${footerButtonsPrefix}-${this.state}`].options
                    },
                    formHeaderContent: data[appName][screenName].form_nav_header.options
                };
                this.content = cloneDeep(content);
            };
            this.render(callback);
        });
        const formId = '25a1a9e1-c2d8-4a23-8968-3d68314fee20';
        const mappingFormIds = 'FormW2#af7599e1-fd29-4121-a7a3-229ccfa5faed';
        const formData = await this.dataService.getFormData(
            formName, formId, mappingFormIds
        );
        this.data = formData[`${formName}:${formId}`];
        this.cdr.detectChanges();
    }
    /** Dummy destroy */
    protected destroy(): void {
    }
    /**
     * Add a new row in grid
     * Do not remove this, method. This is called dynamically from the Form Button actions in Form JSON
     * @param params Button Action params
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    protected addRow(params: any) {
        addRowUtil(this.currentSection, this.data, params, formName);
    }
    /**
     * Add a new row in grid
     * Do not remove this, method. This is called dynamically from the Form Button actions in Form JSON
     * @param params Button Action params
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    protected importPayroll() {
        // TO DO
    }
    /**
     * Sets visibility dynamically
     * Do not remove this, method. This is called dynamically from the Form Button actions in Form JSON
     * @param params Button Action params
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    protected setVisibility(params: any) {
        setVisibility(params, this.formMetaService.screenFieldLocations, this.metaData);
    }
    private goToNextSection() {
        this.content.formHeaderContent[this.currentSectionIndex].isSelected = false;
        this.content.formHeaderContent[++this.currentSectionIndex].isSelected = true;
        this.refreshContents();
    }

    private refreshContents() {
        this.currentSection = this.metaData.sections[this.currentSectionIndex];
        this.state = this.currentSectionIndex === this.metaData.sections.length - 1 ? States.Final : States.Normal;
        this.content.taskContent.footerButtons = this.originalContent[appName][screenName][`${footerButtonsPrefix}-${this.state}`].options;
        this.content = cloneDeep(this.content);
    }
    private saveState() {
        if (this.state === States.Final) {
            this.saveAndReview();
        } else {
            this.goToNextSection();
        }
    }

    private saveAndReview() {
        const formId = '25a1a9e1-c2d8-4a23-8968-3d68314fee20';
        const mappingFormIds = 'FormW2#af7599e1-fd29-4121-a7a3-229ccfa5faed';
        this.dataService.saveData(formName, formId, mappingFormIds);
    }

    private saveLater() {
        const formId = '25a1a9e1-c2d8-4a23-8968-3d68314fee20';
        const mappingFormIds = 'FormW2#af7599e1-fd29-4121-a7a3-229ccfa5faed';
        this.dataService.saveData(formName, formId, mappingFormIds);
    }

}
