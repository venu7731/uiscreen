import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AddW2Module } from './app/add-w2.module';
import { environment } from './environments/environment';

if (environment.production) {
    try {
        enableProdMode();
    } catch (err) {
        console.log('Production mode already enabled in container app');
    }
}

platformBrowserDynamic()
    .bootstrapModule(AddW2Module, { ngZoneEventCoalescing: true })
    .catch((err) => console.error(err));
