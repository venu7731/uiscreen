import { parse, join, normalize } from 'path';
import { readdirSync } from 'fs';

const diskdb = require('diskdb');

export function formMetaRoute(req, res) {
    const { device, app, screen } = req.params;
    const db = getFile({ device, app });
    const node = screen;
    if (!db[node]) {
        return res.json(null);
    }
    return res.json(db[node].find());
}

function getFile({ device, app }) {
    let rootDir = join(__dirname, '../../../apps/local-server', 'src', 'assets', 'form-meta', device, app);
    rootDir = normalize(rootDir);
    const allFiles = readdirSync(rootDir).map((file) => {
        return parse(file).name;
    });
    return diskdb.connect(rootDir, allFiles);
}