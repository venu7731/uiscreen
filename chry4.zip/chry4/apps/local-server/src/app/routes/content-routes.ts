import { parse, join, normalize } from 'path';
import { readdirSync } from 'fs';

const diskdb = require('diskdb');

export function contentRoute(req, res) {
    const { app } = req.params;
    const db = getFile({ app });
    const node = 'content';
    if (!db[node]) {
        return res.json(null);
    }
    return res.json(db[node].find());
}

function getFile({ app }) {
    let rootDir = join(__dirname, '../../../apps/local-server', 'src', 'assets', 'content', app);
    rootDir = normalize(rootDir);
    const allFiles = readdirSync(rootDir).map((file) => {
        return parse(file).name;
    });
    return diskdb.connect(rootDir, allFiles);
}