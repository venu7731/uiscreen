/**
 * This is not a production server yet!
 * This is only a minimal backend to get started.
 */

import * as express from 'express';
import { join } from 'path';

import { contentRoute } from './app/routes/content-routes';
import { formMetaRoute } from './app/routes/form-routes';
import { configRoute } from './app/routes/config-route';

const app = express();
app.use('/assets', express.static(join(__dirname, 'assets')));

app.get('/api', (req, res) => {
    res.send({ message: 'Welcome to local-server!' });
});

app.get('/api/content/get/:app', contentRoute);
app.get('/api/form-meta/get/:device/:app/:screen', formMetaRoute);
app.get('/api/configuration/get', configRoute);

const port = process.env.port || 9500;
const server = app.listen(port, () => {
    console.log(`Listening at http://localhost:${port}/api`);
});
server.on('error', console.error);
