import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { HomeModule } from './app/home.module';
import { environment } from './environments/environment';

if (environment.production) {
    try {
        enableProdMode();
    } catch (err) {
        console.log('Production mode already enabled in container app');
    }
}

platformBrowserDynamic()
    .bootstrapModule(HomeModule, { ngZoneEventCoalescing: true })
    .catch((err) => console.error(err));
