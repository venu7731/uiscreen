import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, NgZone } from '@angular/core';

import { HRBBaseComponent, HRBContentManagerService, HRBMetaDataManagerService, HRBStateManagerService } from '@chrysalis/core';

import { appName } from './constants/hrb-app.constants';

/** OnBoarding Interstitial root component */
@Component({
    selector: 'hrb-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HomeComponent extends HRBBaseComponent {
    /** Screen name */
    @Input() public set screen(val: string) {
        if (val) {
            this.metaDataManager.currentMetaData = {};
            this.metaDataManager.getMetaData(appName, val).then((data) => {
                const callback = () => {
                    this.metaData = data;
                };
                this.render(callback);
            });
        }
    }
    /** Content data */
    public content: unknown;
    /** Meta data */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public metaData: any;
    /** Data */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public data: any = {
        refundAmount: 10,
        primaryCardState: 'confirm-status',
        secondaryCardState: 'draft',
        progressPercent: 33
    };
    /**
     * Constructor function
     */
    constructor(private stateManager: HRBStateManagerService,
        private metaDataManager: HRBMetaDataManagerService,
        private contentManager: HRBContentManagerService,
        cdr: ChangeDetectorRef,
        ngZone: NgZone) {
        super(cdr, ngZone);
    }

    /** Update the data */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public updateData(data: any) {
        this.data = { ...this.data, ...data };
    }
    /** Subscribe to global state  */
    protected async init() {
        this.contentManager.init(appName);
        this.addSafeSubscriber(this.stateManager.onContentUpdated, (data) => {
            if (!data || !data[appName]) {
                return;
            }
            const callback = () => {
                this.content = data;
            };
            this.render(callback);
        });
    }

    /** Dummy destroy */
    protected destroy(): void {
    }

}
