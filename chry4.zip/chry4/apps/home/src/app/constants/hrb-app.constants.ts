/** App name */
export const appName = 'home';