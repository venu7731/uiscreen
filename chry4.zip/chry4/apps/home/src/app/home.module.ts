import { BrowserModule } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, DoBootstrap, Injector, NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { createCustomElement } from '@angular/elements';
import { BdsNgModule } from '@bds/bds-ng';

import { CoreModule } from '@chrysalis/core';
import { UiControlsModule } from '@chrysalis/ui-controls';

import { HomeComponent } from './home.component';

@NgModule({
    declarations: [
        HomeComponent
    ],
    imports: [BrowserModule, BrowserAnimationsModule, CoreModule, UiControlsModule, BdsNgModule],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class HomeModule implements DoBootstrap {

    constructor(private injector: Injector) { }

    /** Hook for manual bootstrapping of the application */
    public ngDoBootstrap() {

        /** Convert Angular component into a custom element */
        const appElement = createCustomElement(HomeComponent, { injector: this.injector });

        /** Define custom element tag */
        const customElementTag = 'hrb-home';

        /** Verify if custom element is already present in the customElementRegistry */
        if (!customElements.get(customElementTag)) {
            /** Define a new custom element */
            customElements.define(customElementTag, appElement);
        }
    }
}
