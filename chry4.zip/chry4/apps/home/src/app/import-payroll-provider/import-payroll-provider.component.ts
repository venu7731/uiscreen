import { Component } from '@angular/core';
import { desktopQuery, HRBBaseComponent, mobileQuery } from '@chrysalis/core';

@Component({
    selector: 'hrb-import-payroll-provider',
    templateUrl: './import-payroll-provider.component.html',
    styleUrls: ['./import-payroll-provider.component.scss']
})
export class ImportPayrollProviderComponent extends HRBBaseComponent {
    /** Content */
    /** Desktop media query */
    public desktopQuery = desktopQuery;
    /** Mobile media query */
    public mobileQuery = mobileQuery;
    /** Dummy init */
    protected init(): void {}
    /** Dummy destroy */
    protected destroy(): void {}
}
