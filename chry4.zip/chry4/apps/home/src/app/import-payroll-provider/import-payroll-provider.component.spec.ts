import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportPayrollProviderComponent } from './import-payroll-provider.component';

describe('ImportPayrollProviderComponent', () => {
  let component: ImportPayrollProviderComponent;
  let fixture: ComponentFixture<ImportPayrollProviderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ImportPayrollProviderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportPayrollProviderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
