module.exports = {
    projects: [
        '<rootDir>/apps/container',
        '<rootDir>/apps/verify-id',
        '<rootDir>/libs/core',
        '<rootDir>/libs/ui-controls',
        '<rootDir>/apps/local-server',
        '<rootDir>/apps/home',
        '<rootDir>/apps/add-w2',
        '<rootDir>/apps/onboarding'
    ]
};
